var BREAKPOINTS = require('*/cartridge/config/imageTransformations');
var Image = require('dw/experience/image/Image');
var MediaFile = require('dw/content/MediaFile');
var URLUtils = require('dw/web/URLUtils');

var transformationCapabilities = [
    'scaleWidth',
    'scaleHeight',
    'scaleMode',
    'imageX',
    'imageY',
    'imageURI',
    'cropX',
    'cropY',
    'cropWidth',
    'cropHeight',
    'format',
    'quality',
    'strip'
];

function constructTransformationObject(options, transform) {
    var result = transform || {};
    Object.keys(options).forEach(function (element) {
        if (transformationCapabilities.indexOf(element)) {
            result[element] = options[element];
        }
    });
    return result;
}

function scale (device, context) {
    var transformObj = null;
    try {
        var targetDims = context && BREAKPOINTS[context] && BREAKPOINTS[context][device] ?
            BREAKPOINTS[context][device] :
            BREAKPOINTS['default'][device];
    }
    catch (e) {
        // Something went wrong and we can't block.
        var targetDims = {
            width: 1000,
            height: 1000
        }
    }
    transformObj = {
        scaleWidth: targetDims.width,
        scaleHeight: targetDims.height,
        scaleMode: 'fit'
    };
    return transformObj;
};

function url(image, options) {
    var transform = {};
    if (image instanceof MediaFile || image instanceof Image) {
        var mediaFile = image instanceof MediaFile ? image : image.file;

        transform = scale(options.device, options.context);
        transform = constructTransformationObject(options, transform);

        if (transform && Object.keys(transform).length) {
            return mediaFile.getImageURL(transform).toString().replace(/ /g, '%20');
        }

        return mediaFile.getAbsURL().toString().replace(/ /g, '%20');
    }
    else {
        transform = scale(options.device, options.context);
        transform = constructTransformationObject(options, transform);
        return preProcessURL(URLUtils.imageURL(image, transform).toString());
    }
};

function preProcessURL(url) {
    try {
        var splits = url.split('static');
        return encodeURI(splits[0] + 'static' + splits[2]);
    } catch (e) {
        // Failed to process...
        return url;
    }
}

function getScaledImage (image, context) {
    if (!image) {
        return null;
    }
    var imageObj = {};
    context = context ? context : 'default';
    if (image instanceof Image) {
        imageObj.alt = image.file.getAlt();
        imageObj.focalPointX = (image.focalPoint.x * 100) + '%';
        imageObj.focalPointY = (image.focalPoint.y * 100) + '%';
        image = image.file;
    }
    imageObj.src = {
        mobile: url(image, { device: 'mobile', context: context }),
        mobileRetina: url(image, { device: 'mobileRetina', context: context }),
        desktop: url(image, { device: 'desktop', context: context }),
        desktopRetina: url(image, { device: 'desktopRetina', context: context })
    };
    return imageObj;
};

module.exports = {
    scale: scale,
    url: url,
    getScaledImage: getScaledImage,
}