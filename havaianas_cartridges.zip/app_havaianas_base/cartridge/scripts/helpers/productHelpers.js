'use strict';

var productHelpers = module.superModule || {};

/**
 * Returns whether or not the product is for "kids" or "babies".
 * @param {dw.catalog.Product} product
 * @return {boolean}
 */
function isKids (product) {
    return product.custom.hav_age.toUpperCase() == 'KIDS' || product.custom.hav_age.toUpperCase() == 'BABY';
}

/**
 * Tries to return a content with the ID "sizeguide-[productType]".
 * @param {dw.catalog.Product} product - SFCC's API Product
 * @returns {dw.content.Content} Content
 */
function getSizeGuideContent (product) {
    if (!product)
        return null;

    var Resource       = require('dw/web/Resource');
    var ContentMgr     = require('dw/content/ContentMgr');
    var masterProduct  = assureMasterProduct(product);
    var kids           = isKids(product);
    var productType    = masterProduct.custom.hav_productType;

    if (!productType)
        throw new ReferenceError(Resource.msgf('error.product.attributes.typenotspecified', 'product', null, masterProduct.getID()));

    var sizeGuideID = 'sizeguide-' + productType;
    sizeGuideID = kids ? sizeGuideID + '-kids' : sizeGuideID;
    var sizeGuide   = ContentMgr.getContent(sizeGuideID);

    if (!sizeGuide)
        throw new Error(Resource.msg('error.sizeguide.table.notspecifiedfortype', 'product', null))

    return sizeGuide;
}

/**
 * Assures that we get a master product
 * @param {dw.catalog.Product} product
 * @returns {dw.catalog.Product} masterProduct
 */
function assureMasterProduct (product) {
    if (!product)
        return null

    if (product.isMaster())
        return product;
    else
        return product.getMasterProduct();
}

var collections = require('*/cartridge/scripts/util/collections');
var HashMap = require('dw/util/HashMap');

/**
 * Return the Variant by value attribute filter
 * @param {dw.catalog.ProductVariationModel} variationModel -  Class representing the complete variation information for a master product in the system
 * @param {String} value - variation attribute value
 *
 * @returns {Object} - variant product
 */
function getVariantByColorFilter(variationModel, value) {
    var color = new HashMap();
    color.color = value;
    var variant = variationModel.getVariants(color) ;
    return variant;
}

/**
 * Return the VariationGroup by value attribute filter
 * @param {dw.catalog.ProductVariationModel} variationModel -  Class representing the complete variation information for a master product in the system
 * @param {String} value - variation attribute value
 *
 * @returns {Object} - variation group product
 */
function getVariationGroupByFilter(variationModel, value) {
    return collections.find(variationModel.variationGroups , function(item){
        return item.custom.color == value;
    });
}

/**
 * Sorts attribute values by display value.
 * @param {Array} processedValues
 */
function sortAttributesByValue(processedValues) {
    return processedValues.sort(function (a,b) {
        if (a.value < b.value) {
            return -1;
        }
        else if (a.value > b.value) {
            return 1;
        }
        return 0;
    });
}

function getVariantAddToCartUrls(pid, variables, context) {
    var HashMap = require('dw/util/HashMap');
    var ProductMgr = require('dw/catalog/ProductMgr');
    var URLUtils = require('dw/web/URLUtils');
    var Collection = require('dw/util/Collection');

    var product = ProductMgr.getProduct(pid);
    var variationModel = product.getVariationModel();
    if (product.variant) {
        var colorAttribute;
        for (let i = 0; i < variationModel.productVariationAttributes.length; i++) {
            if (variationModel.productVariationAttributes[i].ID === 'color') {
                colorAttribute = variationModel.productVariationAttributes[i];
                break;
            }
        }
        if (variationModel.variationGroups.length > 0) {
            var colorValue = variationModel.getVariationValue(product, colorAttribute);
            variationModel = variationModel.master.variationModel;
            variationModel.setSelectedAttributeValue('color', colorValue.value);
        }
        else {
            return [];
        }
    }
    if (variables) {
        Object.keys(variables).forEach(function(key) {
            variationModel.setSelectedAttributeValue(key, variables[key].value);
        });
    }

    var sizeAttribute;
    for (let i = 0; i < variationModel.productVariationAttributes.length; i++) {
        if (variationModel.productVariationAttributes[i].ID === 'size') {
            sizeAttribute = variationModel.productVariationAttributes[i];
            break;
        }
    }
    var sizes = variationModel.getAllValues(sizeAttribute);

    var variants = [];
    for (let i = 0; i < sizes.length; i++) {
        variationModel.setSelectedAttributeValue('size', sizes[i].ID);
        var selectedVariants = variationModel.getSelectedVariants();
        collections.forEach(selectedVariants, function (e) {
            variants.push({
                available: e.getAvailabilityModel().isOrderable(),
                value: sizes[i].value,
                displayValue: sizes[i].displayValue,
                url: e.getAvailabilityModel().isOrderable() ?
                    context == 'pay' ? URLUtils.url('Cart-AddProduct', 'context', context).toString() : URLUtils.url('Product-CheckoutTile', 'pid', e.ID) :
                    URLUtils.url('Product-Unavailable', 'pid', e.ID).toString(),
                id: e.ID,
                selectable: true
            });
        });
    }
    variants = sortAttributesByValue(variants);
    return variants;
}

/**
 * Reallocates an selected attribute to the first element of the list.
 * @param {Array} attrValues - An array of variation attributes
 * @param {Number} minIndex - We only shuffle if the selected value's index is above this value. This is to make the product tile more configurable.
 * @returns {Array}
 */
function prioritizeSelectedAttribute (attrValues, minIndex) {
    if (Array.isArray(attrValues)) {
        for each (attr in attrValues) {
            var attrIndex = attrValues.indexOf(attr);
            if (attr.selected && attrIndex > minIndex) {
                var item = attrValues[attrIndex];
                attrValues[attrIndex] = attrValues[0];
                attrValues[0] = item;
                break
            }
        }
    }

    return attrValues;
}

/**
 * Reallocates size selected attribute to the first element of the list.
 * This has to be used _SPECIFICALLY_ for the checkout tile.
 * @param {Array} attrValues - An array of variation attributes
 * @param {Number} minIndex - We only shuffle if the selected value's index is above this value. This is to make the product tile more configurable.
 * @returns {Array}
 */
function prioritizeSizeSelected (attrValues) {
    if (Array.isArray(attrValues)) {
        attrValues = sortAttributesByValue(attrValues);
        for each (attr in attrValues) {
            var attrIndex = attrValues.indexOf(attr);
            if (attr.selected) {
                var item = attrValues[attrIndex];
                attrValues.splice(attrIndex, 1);
                attrValues.unshift(item);
                break
            }
        }
    }

    return attrValues;
}


/**
 * Returns a hash containing the ProductVariationModel selected attributes
 * @param {dw.catalog.Product|dw.catalog.VariationModel} variationModel - Variation Model or Product instance
 * @returns {Object} - containing the object's selected attributes
 */
function getVariationAttributeValues (variationModel) {
    if (variationModel instanceof dw.catalog.Product)
        variationModel = variationModel.getVariationModel();

    var allVariationAttributes = variationModel.getProductVariationAttributes().toArray();
    var attributeValues        = {};

    allVariationAttributes.forEach(function (variationAttribute) {
        var attributeID   = variationAttribute.getAttributeID();
        var selectedValue = variationModel.getSelectedValue(variationAttribute);

        if (selectedValue)
            attributeValues[attributeID] = selectedValue;
    });

    return attributeValues;
}

function getProductTileModel (apiProduct, querystring, endPoint) {
    var productTileModel  = require('*/cartridge/models/product/productTile');
    var productTileParams = { pview: 'tile' };

    Object.getOwnPropertyNames(querystring)
        .forEach(function (propertyName) {
            productTileParams[propertyName] = querystring[propertyName];
        });

    var productType = productHelpers.getProductType(apiProduct);
    var options     = productHelpers.getConfig(apiProduct, productTileParams);
    var product     = productTileModel({}, options.apiProduct, productType, options.variationModel, endPoint, null, productTileParams.imgContext);

    return product;
}

/**
 * This takes a Product object and magically converts it to a Variation Group if it's a Master or a Variant.
 * @param {dw.catalog.Product} apiProduct
 * @param {Object} options
 */
function normalizeProduct(apiProduct, options) {
    if (options.productType == 'master' && apiProduct.variationModel.variationGroups.length > 0) {
        var collections = require('*/cartridge/scripts/util/collections');
        var variationGroups = apiProduct.variationModel.variationGroups;
        var availableVariationGroup = collections.find(variationGroups, function (e) {
            return e.getAvailabilityModel().isOrderable()
        });
        apiProduct = availableVariationGroup ? availableVariationGroup : variationGroups[0];

        options = productHelpers.getConfig(apiProduct, {pid: apiProduct.getID()});
    }
    else if (options.productType == 'variant') {
        var variationGroup = getVariationGroupByFilter(apiProduct.variationModel, apiProduct.custom.color);
        if (variationGroup) {
            apiProduct = variationGroup;
            options = productHelpers.getConfig(apiProduct, {pid: apiProduct.getID()});
        }
    }
    return {
        apiProduct: apiProduct,
        options: options
    }
}

var productHelpers = module.superModule || {};
productHelpers.assureMasterProduct = assureMasterProduct;
productHelpers.getProductTileModel = getProductTileModel;
productHelpers.getVariantByColorFilter = getVariantByColorFilter;
productHelpers.prioritizeSelectedAttribute = prioritizeSelectedAttribute
productHelpers.prioritizeSizeSelected = prioritizeSizeSelected;
productHelpers.getVariationAttributeValues = getVariationAttributeValues;
productHelpers.getVariantAddToCartUrls = getVariantAddToCartUrls;
productHelpers.getVariationGroupByFilter = getVariationGroupByFilter;
productHelpers.getSizeGuideContent = getSizeGuideContent;
productHelpers.normalizeProduct = normalizeProduct;
productHelpers.sortAttributesByValue = sortAttributesByValue;

module.exports = productHelpers;
