'use strict';

var ContentMgr = require('dw/content/ContentMgr');
var URLUtils = require('dw/web/URLUtils');
var StringUtils = require('dw/util/StringUtils');
var Calendar = require('dw/util/Calendar');
var Resource = require('dw/web/Resource');

function estimatedTimeOfArrival(shipments) {
    var collections = require('*/cartridge/scripts/util/collections');
    var latestDate = shipments[0].custom.estimatedDeliveryDate;
    var currentDate = '';

    collections.forEach(shipments, function (shipment) {
        currentDate = shipment.custom.estimatedDeliveryDate;
        if (currentDate > latestDate) {
            latestDate = currentDate;
        }
    });

    return latestDate;
};

function daysUntilDelivery(creationDate, dateEstimated) {
    if (!empty(dateEstimated)) {
        creationDate = creationDate.getTime();
        dateEstimated = dateEstimated.getTime();

        var daysUntilDelivery = dateEstimated - creationDate;

        daysUntilDelivery = Math.ceil(daysUntilDelivery / (1000 * 3600 * 24));

        return Math.abs(daysUntilDelivery);
    }
    else {
        return 0;
    }
};

function formatShipments(shipments) {
    var collections = require('*/cartridge/scripts/util/collections');
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
    var replacementString = '';
    var shipmentETA = 0;
    var isInStorePickup = false;

    collections.forEach(shipments, function (shipment) {
        isInStorePickup = shipment.custom.isPickup;

        replacementString += formatLineItems(shipment.productLineItems, 'shipment');
        
        if (!isInStorePickup) {
            replacementString += renderTemplateHelper.getRenderedHtml(shipment, 'email/deliveryType');

            replacementString += renderTemplateHelper.getRenderedHtml(shipment.shippingAddress, 'email/deliveryAddress');
            shipmentETA = daysUntilDelivery(shipment.getCreationDate(), shipment.custom.estimatedDeliveryDate);
    
            var renderingObj = {
                shipmentETA: shipmentETA,
                isInStorePickup: isInStorePickup
            };
            replacementString += renderTemplateHelper.getRenderedHtml(renderingObj, 'email/deliveryETA');
        }
        else {
            if (shipment.custom.fromStoreId) {
                var storeModel = require('*/cartridge/models/store');
                var StoreMgr = require('dw/catalog/StoreMgr');
                var apiStore = StoreMgr.getStore(shipment.custom.fromStoreId);
                var pickupStore = shipment.custom.fromStoreId && apiStore ? new storeModel(apiStore) : null;
                var objData = {
                    pickupStore: pickupStore,
                    shipment: shipment
                }
                replacementString += renderTemplateHelper.getRenderedHtml(objData, 'email/pickupInformation');
            }
        }
    });

    return replacementString;
};

function formatLineItems(lineItems, context) {
    var collections = require('*/cartridge/scripts/util/collections');
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
    var replacementString = '';

    collections.forEach(lineItems, function (lineItem) {
        var productVariationModel = lineItem.product.getVariationModel();
        var productVariationAttributeSize = productVariationModel.getProductVariationAttribute('size');
        var productAttributeSize = productVariationModel.getSelectedValue(productVariationAttributeSize);

        var formattedLineItem = {
            productName: lineItem.productName,
            context: context,
            price: lineItem.getAdjustedPrice().toFormattedString(),
            quantity: lineItem.quantityValue,
            size: productAttributeSize.displayValue,
        };
        replacementString = replacementString.concat(renderTemplateHelper.getRenderedHtml(formattedLineItem, 'email/productLineItems'));
    });

    return replacementString;
};

function formatPaymentInfo(paymentInstrument) {
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');

    return renderTemplateHelper.getRenderedHtml(paymentInstrument, 'email/paymentOptions');
};

function formatPaymentMethod(paymentMethod) {
    if(paymentMethod == 'GIFT_CERTIFICATE') {
        return Resource.msg('email.msg.payment.giftcertificate', 'transactionalEmails', null);
    } else {
        return Resource.msg('email.msg.payment.creditcard', 'transactionalEmails', null);
    }
};

function formatQuantityLineItens(quantity) {
     return quantity + ' ' + (quantity == 1 ? Resource.msg('label.text.item', 'cart', null) : Resource.msg('label.text.items', 'cart', null));
}

/*
 * Returns the content asset's text with replacements for the customer and order infos
 * @param {string} template - The content asset's registered title
 * @param {string} dataObj - data from the customer  or from the order which will replace the placeholders in the content asset
 * @returns {string} contentBody
 */

function getContentBody(template, dataObj) {
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
    var contentBody = '';
    var customerLocale = '';

    if (dataObj.order) {
        customerLocale = dataObj.order.customerLocaleID;
    }
    if (dataObj.localeID) {
        customerLocale = dataObj.localeID;
    }

    contentBody = renderTemplateHelper.getRenderedHtml({ template: template }, 'email/emailContentBody',
        customerLocale);

    contentBody = contentBody.replace('{{[name]}}', dataObj.name.firstName);

    //this is where order infos will be filtered  
    if (dataObj.order) {
        contentBody = contentBody.replace('{{[orderNo]}}', dataObj.order.orderNo);
        contentBody = contentBody.replace('{{[orderCountLineItems]}}', formatQuantityLineItens(dataObj.order.productLineItems.length));
        contentBody = contentBody.replace('{{[orderLineItems]}}', formatLineItems(dataObj.order.productLineItems));
        contentBody = contentBody.replace('{{[orderTotal]}}', dataObj.order.totalGrossPrice.toFormattedString());
        
        var TotalsModel = require('*/cartridge/models/totals');
        var totals = new TotalsModel(dataObj.order);

        contentBody = contentBody.replace('{{[orderTotalDiscount]}}', totals.orderLevelDiscountTotal.formatted);

        contentBody = contentBody.split('{{[Order-Track]}}').join(URLUtils.abs('Order-Details', 'orderUUID', dataObj.order.UUID));

        contentBody = contentBody.replace('{{[orderCreationDate]}}', StringUtils.formatCalendar(
            new Calendar(dataObj.order.creationDate), customerLocale, Calendar.INPUT_DATE_PATTERN));

        contentBody = contentBody.replace('{{[deliveryDate]}}', StringUtils.formatCalendar(
            new Calendar(new Date(dataObj.order.getLastModified())), customerLocale, Calendar.INPUT_DATE_PATTERN));

        contentBody = contentBody.replace('{{[paymentInfo]}}', formatPaymentInfo(dataObj.order.paymentInstrument));
        contentBody = contentBody.replace('{{[paymentMethod]}}', formatPaymentMethod(dataObj.order.paymentInstrument.paymentMethod));
        contentBody = contentBody.replace('{{[customerName]}}', dataObj.order.customerName);
        contentBody = contentBody.replace('{{[creditCardNumber]}}', dataObj.order.paymentInstrument.creditCardNumber);
        dataObj.order.paymentInstrument === 'CREDIT_CARD' ?
            contentBody = contentBody.replace('{{[paymentTransactionCreationDate]}}', StringUtils.formatCalendar(
                new Calendar(new Date(dataObj.order.paymentInstrument.getCreationDate())), customerLocale, Calendar.INPUT_DATE_PATTERN)) :
            contentBody = contentBody.replace('{{[paymentTransactionCreationDate]}}', StringUtils.formatCalendar(
                new Calendar(new Date(dataObj.order.paymentInstrument.getLastModified())), customerLocale, Calendar.INPUT_DATE_PATTERN));
            
        if (dataObj.shipments) {
            contentBody = contentBody.replace('{{[shipmentDate]}}', StringUtils.formatCalendar(
                new Calendar(new Date(dataObj.shipments[0].getLastModified())), customerLocale, Calendar.INPUT_DATE_PATTERN));

            var estimatedArrival = estimatedTimeOfArrival(dataObj.shipments);
            var estimatedArrivalDateFormatted = estimatedArrival ? StringUtils.formatCalendar(new Calendar(estimatedArrival), customerLocale, Calendar.INPUT_DATE_PATTERN) : '-';
                
            contentBody = contentBody.replace('{{[estimatedArrival]}}', estimatedArrivalDateFormatted);
        }
        
        if (dataObj.shipments || dataObj.shipment) {
            contentBody = contentBody.replace('{{[shipmentLine]}}', formatShipments(dataObj.shipments));
            contentBody = contentBody.replace('{{[singleShipmentLine]}}',
                formatLineItems(dataObj.shipment ? dataObj.shipment.productLineItems : dataObj.shipments[0].productLineItems));
        };
    };

    if (dataObj.exchangeObject) {
        contentBody = contentBody.replace('{{[mergeCouponOccured]}}', dataObj.exchangeObject.mergeOccured);
        contentBody = contentBody.replace('{{[couponCode]}}', dataObj.exchangeObject.couponCode);
        contentBody = contentBody.replace('{{[amountCoupon]}}', dataObj.exchangeObject.amount);
    }

    if (dataObj.passwordResetUrl) {
        contentBody = contentBody.split('{{[passwordResetLink]}}');
        contentBody = contentBody.join(dataObj.passwordResetUrl);
    };

    return contentBody;
};

function getFooter(template, dataObj){
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');

    var footer = '';
    var customerLocale = '';

    if (dataObj.order) {
        customerLocale = dataObj.order.customerLocaleID;
    }
    if (dataObj.localeID) {
        customerLocale = dataObj.localeID;
    }

    footer = renderTemplateHelper.getRenderedHtml({ template: 'hav_transactionalEmail-footer' }, 'email/emailContentBody',
        customerLocale);

    var footerColorConfig = require('~/cartridge/config/emailFooterColorConfig');
    var footerColors = footerColorConfig(template);

    footer = footer.split('{{bgColor}}').join(footerColors.backgroundColor);
    footer = footer.replace(/{{textColor}}/g, footerColors.textColor);
    footer = footer.replace(/{{hyperLinkColor}}/g, footerColors.hyperLinkColor);
    footer = footer.replace(/{{footerIconColor}}/g, footerColors.footerIconColor || '');

    return footer;
};

function getSubject(template, dataObj) {
    var asset = ContentMgr.getContent(template);
    var subject = asset.custom.hav_emailSubject.replace('{{[orderNo]}}', dataObj ? dataObj.order.orderNo : '');
    return subject;
};

module.exports = {
    getSubject: getSubject,
    getContentBody: getContentBody,
    getFooter: getFooter
}
