'use strict';

var accountHelper = module.superModule || {};

function sendAccountEditedEmail(profile) {
    // Send account edited email
    var transactionalEmailsHelper = require('*/cartridge/scripts/helpers/transactionalEmailsHelper');
    transactionalEmailsHelper.sendAccountEditedEmail(profile);

}

accountHelper.sendAccountEditedEmail = sendAccountEditedEmail;

module.exports = accountHelper;
