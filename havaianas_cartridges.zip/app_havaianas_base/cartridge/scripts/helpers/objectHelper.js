
/**
 * Creates a mutable property for a given object
 * @param {Object} object - An object which will have a property defined
 * @param {String} propertyName - The property name that's going to be created
 *
 * @returns {void}
 */
function propertyDefiner(object, propertyName) {
    Object.defineProperty(object, propertyName, {
        configurable: true,
        value: null
    });
};

/**
 * Join object properties from source into target param
 * @param {Object} target - The object that will receive the properties
 * @param {Object} propertyName - The object that will be used as a reference to copy properties
 *
 * @returns {void}
 */
function joinProperties(target, source) {
    Object.keys(source).forEach(function (property) {
        var propertyValue = source[property];
        Object.defineProperty(target, property, {
            configurable: true,
            value: propertyValue
        });
    });
}

function assign (target) {
    'use strict';
    if (target === undefined || target === null) {
        throw new TypeError('Cannot convert first argument to object');
    }

    var to = Object(target);
    for (var i = 1; i < arguments.length; i++) {
    var nextSource = arguments[i];
    if (nextSource === undefined || nextSource === null) {
        continue;
    }
    nextSource = Object(nextSource);

    var keysArray = Object.keys(Object(nextSource));
    for (var nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex++) {
        var nextKey = keysArray[nextIndex];
        var desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
        if (desc !== undefined && desc.enumerable) {
            to[nextKey] = nextSource[nextKey];
        }
    }
    }
    return to;
}

module.exports = {
    assign: assign,
    propertyDefiner: propertyDefiner,
    joinProperties: joinProperties
};
