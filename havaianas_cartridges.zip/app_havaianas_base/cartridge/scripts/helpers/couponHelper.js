'use strict';

var BasketMgr = require('dw/order/BasketMgr');

/**
 * Tries to find a coupon for the given coupon code. Returns null if no one is found.
 * 
 * @param {String} couponCode - dw.campaign.Coupon code or external coupon code.
 * @return {Object|null} returns a object with two properties: externalCoupon and coupon.
 */
function getCouponByCode (couponCode) {
    var CouponMgr = require('dw/campaign/CouponMgr');
    var { getExternalCouponByCode } = require('*/cartridge/scripts/helpers/couponHelper');

    var coupon = CouponMgr.getCouponByCode(couponCode) || 
        getExternalCouponByCode(couponCode);

    /**
     * Possible returns:
     *  - dw.campaign.Coupon
     *  - null
     *  - Object
     */

    if (!(coupon instanceof dw.campaign.Coupon)) {
        return coupon;
    } 

    return {
        valid: true,
        externalCoupon: false,
        coupon: coupon
    }
}

// Decimal utils implemented in purpose to prevent floating point contraventions.
function instantiateDecimals (array) {
    var Decimal = require('dw/util/Decimal');
    return array.map(function (number) {
        return new Decimal(number || 0);
    })
}
function sumValues (destination, source) {
    var decimals = instantiateDecimals([destination, source]);
    return decimals[0].add(decimals[1]);
}

function subtractValues (destination, source) {
    var decimals = instantiateDecimals([destination, source]);
    return decimals[0].subtract(decimals[1]);
}

/**
 * Creates a CouponLineItem for the current basket based on the supplied external coupon object.
 * @param {Object} externalCoupon - External coupon object, commonly retrieved by external methods.
 */
function createExternalCouponLineItem (externalCoupon) {
    var currentBasket = BasketMgr.getCurrentBasket();
    var Transaction = require('dw/system/Transaction');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
    var useCouponBalance = currentBasket.custom.hav_useCouponBalance;
    var maxBalance;

    Transaction.wrap(function() {
        if (!useCouponBalance) {
            var couponStorage = getCouponStorage();

            if (couponStorage) {
                couponStorage.referenceList.push(externalCoupon.code);
                if (!couponStorage.isPendingMerge) {
                    couponStorage.referenceList.push(couponStorage.code)
                    couponStorage.code = getDefaultAccumulativeCouponCode();
                }
                couponStorage.maxBalance = sumValues(couponStorage.maxBalance, externalCoupon.balance).get();
                couponStorage.isPendingMerge = true;
                
            } else {
                couponStorage = {
                    code: externalCoupon.code,
                    isPendingMerge: false,
                    maxBalance: externalCoupon.balance,
                    referenceList: [],
                    appliedAmount: 0
                };
            }

            currentBasket.custom.hav_externalCouponStorage = JSON.stringify(couponStorage);
            maxBalance = couponStorage.maxBalance;
        } else {
            var existingCouponLineItem = getExternalCouponLineItem();
            var couponLineItem;

            if (existingCouponLineItem) {
                couponLineItem = existingCouponLineItem.custom.hav_isPendingMerge ?
                    mergeCouponLineItem(existingCouponLineItem, externalCoupon) :
                    instantiateAccumulativeCoupon(existingCouponLineItem, externalCoupon);
            } else {
                couponLineItem = currentBasket.createCouponLineItem(externalCoupon.code);
                couponLineItem.custom.hav_maxBalance = externalCoupon.balance;
            }

            maxBalance = couponLineItem.custom.hav_maxBalance;
            updateCouponStorage(couponLineItem)
        }

        basketCalculationHelpers.calculateTotals(currentBasket);
    });
    
    return {
        formattedBalance: getMoneyFormattedValue(maxBalance),
        balance: maxBalance
    };
}

/**
 * Retrieves a treated message based on Resources.
 * @param {Error} error - Error instance occured.
 * @returns {String}
 */

function getCouponErrorMessage (error) {
    var Resource = require('dw/web/Resource');
    var errorCodes = {
        COUPON_CODE_ALREADY_IN_BASKET: 'error.coupon.already.in.cart',
        COUPON_ALREADY_IN_BASKET: 'error.coupon.cannot.be.combined',
        COUPON_CODE_ALREADY_REDEEMED: 'error.coupon.already.redeemed',
        COUPON_CODE_UNKNOWN: 'error.unable.to.add.coupon',
        COUPON_DISABLED: 'error.unable.to.add.coupon',
        REDEMPTION_LIMIT_EXCEEDED: 'error.unable.to.add.coupon',
        TIMEFRAME_REDEMPTION_LIMIT_EXCEEDED: 'error.unable.to.add.coupon',
        NO_ACTIVE_PROMOTION: 'error.unable.to.add.coupon',
        default: 'error.unable.to.add.coupon'
    };

    var accessKey =
        error instanceof dw.order.CreateCouponLineItemException ?
            error.errorCode :
            error.message;

    var errorMessageKey = errorCodes[accessKey] || errorCodes.default;
    errorMessage = Resource.msg(errorMessageKey, 'cart', null);

    return errorMessage;
}

/**
 * Retrives the amount applied on the current basket.
 * @param {Object|dw.order.CouponLineItem} externalCoupon - A CouponLineItem or an object that represents a coupon.
 * @returns {Number}
 */
function getCouponAppliedAmount (externalCoupon) {
    if (!externalCoupon)
        return null;

    if (
        !(externalCoupon instanceof dw.order.CouponLineItem) &&
        !empty(externalCoupon.appliedAmount)
        ) {
        return externalCoupon.appliedAmount;
    }

    var priceAdjustments = externalCoupon.getPriceAdjustments();

    var appliedDiscount =
        priceAdjustments.length ? 
            priceAdjustments[0].getAppliedDiscount().getAmount() :
            0;

    return appliedDiscount;
}

/**
 * Retrives the external dw.order.CouponLineItem applied on the current basket
 * @returns {dw.order.CouponLineItem|null}
 */
function getExternalCouponLineItem (lineItemCtnr) {
    var { find }        = require('*/cartridge/scripts/util/collections');
    var subject         = lineItemCtnr;
    if (!subject) {
        var currentBasket = BasketMgr.getCurrentBasket();
        subject = currentBasket;
    }
    var couponLineItems = subject.getCouponLineItems();

    return find(couponLineItems, function (couponLineItem) {
        return !couponLineItem.isBasedOnCampaign();
    });
}

/**
 * Instiates a accumulative coupon in the current basket and removes the old CouponLineItem
 * @param {dw.order.CouponLineItem} couponLineItem 
 * @param {Object} externalCoupon 
 */
function instantiateAccumulativeCoupon (couponLineItem, externalCoupon) {
    var currentBasket = BasketMgr.getCurrentBasket();
    var AmountDiscount = require('dw/campaign/AmountDiscount');
    var Transaction    = require('dw/system/Transaction');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

    if (couponLineItem.getCouponCode() === externalCoupon.code)
        throw new Error('COUPON_CODE_ALREADY_IN_BASKET');

    var overallMaxBalance =
        sumValues(couponLineItem.custom.hav_maxBalance, externalCoupon.balance).get();

    var priceAdjustmentStorage =
        couponLineItem.custom.hav_priceAdjustmentStorage;

    var couponInfo = {
        appliedAmount: getCouponAppliedAmount(couponLineItem),
        overallMaxBalance: overallMaxBalance,
        priceAdjustmentStorage: priceAdjustmentStorage,
        couponCodes: [
            couponLineItem.getCouponCode(),
            externalCoupon.code
        ]
    };

    var accumulativeCoupon;
    
    Transaction.wrap(function () {
        var defaultCouponCode = getDefaultAccumulativeCouponCode();
        accumulativeCoupon = currentBasket.createCouponLineItem(
            defaultCouponCode
        );

        currentBasket.removeCouponLineItem(
            couponLineItem
        );

        accumulativeCoupon.custom.hav_isPendingMerge = true;
        accumulativeCoupon.custom.hav_maxBalance = couponInfo.overallMaxBalance;
        accumulativeCoupon.custom.hav_referenceList = couponInfo.couponCodes;
        accumulativeCoupon.custom.hav_priceAdjustmentStorage = couponInfo.priceAdjustmentStorage;

        accumulativeCoupon.associatePriceAdjustment(
            currentBasket.createPriceAdjustment(
                defaultCouponCode,
                new AmountDiscount(couponInfo.appliedAmount)
            )
        );

        basketCalculationHelpers.calculateTotals(currentBasket);
    });

    updateCouponStorage(accumulativeCoupon);

    return accumulativeCoupon;
}

/**
 * Merge a External Coupon object into a accumulative dw.order.CouponLineItem
 * @param {dw.order.CouponLineItem} accumulativeCoupon - Pending merge CouponLineItem
 * @param {Object} sourceCoupon - External Coupon implementation
 */
function mergeCouponLineItem (accumulativeCoupon, sourceCoupon) {
    if (accumulativeCoupon.custom.hav_referenceList.indexOf(sourceCoupon.code) !== -1)
        throw new Error('COUPON_CODE_ALREADY_IN_BASKET');

    accumulativeCoupon.custom.hav_maxBalance =
        sumValues(accumulativeCoupon.custom.hav_maxBalance, sourceCoupon.balance).get();

    // The Java array does not implement a toJSON method.
    var referenceListCopy = accumulativeCoupon.custom.hav_referenceList.slice(0);
    referenceListCopy.push(sourceCoupon.code);
    accumulativeCoupon.custom.hav_referenceList = referenceListCopy

    updateCouponStorage(accumulativeCoupon);

    return accumulativeCoupon;
}

/**
 * Using dw.value.Money, returns a currency formatted string
 * based on the amount parameter.
 * @param {Number} amount 
 * @param {[Boolean]} withoutCurrencySymbol - optional, ignores the currency symbol on return 
 * @returns {String}
 */
function getMoneyFormattedValue (amount, withoutCurrencySymbol) {
    var Money = require('dw/value/Money');
    var currentCurrency = session.getCurrency();
    var moneyInstance = new Money(amount || 0, currentCurrency.getCurrencyCode());

    return withoutCurrencySymbol ?
        moneyInstance.toNumberString() :
        moneyInstance.toFormattedString();
}

function assertNoGiftCertificateOverride(giftCertificate, amount) {
    if (!giftCertificate)
        return true;

    var paymentTransaction = giftCertificate.getPaymentTransaction();
    var appliedAmount = paymentTransaction.getAmount().getDecimalValue();
    var giftCertificateAmount = appliedAmount ? 
            appliedAmount.add(1) :
            0;

    var amountAlreadyApplied = !(giftCertificateAmount ^ amount);

    return  !(giftCertificate && amountAlreadyApplied);
}

/**
 * Replaces the current CouponLineItem's price ajustment with a 
 * new containing a discount based on the amount parameter
 * @param {dw.order.couponLineItem} couponLineItem 
 * @param {Number} amount 
 */
function changeCouponAppliedAmount (couponLineItem, amount) {
    var currentBasket = BasketMgr.getCurrentBasket();
    var AmountDiscount = require('dw/campaign/AmountDiscount');
    var { find } = require('*/cartridge/scripts/util/collections');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
    var Decimal = require('dw/util/Decimal');
    var Transaction = require('dw/system/Transaction');
    var Money = require('dw/value/Money');

    var priceAdjustment = 
        find(currentBasket.getPriceAdjustments(),
            function (priceAdjustment) {
                return priceAdjustment.getCouponLineItem() === 
                    couponLineItem;
            });

    var discount = new AmountDiscount(amount);

    Transaction.wrap(function () {
        var isGiftCertificateApplied = false;

        var amountDecimal = new Decimal(amount);

        var priceAdjustmentStorage = couponLineItem.custom.hav_priceAdjustmentStorage;
        var basketPureTotal = getBasketPureTotalAmount();
        var appliedGiftCertificate = getCouponAppliedGiftCertificate();

        if (!appliedGiftCertificate && basketPureTotal && basketPureTotal.get() == amountDecimal.get()) {
            var newAmount = subtractValues(amount, basketPureTotal);

            // since gift certificate fills the entirety of basket total, it is not need any
            // other payment method that may be previously selected.
            currentBasket.removeAllPaymentInstruments();

            var giftCertificateValue = new Money(newAmount, session.getCurrency());
            Transaction.wrap(function () {
                couponLineItem.custom.hav_priceAdjustmentStorage = amount;
                currentBasket.createGiftCertificatePaymentInstrument(
                    getFulFillGiftCertificateCode(),
                    giftCertificateValue
                );
            });

            if (priceAdjustment)
                currentBasket.removePriceAdjustment(priceAdjustment);

            // This is needed so that the coupon stays in the order after checkout.
            var valuePlaceholder = new AmountDiscount(amount);
            couponLineItem.associatePriceAdjustment(
                currentBasket.createPriceAdjustment(
                    couponLineItem.getCouponCode(),
                    valuePlaceholder
                )
            );

            isGiftCertificateApplied = true;
        }

        if (!isGiftCertificateApplied && assertNoGiftCertificateOverride(appliedGiftCertificate, amountDecimal)) {
            if (priceAdjustment)
                currentBasket.removePriceAdjustment(priceAdjustment);

            couponLineItem.associatePriceAdjustment(
                currentBasket.createPriceAdjustment(
                    couponLineItem.getCouponCode(),
                    discount
                )
            );
        }

        // Mainly because of shipping values changes, removes the old gift certificate it the new
        // value isn't the same, but if the new value is still appliable for a gift certificate, it was 
        // created back there.
        if (appliedGiftCertificate && amount !== priceAdjustmentStorage) {
            currentBasket.removePaymentInstrument(
                appliedGiftCertificate
            );
        }

        updateCouponStorage(couponLineItem);

        basketCalculationHelpers.calculateTotals(currentBasket);
    });
}

/**
 * Using dw.value.Money, returns a currency formatted string
 * based on the discount applied on the internal CouponLineItem.
 * @param {dw.order.CouponLineItem} couponLineItem - CouponLineItem originated from an internal coupon
 * @returns {String}
 */
function getInternalCouponDisplayString (couponLineItem) {
    var Resource = require('dw/web/Resource');
    var Discount = require('dw/campaign/Discount');
    var priceAdjustment = couponLineItem.getPriceAdjustments()

    if (!priceAdjustment.length)
        return "-";
    
    priceAdjustment =  priceAdjustment[0];

    var appliedDiscount = priceAdjustment.getAppliedDiscount();
    var discountType    = appliedDiscount.getType();

    /*
        Lacks a better definitions for other types than percentage and amount.
     */
    if (discountType === Discount.TYPE_PERCENTAGE) {
        return Resource.msgf('text.coupon.percentagediscount', 'checkout', null, appliedDiscount.getPercentage());
    }
        // This clause looks incorrect, but free shipping is actually TYPE_FREE
    else if (discountType == Discount.TYPE_FREE_SHIPPING || discountType == Discount.TYPE_FREE) {
        return Resource.msg('text.coupon.freeshipping', 'checkout', null);
    }
    else {
        return getMoneyFormattedValue(appliedDiscount.getQuantity());
    }
}

/*
            ============== COUPON STORAGE ==============

    The coupon storage was conceived to be a editable space that
    represents a coupon that can be applied and removed depending on
    user's preference, in case of removing, the coupon information must
    persist and to be reapplied if desired. 

    There is three functions that use this functionality directly:
        - getCouponStorage
        - updateCouponStorage
        - restoreExternalCouponLineItem

    In other functions, updateCouponStorage can be found generally at
    the bottom, as the name suggests, it is in purpose to keep the
    coupon in storage updated.

                ===== PRICE ADJUSTMENT STORAGE =====
    This field was conceived as a result of the implementation of 
    Gift Certificates, it is used to determine if the state of a coupon
    is still valid and to support some of the customer's regrets.

            ============================================                
*/

/**
 * Retrieves the coupon storage on the current basket
 * @returns {Object|null} 
 */
function getCouponStorage () {
    var currentBasket = BasketMgr.getCurrentBasket();
    var couponStorage =
        JSON.parse(
            currentBasket.custom.hav_externalCouponStorage ||
            null
        );
    
    return couponStorage;
}

/**
 * Updates the current basket's coupon storage with the parametrized coupon
 * @param {dw.order.CouponLineItem|Object} externalCoupon 
 */
function updateCouponStorage (externalCoupon) {
    var currentBasket = BasketMgr.getCurrentBasket();
    var Transaction = require('dw/system/Transaction');

    if (!externalCoupon)
        return;

    var coupon;

    if (externalCoupon instanceof dw.order.CouponLineItem) {
        var isPendingMerge = !!externalCoupon.custom.hav_isPendingMerge
        coupon = {
            code: externalCoupon.getCouponCode(),
            isPendingMerge: isPendingMerge,
            priceAdjustmentStorage: externalCoupon.custom.hav_priceAdjustmentStorage,
            maxBalance: externalCoupon.custom.hav_maxBalance,
            referenceList: externalCoupon.custom.hav_referenceList.splice(0),
            appliedAmount: getCouponAppliedAmount(externalCoupon)
        }
    } else {
        coupon = {
            code: externalCoupon.code,
            isPendingMerge: false,
            priceAdjustmentStorage: 0,
            maxBalance: externalCoupon.balance,
            referenceList: [],
            isPreSelected: externalCoupon.isPreSelected,
            appliedAmount: 0
        }
    }

    Transaction.wrap(function () {
        currentBasket.custom.hav_externalCouponStorage = JSON.stringify(coupon);
    });

    return;
}

/**
 * Creates a CouponLineItem out of the coupon storage from the current basket.
 * @returns {dw.order.CouponLineItem} - created CouponLineItem
 */
function restoreExternalCouponLineItem () {
    var currentBasket = BasketMgr.getCurrentBasket();
    var Transaction = require('dw/system/Transaction');
    var couponStorage = JSON.parse(currentBasket.custom.hav_externalCouponStorage || null);
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

    if (!couponStorage)
        return;

    var couponLineItem;
    Transaction.wrap(function () {
        couponLineItem = currentBasket.createCouponLineItem(couponStorage.code);

        couponLineItem.custom.hav_isPendingMerge = couponStorage.isPendingMerge;
        couponLineItem.custom.hav_maxBalance = couponStorage.maxBalance;
        couponLineItem.custom.hav_referenceList = couponStorage.referenceList;

        if (couponStorage.priceAdjustmentStorage)
            couponLineItem.custom.hav_priceAdjustmentStorage = couponStorage.priceAdjustmentStorage;

        var appliedAmount = couponStorage.appliedAmount || couponStorage.priceAdjustmentStorage;

        if (isNaN(parseFloat(appliedAmount)))
            appliedAmount = 0;
       
        changeCouponAppliedAmount(couponLineItem, appliedAmount);

        basketCalculationHelpers.calculateTotals(currentBasket);
    });

    return couponLineItem;
}

/**
 * Remove the external CouponLineItems applied on the current basket
 * @param {[Boolean]} eraseStorage - Optional parameter, if true it erases the coupon storage
 */
function removeExternalCouponLineItems (eraseStorage) {
    var currentBasket = BasketMgr.getCurrentBasket();
    var Transaction = require('dw/system/Transaction');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
    var { getSiteEnabledValidations } = require('*/cartridge/scripts/helpers/couponHelper');
    if (currentBasket) {
        var couponLineItems = currentBasket.getCouponLineItems().toArray();

        Transaction.wrap(function () {
            couponLineItems.forEach(function (couponLineItem) {
                if (!couponLineItem.isBasedOnCampaign())
                    currentBasket.removeCouponLineItem(couponLineItem);
            });

            if (eraseStorage) {
                currentBasket.custom.hav_externalCouponStorage = '';
            }

            var giftCertificate = getCouponAppliedGiftCertificate();

            if (giftCertificate) {
                currentBasket.removePaymentInstrument(
                    giftCertificate
                );
            }

            currentBasket.custom.hav_useCouponBalance = false;

            getSiteEnabledValidations().forEach(function (validation) {
                currentBasket.custom[validation.attrName] = '';
            });

            currentBasket.custom.hav_isValidationStored = false;

            basketCalculationHelpers.calculateTotals(currentBasket);
        });
    }
}

/**
 * Retrieves the basket total without the external CouponLineItems price adjustments.
 * @returns {Number}
 */
function getBasketPureTotalAmount () {
    var currentBasket = BasketMgr.getCurrentBasket();
    var Decimal = require('dw/util/Decimal');
    var Transaction = require('dw/system/Transaction');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

    Transaction.wrap(function () {
        basketCalculationHelpers.calculateTotals(currentBasket);
    })

    var totalGrossPrice = currentBasket.getTotalGrossPrice().getDecimalValue();

    if (currentBasket.custom.hav_useCouponBalance === false)
        return totalGrossPrice;

    var externalCouponAmount = getCouponAppliedAmount(
        getExternalCouponLineItem()
    );

    externalCouponAmount = new Decimal(externalCouponAmount || 0)

    return totalGrossPrice ? totalGrossPrice.add(externalCouponAmount) : externalCouponAmount;
}

/**
 * Retrieves the configured Site Preference for the default coupon-related gift certificate code.
 * If no one is set, returns 'VOUCHER_FULFILL'
 * @returns {String}
 */
function getFulFillGiftCertificateCode () {
    var Site = require('dw/system/Site');
    var Havaianas = Site.getCurrent();

    var defaultPlaceHolder = Havaianas.getCustomPreferenceValue('hav_couponGiftCertificateCode');

    return defaultPlaceHolder || 'VOUCHER_FULFILL';
}

/**
 * Retrieves the configured Site Preference for the default linx accumulative voucher code.
 * If no one is set, returns 'PENDING_MERGE'
 * @returns {String}
 */
function getDefaultAccumulativeCouponCode () {
    var Site = require('dw/system/Site');
    var Havaianas = Site.getCurrent();

    var defaultCode = Havaianas.getCustomPreferenceValue('hav_accumulativeCouponCode');

    return defaultCode || 'PENDING_MERGE';
}

/**
 * Retrieves the Gift Certificate applied from a external coupon line item in the current basket.
 * @param {[dw.order.lineItemCtnr]} lineItemCtnr - optional, changes the target to the
 * LineItemCtnr parametrized.
 */
function getCouponAppliedGiftCertificate (lineItemCtnr) {
    var subject = lineItemCtnr;
    if (!subject) {
        var currentBasket = BasketMgr.getCurrentBasket();
        subject = currentBasket;
    }

    var giftCertificates = subject.getGiftCertificatePaymentInstruments(
        getFulFillGiftCertificateCode()
    );

    return giftCertificates.length ? giftCertificates[0] : null;
}

/**
 * Mainly developed for the purpose to update the external coupon's values
 * on shipping change, updates the coupon line item state.
 * @returns {Boolean} - If the coupon tile on page needs to be refreshed.
 */
function verifyExternalCouponState() {
    var currentBasket = BasketMgr.getCurrentBasket();
    var externalCouponLineItem = getExternalCouponLineItem();
    var isRefreshNeeded;

    if (!externalCouponLineItem)
        return;

    var couponAppliedAmount = getCouponAppliedAmount(externalCouponLineItem);
    var giftCertificate = getCouponAppliedGiftCertificate();
    var basketPureTotal = getBasketPureTotalAmount();

    var priceAdjustmentStorage = externalCouponLineItem.custom.hav_priceAdjustmentStorage;

    if (giftCertificate) {
        var giftCertificateAppliedAmount =
            giftCertificate
                .getPaymentTransaction()
                .getAmount()
                .getValue();


        if (giftCertificateAppliedAmount !== basketPureTotal) {
            var Transaction = require('dw/system/Transaction');
            Transaction.wrap(function () {
                currentBasket.removePaymentInstrument(
                    giftCertificate
                );
            });

            var priceSubject;
            if (giftCertificateAppliedAmount > basketPureTotal) {
                priceSubject = basketPureTotal;
                isRefreshNeeded = true;
            } else {
                priceSubject = priceAdjustmentStorage
            }

            changeCouponAppliedAmount(
                externalCouponLineItem,
                priceSubject
            );
        }

    } else if (couponAppliedAmount === basketPureTotal) {
        changeCouponAppliedAmount(
            externalCouponLineItem,
            couponAppliedAmount
        )
    }

    return isRefreshNeeded;
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function getSiteEnabledValidations () {
    var siteFields =  [];
    return siteFields;
}

function removeAllInternalCoupons() {
    var Transaction = require('dw/system/Transaction');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
    var collections = require('*/cartridge/scripts/util/collections');
    var currentBasket = BasketMgr.getCurrentBasket();
    if (currentBasket) {
        collections.find(currentBasket.couponLineItems, function (item) {
            Transaction.wrap(function () {
                currentBasket.removeCouponLineItem(item);
            });
        });
        Transaction.wrap(function () {
            basketCalculationHelpers.calculateTotals(currentBasket);
        });

    }
}

module.exports = {
    getSiteEnabledValidations: getSiteEnabledValidations,
    changeCouponAppliedAmount: changeCouponAppliedAmount,
    createExternalCouponLineItem: createExternalCouponLineItem,
    getExternalCouponLineItem: getExternalCouponLineItem,
    getCouponAppliedAmount: getCouponAppliedAmount,
    getCouponAppliedGiftCertificate: getCouponAppliedGiftCertificate,
    getCouponByCode: getCouponByCode,
    getCouponStorage: getCouponStorage,
    getCouponErrorMessage: getCouponErrorMessage,
    getFulFillGiftCertificateCode: getFulFillGiftCertificateCode,
    getBasketPureTotalAmount: getBasketPureTotalAmount,
    getInternalCouponDisplayString: getInternalCouponDisplayString,
    getMoneyFormattedValue: getMoneyFormattedValue,
    instantiateAccumulativeCoupon: instantiateAccumulativeCoupon,
    mergeCouponLineItem: mergeCouponLineItem,
    restoreExternalCouponLineItem: restoreExternalCouponLineItem,
    removeExternalCouponLineItems: removeExternalCouponLineItems,
    sumValues: sumValues,
    subtractValues: subtractValues,
    updateCouponStorage: updateCouponStorage,
    verifyExternalCouponState: verifyExternalCouponState,
    removeAllInternalCoupons: removeAllInternalCoupons
}