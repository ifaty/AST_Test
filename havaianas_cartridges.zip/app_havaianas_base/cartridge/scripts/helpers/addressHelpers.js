'use strict';

var addressHelper = module.superModule || {};

/**
 * Currently not being used.
 * Returns stored address with given postal code if it exists.
 * @param {string} postalCode - Postal code that should be searched
 * @param {Object[]} storedAddresses - List of stored user addresses
 * @returns {boolean|null} - Stored address or null
 */
function getStoredAddressFromPostalCode(postalCode, storedAddresses) {
    for (var i = 0, l = storedAddresses.length; i < l; i++) {
            if (storedAddresses[i].postalCode === postalCode) {
            return storedAddresses[i];
        }
    }
    return null;
}

addressHelper.getStoredAddressFromPostalCode = getStoredAddressFromPostalCode;

module.exports = addressHelper;