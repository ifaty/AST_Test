/**
 * Wraps the path for storing profile pictures with separatos (i.e. '/').
 * @param {String} path - The path where profile pictures should be stored.
 */
function wrapWithSeparators(path) {
    var File = require('dw/io/File');
    var tmp = path;

    // Adds the '/' to the specified path if it was not inserted.
    if (tmp[0] != File.SEPARATOR) {
        tmp = File.SEPARATOR + tmp;
    }

    if (tmp[tmp.length - 1] != File.SEPARATOR) {
        tmp += File.SEPARATOR;
    }
    return tmp;
}

/**
 * Processes and deals with form sent by the request, handles case in which form isn't multipart.
 * @param {Object} req - Request object as available in any controller.
 * @param {Object} fileConfig - Model object of all site prefs related to profile pictures.
 * @param {dw.web.HttpParameterMap} params - HttpParameterMap of the current request.
 */
function processMultipartForm(req, fileConfig, params) {
    var File = require('dw/io/File');
    var LinkedHashMap = require('dw/util/LinkedHashMap');
    var response;
    var receivedFileType;

    var files = new LinkedHashMap();

    var closure = function(field, ct, oname){
        if (!oname)
            return null;
		receivedFileType = oname.split('.');
		receivedFileType = receivedFileType[receivedFileType.length - 1].toLowerCase();
        var file = new File( File.CATALOGS + fileConfig.profilePicturePath + fileConfig.profilePicturePrefix + req.currentCustomer.raw.getID() + '.' + receivedFileType);
        if (fileConfig.allowedTypes.indexOf('.' + receivedFileType) == -1) {
            response = {
                errorMsg: Resource.msgf('error.personalinfo.uploadprofilepicture.filetype', 'forms', 'null', receivedFileType),
                success: false
            }
            return null;
        }
        return file;
    };

    files = params.processMultipart(closure);

    if (!empty(response)) {
        return {
            response: response,
            validForm: false
        }
    }

    return {
        files: files,
        receivedFileType: receivedFileType,
        validForm: true
    };
}

/**
 * Removes previous profile picture in case the customer decided to use a new one with the same extension.
 * Currently it doesn't remove pictures with different extensions.
 * @param {String} profilePictureURL - URL of the current profile picture set by the customer.
 * @param {String} receivedFileType - The new profile picture's extension.
 * @param {Object} fileConfig - Model object of all site prefs related to profile pictures.
 * @param {String} customerId - The ID of the customer changing their profile picture.
 */
function removePreviousPicture(profilePictureURL, receivedFileType, fileConfig, customerId) {
    var File = require('dw/io/File');

    if (!empty(profilePictureURL)) {
        profilePictureURL = profilePictureURL.split('/');
        profilePictureURL = profilePictureURL[profilePictureURL.length - 1] // retrieves the url's last piece, commonly the image with its parameters
        var urlParameters = profilePictureURL.indexOf('?');
        var fileName = urlParameters != -1 ? // remove those params if there are any.
            profilePictureURL.substring(0 , urlParameters) :
            profilePictureURL;
        var oldFileExtension = fileName.split('.'); // gets the file extension to do the comparison with the new file
        oldFileExtension = oldFileExtension[oldFileExtension.length - 1]

        if (oldFileExtension != receivedFileType) {  // Check if it was overwritten
            var oldProfilePicture = new File(File.CATALOGS + fileConfig.profilePicturePath + fileConfig.profilePicturePrefix + customerId + '.' + oldFileExtension);
            oldProfilePicture.remove();
        }
    }
}

module.exports = {
    wrapWithSeparators: wrapWithSeparators,
    processMultipartForm: processMultipartForm,
    removePreviousPicture: removePreviousPicture
}