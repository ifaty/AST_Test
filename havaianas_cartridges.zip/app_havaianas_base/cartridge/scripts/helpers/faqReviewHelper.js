'use strict';

const Transaction = require('dw/system/Transaction');
const customerMgr = require('dw/customer/CustomerMgr');
const customObjectMgr = require('dw/object/CustomObjectMgr');
const ContentMgr = require('dw/content/ContentMgr');

function createFaqObject(question){
    let faqObject = {};

    Transaction.wrap(function () {
        faqObject = customObjectMgr.createCustomObject('faq-reviews', question.ID);
        let custom = faqObject.getCustom();

        custom.question = question.custom.hav_faq_question;
        custom.answer = question.custom.hav_faq_answer;
        custom.likes = 0;
        custom.dislikes = 0;
    });

    return faqObject;
}

function decreaseReview(review, faqObject) {

    let custom = faqObject.getCustom();

    Transaction.wrap(function () {

        if(review === true || review === 'true'){
            custom.likes--
        }else if(review === false || review === 'false'){
            custom.dislikes--
        }

    })

}

function increaseReview(review, faqObject) {

    let custom = faqObject.getCustom();

    Transaction.wrap(function () {

        if(review === true || review === 'true'){
            custom.likes++
        }else if(review === false || review === 'false'){
            custom.dislikes++
        }

    })
}

function isReviewed(oldReviews, faqObject) {

    if(oldReviews && oldReviews.questions){
        return !!oldReviews.questions[faqObject.custom.id];
    }

    return false;
}

function reviewsJsonBuilder (review, faqObject, oldReviews) {
    let json = oldReviews || {questions:{}};
    let date = new Date();
    let today = date.getDate() + '/' + date.getMonth() + '/' + date.getFullYear();

    json.questions[faqObject.custom.id] = {
        id: faqObject.custom.id,
        review: review,
        date: today
    };

    return json;
}

function handleOldReviews(customer, faqObject, review, oldReviews){

    try{
        oldReviews = JSON.parse(oldReviews);
    }catch(e){
        let Logger = require('dw/system/Logger');
        Logger.error(e.message);
    }

    if(isReviewed(oldReviews, faqObject)){

        if(oldReviews.questions[faqObject.custom.id].review !== review){
            decreaseReview(oldReviews.questions[faqObject.custom.id].review, faqObject);
        }else {
            return false;
        }
    }

    return reviewsJsonBuilder(review, faqObject, oldReviews);
}

function handleFaqReview(questionID, review, customer, reviewsCookie){

    let question = ContentMgr.getContent(questionID);

    if(!question){
        return {
            success: false
        }
    }

    let faqObject = customObjectMgr.getCustomObject('faq-reviews', question.ID) || createFaqObject(question);

    if(customer && customer.raw.authenticated === true && customer.profile){
        let profile = customerMgr.getProfile(customer.profile.customerNo);

        if(profile){
            var customerReviewsJson = handleOldReviews(customer, faqObject, review, profile.custom.hav_faq_reviews);

            if(customerReviewsJson){
                Transaction.wrap(function(){
                    profile.custom.hav_faq_reviews = JSON.stringify(customerReviewsJson);
                });
                increaseReview(customerReviewsJson.questions[faqObject.custom.id].review, faqObject);
                return customerReviewsJson;
            }
        }

    }

    if(reviewsCookie){
        var cookieReviewsJson = handleOldReviews(customer, faqObject, review, reviewsCookie);

        if(cookieReviewsJson){
            increaseReview(cookieReviewsJson.questions[faqObject.custom.id].review, faqObject);
            return cookieReviewsJson;
        }
    }

    return reviewsJsonBuilder(review, faqObject);
}

module.exports = {
    handleFaqReview: handleFaqReview
};
