'use strict';

function productReviewsEnabled() {
    var Site = require('dw/system/Site');
    return Site.current.getCustomPreferenceValue('hav_enableProductReviews') || false;
};

module.exports = {
    productReviewsEnabled: productReviewsEnabled
};