'use strict';

var { getOCAPIService } = require('*/cartridge/scripts/helpers/ocapiHelper');

/**
 * Returns a store reader based on a SystemObjectMgr call.
 * It retrieves data per page, calling "next()" will query the next page.
 * @returns {Object} { result?, hasNext(), next() }
 */
function getStoreReader () {
    var SystemObjectMgr = require('dw/object/SystemObjectMgr');

    return SystemObjectMgr.querySystemObjects("Store", "", "ID asc");
}

/**
 * This method indexes all stores by creating a single custom object for each locality (i.e. state or province)
 * And writing a hierarchical object inside each of them created by the Rebuild Store Index JOB
 * @param {Object} preWrittenIndex - JSON that contains all store info by disposition
 */
function writeIndex(preWrittenIndex) {
    var CustomObjectMgr = require('dw/object/CustomObjectMgr');
    var Logger = require('dw/system/Logger');
    var Transaction = require('dw/system/Transaction');
    var Site = require('dw/system/Site');

    var storeIndexConfigurations = {
        customObjectID: Site.current.getCustomPreferenceValue('hav_storeIndexObjectID') || 'hav_storeLocality',
        errorLogCategory: Site.current.getCustomPreferenceValue('hav_storeIndexLogCategory') || 'store-index'
    };

    Logger = Logger.getLogger(storeIndexConfigurations.errorLogCategory);

    Object.keys(preWrittenIndex).forEach(function(locality) {
        try {
            Transaction.wrap(function() {
                var localityObject =
                    CustomObjectMgr.getCustomObject(storeIndexConfigurations.customObjectID, locality) ||
                    CustomObjectMgr.createCustomObject(storeIndexConfigurations.customObjectID, locality) ;
        
                localityObject = localityObject.getCustom();
                localityObject.data = JSON.stringify(preWrittenIndex[locality]);
            });
        } catch (e) {
            Logger.error('Could not update locality index with ID: '+locality+'. Stack trace:\n' + e.stack);
        }
    });

}

/**
 * Returns data stored in locality index (i.e. custom object)
 * @param {string} - Locality ID
 */
function getIndex(locality) {
    var CustomObjectMgr = require('dw/object/CustomObjectMgr');
    var Logger = require('dw/system/Logger');
    var Site = require('dw/system/Site');

    var storeIndexConfigurations = {
        customObjectID: Site.current.getCustomPreferenceValue('hav_storeIndexObjectID') || 'hav_storeLocality',
        errorLogCategory: Site.current.getCustomPreferenceValue('hav_storeIndexLogCategory') || 'store-index'
    };

    Logger = Logger.getLogger(storeIndexConfigurations.errorLogCategory);

    try {
        var localityObject =
            CustomObjectMgr.getCustomObject(storeIndexConfigurations.customObjectID, locality);
        localityObject = localityObject.getCustom();
        return JSON.parse(localityObject.data);
    } catch (e) {
        Logger.warn('Could not get locality index with ID: ' + locality + '. Stack trace:\n' + e.stack);
    }
    return {};
}

module.exports = {
    getStoreReader: getStoreReader,
    writeIndex: writeIndex,
    getIndex: getIndex
}