'use strict';

function calculateDistance(x, y) {
    // lat1 = x, lat2 = y
    var R = 6371e3; // metres
    var φ1 = x.latitude * Math.PI/180; // φ, λ in radians
    var φ2 = y.latitude * Math.PI/180;
    var Δφ = (y.latitude - x.latitude) * Math.PI/180;
    var Δλ = (y.longitude - x.longitude) * Math.PI/180;

    var a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ/2) * Math.sin(Δλ/2);

    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    var d = R * c; // in metres

    return d;
};

function getStoredAddress () {
    return {};
}

module.exports = {
    calculateDistance: calculateDistance,
    getStoredAddress: getStoredAddress
};