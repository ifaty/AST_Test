/**
 * Returns search menu text placeholders
 *
 * @returns {void}
 */
function getSearchPlaceholders() {
    var Resource = require('dw/web/Resource');

    var placeHolders = [];
    var placeHolderPhrase;
    for (
        var i = 1;
        (placeHolderPhrase = Resource.msg('placeholder.searchbar.phrase' + i, 'search', 'null')) !== 'null';
        ++i
        ) {
        placeHolders.push(placeHolderPhrase);
    }

    return JSON.stringify(placeHolders);
}

module.exports = {
    getSearchPlaceholders: getSearchPlaceholders
};
