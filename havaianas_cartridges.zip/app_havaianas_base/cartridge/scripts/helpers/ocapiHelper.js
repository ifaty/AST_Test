'use strict';

/**
 * @return {dw.svc.Result} The result of calling the auth service.
 */
function getAccessToken() {
    var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
    var Site = require('dw/system/Site');
    var Logger = require('dw/system/Logger');
    var StringUtils = require('dw/util/StringUtils');

    var logCategory = logCategory || 'ocapi-internal';

    var ocapiCredService = LocalServiceRegistry.createService("OCAPI-auth-internal", {
        createRequest: function(svc, args) {
            var clientId = Site.getCurrent().getCustomPreferenceValue("hav_ocapiClientId") || 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
            var clientSecret = Site.getCurrent().getCustomPreferenceValue("hav_ocapiClientSecret") || 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
            svc.setRequestMethod("POST");
            svc.addHeader('Content-Type', 'application/x-www-form-urlencoded');
            svc.addHeader('Authorization', 'Basic ' + StringUtils.encodeBase64(clientId + ':' + clientSecret));

            return 'grant_type=client_credentials';
        },
        parseResponse: function(svc, client) {
            return client.text;
        },
        filterLogMessage: function(msg) {
            return msg;
        }
    });

    var result = ocapiCredService.call();

    if (!result.ok) {
        Logger.getLogger(logCategory, logCategory).error('OCAPI auth call failed. Error message: {0}', result.errorMessage);
        throw new Error("Failed to get OCAPI access token.");
    }
    else {
        Logger.getLogger(logCategory, logCategory).info('Successfully acquired OCAPI access token.');
    }

    return JSON.parse(result.getObject()).access_token;
}

/**
 * Builds a OCAPI service set with the adequate access token, to use it
 * use .call passing an Object { url, method, data }, like an AJAX call.
 * @returns {dw.svc.Service}
 */
function getOCAPIService () {
    var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
    var System = require('dw/system/System');

    var currentAccessToken = getAccessToken();

    var ocapiService = LocalServiceRegistry.createService("OCAPI-internal", {
        createRequest: function(svc, args) {
            svc.setRequestMethod(args.method);
            svc.setURL("https://" + System.getInstanceHostname() + svc.URL + args.url);
            svc.addHeader('Content-Type', 'application/json;charset=UTF-8');
            svc.addHeader('Authorization', 'Bearer ' + currentAccessToken);

            return JSON.stringify(args.data);
        },
        parseResponse: function(svc, client) {
            return client.text;
        },
        filterLogMessage: function(msg) {
            return msg;
        }
    });

    return ocapiService;
}

/**
 * This function simply saves custom prefs to the specified instance types and logs according to the log category param.
 * @param {Object} body This is simply an object containing the custom prefs that should be updated and their respective values.
 * E.g. {c_hav_storySettings: '{}'}
 * @param {Array} instanceTypes The instance types to which we should save.
 * @param {String} logCategory Logging category.
 */
function saveCustomPreferences(body, instanceTypes, logCategory) {
    var Logger = require('dw/system/Logger');
    var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
    var Site = require('dw/system/Site');
    var System = require('dw/system/System');
    var Transaction = require('dw/system/Transaction');
    var ocapiSettings = require('*/cartridge/config/ocapiSettings');
    logCategory = logCategory || 'ocapi-internal';

    var currentAccessToken = getAccessToken();

    var ocapiService = LocalServiceRegistry.createService("OCAPI-internal", {
        createRequest: function(svc, args) {
            svc.setRequestMethod("PATCH");
            svc.addHeader('Content-Type', 'application/json;charset=UTF-8');
            svc.addHeader('Authorization', 'Bearer ' + currentAccessToken);

            return JSON.stringify(body);
        },
        parseResponse: function(svc, client) {
            return client.text;
        },
        filterLogMessage: function(msg) {
            return msg;
        }
    });
    // var instanceTypes = Site.getCurrent().getCustomPreferenceValue("hav_PDInstanceTypes");
    if (instanceTypes) {
        var baseUrl = "https://" + System.getInstanceHostname() + ocapiService.URL;
        for (var i = 0, len = instanceTypes.length; i < len; i++) {
            ocapiService.URL = baseUrl + "sites/" + Site.getCurrent().getID() + "/site_preferences/preference_groups/" + ocapiSettings.configName + "/" + instanceTypes[i];
            var result;
            Transaction.wrap(function () {
                result = ocapiService.call();
            });
            if (!result.ok) {
                Logger.getLogger(logCategory, logCategory).warn('Failed on saving settings for instance group {0}. Error message: {1}', instanceTypes[i], result.errorMessage);
            }
            else {
                Logger.getLogger(logCategory, logCategory).info('Successfully saved settings for instance type {0}.', instanceTypes[i]);
            }
        }
    }
}

/**
 * This function simply saves custom prefs to the specified instance types and logs according to the log category param.
 * @param {Object} body This is simply an object containing the custom prefs that should be updated and their respective values.
 * E.g. {c_hav_storySettings: '{}'}
 * @param {Array} instanceTypes The instance types to which we should save.
 * @param {String} logCategory Logging category.
 */
function saveGlobalCustomPreferences(body, instanceTypes, logCategory) {
    var Logger = require('dw/system/Logger');
    var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
    var System = require('dw/system/System');
    var Transaction = require('dw/system/Transaction');
    var ocapiSettings = require('*/cartridge/config/ocapiSettings');
    logCategory = logCategory || 'ocapi-internal';

    var currentAccessToken = getAccessToken();

    var ocapiService = LocalServiceRegistry.createService("OCAPI-internal", {
        createRequest: function(svc, args) {
            svc.setRequestMethod("PATCH");
            svc.addHeader('Content-Type', 'application/json;charset=UTF-8');
            svc.addHeader('Authorization', 'Bearer ' + currentAccessToken);

            return JSON.stringify(body);
        },
        parseResponse: function(svc, client) {
            return client.text;
        },
        filterLogMessage: function(msg) {
            return msg;
        }
    });
    // var instanceTypes = Site.getCurrent().getCustomPreferenceValue("hav_PDInstanceTypes");
    if (instanceTypes) {
        var baseUrl = "https://" + System.getInstanceHostname() + ocapiService.URL;
        for (var i = 0, len = instanceTypes.length; i < len; i++) {
            ocapiService.URL = baseUrl + "global_preferences/preference_groups/" + ocapiSettings.globalPrefsGroup + "/" + instanceTypes[i];
            var result;
            Transaction.wrap(function () {
                result = ocapiService.call();
            });
            if (!result.ok) {
                Logger.getLogger(logCategory, logCategory).warn('Failed on saving settings for instance group {0}. Error message: {1}', instanceTypes[i], result.errorMessage);
            }
            else {
                Logger.getLogger(logCategory, logCategory).info('Successfully saved settings for instance type {0}.', instanceTypes[i]);
            }
        }
    }
}

module.exports = {
    saveCustomPreferences: saveCustomPreferences,
    saveGlobalCustomPreferences: saveGlobalCustomPreferences,
    getOCAPIService: getOCAPIService
};
