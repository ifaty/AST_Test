/**
 * TODO: Refactoring this file into Factory and Model.
 *
 * This file should actually be implemented through a Factory to comply to SFRA's model architecture.
 * Specifically, getColorSpecification shouldn't even exist be the public construction method provided by the Factory to create Color Matrix models.
 * Thus, checking conditions such as "isFixedTone" and applying their required modifications should be delegated to decorators.
 *
 * For instance, one would call
 *      ColorMatrixFactory.get({<color options>}, {<context options>}) // Which would replace getColorSpecification
 * and get a ColorMatrix model (replacing getColorMatrix()) instance with properties defined by <color options> and <context options>.
 * This way we wouldn't delegate so much responsability to a single helper method.
 */


var {DEFAULT_COLORS, DEFAULT_VARIATION_COLORS} = require('*/cartridge/config/defaultColorMatrixColors');

var Logger = require('dw/system/Logger');

/**
 * This function returns the fallback tone in case we need it.
 * Basically, it returns a darker tone if it exists or a lighter one if not.
 * @param {[string]} toneLevel 
 */
function getFallbackTone(toneLevel) {
    var System = require('dw/system/System');
    var OrgPreferences = System.getPreferences().getCustom();

    var siteTones = JSON.parse(OrgPreferences['hav_colorMatrix_' + 'toneIndex']);
    var toneIndex = siteTones.indexOf(toneLevel) || 1;

    return toneIndex + 1 < siteTones.length ? siteTones[toneIndex + 1] : siteTones[toneIndex - 1];
}

function getUpTone(toneLevel) {
    var System = require('dw/system/System');
    var OrgPreferences = System.getPreferences().getCustom();

    var siteTones = JSON.parse(OrgPreferences['hav_colorMatrix_' + 'toneIndex']);
    var toneIndex = siteTones.indexOf(toneLevel) || 1;

    return toneIndex - 1 > 0 ? siteTones[toneIndex - 1] : siteTones[toneIndex + 1];
}

/**
 * Receives up to two colors and two tones and search a color specification in the color matrix.
 * The parameters received are color custom attributes defined in {dw.catalog.Product}.
 * @param {string} primaryColor - obligatory
 * @param {[string]} primaryColorTone - optional
 * @param {[string]} secondaryColor - optional
 * @param {[string]} secondaryColorTone  - optional
 * @returns {Object|string} returns an object containing the color specification or the error message.
 */
function getColorMatrix(primaryColor, primaryColorTone, secondaryColor, secondaryColorTone) {
    var Resource = require('dw/web/Resource');
    var System = require('dw/system/System');
    var OrgPreferences = System.getPreferences().getCustom();

    if (empty(primaryColor) || typeof primaryColor !== 'string') {
        throw new ReferenceError(Resource.msg('error.color.primarycolornotprovided', 'colorMatrix', 'null'));
    }

    var attributes = {
        primaryColor: primaryColor.toLowerCase(),
        primaryColorTone: primaryColorTone ? primaryColorTone.toLowerCase() : null,
        secondaryColor: secondaryColor ? secondaryColor.toLowerCase() : null,
        secondaryColorTone: secondaryColorTone ? secondaryColorTone.toLowerCase() : null
    }

    var colorMatrix = JSON.parse(OrgPreferences['hav_colorMatrix_' + attributes.primaryColor]);

    if (empty(colorMatrix))
        throw new ReferenceError(Resource.msg('error.color.primarycolornotfound', 'colorMatrix', null));

    colorMatrix = secondaryColor ?
        colorMatrix[attributes.secondaryColor] :
        colorMatrix[attributes.primaryColor];

    if (empty(colorMatrix))
        throw new ReferenceError(Resource.msg('error.color.complementarycolornotfound', 'colorMatrix', null));

    return colorMatrix;
}

/**
 * Receives up to two colors and two tones and search a color specification in the color matrix.
 * The parameters received are color custom attributes defined in {dw.catalog.Product}.
 * @param {string} primaryColor - obligatory
 * @param {[string]} primaryColorTone - optional
 * @param {[string]} secondaryColor - optional
 * @param {[string]} secondaryColorTone  - optional
 * @param {Object} options - optional
 * @returns {Object|string} returns an object containing the color specification or the error message.
 */
function getColorSpecification(primaryColor, primaryColorTone, secondaryColor, secondaryColorTone, options) {
    var Resource = require('dw/web/Resource');
    var System = require('dw/system/System');
    var OrgPreferences = System.getPreferences().getCustom();
    options = options || {};

    if (empty(primaryColor) || typeof primaryColor !== 'string') {
        Logger.warn(Resource.msg('error.color.primarycolornotprovided', 'colorMatrix', 'null'));
        return DEFAULT_COLORS;
    }

    var attributes = {
        primaryColor: primaryColor.toLowerCase(),
        primaryColorTone: primaryColorTone ? primaryColorTone.toLowerCase() : null,
        secondaryColor: secondaryColor ? secondaryColor.toLowerCase() : null,
        secondaryColorTone: secondaryColorTone ? secondaryColorTone.toLowerCase() : null
    }

    var siteTones = JSON.parse(OrgPreferences['hav_colorMatrix_' + 'toneIndex']);

    var toneLevel = empty(secondaryColorTone) ?
        attributes.primaryColorTone || 'regular' :
        attributes.secondaryColorTone;

    /* Fallback to avoid wrong values set in the color tones */
    toneLevel = siteTones.indexOf(toneLevel) >= 0 ? toneLevel : 'regular';

    if (options.productColors) {
        toneLevel = getFallbackTone(toneLevel);
    }

    // This option is not currently being used but will be as soon as HAVECOM-488 is ready.
    if (options.modal) {
        toneLevel = getFallbackTone(toneLevel);
    }

    if (options.variationColor) {
        toneLevel = getUpTone(toneLevel);
    }

    try {
        var colorMatrix = getColorMatrix(primaryColor, primaryColorTone, secondaryColor, secondaryColorTone);
    } catch (error) {
        Logger.warn(Resource.msg('error.color.primarycolornotfound', 'colorMatrix', null));
        return DEFAULT_COLORS;
    }

    var correctColorMatrix = colorMatrix[toneLevel];
    correctColorMatrix.offwhite = getOffwhiteColor(colorMatrix);
    return correctColorMatrix;
}

/**
 * Returns 'offwhite' color as specified - ultralight background.
 * @param {Object} colorMatrix - The color matrix in question.
 */
function getOffwhiteColor(colorMatrix) {
    return colorMatrix['ultralight'].background;
}

/**
 * Receives an order by param and returns an object containing the color definitions
 * of a product selected following certain set of rules of priority.
 * @param {dw.order.Order | dw.util.Collection} order 
 * @returns {Object} with the higher priority product's color definition available
 */
function getProductColorByPriority(obj) {
    var Site = require('dw/system/Site');
    var Collection = require('dw/util/Collection');
    var collections = require('*/cartridge/scripts/util/collections');
    var priorityLine = Site.current.getCustomPreferenceValue('hav_productTypePriority') ||
        ['thematic-flip-flop', 'flip-flop', 'shoe', 'cloth'];

    var productLineItems = obj instanceof Collection ? obj : obj.getAllProductLineItems();
    var productTypes = [];
    collections.forEach(productLineItems, function (productLineItem) {
        var product = productLineItem.getProduct();

        if (product)
            productTypes.push({
                product: product,
                type: product.custom.hav_productType || ''
            });
    });
    
    if(empty(productTypes)){
        return null;
    }

    var correspondentTypes = productTypes.filter(function (product) {
        return priorityLine.indexOf(product.type.toLowerCase()) !== -1;
    });

    /**
     * Due to how the color matrix works, we CANNOT use random products.
     * Since we render a color matrix div on separate pages, it's expected that they have the same hex values.
     * Using random products, we aren't able to guarantee that property.
     * If eventually we find a way to solve this (i.e. a convoluted way to pass color matrix state), we may return to using random products.
     */

    if (empty(correspondentTypes)) {
        var randomProduct = productTypes[0].product;
        return {
            productId: randomProduct.ID,
            primaryColor: randomProduct.custom.hav_primaryColor,
            primaryColorTone: randomProduct.custom.hav_primaryColorTone,
            secondaryColor: randomProduct.custom.hav_secondaryColor,
            secondaryColorTone: randomProduct.custom.hav_secondaryColorTone
        }
    }

    var smallerIndexAvailable = correspondentTypes.reduce(function (record, product) {
        return priorityLine.indexOf(product.type.toLowerCase()) < record ?
            priorityLine.indexOf(product.type.toLowerCase()) :
            record;
    }, correspondentTypes.length);

    var prioritizedItems = correspondentTypes.filter(function (product) {
        return priorityLine.indexOf(product.type.toLowerCase()) == smallerIndexAvailable;
    });

    var randomProduct = prioritizedItems[0].product;

    return {
        productId: randomProduct.ID,
        primaryColor: randomProduct.custom.hav_primaryColor,
        primaryColorTone: randomProduct.custom.hav_primaryColorTone,
        secondaryColor: randomProduct.custom.hav_secondaryColor,
        secondaryColorTone: randomProduct.custom.hav_secondaryColorTone
    };
}

/**
 * @returns {Object} returns default colors to use as fallback
 */
function getDefaultColors() {
    return DEFAULT_COLORS;
}

/**
 * Receives up to two colors and primary color tone and search product variations color specification in the color matrix.
 * The parameters received are color custom attributes defined in {dw.catalog.Product}.
 * @param {string} primaryColor - mandatory
 * @param {string} primaryColorTone - oprtional
 * @param {string} secondaryColor  - optional
 * @returns {Object|string} return an object containing the color specification or an error code
 */
function getVariationColorMatrix(primaryColor, primaryColorTone, secondaryColor) {
    var Resource = require('dw/web/Resource');
    var System = require('dw/system/System');
    var OrgPreferences = System.getPreferences().getCustom();

    var primaryColorOppositeTone = getOppositeTone(primaryColorTone || 'regular');

    var orderedColorMatrix = OrgPreferences['hav_colorMatrix_colorOrder'].split(",");
    var i = 0;
    for (i; i < orderedColorMatrix.length; i++) {
        if (orderedColorMatrix[i] == secondaryColor) {
            if(i == orderedColorMatrix.length - 1){
                break;
            }
            i++;
            break;
        }
    }
    try {
        var nextColorMatrix = getColorMatrix(primaryColor, null, orderedColorMatrix[i], null);

        var colorMatrix = getColorMatrix(primaryColor, null, secondaryColor, null);
    } catch (error) {
        Logger.warn(Resource.msg('error.color.primarycolornotfound', 'colorMatrix', null));
        return DEFAULT_VARIATION_COLORS;
    }
    var variationColorMatrix = {
        gradientFirstColors: colorMatrix[primaryColorOppositeTone],
        gradientSecondColors: nextColorMatrix[primaryColorOppositeTone]
    }

    return variationColorMatrix;
}

/**
 * Receives an tone specified in custom preferences.
 * @param {string} tone - mandatory
 * @returns {string} Return an string that represent the opposite tone
 */
function getOppositeTone(tone) {
    var oppositeTone;
    switch (tone) {
        case "ultralight":
            oppositeTone = "regular";
            break;
        case "lighter":
            oppositeTone = "dark";
            break;
        case "light":
            oppositeTone = "darker";
            break;
        case "regular":
            oppositeTone = "ultralight";
            break;
        case "dark":
            oppositeTone = "lighter";
            break;
        case "darker":
            oppositeTone = "light";
            break;
        default:
            oppositeTone = "ultralight";
            break;
    }
    return oppositeTone;
}

/**
 * Receives up to two colors and two tones and search a color specification in the color matrix.
 * The parameters received are color custom attributes defined in {dw.catalog.Product}.
 * Applies both getColorSpecification and getVariationColorMatrix, merging the results.
 * @param {string} primaryColor - obligatory
 * @param {[string]} primaryColorTone - optional
 * @param {[string]} secondaryColor - optional
 * @param {[string]} secondaryColorTone  - optional
 * @param {Object} adjacentColors - optional, properties which should be with the result.
 * @param {Object} fixedTone - optional, whether or not to do tone juggling and whether or not to darken colors (product)
 */
function get (primaryColor, primaryColorTone, secondaryColor, secondaryColorTone, adjacentColors, options) {
    var objectHelper = require('*/cartridge/scripts/helpers/objectHelper');

    var principalColorSpecification =
        getColorSpecification(primaryColor, primaryColorTone, secondaryColor, secondaryColorTone, options);

    var fallbackColorSpecification =
        getColorSpecification(primaryColor, getFallbackTone(primaryColorTone || 'regular'), secondaryColor, getFallbackTone(secondaryColorTone || 'regular'), options);

    var variationColors = getVariationColorMatrix(primaryColor, primaryColorTone, secondaryColor);

    var response = {
        colors : principalColorSpecification,
        fallbackColors : fallbackColorSpecification
    };

    if (adjacentColors)
        adjacentColors.primaryColor = primaryColor;

    objectHelper.assign(response.colors, adjacentColors) ;
    objectHelper.assign(response, variationColors);

    response.toJSON = function () {
        var result = {}
        Object.getOwnPropertyNames(response)
            .forEach(function (propertyName) {
                var value = response[propertyName]
                if (value !== undefined && typeof value !== 'function') {
                    result[propertyName] = JSON.stringify(value);
                }
            });
        return result;
    };

    return response;
}

module.exports = {
    get: get,
    getProductColorByPriority: getProductColorByPriority,
    getDefaultColors: getDefaultColors,
    getColorSpecification: getColorSpecification,
    getVariationColorMatrix: getVariationColorMatrix,
    getFallbackTone: getFallbackTone
}