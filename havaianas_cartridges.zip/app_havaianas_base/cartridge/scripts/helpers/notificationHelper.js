'use strict';

function addEmailToNotificationList(config) {
    var Transaction = require('dw/system/Transaction');
    var CustomObjectMgr = require('dw/object/CustomObjectMgr');
    var notifyEntry = config.email + '|' + config.locale;
    var notifyConfigurations = {
        customObjectID: config.customObjectID,
        errorLogCategory: config.errorLogCategory
    };

    var response = {
        success: true,
        errorMsg: ''
    };

    try {
        Transaction.wrap(function() {
            var notificationObject = 
                CustomObjectMgr.getCustomObject(notifyConfigurations.customObjectID, config.customObjectInstance) ||
                CustomObjectMgr.createCustomObject(notifyConfigurations.customObjectID, config.customObjectInstance) ;

            var notificationObject = notificationObject.getCustom();
            var emailList = JSON.parse(notificationObject.emailList || '[]');
            emailList.push(notifyEntry);
            notificationObject.emailList = JSON.stringify(emailList);
        });
    } catch (e) {
        var Logger = require('dw/system/Logger');
        var { errorLogCategory } = notifyConfigurations;
        if (!empty(errorLogCategory)) {
            Logger = Logger.getLogger(errorLogCategory);
        }

        var errorMsg = Resource.msgf(
            'error.product.notify.customobject.notfound',
            'technical',
            null,
            notifyConfigurations.customObjectID
        );
        Logger.warn(errorMsg);
        response = {
            success: false,
            errorMsg: errorMsg
        };
    }

    return response;
}

module.exports = {
    addEmailToNotificationList: addEmailToNotificationList
}