'use strict';

/**
 * This function splits a space separated list of names into first and last names. 
 * If there's only a single name on the list (e.g. Asian names), we return an first and last name as the same thing.
 * @param {string} name Name to be split into first and last names.
 * @return {JSON} Object with first and last name attributes.
 */
function splitNames (name) {
    var firstName;
    var lastName;

    // The code below isn't accounting for all cases.
    var splitNames = name.replace(/\s+/g,' ').trim().split(' ');
    if (splitNames.length > 0) { // Probably a western name.
        firstName = splitNames[0];
        lastName = splitNames[splitNames.length - 1];
    }
    else { // Fallback for non-western names.
        firstName = splitNames[0];
        lastName = firstName;
    }
    return {
        firstName: firstName,
        lastName: lastName
    };
}

module.exports = {
    splitNames: splitNames
}
