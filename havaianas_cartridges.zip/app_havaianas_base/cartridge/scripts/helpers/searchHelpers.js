'use strict';

var searchHelpersBase = module.superModule;

var preferences = require('*/cartridge/config/preferences');
var DEFAULT_PAGE_SIZE = preferences.defaultPageSize ? preferences.defaultPageSize : 12;
var COLOR_REFINEMENT_ID = 'hav_colorset';

/**
 * Set search configuration values
 *
 * @param {dw.catalog.ProductSearchModel} apiProductSearch - API search instance
 * @param {Object} params - Provided HTTP query parameters
 * @return {dw.catalog.ProductSearchModel} - API search instance
 */
function setupStorySearch(apiProductSearch, pageId) {
    var ArrayList = require('dw/util/ArrayList');
    var shopModeHelper = require('*/cartridge/scripts/helpers/shopModeHelper');

    var storyProductList = shopModeHelper.getProductList(pageId);
    var a = new ArrayList();
    storyProductList.forEach(function (e) {
        a.push(e);
    });
    apiProductSearch.setProductIDs(a);
    apiProductSearch.setCategoryID('root');

    return apiProductSearch;
}

function generateClearUrls(refineurl, req, productSearch) {
    var Logger = require('dw/system/Logger');
    var clearUrls = {};
    var whitelistedParams = {'pmin':'priceMax', 'pmax':'priceMin'};

    if (productSearch.isCategorySearch) {
        var tmp = refineurl;
        clearUrls.clearCategoryUrl = refineurl.remove('cgid');
    }

    try {
        // Preferences
        if (req.querystring.preferences) {
        var i = 1;
            Object.keys(req.querystring.preferences).forEach(function (preference) {
                var tmp = refineurl;
                tmp.remove('prefn' + i);
                tmp.remove('prefv' + i);
                i++;
                clearUrls[preference] = tmp;
            });
        }
        Object.keys(whitelistedParams).forEach(function (e) {
            var tmp = refineurl;
            tmp.remove(whitelistedParams[e]);
            clearUrls[whitelistedParams[e]] = tmp;
        });
    } catch (error) {
        Logger.error('Error generating clear filter URLs: ' + error.stack);
    }
    

    return clearUrls;
}

function getClearCategoryUrl(viewData, pageId) {
    var QueryString = require('server').querystring;
    var URLUtils = require('dw/web/URLUtils');
    var urlHelper = require('*/cartridge/scripts/helpers/urlHelpers');

    var params = viewData.refineurl.toString().split('?')[1];
    var querystring = new QueryString(params);
    delete querystring.cgid;
    var url;
    if (querystring.preferences || querystring.onSale) { 
        url = URLUtils.url('Search-Show').toString() + '?' + querystring.toString();
    }
    else if (!empty(pageId)) {
        url = URLUtils.url('Page-Show', 'cid', pageId);
    }
    else {
        url = URLUtils.url('Search-Show', 'cgid', 'root');
    }
    return url;
}

function getFirstProductColors(viewData) {
    var ProductMgr = require('dw/catalog/ProductMgr');
    var colorMatrixHelper = require('*/cartridge/scripts/helpers/colorMatrixHelper');
    
    var colorMatrix;
    var firstProductId;

    if (viewData.showResults) {
        firstProductId = viewData.productSearch.productIds[0].productID;
    }
    else if (viewData.otherProductsSearch && viewData.otherProductsSearch.productIds.length > 0) {
        firstProductId = viewData.otherProductsSearch.productIds[0].productID;
    }
    var product = ProductMgr.getProduct(firstProductId);
    try {
        colorMatrix = colorMatrixHelper.getColorSpecification(
            product.custom.hav_primaryColor,
            product.custom.hav_primaryColorTone,
            product.custom.hav_secondaryColor,
            product.custom.hav_secondaryColorTone
        );
    } catch (e) {
        // TODO: add default colors
    }

    return colorMatrix;
}

function getClearAllUrl() {
    var URLUtils = require('dw/web/URLUtils');
    return URLUtils.url('Search-Show', 'cgid', 'root');
}

function getClearAllColorsObj(querystring) {
    var URLUtils = require('dw/web/URLUtils');
    var QueryString = require('server').querystring;
    var newQuerystring = new QueryString(querystring.toString());
    if (newQuerystring.preferences) {
        delete newQuerystring.preferences[COLOR_REFINEMENT_ID];
    }
    delete newQuerystring.ajax;
    var keys = Object.keys(newQuerystring);
    var url;
    if (newQuerystring.cgid) {
        url = URLUtils.url('Search-Show', 'cgid', newQuerystring.cgid);
        delete newQuerystring.cgid;
        if (keys.length > 1) {
            url = url + (url.toString().indexOf('?') > -1 ? '&' : '?') + newQuerystring.toString();
        }
    }
    else {
        url = URLUtils.url('Search-Show') + '?' + newQuerystring.toString();
    }

    return {
        url: url,
        prefNumber: Object.keys(newQuerystring.preferences || {}).length + 1
    };
}

function getRefineUrl(querystring) {
    var URLUtils = require('dw/web/URLUtils');
    var QueryString = require('server').querystring;
    var newQuerystring = new QueryString(querystring.toString());
    delete newQuerystring.ajax;
    if (newQuerystring.cgid) {
        url = URLUtils.url('Search-Show', 'cgid', newQuerystring.cgid);
        delete newQuerystring.cgid;
        url = url + (url.toString().indexOf('?') > -1 ? '&' : '?') + newQuerystring.toString();
    }
    else {
        url = URLUtils.url('Search-Show') + '?' + newQuerystring.toString();
    }
    return url;
}

function getLocalizedSelectedColors(querystring) {
    var Resource = require('dw/web/Resource');
    if (!querystring.preferences || !querystring.preferences[COLOR_REFINEMENT_ID]) {
        return [];
    }

    var colors = [];
    var prefColors = querystring.preferences[COLOR_REFINEMENT_ID] || '';
    prefColors.split('|').forEach(
        function (e) {
            colors.push(Resource.msg(
                ['label.refinement', COLOR_REFINEMENT_ID, e].join('.'),
                'search',
                e
            ))
        }
    );
    return colors;
}

function getCustomPriceRefinementObject(params) {
    var URLUtils = require('dw/web/URLUtils');
    var obj = {};

    obj.show = params.customPrice ? true : false;
    if (!obj.show) {
        params.pmin = 0;
        params.pmax = 0;
        params.customPrice = true;
    }
    else {
        obj.valueTo = params.pmax;
        delete params.pmin;
        delete params.pmax;
        delete params.customPrice;
    }
    obj.url = URLUtils.url('Search-Show') + '?' + params.toString();

    return obj;
}

function getOnSaleRefinementObject(params) {
    var URLUtils = require('dw/web/URLUtils');
    var Resource = require('dw/web/Resource');

    var obj = {};
    obj.selected = params.onSale;
    if (params.onSale) {
        delete params.onSale;
    }
    else {
        params.onSale = true;
    }
    obj.url = Object.keys(params).length == 1 && params.pageId ? 
        URLUtils.url('Page-Show', 'cid', params.pageId) : 
        URLUtils.url('Search-Show') + '?' + params.toString();
    obj.displayValue = Resource.msg('label.filter.onsale', 'shopMode', null);
    obj.onSaleRefinement = true;
    return obj;
}

function setupOnSaleSearch(apiProductSearch, querystring) {
    var PromotionMgr = require('dw/campaign/PromotionMgr');
    var ArrayList = require('dw/util/ArrayList');
    var collections = require('*/cartridge/scripts/util/collections');
    
    var productPromotionIds = new ArrayList();

    if (querystring.onSale) {
        var productPromotions= PromotionMgr.activeCustomerPromotions.getProductPromotions();

        collections.forEach(productPromotions, function (promo) {
            productPromotionIds.add(promo.ID);
        });

        if (!apiProductSearch.refinedByCategory) {
            apiProductSearch.setCategoryID('root');
        }
    }

    apiProductSearch.setPromotionIDs(productPromotionIds.slice(0, 30));

    return apiProductSearch;
}

function searchOtherProducts(req, res, resultsLength) {
    var result = searchHelpersBase.search(req,res);
    var productSearch = result.productSearch;
    if (!productSearch) {
        return null;
    }
    var showMoreUrl = productSearch.showMoreUrl.toString();
    if (resultsLength < DEFAULT_PAGE_SIZE && !empty(showMoreUrl)) {
        showMoreUrl = showMoreUrl.replace('pageId', 'stub');
        productSearch.showMoreUrl = showMoreUrl.replace(/sz=\d+/g,'sz='+productSearch.pageSize);
    }
    return productSearch;
}

searchHelpersBase.generateClearUrls = generateClearUrls;
searchHelpersBase.getClearCategoryUrl = getClearCategoryUrl;
searchHelpersBase.getFirstProductColors = getFirstProductColors;
searchHelpersBase.getClearAllUrl = getClearAllUrl;
searchHelpersBase.getCustomPriceRefinementObject = getCustomPriceRefinementObject;
searchHelpersBase.getOnSaleRefinementObject = getOnSaleRefinementObject;
searchHelpersBase.setupOnSaleSearch = setupOnSaleSearch;
searchHelpersBase.setupStorySearch = setupStorySearch;
searchHelpersBase.searchOtherProducts = searchOtherProducts;
searchHelpersBase.getClearAllColorsObj = getClearAllColorsObj;
searchHelpersBase.getRefineUrl = getRefineUrl;
searchHelpersBase.getLocalizedSelectedColors = getLocalizedSelectedColors;
module.exports = searchHelpersBase;