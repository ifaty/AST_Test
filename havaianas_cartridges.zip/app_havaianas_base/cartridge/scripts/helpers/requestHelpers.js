'use strict';
/**
 * Returns whether the current request is AJAX or not.
 */
function isAjaxRequest () {
    return request.httpHeaders['x-requested-with'] !== null && request.httpHeaders['x-requested-with'] === 'XMLHttpRequest';
}

module.exports = {
    isAjaxRequest: isAjaxRequest
}
