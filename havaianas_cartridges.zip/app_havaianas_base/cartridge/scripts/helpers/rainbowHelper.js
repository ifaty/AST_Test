'use strict';

var COLOR_ATTRIBUTE='hav_colorset'

/**
 * @return Array contained with color configurations contained in objects, returns an empty array if
 *         there is no configuration defined.
 */
function getRainbowColors () {
    var Resource = require('dw/web/Resource');
    var obj = JSON.parse(dw.system.System.getPreferences().getCustom()['hav_rainbowColors'] || '[]');
    
    for (var i = 0, len = obj.length; i < len; i++) {
        obj[i].colorId = obj[i].colorName;
        obj[i].colorName = Resource.msg('label.refinement.' + COLOR_ATTRIBUTE + '.' + obj[i].colorName, 'search', null);
    }
    return obj;
}

/**
 * @return Array contained with color configurations contained in objects, returns an empty array if
 *         there is no configuration defined.
 */
function getLocalizedMap () {
    var Resource = require('dw/web/Resource');
    var obj = JSON.parse(dw.system.System.getPreferences().getCustom()['hav_rainbowColors'] || '[]');
    var colors = {};
    
    for (var i = 0, len = obj.length; i < len; i++) {
        var colorName = Resource.msg('label.refinement.' + COLOR_ATTRIBUTE + '.' + obj[i].colorName, 'search', null)
        colors[colorName] = obj[i].colorName;
    }
    return colors;
}

function getRainbowValue(colorValue, tone) {
    var rainbowColors = getRainbowColors();
    var value = null;
    var normalizedValue = colorValue.toLowerCase();
    rainbowColors.forEach(function (e) {
        // We have to check for color name and color ID because buckets.
        // If a bucket is configured for a certain color to have a different display name, we check for the color name, otherwise we check for the ID.
        if (e.colorName.toLowerCase() == normalizedValue || e.colorId.toLowerCase() == normalizedValue ) {
            value = e;
        }
    });
    if (tone && value) {
        return value.tones[tone.toLowerCase()]
    }
    else if (value) {
        return value.colorBackground;
    }
    else {
        return {}
    }
}

module.exports = {
    getRainbowColors: getRainbowColors,
    getRainbowValue: getRainbowValue,
    getLocalizedMap: getLocalizedMap
}
