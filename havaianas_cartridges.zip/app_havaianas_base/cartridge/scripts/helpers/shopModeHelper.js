'use strict';

var Logger = require('dw/system/Logger');

function getShopModeProductIndexCustomPref() {
    var OrgPreferences = dw.system.System.getPreferences().getCustom();
    return OrgPreferences["hav_shopModeProductIndex"];
}

function getShopModeProductIndex() {
    var customPref = getShopModeProductIndexCustomPref();
    var shopModeProductIndex = JSON.parse(customPref || '{}');

    return shopModeProductIndex;
}

function updateProductList(pageId, model) {
    var ocapiHelper = require('*/cartridge/scripts/helpers/ocapiHelper');
    var Site = require('dw/system/Site');
    var Logger = require('dw/system/Logger');

    var productIDs = getProductIDs(model);
    var shopModeProductIndex = getShopModeProductIndex();

    shopModeProductIndex[pageId] = productIDs;

    try {
        var instanceTypes = Site.getCurrent().getCustomPreferenceValue("hav_PDInstanceTypes");
        ocapiHelper.saveGlobalCustomPreferences(
            {c_hav_shopModeProductIndex: JSON.stringify(shopModeProductIndex)},
            instanceTypes,
            'page-designer');
        Logger.getLogger('page-designer', 'page-designer').info('Successfully updated shop mode index.');
    } catch (e) {
        Logger.getLogger('page-designer', 'page-designer').error('Error updating shop mode index: ' + e.stack);
    }
}

function getProductIDs(model) {
    var IDs = [];
    var components = model.regions.shop_region.region.visibleComponents;
    try {
        components.toArray().forEach(function (e) {
            IDs.push(e.getAttribute('product'));
        });
    } catch (e) {
        Logger.getLogger('page-designer', 'page-designer').error('Error returning shop mode index: ' + e.stack);
    }
    return IDs;
}

function getProductList(pageId) {
    var shopModeProductIndex = getShopModeProductIndex();

    return !empty(shopModeProductIndex[pageId]) ? shopModeProductIndex[pageId] : [];
}

module.exports = {
    updateProductList: updateProductList,
    getProductList: getProductList
};
