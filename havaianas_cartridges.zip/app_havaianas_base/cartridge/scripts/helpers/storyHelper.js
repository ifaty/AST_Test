'use strict';

var storyAttributes = require('*/cartridge/config/storyMetadataAttributes');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');
var Lock = require('*/cartridge/models/lock');


var shapeMap = {
    'Editorial': 'editorial-shape',
    'Product': 'product-shape',
    'Automatically Generated': 'automated-shape'
}

function getStorySettingsCustomPref() {
    var OrgPreferences = dw.system.System.getPreferences().getCustom();
    return OrgPreferences["hav_storySettings"];
}

function getStorySettings() {
    var customPref = getStorySettingsCustomPref();
    var storySettings = JSON.parse(customPref || '{}');

    return storySettings;
}

function saveStorySettings(pageId, settingsComponent, contentObject) {
    var ocapiHelper = require('*/cartridge/scripts/helpers/ocapiHelper');
    var Site = require('dw/system/Site');
    var Logger = require('dw/system/Logger');

    var lock = new Lock('storyDataLock');
    // We need to use a lock here to prevent this code from making too many OCAPI calls when in PD's edit mode.
    // But since we only want to execute the code _once_, we immediately exit the function if the lock is not ready from the get-go.
    lock.signal(1);
    var hadToWait = lock.wait();
    if (hadToWait) {
        lock.signal(-1);
        return;
    }

    var storySettings = getStorySettings();

    if (!settingsChanged(pageId, storySettings, settingsComponent, contentObject)) {
        return;
    }

    storySettings = updateSettings(pageId, storySettings, settingsComponent, contentObject);

    try {
        var instanceTypes = Site.getCurrent().getCustomPreferenceValue("hav_PDInstanceTypes");
        ocapiHelper.saveGlobalCustomPreferences(
            {c_hav_storySettings: JSON.stringify(storySettings)},
            instanceTypes,
            'page-designer');
        Logger.getLogger('page-designer', 'page-designer').info('Successfully updated story settings for page {0}', pageId);
    } catch (e) {
        Logger.getLogger('page-designer', 'page-designer').error('Error updating story settings: ' + e.stack);
    }
    lock.signal(-1);
}

function stringifyImgSrc(image) {
    return {
        desktop: !empty(image) && !empty(image.src) && !empty(image.src.desktop) ? image.src.desktop.toString() : "",
        desktopRetina: !empty(image) && !empty(image.src) && !empty(image.src.desktopRetina) ? image.src.desktopRetina.toString() : "",
        mobile: !empty(image) && !empty(image.src) && !empty(image.src.mobile) ? image.src.mobile.toString() : "",
        mobileRetina: !empty(image) && !empty(image.src) && !empty(image.src.mobileRetina) ? image.src.mobileRetina.toString() : ""
    };
}

function updateSettings(pageId, storySettings, settingsComponent, contentObject) {
    var Logger = require('dw/system/Logger');
    // Code to deal with story removal
    if (settingsComponent.persist == 'No') {
        storySettings = removeStory(storySettings, pageId);
        return storySettings;
    }
    // Code to add story metadata
    storySettings.stories = storySettings.stories || {};
    var pageEntry, newStory;
    if (storySettings.stories[pageId] && storySettings.stories[pageId].position) {
        pageEntry = storySettings.stories[pageId];
        newStory = false;
    }
    else {
        pageEntry = {};
        newStory = true;
    }
    storyAttributes.forEach(function (e) {
        pageEntry[e] = settingsComponent[e];
    });
    pageEntry.searchBackground = contentObject.searchBackground ? contentObject.searchBackground.file.URL.toString() : '';
    pageEntry.searchIcon = contentObject.searchIcon ? contentObject.searchIcon.file.URL.toString() : '';
    pageEntry.dateOfCreation = pageEntry.dateOfCreation ? pageEntry.dateOfCreation : new Date();
    storySettings.stories[pageId] = pageEntry;

    storySettings.shopModeIndex = storySettings.shopModeIndex ? storySettings.shopModeIndex : {};
    if (pageEntry.shopModePage) {
        storySettings.shopModeIndex[pageEntry.shopModePage] = pageId;
    }

    // This removes any deleted pages.
    // We could keep all of them in the settings object, but doing any sort of inspection would eventually get rather difficult.
    // TODO: Incorporate this into a sporadic job.
    try {
        cleanUpStorySettings(storySettings);
    } catch (e) {
        Logger.getLogger('page-designer', 'page-designer').warn('[CLEANUP] Could not clean up stories: ' + e);
    }

    // Code to sort stories
    storySettings.ordering = storySettings.ordering || [];
    var normalizedPosition = pageEntry.position - 1 < 0 ? pageEntry.position : pageEntry.position - 1; // Handling case where position in the component is 0
    var possiblePosition = storySettings.ordering.indexOf(pageId);

    if (possiblePosition === normalizedPosition) {
        return storySettings;
    }

    // If story doesn't exist in the settings
    if (newStory) {
        storySettings.ordering.push(pageId);
    }

    // If we have a new position value for the story
    if (possiblePosition !== normalizedPosition) {
        storySettings.ordering = storySettings.ordering.sort(function (a, b) {
            var storyA = storySettings.stories[a];
            var storyB = storySettings.stories[b];
            if (storyA.position - storyB.position !== 0) {
                return storyA.position - storyB.position;
            }
            else {
                return (new Date(storyA.dateOfCreation)).valueOf() - (new Date(storyB.dateOfCreation)).valueOf();
            }
        });
    }

    return storySettings;
}

/**
 * Removing every page that no longer exists in the library.
 * This is a conservative clean up, as we can't check visibility due to locale shenanigans.
 * @param {Object} storySettings
 */
function cleanUpStorySettings(storySettings) {
    var Logger = require('dw/system/Logger');
    var PageMgr = require('dw/experience/PageMgr');

    var storyIds = Object.keys(storySettings.stories);
    for (var i = 0, len = storyIds.length; i < len; i++) {
        var page = PageMgr.getPage(storyIds[i]);
        if (page == null) {
            try {
                storySettings = removeStory(storySettings, storyIds[i]);
                Logger.getLogger('page-designer', 'page-designer').info('[CLEANUP] Removed page with ID {0} from index because it no longer exists.', storyIds[i]);
            } catch (error) {
                Logger.getLogger('page-designer', 'page-designer').warn('[CLEANUP] Could not remove page with ID {0}.', storyIds[i]);
            }
        }
    }

    return storySettings;
}

/**
 * Removes a single story from the settings.
 * @param {Object} storySettings
 * @param {String} pageId
 */
function removeStory(storySettings, pageId) {
    var pageEntry = storySettings.stories[pageId];
    if (pageEntry != null) {
        delete storySettings.stories[pageId];
        if (storySettings.shopModeIndex[pageEntry.shopModePage] != null) {
            delete storySettings.shopModeIndex[pageEntry.shopModePage]
        }
    }
    storySettings.ordering = storySettings.ordering.filter(function (v, i, arr) {
        return v != pageId;
    });
    return storySettings;
}

function updateViewAllData(pageId, image, video) {
    var ocapiHelper = require('*/cartridge/scripts/helpers/ocapiHelper');
    var Site = require('dw/system/Site');
    var Logger = require('dw/system/Logger');

    // We have to wrap the operation below with semaphore signalling to avoid a quota limit exception.
    var lock = new Lock('viewAllDataLock');
    lock.signal(1);
    var hadToWait = lock.wait();
    if (hadToWait) {
        lock.signal(-1);
        return;
    }

    var storySettings = getStorySettings();
    if (!storySettings.stories || !storySettings.stories[pageId]) {
        Logger.getLogger('page-designer', 'page-designer').warn('Could not update view all settings for page {0} because there is no record of it in the settings.', pageId);
        return;
    }
    var storyEntry = storySettings.stories && storySettings.stories[pageId] ? storySettings.stories[pageId] : {};

    // storyEntry.viewAllImage = stringifyImgSrc(image);
    storyEntry.viewAllImage = image ? image.file.URL.toString() : '';

    storyEntry.viewAllVideo = !empty(video) ? video : "";
    storySettings.stories[pageId] = storyEntry;
    try {
        var instanceTypes = Site.getCurrent().getCustomPreferenceValue("hav_PDInstanceTypes");
        ocapiHelper.saveGlobalCustomPreferences(
            {c_hav_storySettings: JSON.stringify(storySettings)},
            instanceTypes,
            'page-designer');
        Logger.getLogger('page-designer', 'page-designer').info('Successfully updated view all settings for page {0}', pageId);
    } catch (e) {
        Logger.getLogger('page-designer', 'page-designer').error('Error updating story settings: ' + e.stack);
    }
    lock.signal(-1);
}

function settingsChanged(pageId, storySettings, settingsComponent, contentObject) {
    storySettings.stories = storySettings.stories || {};
    var pageEntry = storySettings.stories[pageId] || {};
    var changed = false;

    storyAttributes.forEach(function (e) {
        if (!changed && pageEntry[e] == settingsComponent[e]) {
            return;
        }
        changed = true;
    });

    return changed;
}

function viewAllDataChanged(storyInfo, image, video) {
    // TODO: fix this stub function.
    if (empty(storyInfo.viewAllImage)) {
        return true;
    }
    else {
        return storyInfo.viewAllImage != (image.file ? image.file.URL.toString() : '');
    }
}

function getStoryShape(storyType) {
    return shapeMap[storyType];
}

/**
 * Returns maybe the previous and next items in the ordering, given an active index.
 * @param {Object} options - options.previous and options.next are boolean attr. that decide whether or not we should even look for those neighbours.
 * @param {[String]} ordering - the ordering upon which we search for prev and next items.
 * @param {String} activeIdx - the target index after which we look for neighbours.
 */
function getMaybePreviousNext(options, ordering, activeIdx) {
    return {
        previous: options.previous != false && activeIdx > 0 && ordering.length > 1 ? ordering[activeIdx - 1] : null,
        next: options.next != false && activeIdx < ordering.length - 1 ? ordering[activeIdx + 1] : null
    }
}

function getStoryInfo(pageId, context) {
    var storySettings = getStorySettings();
    var storyInfo = storySettings.stories && storySettings.stories[pageId] ? storySettings.stories[pageId] : {};
    storyInfo.id = pageId;
    if (storyInfo) {
        storyInfo.shape = getStoryShape(storyInfo.type);
        storyInfo.viewAllImage = typeof storyInfo.viewAllImage == 'string' ?
            ImageTransformation.getScaledImage(storyInfo.viewAllImage, 'viewAllImage').src :
            storyInfo.viewAllImage;
        storyInfo.searchBackground = typeof storyInfo.viewAllImage == 'string' ?
            ImageTransformation.getScaledImage(storyInfo.searchBackground, 'discoveryImage').src :
            storyInfo.searchBackground;
        storyInfo.searchIcon = typeof storyInfo.viewAllImage == 'string' ?
            ImageTransformation.getScaledImage(storyInfo.searchIcon, 'shop') :
            storyInfo.searchIcon;
    }
    if (context == 'frontend') {
        delete storyInfo.position;
        delete storyInfo.dateOfCreation;
        delete storyInfo.persist;
    }
    return storyInfo;
}

function getStoryInfoFromShopmode(shopModePageId) {
    var storySettings = getStorySettings();
    var shopModeIndex = storySettings.shopModeIndex || {};
    var pageId = shopModeIndex[shopModePageId];
    if (!pageId) {
        return {};
    }
    // var storyInfo = storySettings.stories && storySettings.stories[pageId] ? storySettings.stories[pageId] : {};
    // storyInfo.id = pageId;
    return getStoryInfo(pageId);
}

function getStoryOrderingInfo(storySettings, options) {
    var PageMgr = require('dw/experience/PageMgr');
    if (!storySettings.ordering) {
        return {};
    }
    options = options ? options : {};
    var ordering = [];
    var shapes = [];
    var shopModePages = [];
    var neighbourInfo, previous, next, previousShop, nextShop;
    for (var i = 0, len = storySettings.ordering.length; i < len; i++) {
        var page = PageMgr.getPage(storySettings.ordering[i]);
        if (page && page.visible) { // Checking visibility
            ordering.push(page.ID);
            shapes.push(getStoryShape(storySettings.stories[page.ID].type));
            var currentShopModePage = storySettings.stories[page.ID].shopModePage;
            if (!empty(currentShopModePage) && shopModePages.indexOf(currentShopModePage) == -1) {
                var shopPage = PageMgr.getPage(currentShopModePage);
                if (shopPage && shopPage.visible) {
                    shopModePages.push(currentShopModePage);
                }
            }
        }
    }
    var viewMore = ordering.length > options.offset + options.pagesize;

    // The if's below would be slightly better if done inside the for loop above.
    // I decoupled them for reading sake for now.

    // This finds previous and next stories.
    var activeIdx = ordering.indexOf(options.activeId);
    if (options.activeId && activeIdx > -1) {
        neighbourInfo = getMaybePreviousNext(options, ordering, activeIdx);
        previous = neighbourInfo.previous;
        next = neighbourInfo.next;
    }

    // This finds previous and next shop modes.
    var activeShopIdx = shopModePages.indexOf(options.activeShopId);
    if (options.activeShopId && activeShopIdx > -1) {
        neighbourInfo = getMaybePreviousNext(options, shopModePages, activeShopIdx);
        previousShop = neighbourInfo.previous;
        nextShop = neighbourInfo.next;
    }

    if (!empty(options.offset) && !empty(options.pagesize)) {
        ordering = ordering.slice(options.offset, options.offset + options.pagesize);
        shapes = shapes.slice(options.offset, options.offset + options.pagesize);
        shopModePages = shopModePages.slice(options.offset, options.offset + options.pagesize);
    }
    return {
        ordering: ordering,
        shapes: shapes,
        shopModePages: shopModePages,
        viewMore: viewMore,
        previous: previous,
        next: next,
        previousShop: previousShop,
        nextShop: nextShop
    };
}

function getFirstStoryId() {
    var storySettings = getStorySettings();
    var storyOrderingInfo = getStoryOrderingInfo(storySettings);
    return storyOrderingInfo.ordering[0];
}

function getFirstShopmodeId() {
    var storySettings = getStorySettings();
    var storyOrderingInfo = getStoryOrderingInfo(storySettings);
    return storyOrderingInfo.shopModePages[0];
}

module.exports = {
    settingsComponentID: 'settings',
    saveStorySettings: saveStorySettings,
    getStorySettings: getStorySettings,
    getStoryShape: getStoryShape,
    getStoryInfo: getStoryInfo,
    getStoryOrderingInfo: getStoryOrderingInfo,
    updateViewAllData: updateViewAllData,
    viewAllDataChanged: viewAllDataChanged,
    getStoryInfoFromShopmode: getStoryInfoFromShopmode,
    getFirstStoryId: getFirstStoryId,
    getFirstShopmodeId: getFirstShopmodeId
};
