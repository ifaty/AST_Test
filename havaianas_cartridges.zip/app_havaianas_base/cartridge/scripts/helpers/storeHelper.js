'use strict';

var Site = require('dw/system/Site');
var Havaianas = Site.getCurrent();

// Util functions

var {
    getIndex
} = require('*/cartridge/scripts/helpers/indexHelper');
const store = require('../../models/store');

/**
 * 
 * @param {Object} storeTypes - stores separated by its types
 * @param {Array} priority - prority of store types, changes the position of certain store types on
 * the generated string.
 * 
 * @returns {Object} { totalOfStores<Number>, displayValue?<String>}
 */
function getResultInfo (storeTypes, priority) {
    var Resource = require('dw/web/Resource');
    var totalOfStores = 0;
    var displayValue = Object.getOwnPropertyNames(storeTypes)
        .sort(function (x, y) {
            return priority.indexOf(x) - priority.indexOf(y);
        })
        .reduce(function (displayString, storeType) {
            var amount = storeTypes[storeType];
            totalOfStores += amount;
            var nounType = amount > 1 ? 'plural' : 'singular';

            displayString.push(
                Resource.msgf(
                    'label.stores.type.' + storeType.toLowerCase() + '.' + nounType.toLowerCase(),
                    'findstore',
                    null,
                    amount
                )
            );

            return displayString;
        }, [])
        .toString()
        .split(',')
        .join(', ');

    return {
        totalOfStores: totalOfStores,
        displayValue: displayValue
    }
}

/**
 * Return a Object separating the items of storeSearch separated by its types.
 * Also defines a property indicating the closest distance(meters) in each group.
 * 
 * @param {Array} storeSearch  result of a query for stores
 * @param {Object} geolocation  { latitude<Number>, longitude<Number> }
 * 
 * @returns {Object} { [storeType]: { closestDistance<Number>, stores<Array> }, ...}
 */
function groupStoresByType (storeSearch, geolocation) {
    var StoreResult = require('*/cartridge/models/StoreResult');
 
    return storeSearch.reduce(function (acc, store) {
        var storeResult = new StoreResult(store, geolocation);
        var storeType = storeResult.type;

        if (!acc[storeType])
            acc[storeType] = {
                closestDistance: storeResult.distance.value,
                stores: [storeResult]
            }
        else {
            var storeGroup = acc[storeType];
            storeGroup.closestDistance =
                storeGroup.closestDistance < storeResult.distance ?
                    storeResult.distance :
                    storeGroup.closestDistance;

            storeGroup.stores.push(storeResult);
        }

        return acc;
    }, {});
}

/**
 * Meant to be used with a keyIterator, returns the first item from a iterator
 * that satisfies the callback. Similar to Array.prototype.find.
 * @param {dw.util.Iterator} iterator 
 * @param {Function} callback 
 * 
 * @returns - the element that matches the callback or undefined
 */
function findInKeys (iterator, callback) {
    if (!(iterator instanceof dw.util.SeekableIterator) ||
          typeof callback !== 'function')
        throw new TypeError('invalid arguments.');

    var key;
    while (iterator.hasNext()) {
        key = iterator.next();
        if (callback(key))
            return key;
    }
}

//--------------


function getGroupedMarkerInfo(index) {
    var Logger = require('dw/system/Logger');
    var findStoreLog = Havaianas.getCustomPreferenceValue('StoreLogger') || 'FindStore';

    var markerInfo = {};
    var whitelistedKeys = ['geolocation', 'storeTypes', 'storeCount', 'stores'];
    try {
        markerInfo.geolocation = index.geolocation
        markerInfo.storeCount = index.storeCount;
        markerInfo.storeTypes = index.storeTypes;
    }
    catch (e) {
        Logger
            .getLogger(findStoreLog, findStoreLog)
            .error('\nCould not retrieve marker information from index. Stack trace: {0}', e.stack);
    }
    if (index.stores) {
        markerInfo.stores = index.stores;
    }
    markerInfo.items = [];
    
    Object.keys(index).forEach(function(key) {
        if (whitelistedKeys.indexOf(key) == -1) {
            var obj = {};
            obj[key] = index[key];
            markerInfo.items.push(obj);
        }
    })
    return markerInfo;
}


/**
 * Performs a search returning an array of localities containing
 * their pertaining stores.
 * @param {String} input - whatever the user has input, e.g. "sorocaba sp"
 * @param {[Array]} merchandizeFilter? - optional merchandize filter
 * 
 * @return {Array} [{uuid, name, stores, marker}, ...]
 */
function searchLocalities (input, merchandizeFilter) {
    var UUIDUtils = require('dw/util/UUIDUtils');
    var StringUtils = require('dw/util/StringUtils');
    var Logger = require('dw/system/Logger');
    var SystemObjectMgr = require('dw/object/SystemObjectMgr');

    var typePriority = Havaianas.getCustomPreferenceValue('StoreTypePriority').split(',');

    var storeSearch = SystemObjectMgr.querySystemObjects(
        'Store',
        'name ILIKE {0} OR address2 ILIKE {0} OR city ILIKE {0} OR stateCode ILIKE {0}',
        null,
        '*'+input+'*'
    ).asList().toArray();

    if (!storeSearch.length)
        return [];
    if (storeSearch.length == 1) {
        return {
            fallback: true,
            storeId: storeSearch[0].ID
        }
    }

    if (merchandizeFilter && merchandizeFilter.length) {
        storeSearch = applyMerchandizeFilter(storeSearch, merchandizeFilter);
    }

    var localities = {};

    var findStoreLog = Havaianas.getCustomPreferenceValue('StoreLogger') || 'FindStore';
    storeSearch.forEach(function (store) {
        var locality = StringUtils.trim(store.stateCode || '');
        var storeType = store.custom.storeType

        if (!storeType || !locality) {
            Logger
                .getLogger(findStoreLog, findStoreLog)
                .error('\nStore "{0}" is missing properties, not displaying in locality search.', store.getID());
            return;
        }

        if (!localities[locality])
            localities[locality] = {}
            
        var storeTypes = localities[locality]
        storeTypes[storeType] = getIndex(locality).storeTypes[storeType];
        
    });

    return Object.getOwnPropertyNames(localities)
        .sort()
        .map(function (locality) {
            var localityInfo = getResultInfo(localities[locality], typePriority);
            try {
                return {
                    uuid: UUIDUtils.createUUID(),
                    name: locality,
                    stores: localityInfo.displayValue,
                    marker: JSON.stringify({
                        geolocation: getGroupedMarkerInfo(getIndex(locality)),
                        storeQuantity: localityInfo.totalOfStores
                    })
                }
            } catch (e) {
                Logger
                    .getLogger(findStoreLog, findStoreLog)
                    .error('\nCould not return info for locality "{0}". Stack trace: {1}', locality, e.stack);
            }
        });
}

/**
 * Performs a search for a statecode returning an array of cities containing
 * their pertaining stores.
 * @param {String} stateCode - state code, e.g. "SP"
 * @param {[Array]} merchandizeFilter? - optional merchandize filter
 * 
 * @return {Array} [{uuid, name, stores, marker}, ...]
 */
function searchCitiesFromLocality (stateCode, merchandizeFilter) {
    var UUIDUtils = require('dw/util/UUIDUtils');
    var StringUtils = require('dw/util/StringUtils');
    var HashMap = require('dw/util/HashMap');
    var Logger = require('dw/system/Logger');
    var SystemObjectMgr = require('dw/object/SystemObjectMgr');
    
    var queryMap = new HashMap();

    var typePriority = Havaianas.getCustomPreferenceValue('StoreTypePriority').split(',');

    queryMap.put('stateCode', stateCode);

    var storeSearch = SystemObjectMgr.querySystemObjects(
        'Store',
        queryMap,
        null
    ).asList().toArray();

    if (!storeSearch.length)
        return [];

    if (merchandizeFilter && merchandizeFilter.length) {
        storeSearch = applyMerchandizeFilter(storeSearch, merchandizeFilter);
    }

    var cities = {};

    var findStoreLog = Havaianas.getCustomPreferenceValue('StoreLogger') || 'FindStore';
    storeSearch.forEach(function (store) {
        var city = StringUtils.trim(store.city || '');
        var storeType = store.custom.storeType

        if (!storeType || !city) {
            Logger
                .getLogger(findStoreLog, findStoreLog)
                .error('\nStore "{0}" is missing properties, not displaying in sublocality search.', store.getID());
            return;
        }

        if (!cities[city])
            cities[city] = {}
            
        var storeTypes = cities[city]
        storeTypes[storeType] = (storeTypes[storeType] || 0) + 1
        
    });

    var curIndex = getIndex(stateCode);

    return Object.getOwnPropertyNames(cities)
        .sort()
        .map(function (city) {
            var cityInfo = getResultInfo(cities[city], typePriority);
            try {
                return {
                    uuid: UUIDUtils.createUUID(),
                    name: city,
                    stores: cityInfo.displayValue,
                    marker: JSON.stringify({
                        geolocation: getGroupedMarkerInfo(curIndex[city]),
                        storeQuantity: cityInfo.totalOfStores
                    })
                }
            } catch (e) {
                Logger
                    .getLogger(findStoreLog, findStoreLog)
                    .error('\nCould not return info for city "{0}". Stack trace: {1}', city, e.stack);
            }
        });
}

/**
 * Performs a search within a city returning an array of sublocalities containing
 * its pertaining stores.
 * @param {String} city  - city name
 * @param {String} stateCode - state code, e.g. "SP"
 * @param {[Array]} merchandizeFilter? - optional merchandize filter
 * 
 * @return {Array} [{uuid, name, stores, marker}, ...]
 */
function searchSublocalitiesFromCity (city, stateCode, merchandizeFilter) {
    var UUIDUtils = require('dw/util/UUIDUtils');
    var StringUtils = require('dw/util/StringUtils');
    var HashMap = require('dw/util/HashMap');
    var Logger = require('dw/system/Logger');
    var SystemObjectMgr = require('dw/object/SystemObjectMgr');
    
    var queryMap = new HashMap();

    var typePriority = Havaianas.getCustomPreferenceValue('StoreTypePriority').split(',');
   

    queryMap.put('city', city);
    queryMap.put('stateCode', stateCode);

    var storeSearch = SystemObjectMgr.querySystemObjects(
        'Store',
        queryMap,
        null
    ).asList().toArray();

    if (!storeSearch.length)
        return [];

    if (merchandizeFilter && merchandizeFilter.length) {
        storeSearch = applyMerchandizeFilter(storeSearch, merchandizeFilter);
    }

    var sublocalities = {};

    var findStoreLog = Havaianas.getCustomPreferenceValue('StoreLogger') || 'FindStore';
    storeSearch.forEach(function (store) {
        var sublocality = StringUtils.trim(store.address2 || '');
        var storeType = store.custom.storeType

        if (!storeType || !sublocality) {
            Logger
                .getLogger(findStoreLog, findStoreLog)
                .error('\nStore "{0}" is missing properties, not displaying in sublocality search.', store.getID());
            return;
        }

        if (!sublocalities[sublocality])
            sublocalities[sublocality] = {}
            
        var storeTypes = sublocalities[sublocality]
        storeTypes[storeType] = (storeTypes[storeType] || 0) + 1
        
    });

    var curIndex = getIndex(stateCode);
    var sublocationData = curIndex[city] || {};

    return Object.getOwnPropertyNames(sublocalities)
        .sort()
        .map(function (sublocality) {
            var sublocalityInfo = getResultInfo(sublocalities[sublocality], typePriority);
            try {
                return {
                    uuid: UUIDUtils.createUUID(),
                    name: sublocality,
                    stores: sublocalityInfo.displayValue,
                    marker: JSON.stringify({
                        geolocation: sublocationData[sublocality],
                        storeQuantity: sublocalityInfo.totalOfStores
                    })
                }
            } catch (e) {
                Logger
                    .getLogger(findStoreLog, findStoreLog)
                    .error('\nCould not return info for sublocality "{0}". Stack trace: {1}', sublocality, e.stack);
            }
        });
}

/**
 * @param {Object} location - {sublocality?, city, stateCode}
 * @returns {Boolean}
 */
function hasStoreInAddress (address) {
    var SystemObjectMgr = require('dw/object/SystemObjectMgr');
    var HashMap = require('dw/util/HashMap');
    var queryMap = new HashMap();

    if (address.sublocality)
        queryMap.put('address2', address.sublocality);
    queryMap.put('city', address.city);
    queryMap.put('stateCode', address.stateCode);

    var storeSearch = SystemObjectMgr.querySystemObjects(
        'Store',
        queryMap,
        null
    )

    return storeSearch.hasNext();
}

/**
 * Queries the cities that match a certain RegExp based on the input parametrized.
 * @param {String} input 
 * @returns {Array} [ { city, stateCode, displayValue }?, ... ]
 */
function getSuggestions (input) {
    var Resource = require('dw/web/Resource');
    var SystemObjectMgr = require('dw/object/SystemObjectMgr');
    var URLUtils = require('dw/web/URLUtils');

    var cityMaxSuggestions = Havaianas.getCustomPreferenceValue('StoreCityMaxSuggestions') || 5;

    var storeSearch = SystemObjectMgr.querySystemObjects(
        'Store',
        'name ILIKE {0} OR address2 ILIKE {0} OR city ILIKE {0} OR stateCode ILIKE {0}',
        null,
        '*'+input+'*'
    )

    var prevSuggestions = [];
    var suggestions = [];
    var store;
    while (storeSearch.hasNext()) {
        store = storeSearch.next();
        if (store.address2 && prevSuggestions.indexOf(store.address2) == -1) {
            prevSuggestions.push(store.address2);
            suggestions.push({
                type: 'sublocality',
                url: URLUtils.url('Stores-Get', 'location', store.address2 + ',' + store.city + ',' + store.stateCode),
                displayValue: Resource.msgf('text.stores.location.suggestion.sublocality', 'findstore', null, store.address2, store.city, store.stateCode)
            });
        }
        if (store.city && prevSuggestions.indexOf(store.city) == -1) {
            prevSuggestions.push(store.city);
            suggestions.push({
                type: 'city',
                url: URLUtils.url('Stores-GetSublocalities', 'location', store.city + ',' + store.stateCode),
                displayValue: Resource.msgf('text.stores.location.suggestion.city', 'findstore', null, store.city, store.stateCode)
            });
        }
        if (store.stateCode && prevSuggestions.indexOf(store.stateCode) == -1) {
            prevSuggestions.push(store.stateCode);
            suggestions.push({
                type: 'locality',
                url: URLUtils.url('Stores-GetCities', 'location', store.stateCode),
                displayValue: Resource.msgf('text.stores.location.suggestion.locality', 'findstore', null, store.stateCode)
            });
        }
        suggestions.push({
            type: 'store',
            url: URLUtils.url('Stores-Details', 'store', store.ID),
            displayValue: Resource.msgf('text.stores.location.suggestion.name', 'findstore', null, store.name, store.address2)
        });
        if (suggestions.length === cityMaxSuggestions)
            break;
    }

    return suggestions;
}

/**
 * Returns the presentation order represented by store types.
 * @param {Object} searchResult - Stores grouped by store types, product of storeHelper.groupStoresByType
 * @returns {Array} containing the types ordered.
 */
function getPresentationOrder (searchResult) {
    var typePriority = Havaianas.getCustomPreferenceValue('StoreTypePriority').split(',');
    var typesInResult = Object.getOwnPropertyNames(searchResult);
    typePriority = typePriority.filter(function (type) {
        return typesInResult.indexOf(type) !== -1;
    });

    var MAX_DISTANCE = 5000;

    var conceptStore = searchResult.concept;
    var labStore = searchResult.lab;
    var resellerStore = searchResult.reseller;

    if ((!conceptStore || conceptStore.closestDistance > MAX_DISTANCE)) {
        if  (labStore && labStore.closestDistance < MAX_DISTANCE) {
            var labStoreIndex = typePriority.indexOf('lab');
            if (typePriority.length > 1) {
                typePriority.splice(labStoreIndex);
                typePriority.unshift('lab');
            }
        } else if (resellerStore && resellerStore.closestDistance < MAX_DISTANCE){
            var resellerStoreIndex = typePriority.indexOf('reseller');
            if (typePriority.length > 1) {
                typePriority.splice(resellerStoreIndex);
                typePriority.unshift('reseller');
            }
        }
    }

    return typePriority;
}

function applyMerchandizeFilter (stores, merchandizeFilter) {
    var { find } = require('*/cartridge/scripts/util/array');

    var merchandizeOffered = JSON.parse(
        Havaianas.getCustomPreferenceValue('StoreMerchandizeProperties')
    );

    return stores.filter(function (store) {
        return !find(merchandizeFilter, function (filter) {
            var internalValue = merchandizeOffered[filter];
            return !store.custom[internalValue];
        })
    });
}

/**
 * Queries for stores located at the specified sublocality.
 * 
 * @param {Object} address  { sublocality<String>, city<String>, stateCode<String> }
 * @param {Number} page - defaults to 1
 * @param {[Array]} merchandizeFilter optional, chosen filters, each must me a single string.
 * @param {Object} geolocation  { latitude<Number>, longitude<Number> } - used to calculate the distances.
 */
function getStoresByAddress(address, page, merchandizeFilter, geolocation) {
    var SystemObjectMgr = require('dw/object/SystemObjectMgr');
    var HashMap = require('dw/util/HashMap');
    var storesPerPage = Havaianas.getCustomPreferenceValue('StoresPerPage') || 10;

    var queryMap = new HashMap()
   

    queryMap.put('address2', address.sublocality);
    queryMap.put('city', address.city);
    queryMap.put('stateCode', address.stateCode);

    var storeSearch = SystemObjectMgr.querySystemObjects(
        'Store',
        queryMap,
        null
    ).asList().toArray();

    if (storeSearch.length && merchandizeFilter && merchandizeFilter.length)
        storeSearch = applyMerchandizeFilter(storeSearch, merchandizeFilter);

    storeSearch = groupStoresByType(storeSearch, geolocation);

    var presentationOrder = getPresentationOrder(storeSearch);
    var offset = (page - 1) * storesPerPage;
    var paginatedResults = getItemsFromStoreSearch(storeSearch, presentationOrder, offset);

    presentationOrder = presentationOrder.filter(function (type) {
        return paginatedResults.stores[type];
    });

    return {
        paginatedResults: paginatedResults,
        presentationOrder: presentationOrder
    }
}

/**
 * Queries for stores in a radius based on the supplied geolocation.
 * The radius is configured at the site preference 'StoreSearchMaxDistance'.
 * 
 * @param {Object} geolocation { latitude<Number>, longitude<Number> }
 * @param {Number} page - defaults to 1
 * @param {Array} merchandizeFilter optional, chosen filters.
 */
function getStoresByProximity (geolocation, page, merchandizeFilter) {
    var { find } = require('*/cartridge/scripts/util/array');
    var StoreMgr = require('dw/catalog/StoreMgr');
    var distanceUnit = Havaianas.getCustomPreferenceValue('hav_distanceUnit').getValue();
    var maxDistance  = parseInt(Havaianas.getCustomPreferenceValue('StoreSearchMaxDistance'));
    var storesPerPage = Havaianas.getCustomPreferenceValue('StoresPerPage') || 10;

    if (!geolocation.latitude || !geolocation.longitude)
        return {};

    var result = StoreMgr.searchStoresByCoordinates(
        geolocation.latitude,
        geolocation.longitude,
        distanceUnit,
        maxDistance
    );

    var storeKeys = result.keySet();
    result = Object.keys(storeKeys).map(function (key) {
        return storeKeys[key];
    })

    if (result.length && merchandizeFilter && merchandizeFilter.length)
        result = applyMerchandizeFilter(result, merchandizeFilter);

    var storeSearch = groupStoresByType(result, geolocation);
    var presentationOrder = getPresentationOrder(storeSearch);

    var offset = (page - 1) * storesPerPage; 
    var paginatedResults = getItemsFromStoreSearch(storeSearch, presentationOrder, offset);

    return {
        paginatedResults: paginatedResults,
        presentationOrder: presentationOrder.filter(function (type) {
            return paginatedResults.stores[type];
        })
    }
}

function sortShippingMethodsByStores(shippingMethods, geolocation) {
    var shippingHelpers = require('*/cartridge/scripts/checkout/shippingHelpers');
    var shippingMethodInformation = require('*/cartridge/models/store/decorators/shippingMethodInformation');
    var result = [];
    var storeMap = {};
    var shippingMethodIndex = {};
    shippingMethods.forEach(function (e, idx) {
        if (e.store) {
            shippingMethodIndex[e.ID] = idx;
            result.push(e.store);
            storeMap[e.store.ID] = e.ID;
        }
    })
    var storeSearch = groupStoresByType(result, geolocation);
    var presentationOrder = getPresentationOrder(storeSearch);

    var paginatedResults = getItemsFromStoreSearch(storeSearch, presentationOrder, 0);

    presentationOrder = presentationOrder.filter(function (type) {
        return paginatedResults.stores[type];
    });

    var tmpStores;
    for (var i = 0, len = presentationOrder.length; i < len; i++) {
        var type = presentationOrder[i];
        tmpStores = paginatedResults.stores[type]
        tmpStores.forEach(function (e) {
            var sMethodId = storeMap[e.id];
            var sMethod = shippingMethods[shippingMethodIndex[sMethodId]];
            shippingMethodInformation(e, sMethod);
        });
    }

    return {
        paginatedResults: paginatedResults,
        presentationOrder: presentationOrder.filter(function (type) {
            return paginatedResults.stores[type];
        })
    }
}

/**
 * Paginates the stores.
 * 
 * @param {Array} storeSearch - product of storeHelpers.groupStoresByType
 * @param {Array} presentationOrder - the order of store types to be presented.
 * @param {Number} offset - how much stores had been displayed
 */
function getItemsFromStoreSearch (storeSearch, presentationOrder, offset) {
    var STEP_SIZE = 10;
    var typesLength = presentationOrder.length;
    var storesPassedBy = 0;

    var storeOutput = {};
    var continuationFromType;

    for(var i = 0, storesAdded = 0; i < typesLength && storesAdded < STEP_SIZE; ++i) {
        var amountToAdd = STEP_SIZE - storesAdded;
        var storeType = presentationOrder[i];
        var stores = storeSearch[storeType].stores;

        var offsetRemaining = (storesPassedBy + stores.length) - offset;
        if (offsetRemaining >= 0) {
            var startIndex = (stores.length - offsetRemaining);

            if (startIndex <= 0)
                startIndex = 0
            else {
                continuationFromType = storeType;
            }

            storeOutput[storeType] = stores.slice(startIndex, amountToAdd);
            var amountAdded = storeOutput[storeType].length;

            storesAdded += amountAdded;
        }

        storesPassedBy += stores.length;
    }

    return {
        stores: storeOutput,
        sequelFromType: continuationFromType
    }
}

function getStoreByExternalId (externalId) {
    var SystemObjectMgr = require('dw/object/SystemObjectMgr');

    var store = SystemObjectMgr.querySystemObject(
        'Store',
        'custom.externalId = {0}',
        externalId
    );

    return store;
}

module.exports = {
    getSuggestions: getSuggestions,
    getItemsFromStoreSearch: getItemsFromStoreSearch,
    getPresentationOrder: getPresentationOrder,
    getStoresByAddress: getStoresByAddress,
    getStoresByProximity: getStoresByProximity,
    getStoreByExternalId: getStoreByExternalId,
    hasStoreInAddress: hasStoreInAddress,
    searchLocalities: searchLocalities,
    searchCitiesFromLocality: searchCitiesFromLocality,
    searchSublocalitiesFromCity: searchSublocalitiesFromCity,
    sortShippingMethodsByStores: sortShippingMethodsByStores
}