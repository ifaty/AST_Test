'use strict';
var URLUtils = require('dw/web/URLUtils');
var Site = require('dw/system/Site');
var nameHelper = require('*/cartridge/scripts/helpers/nameHelper');
var emailContentHelper = require('*/cartridge/scripts/helpers/emailContentHelper');
var emailHelpers = require('*/cartridge/scripts/helpers/emailHelpers');
var emailTemplateConfig = require('~/cartridge/config/emailTemplateConfig');

function getPasswordResetToken(customer) {
    var Transaction = require('dw/system/Transaction');

    var passwordResetToken;
    Transaction.wrap(function () {
        passwordResetToken = customer.profile.credentials.createResetPasswordToken();
    });
    return passwordResetToken;
};

/**
 * Send an email that would notify the user that account was created
 * @param {dw.customer.Profile} registeredUser - object that contains user's email address and name information.
 * Created to overwrite the standard functionality of account helper's homonym function
 */
function sendCreateAccountEmail(registeredUser) {
    var name = nameHelper.splitNames(registeredUser.lastName);
    var template = 'hav_sendCreateAccountEmail';
    var localeID = request.locale;

    var dataObj = {
        name: name,
        localeID: localeID
    };

    var emailContent = {
        subject: emailContentHelper.getSubject(template),
        contentBody: emailContentHelper.getContentBody(template, dataObj),
        footer: emailContentHelper.getFooter(template, dataObj)
    };

    var emailObj = {
        to: registeredUser.email,
        subject: emailContent.subject,
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: emailHelpers.emailTypes.registration
    };

    emailHelpers.sendEmail(emailObj, 'email/emailPage', emailContent);
}

/**
 * Sends the email with password reset instructions
 * @param {string} email - email for password reset
 * @param {Object} resettingCustomer - the customer requesting password reset
 * Created to overwrite the standard functionality of account helper's homonym function
 */
function sendPasswordResetEmail(email, resettingCustomer) {
    var name = nameHelper.splitNames(resettingCustomer.profile.lastName);
    var passwordResetToken = getPasswordResetToken(resettingCustomer);
    var url = URLUtils.https('Account-SetNewPassword', 'Token', passwordResetToken);
    var template = 'hav_sendPasswordResetEmail';
    var localeID = request.locale;

    var dataObj = {
        name: name,
        passwordResetUrl: url,
        localeID: localeID
    };

    var emailContent = {
        subject: emailContentHelper.getSubject(template),
        contentBody: emailContentHelper.getContentBody(template, dataObj),
        footer: emailContentHelper.getFooter(template, dataObj)
    };

    var emailObj = {
        to: email,
        subject: emailContent.subject,
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: emailHelpers.emailTypes.passwordChanged
    };

    emailHelpers.sendEmail(emailObj, 'email/emailPage', emailContent);
};

/**
 * Send an email that would notify the user that account was edited
 * @param {dw.customer.Profile} profile - object that contains user's profile information.
 * Created to overwrite the standard functionality of account helper's homonym function
 */
function sendAccountEditedEmail(profile) {
    var name = nameHelper.splitNames(profile.lastName);
    var template = 'hav_sendAccountEditedEmail';
    var localeID = request.locale;

    var dataObj = {
        name: name,
        localeID: localeID
    };

    var emailContent = {
        subject: emailContentHelper.getSubject(template),
        contentBody: emailContentHelper.getContentBody(template, dataObj),
        footer: emailContentHelper.getFooter(template, dataObj)
    };

    var emailObj = {
        to: profile.email,
        subject: emailContent.subject,
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: emailHelpers.emailTypes.accountEdited,
        emailContent: emailContent
    };

    emailHelpers.sendEmail(emailObj, 'email/emailPage', emailContent);
};

function sendConfirmationEmail(order) {
    var name = nameHelper.splitNames(order.customerName);
    var template = 'hav_orderConfirmationCreditCard';

    var dataObj = {
        name: name,
        order: order,
        shipments: order.shipments
    };

    var emailContent = {
        subject: emailContentHelper.getSubject(template, dataObj),
        contentBody: emailContentHelper.getContentBody(template, dataObj),
        footer: emailContentHelper.getFooter(template, dataObj)
    };

    var emailObj = {
        to: order.customerEmail,
        subject: emailContent.subject,
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: emailHelpers.emailTypes.orderConfirmation
    };

    emailHelpers.sendEmail(emailObj, 'email/emailPage', emailContent);
};


/*
 * Sends the current order status to the user
 * @param {dw.order.Order} order - The current user's order
 * @param {string} status - the status passed in at each function call
 * * @param {string} voucherIdLinx - the ID of the voucher sent by Linx
 * @returns {void}
 */
function sendOrderStatusEmail(order, status) {
    var name = nameHelper.splitNames(order.customerName);
    var template = emailTemplateConfig(status);

    var dataObj = {
        name: name,
        order: order,
        shipments: order.shipments
    };

    var emailContent = {
        subject: emailContentHelper.getSubject(template, dataObj),
        contentBody: emailContentHelper.getContentBody(template, dataObj),
        footer: emailContentHelper.getFooter(template, dataObj)
    };

    var emailObj = {
        to: order.customerEmail,
        subject: emailContent.subject,
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: emailHelpers.emailTypes.accountEdited,
        emailContent: emailContent
    };

    emailHelpers.sendEmail(emailObj, 'email/emailPage', emailContent);
};

/*
 * Sends the current order payment status to the user
 * @param {dw.order.Order} order - The current user's order
 * @param {string} template - template passed in to the function call
 * @returns {void}
 */
function sendOrderPaymentStatus(order, template) {
    var name = nameHelper.splitNames(order.customerName);

    var dataObj = {
        name: name,
        order: order,
        shipments: order.shipments
    };

    var emailContent = {
        subject: emailContentHelper.getSubject(template, dataObj),
        contentBody: emailContentHelper.getContentBody(template, dataObj),
        footer: emailContentHelper.getFooter(template, dataObj)
    };

    var emailObj = {
        to: order.customerEmail,
        subject: emailContent.subject,
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: emailHelpers.emailTypes.accountEdited,
        emailContent: emailContent
    };

    emailHelpers.sendEmail(emailObj, 'email/emailPage', emailContent);
};

/*
 * Sends the current shipment status to the user 
 * @param {dw.order.Shipment} shipment - The current user's order
 * @param {dw.order.Order} shipment - The updated shipment
 * @param {string} status - the status passed in at each function call
 * @returns {void}
 */

function sendShipmentStatusEmail(order, shipment, status){
    var name = nameHelper.splitNames(order.customerName);
    var template = emailTemplateConfig(status);

    var dataObj = {
        name: name,
        order: order,
        shipments: order.shipments,
        shipment:shipment
    };

    var emailContent = {
        subject: emailContentHelper.getSubject(template, dataObj),
        contentBody: emailContentHelper.getContentBody(template, dataObj),
        footer: emailContentHelper.getFooter(template, dataObj)
    };

    var emailObj = {
        to: order.customerEmail,
        subject: emailContent.subject,
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: emailHelpers.emailTypes.accountEdited,
        emailContent: emailContent
    };

    emailHelpers.sendEmail(emailObj, 'email/emailPage', emailContent);
};

/*
 * Sends the current shipment status to the user
 * @param {dw.customer.Profile} profile - The customer's profile
 * @param {string} profuctUrl (optional) - the url of the product
 * @returns {void}
 */
function sendBackInStockNotificationEmail(profile, productUrl){
    var name = nameHelper.splitNames(profile.lastName);
    var template = 'hav_sendBackInStockNotificationEmail';

    var dataObj = {
        name: name,
    };

    var emailContent = {
        subject: emailContentHelper.getSubject(template),
        contentBody: emailContentHelper.getContentBody(template, dataObj),
        footer: emailContentHelper.getFooter(template, dataObj)
    };

    var emailObj = {
        to: profile.email,
        subject: emailContent.subject,
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: emailHelpers.emailTypes.accountEdited,
        emailContent: emailContent
    };

    emailHelpers.sendEmail(emailObj, 'email/emailPage', emailContent);
};

/*
 * Sends a notification to the customer for order pickup
 * @param {dw.order.Order} profile - The customer's profile
 * @returns {void}
 */

function sendPickupNotificationEmail(order){
    var name = nameHelper.splitNames(order.customerName);
    var template = 'hav_sendPickupNotificationEmail';
    var localeID = order.customerLocaleID;

    var dataObj = {
        name: name,
        localeID: localeID
    };

    var emailContent = {
        subject: emailContentHelper.getSubject(template),
        contentBody: emailContentHelper.getContentBody(template, dataObj),
        footer: emailContentHelper.getFooter(template, dataObj)
    };

    var emailObj = {
        to: order.customerEmail,
        subject: emailContent.subject,
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: emailHelpers.emailTypes.accountEdited,
        emailContent: emailContent
    };

    emailHelpers.sendEmail(emailObj, 'email/emailPage', emailContent);
};

function sendPurchaseVoucherEmail(order){
    var name = nameHelper.splitNames(order.customerName);
    var template = 'hav_purchaseVoucherEmail';
    var localeID = order.customerLocaleID;
    
    var dataObj = {
        name: name,
        localeID: localeID
    };

    var emailContent = {
        subject: emailContentHelper.getSubject(template),
        contentBody: emailContentHelper.getContentBody(template, dataObj),
        footer: emailContentHelper.getFooter(template, dataObj)
    };

    var emailObj = {
        to: order.customerEmail,
        subject: emailContent.subject,
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: emailHelpers.emailTypes.accountEdited,
        emailContent: emailContent
    };

    emailHelpers.sendEmail(emailObj, 'email/emailPage', emailContent);
};

module.exports = {
    sendCreateAccountEmail: sendCreateAccountEmail,
    sendPasswordResetEmail: sendPasswordResetEmail,
    sendAccountEditedEmail: sendAccountEditedEmail,
    sendOrderPaymentStatus: sendOrderPaymentStatus,
    sendOrderStatusEmail: sendOrderStatusEmail,
    sendShipmentStatusEmail: sendShipmentStatusEmail,
    sendBackInStockNotificationEmail: sendBackInStockNotificationEmail,
    sendConfirmationEmail: sendConfirmationEmail,
    sendPickupNotificationEmail: sendPickupNotificationEmail,
    sendPurchaseVoucherEmail: sendPurchaseVoucherEmail
};
