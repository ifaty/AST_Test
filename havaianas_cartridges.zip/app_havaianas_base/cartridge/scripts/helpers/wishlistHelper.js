'use strict';

var Site = require('dw/system/Site');

/**
* @return {Boolean} whether or not the wishlist plugin is enabled
*/
function isWishlistEnabled() {
    return !!Site.getCurrent().getCustomPreferenceValue("hav_enableWishlist");
}

module.exports = {
    isWishlistEnabled: isWishlistEnabled
};