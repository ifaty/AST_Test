'use strict';

var ImageModel = require('*/cartridge/models/product/productImages');
var productHelper = require('*/cartridge/scripts/helpers/productHelpers');
var productTileSwatch = require('*/cartridge/models/product/productTileSwatch');

/**
 * Get product Swatch data for a given product
 * @param {dw.catalog.Product} apiProduct - Product instance returned from the API
 * @returns {Object} - Object containing the product flags
 */
function getswatchData(product) {
    var masterProduct = !product.master ? product.getMasterProduct() : product;
    var swatchData = [];
    var ATTRIBUTE_NAME = 'color';

    //Retrieving product color from PVM
    var productVariationModel = product.getVariationModel();
    var productColorVa = productVariationModel.getProductVariationAttribute(ATTRIBUTE_NAME);
    if (!productColorVa) { // Color attribute doesn't exist
        return null;
    }
    var productColor = productVariationModel.getSelectedValue(productColorVa);

    if (masterProduct.isMaster()) {
        var variationGroups = masterProduct.variationGroups;
        for each (variationGroup in variationGroups) {
            if (!variationGroup.isVariationGroup()) {
                return false;
            } else {
                let pvm = variationGroup.getVariationModel();
                let colorVa = pvm.getProductVariationAttribute(ATTRIBUTE_NAME);
                let currentColor = pvm.getSelectedValue(colorVa);
                var isSelectedColor = currentColor.value == productColor.value ? true : false;
                let productModel = productTileSwatch(Object.create(null), variationGroup, productHelper.getProductType(variationGroup));
                swatchData.push(
                    {
                        'selected': isSelectedColor,
                        'colorName': currentColor.value,
                        'image1': !productModel.tileImages.empty ? productModel.tileImages.items[0] : null,
                        'image2': !productModel.tileImages.empty ? productModel.tileImages.items[1] : null,
                    }
                );
            }
        }
    } else {
        let productModel = productTileSwatch(Object.create(null), product, productHelper.getProductType(product));
        swatchData.push(
            {
                'selected': true,
                'colorName': productColor.value,
                'image1': !productModel.tileImages.empty ? productModel.tileImages.items[0] : null,
                'image2': !productModel.tileImages.empty ? productModel.tileImages.items[1] : null,
            }
        );
    }

    return swatchData;
}

/**
 * Retrieves the product swatch data, used in product tiles
 * @param {dw.catalog.Product} product - Product Information
 *
 * @returns {Object} - Object containing the product flags
 */
function swatchData(apiProduct) {
    var swatchData = getswatchData(apiProduct);
    return swatchData;
};

module.exports = swatchData;