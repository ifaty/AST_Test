'use strict';
var ProductSearchModel = require('dw/catalog/ProductSearchModel');

/**
 * Get product flags attributes for a given product
 * @param {dw.catalog.Product} apiProduct - Product instance returned from the API
 * @returns {Object} - Object containing the product flags
 */
function getProductFlags(product) {
    var productFlags = {};
    productFlags.isNew = !empty(product.custom.hav_productNew) ? product.custom.hav_productNew : false;
    productFlags.isKid = !empty(product.custom.hav_age) && product.custom.hav_age.toUpperCase() == 'KIDS';
    return productFlags;
}

/**
 * Retrieves the productFlags, used in product tiles
 * @param {dw.catalog.Product} product - Product Information
 *
 * @returns {Object} - Object containing the product flags
 */
function productFlags(product) {
    var productFlags = getProductFlags(product);
    return productFlags;
};

module.exports = productFlags;