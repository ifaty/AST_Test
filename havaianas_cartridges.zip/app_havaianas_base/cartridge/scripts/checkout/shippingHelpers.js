'use strict';

var shippingHelperBase = module.superModule;

var collections = require('*/cartridge/scripts/util/collections');

var ShippingModel = require('*/cartridge/models/shipping');

/**
 * Plain JS object that represents a DW Script API dw.order.ShippingMethod object
 * @param {dw.order.Basket} currentBasket - the target Basket object
 * @param {Object} customer - the associated Customer Model object
 * @param {string} containerView - view of the shipping models (order or basket)
 * @returns {dw.util.ArrayList} an array of ShippingModels
 */
function getShippingModels(currentBasket, customer, containerView, safeOptions) {
    var shipments = currentBasket ? currentBasket.getShipments() : null;

    if (!shipments) return [];

    return collections.map(shipments, function (shipment) {
        return new ShippingModel(shipment, null, customer, containerView, safeOptions);
    });
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function getEstimatedDeliveryDate(shipment) {
    return '';
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function getMinDeliveryPrice(applicableShippingMethods) {
    var shippingTypeShippingMethods = getShippingTypeShippingMethods(applicableShippingMethods);
    if (empty(shippingTypeShippingMethods)) {
        return '-';
    }
    return shippingTypeShippingMethods.reduce(function (acc, val) {
        return val.shippingCostWithoutCurrency < acc ? val : acc;
    });
}

function getPickupTypeShippingMethods(applicableShippingMethods) {
    var shippingMethods = [];
    applicableShippingMethods.forEach(function (e) {
        if (shippingHelperBase.isPickupTypeShippingMethod(e)) {
            shippingMethods.push(e);
        }
    });
    return shippingMethods;
}

function getStoresFromPickupTypeShippingMethods(applicableShippingMethods) {
    var storeHelper = require('*/cartridge/scripts/helpers/storeHelper');
    var pickupTypeShippingMethods = getPickupTypeShippingMethods(applicableShippingMethods);
    return storeHelper.sortShippingMethodsByStores(pickupTypeShippingMethods, request.geolocation);
}

function getShippingTypeShippingMethods(applicableShippingMethods) {
    var shippingMethods = [];
    applicableShippingMethods.forEach(function (e) {
        if (shippingHelperBase.isShippingTypeShippingMethod(e)) {
            shippingMethods.push(e);
        }
    });
    return shippingMethods;
}

function generateSyntheticShipmentGroups(shipments) {
    var groups = {};
    collections.forEach(shipments, function (shipment) {
        var shippingMethodId = shippingHelperBase.getSelectedShippingMethodId(shipment);
        if (shippingMethodId) {
            if (groups[shippingMethodId]) {
                groups[shippingMethodId].push(shipment.ID);
            }
            else {
                groups[shippingMethodId] = [shipment.ID];
            }
        }
    });
    return groups;
}

function allShipmentsHaveMethods(shipments) {
    var ret = true;
    collections.forEach(shipments, function (shipment) {
        if (!shippingHelperBase.getSelectedShippingMethodId(shipment)) {
            ret = false;
        }
    });
    return ret;
}

function getStoreIndicesArray(shippingModels) {
    var storeIndicesArray = [];
    var storesArray = [];
    shippingModels.forEach(function (e, idx) {
        if (!e.isPickup) {
            return;
        }
        else if (e.pickupStore && storesArray.indexOf(e.pickupStore.ID) == -1) {
            storeIndicesArray.push(idx);
            storesArray.push(e.pickupStore.ID);
        }
    });
    return storeIndicesArray;
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function clearShippingMethod(currentBasket, shipment) {
    // Currently we don't need to do anything here
    return;
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function getSelectedShippingMethodId(shipment) {
    return shipment.shippingMethodID;
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function isPickupTypeShippingMethod(shippingMethod) {
    return (shippingMethod.storePickup);
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function isShippingTypeShippingMethod(shippingMethod) {
    return (!shippingMethod.storePickup);
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function getStoreFromShippingMethod(shippingMethod) {
    var StoreMgr = require('dw/catalog/StoreMgr');

    var apiStore = StoreMgr.getStore(shippingMethod.ID);
    return apiStore;
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function getShipmentStatus(shipment) {
    return shipment.shippingStatus;
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function getShipmentStore(shipment) {
    return null;
}

shippingHelperBase.getShipmentStatus = getShipmentStatus;
shippingHelperBase.getEstimatedDeliveryDate = getEstimatedDeliveryDate;
shippingHelperBase.getMinDeliveryPrice = getMinDeliveryPrice;
shippingHelperBase.getShippingModels = getShippingModels;
shippingHelperBase.getPickupTypeShippingMethods = getPickupTypeShippingMethods;
shippingHelperBase.getShippingTypeShippingMethods = getShippingTypeShippingMethods;
shippingHelperBase.isPickupTypeShippingMethod = isPickupTypeShippingMethod;
shippingHelperBase.isShippingTypeShippingMethod = isShippingTypeShippingMethod;
shippingHelperBase.getStoreFromShippingMethod = getStoreFromShippingMethod;
shippingHelperBase.getStoresFromPickupTypeShippingMethods = getStoresFromPickupTypeShippingMethods;
shippingHelperBase.getShipmentStore = getShipmentStore;
shippingHelperBase.generateSyntheticShipmentGroups = generateSyntheticShipmentGroups;
shippingHelperBase.getSelectedShippingMethodId = getSelectedShippingMethodId;
shippingHelperBase.allShipmentsHaveMethods = allShipmentsHaveMethods;
shippingHelperBase.clearShippingMethod = clearShippingMethod;
shippingHelperBase.getStoreIndicesArray = getStoreIndicesArray;

module.exports = shippingHelperBase;