'use strict';

var checkoutHelpers = module.superModule || {};
var BasketMgr = require('dw/order/BasketMgr');
var Transaction = require('dw/system/Transaction');
var ShippingHelper = require('*/cartridge/scripts/checkout/shippingHelpers');
var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
var collections = require('*/cartridge/scripts/util/collections');

/**
 * Copies information from the shipping form to the associated shipping address
 * @param {Object} shippingData - the shipping data
 * @param {dw.order.Shipment} [shipmentOrNull] - the target Shipment
 */
function copyShippingAddressToShipment(shippingData, shipmentOrNull) {
    var currentBasket = BasketMgr.getCurrentBasket();
    var shipment = shipmentOrNull || currentBasket.defaultShipment;

    var shippingAddress = shipment.shippingAddress;

    Transaction.wrap(function () {
        if (shippingAddress === null) {
            shippingAddress = shipment.createShippingAddress();
        }

        shippingAddress.setFirstName(shippingData.address.firstName);
        shippingAddress.setLastName(shippingData.address.lastName);
        shippingAddress.setAddress1(shippingData.address.address1);
        shippingAddress.setAddress2(shippingData.address.address2);
        shippingAddress.setCity(shippingData.address.city);
        shippingAddress.setPostalCode(shippingData.address.postalCode);
        shippingAddress.setStateCode(shippingData.address.stateCode);
        var countryCode = shippingData.address.countryCode.value ? shippingData.address.countryCode.value : shippingData.address.countryCode;
        shippingAddress.setCountryCode(countryCode);
        shippingAddress.setPhone(shippingData.address.phone);
        shippingAddress.setSuite(shippingData.address.suite);
        shippingAddress.setPostBox(shippingData.address.postBox);

        if (shippingData.shippingMethod) {
            ShippingHelper.selectShippingMethod(shipment, shippingData.shippingMethod);
        }
    });
}
/**
 * Copies information from the billing form to shipping address
 * @param {Object} billingFormAddress - the billing form address
 * @param {dw.order.Shipment} [shipmentOrNull] - the target Shipment
 */
function copyBillingAddressFormToShipment(billingForshippingDatamAddress, shipmentOrNull) {
    var currentBasket = BasketMgr.getCurrentBasket();
    var shipment = shipmentOrNull || currentBasket.defaultShipment;

    var shippingAddress = shipment.shippingAddress;

    Transaction.wrap(function () {
        if (shippingAddress === null) {
            shippingAddress = shipment.createShippingAddress();
        }

        shippingAddress.setFirstName(billingForshippingDatamAddress.firstName.value);
        shippingAddress.setLastName(billingForshippingDatamAddress.lastName.value);
        shippingAddress.setAddress1(billingForshippingDatamAddress.address1.value);
        shippingAddress.setAddress2(billingForshippingDatamAddress.address2.value);
        shippingAddress.setCity(billingForshippingDatamAddress.city.value);
        shippingAddress.setPostalCode(billingForshippingDatamAddress.postalCode.value);
        shippingAddress.setStateCode(billingForshippingDatamAddress.states.stateCode.value);
        var countryCode = billingForshippingDatamAddress.countryCode ? billingForshippingDatamAddress.countryCode.value ? billingForshippingDatamAddress.countryCode.value : billingForshippingDatamAddress.countryCode : billingForshippingDatamAddress.country.value;
        shippingAddress.setCountryCode(countryCode);
        shippingAddress.setPhone(billingForshippingDatamAddress.phone.value);
        shippingAddress.setSuite(billingForshippingDatamAddress.suite.value);
        shippingAddress.setPostBox(billingForshippingDatamAddress.postBox.value);

        ShippingHelper.selectShippingMethod(shipment, billingForshippingDatamAddress.shippingMethod);
    });
}

/**
 * Copies information from the billing form to shipping address
 * @param {Object} billingFormAddress - the billing form address
 * @param {dw.order.Shipment} [shipmentOrNull] - the target Shipment
 */
function copyBillingAddressToShipment(billingAddress, shipmentOrNull) {
    var currentBasket = BasketMgr.getCurrentBasket();
    var shipment = shipmentOrNull || currentBasket.defaultShipment;

    var shippingAddress = shipment.shippingAddress;

    Transaction.wrap(function () {
        if (shippingAddress === null) {
            shippingAddress = shipment.createShippingAddress();
        }

        shippingAddress.setFirstName(billingAddress.firstName);
        shippingAddress.setLastName(billingAddress.lastName);
        shippingAddress.setAddress1(billingAddress.address1);
        shippingAddress.setAddress2(billingAddress.address2);
        shippingAddress.setCity(billingAddress.city);
        shippingAddress.setPostalCode(billingAddress.postalCode);
        shippingAddress.setStateCode(billingAddress.stateCode);
        shippingAddress.setCountryCode(billingAddress.countryCode);
        shippingAddress.setPhone(billingAddress.phone);
        shippingAddress.setSuite(billingAddress.suite);
        shippingAddress.setPostBox(billingAddress.postBox);
    });
}
/**
 * Save email inputed into currentBasket
 * @param {Object} basket - current basket
 * @param {string} email - email to be set
 */
function saveEmailInBasket(email, basket) {
    if (!basket)
        return
        
    Transaction.wrap(function () {
        basket.setCustomerEmail(email);
    });
}
/**
 * This copies the current customer name to the shipping address
 * @param {dw.order.OrderAddress} shippingAddress 
 */
function setupCustomerNameInShippingAddress(shippingAddress) {
    shippingAddress.setFirstName(session.customer.profile.lastName);
    shippingAddress.setLastName(session.customer.profile.lastName);
}

/**
 * Validate acceptance of terms of use and policy 
 * @param {Object} paymentForm - current form values
 */
function isTermsAndConditionsAccepted(paymentForm) {
    var Resource = require('dw/web/Resource');
    var result = {};
    result.error = false;
    if (!paymentForm.termsandprivacy.value) {
        var formFieldErrors = [];
        var termsandprivacyError = {};
        termsandprivacyError[paymentForm.termsandprivacy.htmlName] = Resource.msg('error.message.required', 'forms', null);
        formFieldErrors.push(termsandprivacyError);
        result.formFieldErrors = formFieldErrors;
        result.error = true;
    }
    return result;
}

//Validation can be different for each country
function validateDateOfBirth() {
    var result = {};
    return result;
}

/**
 * Save acceptance of terms
 * @param {Object} order - current order
 * @param {Object} paymentForm - current paymentForm values
 * @param {Object} req - current req object
 */
function saveTermsAcceptance(order, paymentForm, req) {
    Transaction.wrap(function () {
        order.custom.hav_termsAndPrivacyPolicy = paymentForm.termsandprivacy.value;
        if (req.currentCustomer.raw.authenticated) {
            req.currentCustomer.raw.profile.custom.hav_termsAndPrivacyPolicy = paymentForm.termsandprivacy.value;
        }
    });
}

/**
 * Splits basket into multiple shipments
 * Extracted from CheckoutShippingServices-ToggleMultiShip
 * @param {Object} req - request model
 */
function splitBasketIntoShipments(req) {
    var UUIDUtils = require('dw/util/UUIDUtils');
    var ShippingMgr = require('dw/order/ShippingMgr');
    var Site = require('dw/system/Site');
    var currentBasket = BasketMgr.getCurrentBasket();
    var shipments = currentBasket.shipments;
    var defaultShipment = currentBasket.defaultShipment;
    var defaultPostalCode = defaultShipment.shippingAddress ? defaultShipment.shippingAddress.postalCode : null;

    if (!Site.getCurrent().getPreferences().getCustom()["hav_enableMultishipping"]) {
        req.session.privacyCache.set('usingMultiShipping', false);
        return;
    }
    // split line items into separate shipments
    Transaction.wrap(function () {
        collections.forEach(shipments, function (shipment) {
            if (shipment.productLineItems.length > 1) {
                collections.forEach(shipment.productLineItems, function (lineItem) {
                    var uuid = UUIDUtils.createUUID();
                    var newShipment = currentBasket.createShipment(uuid);
                    // only true if customer is registered
                    if (req.currentCustomer.addressBook && req.currentCustomer.addressBook.preferredAddress) {
                        var preferredAddress = req.currentCustomer.addressBook.preferredAddress;
                        checkoutHelpers.copyCustomerAddressToShipment(preferredAddress, newShipment);
                    }

                    ShippingHelper.selectShippingMethod(newShipment);
                    ShippingHelper.clearShippingMethod(currentBasket, defaultShipment);
                    lineItem.setShipment(newShipment);
                    var newShippingAddress = newShipment.createShippingAddress();
                    if (defaultPostalCode) {
                        newShippingAddress.setPostalCode(shipment.shippingAddress.postalCode);
                    }
                });
            }
        });

        ShippingHelper.selectShippingMethod(defaultShipment);
        ShippingHelper.clearShippingMethod(currentBasket, defaultShipment);
        var defaultShippingAddress = defaultShipment.createShippingAddress();
        if (defaultPostalCode) {
            defaultShippingAddress.setPostalCode(defaultPostalCode);
        }

        checkoutHelpers.ensureNoEmptyShipments(req);

        ShippingMgr.applyShippingCost(currentBasket);

        basketCalculationHelpers.calculateTotals(currentBasket);
    });
}

/**
 * Merges basket shipments into a single one
 * Extracted from CheckoutShippingServices-ToggleMultiShip
 * @param {Object} req - request model
 */
function mergeBasketIntoSingleShipment(req) {
    var ShippingMgr = require('dw/order/ShippingMgr');
    var UUIDUtils = require('dw/util/UUIDUtils');
    var currentBasket = BasketMgr.getCurrentBasket();
    var shipments = currentBasket.shipments;
    var defaultShipment = currentBasket.defaultShipment;
    var defaultPostalCode = defaultShipment.shippingAddress ? defaultShipment.shippingAddress.postalCode : null;

    // combine multiple shipments into a single one
    Transaction.wrap(function () {
        collections.forEach(shipments, function (shipment) {
            if (!shipment.default) {
                collections.forEach(shipment.productLineItems, function (lineItem) {
                    lineItem.setShipment(defaultShipment);
                });
                currentBasket.removeShipment(shipment);
            }
        });

        ShippingHelper.selectShippingMethod(defaultShipment);
        ShippingHelper.clearShippingMethod(currentBasket, defaultShipment);
        var defaultShippingAddress = defaultShipment.createShippingAddress();
        if (defaultPostalCode) {
            defaultShippingAddress.setPostalCode(defaultPostalCode);
        }

        checkoutHelpers.ensureNoEmptyShipments(req);

        if (req.currentCustomer.addressBook && req.currentCustomer.addressBook.preferredAddress) {
            var preferredAddress = req.currentCustomer.addressBook.preferredAddress;
            checkoutHelpers.copyCustomerAddressToShipment(preferredAddress);
        }

        ShippingMgr.applyShippingCost(currentBasket);

        basketCalculationHelpers.calculateTotals(currentBasket);
    });
}

/**
 * Merges given shipments into a single one
 * @param {[dw.order.Shipment]} shipments - Array of shipments
 */
function mergeShipments(shipments) {
    var ShippingMgr = require('dw/order/ShippingMgr');
    var currentBasket = BasketMgr.getCurrentBasket();
    var mergedShipment = shipments[0];

    // combine multiple shipments into a single one
    Transaction.wrap(function () {
        collections.forEach(shipments, function (shipment) {
            if (shipment.ID != mergedShipment.ID) {
                collections.forEach(shipment.productLineItems, function (lineItem) {
                    lineItem.setShipment(mergedShipment);
                });
                currentBasket.removeShipment(shipment);
            }
        });

        ShippingHelper.selectShippingMethod(mergedShipment);

        ShippingMgr.applyShippingCost(currentBasket);

        basketCalculationHelpers.calculateTotals(currentBasket);
    });
}

function saveAdditionalFields(order, paymentForm) {
    var dateUtils = require('*/cartridge/config/dateUtils');
    if (!empty(paymentForm.dateofbirth)) {
        var parsedInput = dateUtils.parseDate(paymentForm.dateofbirth.value);
        var birthdayDate = new Date(parsedInput.year, parsedInput.month - 1, parsedInput.day);
        Transaction.wrap(function () {
            order.custom.hav_customerDateOfBirth = birthdayDate;
        });
    }
}

// OVERRIDE THIS AS FIT!
function treatShippingAddressOnPickup() {
    // This should be called before placing the order.
    // It can be used to treat the basket's shipments before anything happens
    // since it's called in country-specific CheckoutServices-PlaceOrder prepend points.
    return;
}

checkoutHelpers.validateDateOfBirth = validateDateOfBirth;
checkoutHelpers.saveAdditionalFields = saveAdditionalFields;
checkoutHelpers.copyBillingAddressFormToShipment = copyBillingAddressFormToShipment;
checkoutHelpers.saveTermsAcceptance = saveTermsAcceptance;
checkoutHelpers.isTermsAndConditionsAccepted = isTermsAndConditionsAccepted;
checkoutHelpers.copyShippingAddressToShipment = copyShippingAddressToShipment;
checkoutHelpers.saveEmailInBasket = saveEmailInBasket;
checkoutHelpers.setupCustomerNameInShippingAddress = setupCustomerNameInShippingAddress;
checkoutHelpers.splitBasketIntoShipments = splitBasketIntoShipments;
checkoutHelpers.mergeBasketIntoSingleShipment = mergeBasketIntoSingleShipment;
checkoutHelpers.mergeShipments = mergeShipments;
checkoutHelpers.treatShippingAddressOnPickup = treatShippingAddressOnPickup;
checkoutHelpers.copyBillingAddressToShipment = copyBillingAddressToShipment;
module.exports = checkoutHelpers;

