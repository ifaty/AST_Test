'use strict';

var cartHelpersBase = module.superModule;

var collections = require('*/cartridge/scripts/util/collections');

function unrollModel(cartModel) {
    var items = [];
    cartModel.items.forEach(function (e) {
        var amount = e.quantity;
        for (var i = 0, len = amount; i < len; i++) {
            items.push(e);
        }
    });
    cartModel.items = items;
    return cartModel;
}

cartHelpersBase.unrollModel = unrollModel;

module.exports = cartHelpersBase;