'use strict';

var orderHelpersBase = module.superModule;

var OrderMgr = require('dw/order/OrderMgr');
var Order = require('dw/order/Order');
var Resource = require('dw/web/Resource');
var URLUtils = require('dw/web/URLUtils');
var Locale = require('dw/util/Locale');

var OrderModel = require('*/cartridge/models/order');

function getOrderStatus(lineItemContainer, trackable) {
    var orderStatusConfig = require('*/cartridge/config/orderStatusConfig');

    var status = lineItemContainer.getExternalOrderStatus();
    if (empty(status)) {
        status = trackable ? 'DEFAULT' : '';
    }

    return {
        code: orderStatusConfig.storefrontMap[status],
        displayValue: orderStatusConfig.statusMap[status]
    };
}

/**
 * Returns the first productLineItem from a collection of productLineItems.
 * @param {Object} productLineItemsModel - line items model
 * @param {dw.order.LineItemCtnr} lineItemContainer - Current users's basket/order
 * @return {Object} returns an object with image properties
*/
function getFirstProductLineItem(productLineItemsModel, lineItemContainer) {
    var colorMatrixHelper = require("*/cartridge/scripts/helpers/colorMatrixHelper");
    if (productLineItemsModel) {
        var productLineItem;
        var colorMatrixInfo = colorMatrixHelper.getProductColorByPriority(lineItemContainer);
        if (!colorMatrixInfo)
            // We return an imaginary product with default colors
            // This is necessary to not break color matrix code in order tracking pages
            return {
                colorMatrix: colorMatrixHelper.getDefaultColors(),
                stub: true
            };
        productLineItemsModel.items.forEach(function (e) {
            if (e.id === colorMatrixInfo.productId) {
                productLineItem = e;
            }
        });
        return productLineItem;
    }
    return null;
}

/**
* Returns a list of orders for the current customer
* @param {Object} currentCustomer - object with customer properties
* @param {Object} querystring - querystring properties
* @param {string} locale - the current request's locale id
* @returns {Object} - orderModel of the current dw order object
* */
function getFilteredOrders(currentCustomer, querystring, locale, filter) {
    // get filtered orders for this user
    var customerNo = currentCustomer.profile.customerNo;
    var customerOrders;
    switch (filter) {
        case 'trackable':
            customerOrders = OrderMgr.searchOrders(
                'customerNo={0} AND (status={1} OR status={2})',
                'creationDate desc',
                customerNo,
                Order.ORDER_STATUS_NEW,
                Order.ORDER_STATUS_OPEN
            );
            break;
        case 'untrackable':
            customerOrders = OrderMgr.searchOrders(
                'customerNo={0} AND (status={1} OR status={2})',
                'creationDate desc',
                customerNo,
                Order.ORDER_STATUS_CANCELLED,
                Order.ORDER_STATUS_COMPLETED
            );
        default:
            break;
    }

    var orders = [];

    var filterValues = [
        {
            displayValue: Resource.msg('orderhistory.sixmonths.option', 'order', null),
            optionValue: URLUtils.url('Order-Filtered', 'orderFilter', '6').abs().toString()
        },
        {
            displayValue: Resource.msg('orderhistory.twelvemonths.option', 'order', null),
            optionValue: URLUtils.url('Order-Filtered', 'orderFilter', '12').abs().toString()
        }
    ];
    var orderYear;
    var years = [];
    var customerOrder;
    var SIX_MONTHS_AGO = Date.now() - 15778476000;
    var YEAR_AGO = Date.now() - 31556952000;
    var orderModel;

    var currentLocale = Locale.getLocale(locale);

    while (customerOrders.hasNext()) {
        customerOrder = customerOrders.next();
        var config = {
            numberOfLineItems: 'single'
        };

        orderYear = customerOrder.getCreationDate().getFullYear().toString();
        var orderTime = customerOrder.getCreationDate().getTime();

        if (years.indexOf(orderYear) === -1) {
            var optionURL =
                URLUtils.url('Order-Filtered', 'orderFilter', orderYear).abs().toString();
            filterValues.push({
                displayValue: orderYear,
                optionValue: optionURL
            });
            years.push(orderYear);
        }

        if (querystring.orderFilter
            && querystring.orderFilter !== '12'
            && querystring.orderFilter !== '6') {
            if (orderYear === querystring.orderFilter) {
                orderModel = new OrderModel(
                    customerOrder,
                    { config: config, countryCode: currentLocale.country }
                );
                orders.push(orderModel);
            }
        } else if (querystring.orderFilter
            && YEAR_AGO < orderTime
            && querystring.orderFilter === '12') {
            orderModel = new OrderModel(
                customerOrder,
                { config: config, countryCode: currentLocale.country }
            );
            orders.push(orderModel);
        } else if (SIX_MONTHS_AGO < orderTime) {
            orderModel = new OrderModel(
                customerOrder,
                { config: config, countryCode: currentLocale.country, containerView: 'order' }
            );
            orders.push(orderModel);
        }
    }

    return {
        orders: orders,
        filterValues: filterValues
    };
}

/**
 * Returns the lastest delivery date between all the shipments on the LineItemCtnr.
 * @param {dw.order.LineItemCtnr} lineItemContainer 
 * @returns
 */
function getLatestDeliveryDate(lineItemContainer) {
    var timeInMilisseconds = lineItemContainer
        .getShipments()
        .toArray()
        .map(function (shipment) {
            return shipment.custom.estimatedDeliveryDate;
        })
        .reduce(function (currentlyLastest, deliveryDate) {
            return Math.max(
                currentlyLastest,
                deliveryDate ? deliveryDate.getTime() : 0
            );
        });

    return timeInMilisseconds ? new Date(timeInMilisseconds) : null;
}

function getDeliveryDateDisplayValue (date) {
    var Resource = require('dw/web/Resource');
    var Calendar = require('dw/util/Calendar');
    var calendar = new Calendar(date);

    var displayString = Resource.msgf(
        'text.estimated.deliverydate',
        'order',
        null,
        Resource.msg('weekday.' + calendar.get(Calendar.DAY_OF_WEEK), 'order', null),
        Resource.msg('month.' + calendar.get(Calendar.MONTH), 'order', null),
        calendar.get(Calendar.DAY_OF_MONTH)
    );

    return displayString;
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function checkIfHasShippingDeliveryWaiting(lineItemContainer) {
    return false;
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function getMaxDeliveryDate(lineItemContainer, options) {
    return '';
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function getEstimatedDeliveryDate(lineItemContainer, options) {
    return '';
}

// OVERRIDE THIS FUNCTION IN THE INTEGRATION CARTRIDGE
function detectPickup(lineItemContainer) {
    try {
        return lineItemContainer.shipments[0].custom.isPickup;
    } catch (e) {
        return false
    }
}

/**
 * Returns order according by UUID.
 * @param {String} uuid
 */
function getOrderByUUID(uuid) {
    var OrderMgr = require('dw/order/OrderMgr');
    return OrderMgr.searchOrder(
        'UUID = {0}',
        uuid
    );
}

/**
 * Safely retrieves order by ID
 * @param {string} id
 * @param {Object} options 
 */
function getOrderSafelyByID(id, options) {
    return OrderMgr.getOrder(id);
}

/**
 * Gets order tracking result URL.
 * @param {req} req 
 */
function getOrderTrackingResultUrl(req) {
    return URLUtils.url('Order-Overview', 'orderNo', req.querystring.trackOrderNumber).toString()
}

/**
 * Gets order overview URL.
 * @param {req} req 
 */
function getOrderOverviewUrl(req, order) {
    if (req.querystring.orderUUID) {
        return URLUtils.url('Order-Overview', 'orderUUID', req.querystring.orderUUID).toString()
    } else {
        return URLUtils.url('Order-Overview', 'orderNo', order.orderNo).toString()
    }
}

/**
 * This is used in CheckoutServices-PlaceOrder to decide which URL we should generate.
 * @param {dw.order.Order} order
 */
function getPlaceOrderContinueUrl(order) {
    // If the order is authenticated, we can use the order number.
    if (session.customerAuthenticated) {
        return URLUtils.url('Order-Overview', 'orderNo', order.orderNo).toString()
    }
    // Otherwise we need to generate a URL with the UUID.
    else  {
        return URLUtils.url('Order-Overview', 'orderUUID', order.UUID).toString()
    }
}

/**
 * Gets order details URL.
 * @param {req} req 
 */
function getOrderDetailsUrl(req) {
    if (req.querystring.orderUUID) {
        return URLUtils.url('Order-Details', 'orderUUID', req.querystring.orderUUID).toString()
    } else {
        return URLUtils.url('Order-Details', 'orderID', req.querystring.orderNo).toString()
    }
}

/**
 * Checks if order is visible for the current user.
 * @param {dw.order.Order}
 */
function checkIfOrderIsVisible(req, order) {
    // We have to stop direct access if the user isn't authenticated.
    // Therefore, only AJAX calls done through frontend are allowed.
    var requestHelper = require("*/cartridge/scripts/helpers/requestHelpers");
    return (session.customerAuthenticated && req.currentCustomer.profile.customerNo == order.customer.profile.customerNo) 
            || requestHelper.isAjaxRequest();
}

orderHelpersBase.checkIfHasShippingDeliveryWaiting = checkIfHasShippingDeliveryWaiting;
orderHelpersBase.getMaxDeliveryDate = getMaxDeliveryDate;
orderHelpersBase.getFilteredOrders = getFilteredOrders;
orderHelpersBase.getEstimatedDeliveryDate = getEstimatedDeliveryDate;
orderHelpersBase.detectPickup = detectPickup;
orderHelpersBase.getOrderStatus = getOrderStatus;
orderHelpersBase.getFirstProductLineItem = getFirstProductLineItem;
orderHelpersBase.getOrderByUUID = getOrderByUUID;
orderHelpersBase.getOrderSafelyByID = getOrderSafelyByID;
orderHelpersBase.getOrderTrackingResultUrl = getOrderTrackingResultUrl;
orderHelpersBase.getPlaceOrderContinueUrl = getPlaceOrderContinueUrl;
orderHelpersBase.getOrderOverviewUrl = getOrderOverviewUrl;
orderHelpersBase.checkIfOrderIsVisible = checkIfOrderIsVisible;
orderHelpersBase.getOrderDetailsUrl = getOrderDetailsUrl;
module.exports = orderHelpersBase;
