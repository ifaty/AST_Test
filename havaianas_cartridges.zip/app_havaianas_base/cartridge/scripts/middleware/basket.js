'use strict';

/**
 * Applies the default expiration value for the page cache.
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
*/
function getPayButtonInfo(req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var Transaction = require('dw/system/Transaction');
    var URLUtils = require('dw/web/URLUtils');
    var CartModel = require('*/cartridge/models/cart');
    var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

    var couponHelpers = require('*/cartridge/scripts/helpers/couponHelper');
    couponHelpers.removeExternalCouponLineItems(true);
    couponHelpers.removeAllInternalCoupons();

    var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

    var viewData = res.getViewData();
    var currentBasket = BasketMgr.getCurrentBasket();

    if (currentBasket) {
        Transaction.wrap(function () {
            cartHelper.ensureAllShipmentsHaveMethods(currentBasket);

            basketCalculationHelpers.calculateTotals(currentBasket);
        });
    }

    var basketModel = cartHelper.unrollModel(new CartModel(currentBasket));
    viewData.basketModel = basketModel;
    viewData.checkoutUrl = URLUtils.url('Checkout-Begin').toString();
    res.setViewData(viewData);
    next();
}

/**
 * Returns pay button template.
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
*/
function getPayButtonTemplate(req, res, next) {
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
    var viewData = res.getViewData();
    viewData.payButtonTemplate = renderTemplateHelper.getRenderedHtml(viewData, 'checkout/payButton');
    res.setViewData(viewData);
    next();
}

module.exports = {
    getPayButtonInfo: getPayButtonInfo,
    getPayButtonTemplate: getPayButtonTemplate
};
