'use strict';

/**
 * Applies the default expiration value for the page cache.
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
*/
function getPageComponents(req, res, next) {
this.on('route:BeforeComplete', function (req, res) {

    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');

    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');

    var viewData = res.getViewData();

    if (!viewData.success) {
        return;
    }

    if (!viewData.CurrentPageMetaData) {
        viewData.CurrentPageMetaData = {};
    }

    viewData.action = Resource.msg('pagename.discovery.home', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.discovery.home', 'technical', null);
    // Creating a thin model to polymorphically map the colors matrix colors (see colorMatrixContext.isml)
    viewData.page = {
        ID: storyHelper.getFirstStoryId()
    };
    viewData.redirectLogin = true;
    viewData.pageContext = 'main';
    viewData.fallback = true;
    viewData.urls = {
        searchMenu: URLUtils.url('Home-SearchMenu').toString(),
        searchMenuHeader: URLUtils.url('Home-MenuHeader').toString(),
        searchMenuOrderTracking: URLUtils.url('Home-MenuOrderTracking').toString(),
        payButton: URLUtils.url('Cart-MiniCart').toString(),
        discovery: URLUtils.url('Home-ShowCore').toString(),
        checkout: URLUtils.url('Checkout-Begin').toString()
    };
    viewData.components = {
        searchMenuOrderTracking: renderTemplateHelper.getRenderedHtml(viewData, 'components/menu/orderTracking'),
        searchMenuHeader: renderTemplateHelper.getRenderedHtml(viewData, 'components/menu/menuHeader'),
        payButton: renderTemplateHelper.getRenderedHtml(viewData, 'checkout/payButton'),
        discovery: renderTemplateHelper.getRenderedHtml(viewData, '/home/homePage'),
        drawer: renderTemplateHelper.getRenderedHtml(viewData, 'components/drawer/drawer')
    }
    var mobile = viewData.mobile;
    viewData.mobile = false;
    viewData.components.trackOrderForm = renderTemplateHelper.getRenderedHtml(viewData, 'account/components/trackOrderForm')
    viewData.mobile = true;
    viewData.components.trackOrderFormMobile = renderTemplateHelper.getRenderedHtml(viewData, 'account/components/trackOrderForm')
    viewData.mobile = mobile;
    res.setViewData(viewData);
});
next();
}

module.exports = {
    getPageComponents: getPageComponents
};
