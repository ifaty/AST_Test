'use strict';


function getMenuInfo(req, res, next) {
    var Resource = require('dw/web/Resource');
    var OrderHelpers = require('*/cartridge/scripts/order/orderHelpers');
    var MenuHelpers = require('*/cartridge/scripts/helpers/menuHelpers');
    var searchMenuColorMatrix = {};

    var viewData = res.getViewData();
    var orders = [];
    if (req.currentCustomer.raw.authenticated || res.getViewData().authenticatedCustomer) {
        var customer = req.currentCustomer.raw.authenticated ? req.currentCustomer : res.getViewData().authenticatedCustomer ;
        var ordersResult = OrderHelpers.getFilteredOrders(
            customer,
            req.querystring,
            req.locale.id,
            'trackable'
        );
        orders = ordersResult.orders;
    }

    if (!empty(orders)) {
        searchMenuColorMatrix = orders[0].firstLineItem.colorMatrix;
    }

    viewData.placeHolders = MenuHelpers.getSearchPlaceholders();
    viewData.action = Resource.msg('pagename.home.navigation', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.home.navigation', 'technical', null);
    viewData.orders = orders;
    viewData.searchMenuColorMatrix = JSON.stringify(searchMenuColorMatrix);
    viewData.redirectLogin = req.querystring.redirectLogin == 'true';
    viewData.context = req.querystring.context;

    // This is an _insane_ way to extend this route middleware.
    // We need this because some menu information might be integration-specific.
    Object.keys(module.exports).forEach(function (e) {
        var f = module.exports[e];
        if (e != 'getMenuInfo' && typeof f == 'function') {
            f.call(this, req, res);
        }
    });


    res.setViewData(viewData);
    next();
}

module.exports = {
    getMenuInfo: getMenuInfo
};
