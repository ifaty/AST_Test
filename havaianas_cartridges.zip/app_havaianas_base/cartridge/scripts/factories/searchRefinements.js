'use strict';

var collections = require('*/cartridge/scripts/util/collections');
var CatalogMgr = require('dw/catalog/CatalogMgr');

/**
 * Retrieves attribute refinement value model
 *
 * @param {dw.catalog.ProductSearchRefinementDefinition} refinementDefinition - Refinement
 *     definition for which we wish to retrieve refinement values for
 * @return {Object} - Attribute refinement value model module
 */
function getAttributeRefinementValueModel(refinementDefinition) {
    if (refinementDefinition.priceRefinement) {
        return require('*/cartridge/models/search/attributeRefinementValue/price');
    } else if (refinementDefinition.attributeID === 'refinementColor') {
        return require('*/cartridge/models/search/attributeRefinementValue/color');
    } else if (refinementDefinition.attributeID === 'size') {
        return require('*/cartridge/models/search/attributeRefinementValue/size');
    } else if (refinementDefinition.categoryRefinement) {
        return require('*/cartridge/models/search/attributeRefinementValue/category');
    }

    return require('*/cartridge/models/search/attributeRefinementValue/boolean');
}

/**
 * Creates an array of category refinements for category search
 * @param {dw.catalog.ProductSearchModel} productSearch - Product search object
 * @param {dw.catalog.ProductSearchRefinementDefinition} refinementDefinition - Refinement
 *     definition for which we wish to retrieve refinement values for
 * @param {CategoryAttributeValue} Model - model of the category class
 * @return {Array} - List of categories
 */
function createCategorySearchRefinement(productSearch, refinementDefinition, Model) {
    //get the first 2 category levels 
    var categories = [];
    var rootCategory = CatalogMgr.getSiteCatalog().getRoot();
    collections.forEach(rootCategory.subCategories, function (category) {
        if(category.custom.showInMenu) {
            var isCurrentCategory = productSearch.categorySearch && productSearch.categoryID == category.ID? true : false;
            var categoryModel = new Model(productSearch, refinementDefinition, category, isCurrentCategory);
            var subCategories = [];
            collections.forEach(category.subCategories, function (subCategory) {
                if(subCategory.custom.showInMenu) {
                    var isCurrentCategory = productSearch.categorySearch && productSearch.categoryID == subCategory.ID? true : false;
                    var subCategoryModel = new Model(productSearch, refinementDefinition, subCategory, isCurrentCategory);
                    subCategories.push(subCategoryModel);
                }
            });
            if(subCategories.length) {
                categoryModel.subCategories = subCategories;
                categories.push(categoryModel);
            }
        }
    });

    return categories;
}

/**
 * Creates an array of category refinements for category search
 * @param {dw.catalog.ProductSearchModel} productSearch - Product search object
 * @param {dw.catalog.ProductSearchRefinementDefinition} refinementDefinition - Refinement
 *     definition for which we wish to retrieve refinement values for
 * @param {dw.util.Collection.<dw.catalog.ProductSearchRefinementValue>} refinementValues -
 *     Collection of refinement values
 * @param {CategoryAttributeValue} Model - model of the category class
 * @return {Array} - List of categories
 */
function createProductSearchRefinement(productSearch,
    refinementDefinition,
    refinementValues,
    Model,
    httpParams) {
    var catalogMgr = require('dw/catalog/CatalogMgr');
    var tree = [];
    var mappedList = {};
    collections.forEach(refinementValues, function (value) {
        var category = catalogMgr.getCategory(value.value);
        mappedList[value.value] = new Model(
            productSearch,
            refinementDefinition,
            category,
            productSearch.categoryID === value.value,
            httpParams);
        mappedList[value.value].parent = category.parent.ID;
    });

    Object.keys(mappedList).forEach(function (key) {
        var category = mappedList[key];
        if (category.parent !== 'root') {
            if (mappedList[category.parent]) {
                mappedList[category.parent].subCategories.push(category);
            }
        } else {
            tree.push(category);
        }
    });
    return tree;
}

/**
 * Retrieve refinement values based on refinement type
 *
 * @param {dw.catalog.ProductSearchModel} productSearch - Product search object
 * @param {dw.catalog.ProductSearchRefinementDefinition} refinementDefinition - Refinement
 *     definition for which we wish to retrieve refinement values for
 * @param {dw.util.Collection.<dw.catalog.ProductSearchRefinementValue>} refinementValues -
 *     Collection of refinement values
 * @param {Object} httpParams - Any and all params passed, we use these to create custom refinements
 * @return {Array} - List of refinement values
 */
function get(productSearch, refinementDefinition, refinementValues, httpParams) {
    var Model = getAttributeRefinementValueModel(refinementDefinition);

    if (refinementDefinition.categoryRefinement) {
        if (productSearch.categorySearch) {
            // return only current category, direct children and direct parent
            return createCategorySearchRefinement(productSearch, refinementDefinition, Model);
        }
        return createProductSearchRefinement(
            productSearch,
            refinementDefinition,
            refinementValues,
            Model,
            httpParams);
    }

    return collections.map(refinementValues, function (value) {
        return new Model(productSearch, refinementDefinition, value, httpParams);
    });
}

module.exports = {
    get: get
};
