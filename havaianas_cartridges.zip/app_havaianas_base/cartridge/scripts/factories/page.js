'use strict';

var pageDecorator = require('*/cartridge/models/page/decorators/pageDecorators');

module.exports = {
    get: function (controllerAction) {
        var requestPath = empty(controllerAction) ? request.httpPath.substr(request.httpPath.lastIndexOf('/')+1,request.httpPath.length) : controllerAction;
        var controller = requestPath.split('-')[0];
        var action = requestPath.split('-')[1];
        var requestParameters = request.httpParameterMap;
        var page = Object.create(null);
        switch (controller) {
            case 'Product':
                pageDecorator.hreflangProduct(page, requestParameters.pid);
                pageDecorator.canonicalProduct(page, requestParameters.pid);
                break;
            case 'Search':
                pageDecorator.hreflangCategory(page, requestParameters.cgid);
                pageDecorator.canonicalCategory(page, requestParameters);
                break;
            case 'Page'://Used to handle with PageDesigner
                pageDecorator.hreflangPageDesigner(page, requestParameters.cid);
                pageDecorator.canonicalPage(page, requestParameters.cid);
                break;
            case 'ViewAll':
                pageDecorator.hreflangPageDefault(page, requestPath);
                pageDecorator.canonicalViewAll(page, requestPath);
                break;
            case 'Home':
                pageDecorator.hreflangPageDefault(page, requestPath);
                pageDecorator.canonicalHome(page, requestPath);
                break;
            default:
                pageDecorator.hreflangPageDefault(page, requestPath);
                break;
        }
        return page;
    }
};