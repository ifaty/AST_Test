const Resource = require('dw/web/Resource');

function validateFranchiseeForm(form) {
    validateZipCode(form,form.zipcode);
};

function validateDealerForm(form) {
    validateZipCode(form,form.zipcode);
};

function validateZipCode(form,zipCodeField) {
    var zipCodeNumber = zipCodeField.value.replace(/\D/g, '');
    if (parseInt(zipCodeNumber) == 0) {
        form.valid = false;
        zipCodeField.valid = false;
        zipCodeField.error = Resource.msg('zipcode.wrong.pattern', 'forms', null);
    }
};

module.exports = {
    validateDealerForm: validateDealerForm,
    validateFranchiseeForm: validateFranchiseeForm,
    validateZipCode: validateZipCode
}