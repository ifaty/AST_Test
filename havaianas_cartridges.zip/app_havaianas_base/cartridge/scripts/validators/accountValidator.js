const CustomerMgr = require('dw/customer/CustomerMgr');
const Transaction = require('dw/system/Transaction');
const Resource = require('dw/web/Resource');

function isCurrentPasswordCorrect(profile, profileForm) {
    if (profile.customer.externallyAuthenticated) {
        return true;
    }
    var result = true;
    Transaction.wrap(function () {
        var status = profile.credentials.setPassword(
            profileForm.login.currentpassword.value,
            profileForm.login.currentpassword.value,
            true
        );

        if (status.error) {
            result = false;
        }
    });
    return result;
}

function validatePasswordMatch(passwordField, passwordConfirmField, profileForm) {
    if (passwordField.value !== passwordConfirmField.value) {
        profileForm.valid = false;
        passwordField.valid = false;
        passwordConfirmField.valid = false;
        passwordField.error = Resource.msg('error.message.mismatch.newpassword', 'forms', null);
        passwordConfirmField.error = Resource.msg('error.message.mismatch.newpassword', 'forms', null);
    }
}

function validatePasswordAcceptable(passwordField, profileForm) {
    if (passwordField.value &&
        !CustomerMgr.isAcceptablePassword(passwordField.value)) {
        profileForm.valid = false;
        passwordField.valid = false;
        passwordField.error = Resource.msg('error.message.password.constraints.not.matched', 'forms', null);
    }
}

function validateNewPassword(passwordField, passwordConfirmField, profileForm) {
    validatePasswordAcceptable(passwordField, profileForm);
    validatePasswordMatch(passwordField, passwordConfirmField, profileForm);
}

function validateRegistrationEmailFields(registrationForm) {

    var invalidEmail = false;

    if (!registrationForm.customer.email.valid) {
        registrationForm.customer.email.valid = false;
        registrationForm.valid = false;
        invalidEmail = true;
        registrationForm.customer.email.error = Resource.msg('error.message.parse.email.profile.form', 'forms', null);
    }

    if (!registrationForm.customer.emailconfirm.valid) {
        registrationForm.customer.emailconfirm.valid = false;
        registrationForm.valid = false;
        invalidEmail = true;
        registrationForm.customer.emailconfirm.error = Resource.msg('error.message.parse.email.profile.form', 'forms', null);
    }

    if(!invalidEmail) {
        if (registrationForm.customer.email.value.toLowerCase()
            !== registrationForm.customer.emailconfirm.value.toLowerCase()
        ) {
            registrationForm.customer.email.valid = false;
            registrationForm.customer.emailconfirm.valid = false;
            registrationForm.valid = false;
            registrationForm.customer.email.error = Resource.msg('error.message.mismatch.email', 'forms', null);
            registrationForm.customer.emailconfirm.error = Resource.msg('error.message.mismatch.email', 'forms', null);
        }
    }
}

function validateNameLength(nameField, profileForm) {

    if (nameField.valid && nameField.value.length > 100) {
        nameField.valid = false;
        nameField.error = Resource.msg('error.message.100orless', 'forms', null);
        profileForm.valid = false;
    }
}

function validateEditProfileForm(profile, profileForm) {
    var result = {};
    result.error = false;
    var fieldError = {};

    if (empty(profileForm.login.currentpassword.value)) {
        fieldError[profileForm.login.currentpassword.htmlName] = Resource.msg('label.personalinfo.blank.password', 'forms', null);
        result.error = true;
    }
    if (!empty(profileForm.login.currentpassword.value) && !isCurrentPasswordCorrect(profile, profileForm)) {
        fieldError[profileForm.login.currentpassword.htmlName] = Resource.msg('label.personalinfo.wrong.current.password', 'forms', null);
        result.error = true;
    }
    if (!empty(profileForm.login.newpasswords.newpassword.value)) {
        validateNewPassword(profileForm.login.newpasswords.newpassword, profileForm.login.newpasswords.newpasswordconfirm, profileForm);
        if (!profileForm.valid) {
            fieldError[profileForm.login.newpasswords.newpassword.htmlName] = profileForm.login.newpasswords.newpassword.error;
            result.error = true;
        }
    }
    if (!profileForm.customer.email.valid) {
        fieldError[profileForm.customer.email.htmlName] = profileForm.customer.email.error;
        result.error = true;
    }
    validateNameLength(profileForm.customer.name, profileForm);
    if (!profileForm.customer.name.valid) {
        fieldError[profileForm.customer.name.htmlName] = profileForm.customer.name.error;
        result.error = true;
    }
    result.fields = fieldError;
    return result;
}

function validateTermsConditionsPolicyPrivacy(termsandprivacyField, profileForm) {
    if (!termsandprivacyField.checked) {
        profileForm.valid = false;
        termsandprivacyField.valid = false;
        termsandprivacyField.error = Resource.msg('error.message.required', 'forms', null);
    }
}

function validateRegistrationForm(profileForm) {
    validateRegistrationEmailFields(profileForm);
    validateNewPassword(profileForm.login.password, profileForm.login.passwordconfirm, profileForm);
    validateNameLength(profileForm.customer.lastname, profileForm);
    validateTermsConditionsPolicyPrivacy(profileForm.customer.termsandprivacy, profileForm);
};

module.exports = {
    validateEditProfileForm: validateEditProfileForm,
    isCurrentPasswordCorrect: isCurrentPasswordCorrect,
    validateRegistrationForm: validateRegistrationForm,
    validateTermsConditionsPolicyPrivacy: validateTermsConditionsPolicyPrivacy
}