'use strict';

var HashMap = require('dw/util/HashMap');
var Template = require('dw/util/Template');
var base = module.superModule;
/**
 * gets the rendered html from the localized content asset
 * @param {Object} templateContext - object that will fill template placeholders
 * @param {string} templateName - the name of the isml template to render.
 * @param {string} locale - the customer's locale.
 * @returns {string} the rendered isml.
 */
function getRenderedHtml(templateContext, templateName, locale) {
    if (!locale) {
        return base.getRenderedHtml(templateContext, templateName);
    };
    var context = new HashMap();

    Object.keys(templateContext).forEach(function (key) {
        if (key !== 'saluation' && key !== 'setSaluation') {
            context.put(key, templateContext[key]);
        }
    });

    var template = new Template(templateName);
    template.setLocale(locale);
    return template.render(context).text;
};

module.exports = {
    getRenderedHtml: getRenderedHtml
};
