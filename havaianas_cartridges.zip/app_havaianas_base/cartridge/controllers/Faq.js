'use strict';

const server = require('server');
const ContentMgr = require('dw/content/ContentMgr');
const Resource = require('dw/web/Resource');

server.get('Show', function (req, res, next) {

    let faqFolder = ContentMgr.getFolder('faq');

    if (!faqFolder || !faqFolder.subFolders) {
        res.json({
            success: false,
            msg: Resource.msg('error.message.general', 'institutional', null)
        });
        return next();
    }

    res.render('institutional/faq', {
        subFolders: faqFolder.subFolders,
        action: Resource.msg('pagename.faq', 'technical', null),
    });

    next();
});

server.get('Questions', function (req, res, next) {
    if (!req.querystring.subFolder) {
        res.json({
            success: false,
            msg: Resource.msg('error.message.general', 'institutional', null)
        });
        return next();
    }

    let subFolder = ContentMgr.getFolder(req.querystring.subFolder);

    res.render('institutional/faqQuestions/questions', {
        subFolder: subFolder,
        action: Resource.msg('pagename.faq', 'technical', null),
    });

    next();
});

server.post('Review', function (req, res, next) {
    if (!req.form.question || req.form.review == null) {
        res.json({
            success: false,
            msg: Resource.msg('error.message.general', 'institutional', null)
        });
        return next();
    }

    let faqModel = require('*/cartridge/scripts/helpers/faqReviewHelper');
    let reviewsJson = faqModel.handleFaqReview(req.form.question, req.form.review, req.currentCustomer, req.form.cookieReviews);

    if(!reviewsJson){

        res.json({
            success: false,
            msg: Resource.msg('error.message.general', 'institutional', null)
        });

        return next();
    }

    res.json({
        success:true,
        reviews: reviewsJson,
    });

    next();
});

module.exports = server.exports();
