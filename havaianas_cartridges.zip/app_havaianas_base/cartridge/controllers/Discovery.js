'use strict';

var server = require('server');
var cache = require('*/cartridge/scripts/middleware/cache');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');
var pageMetaData = require('*/cartridge/scripts/middleware/pageMetaData');

server.get('Page', consentTracking.consent, cache.applyDefaultCache, function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');
    var storySettings = storyHelper.getStorySettings();

    var offset = parseInt(req.querystring.offset, 10) || 0;
    var pagesize = parseInt(req.querystring.pagesize, 10) || 6;
    var activeId = null;
    var paginated = req.querystring.paginated == 'true' || false;
    var orderingInfo = storyHelper.getStoryOrderingInfo(storySettings, {
        offset: offset,
        pagesize: pagesize,
        activeId: activeId
    });
    if (orderingInfo) {
        res.render('/components/discovery/discovery-page', {
            action: Resource.msg('pagename.discovery.home', 'technical', null),
            pageContext: Resource.msg('pagecontext.discovery.home', 'technical', null),
            ordering: orderingInfo.ordering,
            viewMore: orderingInfo.viewMore,
            paginated: paginated
        });
    }
    next();
}, pageMetaData.computedPageMetaData);


server.get('Show', consentTracking.consent, cache.applyDefaultCache, function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var Site = require('dw/system/Site');
    var pageMetaHelper = require('*/cartridge/scripts/helpers/pageMetaHelper');
    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');

    pageMetaHelper.setPageMetaTags(req.pageMetaData, Site.current);
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.discovery.home', 'technical', null);
    viewData.activeId = storyHelper.updateRequestActiveId(req, request);
    viewData.redirectLogin = req.querystring.redirectLogin == 'true';
    res.setViewData(viewData);
    res.render('/home/homePage');
    next();
}, pageMetaData.computedPageMetaData);


server.get('Story', consentTracking.consent, cache.applyDefaultCache, function (req, res, next) {
    var params = req.querystring;
    var storyID = params.cid;

    var PageMgr = require('dw/experience/PageMgr');
    var page = PageMgr.getPage(storyID);

    if (page != null && page.isVisible()) {
        if (!page.hasVisibilityRules()) {
            res.cachePeriod = 168; // eslint-disable-line no-param-reassign
            res.cachePeriodUnit = 'hours'; // eslint-disable-line no-param-reassign
        }

        res.page(page.ID, {
            paginated: params.paginated == 'true' || false,
            viewAll: params.viewAll == 'true' || false
        });
    }

    return next();
}, pageMetaData.computedPageMetaData);

module.exports = server.exports();
