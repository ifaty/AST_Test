'use strict';

var server = require('server');
var Tile = module.superModule;
server.extend(Tile);

var cache = require('*/cartridge/scripts/middleware/cache');

server.replace('Show', cache.applyInventorySensitiveCache, function (req, res, next) {
    var URLUtils       = require('dw/web/URLUtils');
    var ProductMgr     = require('dw/catalog/ProductMgr');
    var colorMatrixHelper = require('*/cartridge/scripts/helpers/colorMatrixHelper');
    var productHelpers = require('*/cartridge/scripts/helpers/productHelpers');

    var apiProduct   = ProductMgr.getProduct(req.querystring.pid);
    // Sanity check below
    if (!apiProduct || !apiProduct.online) {
        res.render('product/emptyProductTile');
        return next();
    }
    var product      = productHelpers.getProductTileModel(apiProduct, req.querystring, 'ShowQuickView'); // Refactor!!!

    var productUrl   = URLUtils.url('Product-Show', 'pid', product.id).relative().toString();
    var quickViewUrl = URLUtils.url('Product-ShowQuickView', 'pid', product.id)
            .relative().toString();

    var context = {
        product: product,
        variants: productHelpers.getVariantAddToCartUrls(req.querystring.pid, req.querystring.variables, req.querystring.context ? req.querystring.context : 'pay'),
        addToCartUrl: URLUtils.url('Cart-AddProduct'),
        urls: {
            product: productUrl,
            quickView: quickViewUrl
        },
        isWishlistPage: req.querystring.isWishlistPage, 
        display: {},
        colorMatrix: colorMatrixHelper.get(
            apiProduct.custom.hav_primaryColor,
            'ultralight',//apiProduct.custom.hav_primaryColorTone,
            apiProduct.custom.hav_secondaryColor,
            'ultralight' //apiProduct.custom.hav_secondaryColorTone
        ).toJSON()
    };

    Object.keys(req.querystring).forEach(function (key) {
        if (req.querystring[key] === 'true') {
            context.display[key] = true;
        } else if (req.querystring[key] === 'false') {
            context.display[key] = false;
        }
    });

    res.render('product/gridTile.isml', context);

    return next();
});

module.exports = server.exports();