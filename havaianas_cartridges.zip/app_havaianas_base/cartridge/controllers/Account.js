'use strict';

var server = require('server');
var Account = module.superModule;
server.extend(Account);

var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

var profilePictureHelper = require('*/cartridge/scripts/helpers/profilePictureHelper');

var login = require('*/cartridge/scripts/middleware/login');
var menu = require('*/cartridge/scripts/middleware/menu');
var basket = require('*/cartridge/scripts/middleware/basket');

server.get('SetVoucher', function (req, res, next) {
    var Transaction = require('dw/system/Transaction');

    var currentCustomer = req.currentCustomer.raw;
    var voucherCode = req.querystring.voucherCode;

    /*
        This route was created to help testing the customer logged in flow.
        Since by now it does not has any other means to assign a voucher directly to a customer.
    */

    if (currentCustomer.isAuthenticated()) {
        var profile = currentCustomer.getProfile();
        Transaction.wrap(function () {
            profile.custom.hav_ownedVoucherCode = voucherCode;
        });
    }
    
    res.json({
        error: false,
        voucherApplied: voucherCode
    })
    return next();
})

server.replace(
    'SubmitRegistration',
    server.middleware.https,
    csrfProtection.validateAjaxRequest,
    function (req, res, next) {

        var CustomerMgr = require('dw/customer/CustomerMgr');
        var Resource = require('dw/web/Resource');

        var formErrors = require('*/cartridge/scripts/formErrors');
        var accountValidator = require('*/cartridge/scripts/validators/accountValidator');

        var registrationForm = server.forms.getForm('profile');

        accountValidator.validateRegistrationForm(registrationForm);

        // setting variables for the BeforeComplete function
        var registrationFormObj = {
            firstName: registrationForm.customer.firstname.value,
            lastName: registrationForm.customer.lastname.value,
            phone: registrationForm.customer.phone.value,
            email: registrationForm.customer.email.value,
            emailConfirm: registrationForm.customer.emailconfirm.value,
            password: registrationForm.login.password.value,
            passwordConfirm: registrationForm.login.passwordconfirm.value,
            shoesize: registrationForm.customer.shoesize.value,
            clothingsize: registrationForm.customer.clothingsize.value,
            idnumber: registrationForm.customer.idnumber.value,
            dateofbirth: registrationForm.customer.dateofbirth.value,
            termsandprivacy: registrationForm.customer.termsandprivacy.value,
            validForm: registrationForm.valid,
            form: registrationForm,
            isFromGuestUser: (req.form.isFromGuestUser == 'true'),
            orderIdNewUser: req.form.orderIdNewUser
        };

        if (registrationForm.valid) {
            res.setViewData(registrationFormObj);

            this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line no-shadow
                var Transaction = require('dw/system/Transaction');
                var accountHelpers = require('*/cartridge/scripts/helpers/accountHelpers');
                var transactionalEmailsHelper = require('*/cartridge/scripts/helpers/transactionalEmailsHelper');
                var authenticatedCustomer;
                var serverError;
                var dateUtils = require('*/cartridge/config/dateUtils');

                // getting variables for the BeforeComplete function
                var registrationForm = res.getViewData(); // eslint-disable-line

                if (registrationForm.validForm) {
                    var login = registrationForm.email;
                    var password = registrationForm.password;

                    // attempt to create a new user and log that user in.
                    try {
                        Transaction.wrap(function () {
                            var error = {};
                            var newCustomer = CustomerMgr.createCustomer(login, password);

                            var authenticateCustomerResult = CustomerMgr.authenticateCustomer(login, password);
                            if (authenticateCustomerResult.status !== 'AUTH_OK') {
                                error = { authError: true, status: authenticateCustomerResult.status };
                                throw error;
                            }

                            authenticatedCustomer = CustomerMgr.loginCustomer(authenticateCustomerResult, false);

                            if (!authenticatedCustomer) {
                                error = { authError: true, status: authenticateCustomerResult.status };
                                throw error;
                            } else {
                                // assign values to the profile
                                var newCustomerProfile = newCustomer.getProfile();

                                newCustomerProfile.firstName = registrationForm.firstName;
                                newCustomerProfile.lastName = registrationForm.lastName;
                                newCustomerProfile.phoneHome = registrationForm.phone;
                                newCustomerProfile.email = registrationForm.email;
                                newCustomerProfile.custom.hav_shoeSize = registrationForm.shoesize;
                                newCustomerProfile.custom.hav_clothingSize = registrationForm.clothingsize;
                                newCustomerProfile.custom.hav_termsAndPrivacyPolicy = registrationForm.termsandprivacy;
                                
                                newCustomerProfile.custom.hav_idNumber = registrationForm.idnumber;

                                if (!empty(registrationForm.dateofbirth)) {
                                    var parsedInput = dateUtils.parseDate(registrationForm.dateofbirth);
                                    var birthdayDate = new Date(parsedInput.year, parsedInput.month - 1, parsedInput.day);
                                    newCustomerProfile.setBirthday(birthdayDate);
                                    newCustomerProfile.custom.hav_birthday = birthdayDate;
                                }

                                //Get the order based on orderId and set the customer if this submit come from guest checkout
                                if (registrationForm.isFromGuestUser) {
                                    var OrderMgr = require('dw/order/OrderMgr');
                                    var order = OrderMgr.getOrder(registrationForm.orderIdNewUser);
                                    if (order) {
                                        order.setCustomer(newCustomer);
                                    }
                                }
                            }
                        });
                    } catch (e) {
                        var er = e;
                        if (e.authError) {
                            serverError = true;
                        } else {
                            registrationForm.validForm = false;
                            registrationForm.form.customer.email.valid = false;
                            registrationForm.form.customer.emailconfirm.valid = false;
                            registrationForm.form.customer.email.error =
                                Resource.msg('error.message.username.invalid', 'forms', null);
                        }
                    }
                }

                delete registrationForm.password;
                delete registrationForm.passwordConfirm;
                formErrors.removeFormValues(registrationForm.form);

                if (serverError) {
                    res.setStatusCode(500);
                    res.json({
                        success: false,
                        errorMessage: Resource.msg('error.message.unable.to.create.account', 'login', null)
                    });

                    return;
                }

                if (registrationForm.validForm) {
                    // send a registration email
                    transactionalEmailsHelper.sendCreateAccountEmail(authenticatedCustomer.profile);

                    res.json({
                        success: true,
                        redirectUrl: accountHelpers.getLoginRedirectURL(req.querystring.rurl, req.session.privacyCache, true),
                        authenticatedCustomer: {
                            id: authenticatedCustomer.ID,
                            email: authenticatedCustomer.profile.email,
                            lastName: authenticatedCustomer.profile.lastName,
                            profilePictureURL: authenticatedCustomer.profile.custom.hav_profilePictureURL
                        }
                    });

                    req.session.privacyCache.set('args', null);
                } else {
                    res.json({
                        fields: formErrors.getFormErrors(registrationForm)
                    });
                }
            });
        } else {
            res.json({
                fields: formErrors.getFormErrors(registrationForm)
            });
        }

        return next();
    },
    basket.getPayButtonInfo,
    menu.getMenuInfo,
    login.getPageComponents
);

server.append('Show', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.myaccount', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.myaccount', 'technical', null);
    res.setViewData(viewData);
    next();
});

server.post('UploadPhoto', function(req, res, next) {
    var File = require('dw/io/File');
    var LinkedHashMap = require('dw/util/LinkedHashMap');
    var Site = require('dw/system/Site');
    var Resource = require('dw/web/Resource');
    var Transaction = require('dw/system/Transaction');
    var URLUtils = require('dw/web/URLUtils');

    var fileConfig = {
        allowedTypes: Site.current.getCustomPreferenceValue('hav_profilePictureAllowedTypes') || '.png,.jpeg,.jpg',
        maxSize: (Site.current.getCustomPreferenceValue('hav_profilePictureMaxSize') || 5) * Math.pow(10, 6),
        profilePicturePath: Site.current.getCustomPreferenceValue('hav_profilePicturePath'),
        profilePicturePrefix: Site.current.getCustomPreferenceValue('hav_profilePicturePrefix') || ''
    }

    if (empty(fileConfig.profilePicturePath)) {
        res.json({
            errorMsg: Resource.msg('error.personalinfo.uploadprofilepicture.catalognotset', 'forms' , null),
            success: false
        })
        return next();
    }

    // In the url example "/havaianas-pictures/.../..../profilePicture.jpg", catches the first directory,
    // expected to be the catalog name.
    fileConfig.catalogName = fileConfig.profilePicturePath.split('/')[1];

    fileConfig.profilePicturePath = profilePictureHelper.wrapWithSeparators(fileConfig.profilePicturePath);

    var files = new LinkedHashMap();
    var params = request.httpParameterMap;
    var receivedFileType;

    var result = profilePictureHelper.processMultipartForm(req, fileConfig, params);

    // Remembering the closure function, it returns the error if ocurred inside the callback.
    if (result.validForm === false) {
        res.json(result.response);
        return next();
    }

    files = result.files;
    receivedFileType = result.receivedFileType;

    // Check if catalog directory exists
    var catalogDirectory = new File(File.CATALOGS + fileConfig.profilePicturePath);
    if (!catalogDirectory.exists()) {
        res.json({
            errorMsg: Resource.msgf('error.personalinfo.uploadprofilepicture.directorynotfound', 'forms' , null, catalogDirectory.getFullPath()),
            success: false
        })
        return next();
    }

    var response = {
        errorMsg: '',
        success: true
    };
    // processMultipart retrieves null if this is not a multipart request
    if (files === null) {
        res.status(400);
        response.errorMsg = Resource.msg('error.personalinfo.uploadprofilepicture.badrequest', 'forms', null);
        response.success = false;
    }
    else if (files.empty) {
        response.errorMsg = Resource.msg('error.personalinfo.uploadprofilepicture.emptyrequest', 'forms', null);
        response.success = false;
    }
    else if (files.profilePicture.length() > fileConfig.maxSize) {
        files.profilePicture.remove();
        response.errorMsg = Resource.msgf('error.personalinfo.uploadprofilepicture.sizelimitexceeded', 'forms' , null, fileConfig.maxSize);
        response.success = false;
    }

    if (response.success !== true) {
        res.json(response);
        return next();
    }

    // When the file name and file extension equals with an existent file, SFCC overwrites it.
    // But it does not happen when the file extension differs
    // In this piece of code we manually do the removal of pre-existent files that would be remained.
    var profile = req.currentCustomer.raw.profile
    var profilePictureURL = profile.custom.hav_profilePictureURL; // retrieves the old profile picture url
    profilePictureHelper.removePreviousPicture(profilePictureURL, receivedFileType, fileConfig, req.currentCustomer.raw.getID());


    var archivePath = files.profilePicture.getFullPath().split(fileConfig.catalogName + '/default/')[1];
    Transaction.wrap(function() {
        var profile = req.currentCustomer.raw.profile;
        profile.custom.hav_profilePictureURL =
            URLUtils.imageURL(
                URLUtils.CONTEXT_CATALOG,
                fileConfig.catalogName,
                archivePath,
                { scaleWidth: 100 }
                );
    });
    res.json({
        success: true,
        successMsg: Resource.msg('success.personalinfo.uploadprofilepicture', 'forms', null),
        uploadedPictureUrl: profile.custom.hav_profilePictureURL
    })

    return next();
});

server.replace(
    'EditProfile',
    server.middleware.https,
    csrfProtection.generateToken,
    userLoggedIn.validateLoggedIn,
    consentTracking.consent,
    function (req, res, next) {
        var Site = require('dw/system/Site');
        var Resource = require('dw/web/Resource');
        var Site = require('dw/system/Site');
        var dateUtils = require('*/cartridge/config/dateUtils');
        var sitePrefs = Site.getCurrent().getPreferences();
        var availableShoeSizes = JSON.parse(sitePrefs.getCustom()["hav_availableShoeSizes"] || "[]");
        var availableClothingSizes = JSON.parse(sitePrefs.getCustom()["hav_availableClothingSizes"] || "[]");

        var profileForm = server.forms.getForm('personalInfo');
        var profileBirthday = req.currentCustomer.profile.birthday;
        var profileCustomAttributes = req.currentCustomer.raw.profile.custom;
        profileForm.clear();
        profileForm.customer.name.value = req.currentCustomer.profile.lastName;
        profileForm.customer.email.value = req.currentCustomer.profile.email;
        profileForm.customer.dateofbirth.value = profileBirthday ?
            dateUtils.dateToString(profileBirthday) :
            null;
            
        if (profileCustomAttributes) {
            profileForm.customer.idnumber.value = profileCustomAttributes.hav_idNumber || null;
            profileForm.customer.shoesize.value = profileCustomAttributes.hav_shoeSize || null;
            profileForm.customer.clothingsize.value = profileCustomAttributes.hav_clothingSize || null;
        }

        var sessionClicks = session.clickStream.getClicks();
        var currentPipeline = session.clickStream.getLast().getPipelineName();
        sessionClicks.reverse();
        var pastPipeline = (function() {
            for (var i = 0, len = sessionClicks.length; i < len; i++) {
                var pastPipelineName = sessionClicks[i].getPipelineName();
                if (currentPipeline != pastPipelineName)
                    return pastPipelineName;
            }
        })(); // returns undefined if not found.

        if (pastPipeline) {
            pastPipeline = pastPipeline.replace('-', '').toLowerCase()
        }
        else {
            pastPipeline = '';
        }

        var pageContextLabel = Resource.msg(
                'label.personalinfo.button.back.default',
                'forms',
                null
            );

        var allowedImageTypes = Site.current.getCustomPreferenceValue('hav_photoAllowedTypes') || '.png,.jpeg,.jpg';
        var imageSizeLimit = Site.current.getCustomPreferenceValue('hav_photoMaxSize') || 5 * Math.pow(10, 6);
        var profilePictureURL = profileCustomAttributes.hav_profilePictureURL;

        res.render('account/personalInfo', {
            profileForm: profileForm,
            availableShoeSizes: availableShoeSizes,
            availableClothingSizes: availableClothingSizes,
            pageContextLabel: pageContextLabel,
            action: Resource.msg('pagename.profile', 'technical', null),
            pageContext: Resource.msg('pagecontext.profile', 'technical', null),
            imageSizeLimit: imageSizeLimit,
            allowedImageTypes: allowedImageTypes,
            profilePictureURL: profilePictureURL
        });

        return next();
    }
);

server.replace(
    'SaveProfile',
    server.middleware.https,
    csrfProtection.validateAjaxRequest,
    function (req, res, next) {
        var URLUtils = require('dw/web/URLUtils');
        var Resource = require('dw/web/Resource');
        var Transaction = require('dw/system/Transaction');
        var CustomerMgr = require('dw/customer/CustomerMgr');
        var dateUtils = require('*/cartridge/config/dateUtils');

        var accountValidator = require('*/cartridge/scripts/validators/accountValidator');

        var profileForm = server.forms.getForm('personalInfo');

        var customer = CustomerMgr.getCustomerByCustomerNumber(
            req.currentCustomer.profile.customerNo
        );
        var profile = customer.getProfile();

        var resultValidation = accountValidator.validateEditProfileForm(profile, profileForm);

        if (resultValidation.error) {
            res.json({
                success: false,
                fields: resultValidation.fields,
                errorMsg: Resource.msg('form.error.general', 'forms', null)
            });
            this.emit('route:Complete', req, res);
            return;
        }

        var newPasswords = profileForm.login.newpasswords;
        var result = {
            lastName: profileForm.customer.name.value,
            email: profileForm.customer.email.value,
            currentPassword: profileForm.login.currentpassword.value,
            newPassword: newPasswords.newpassword.value,
            newPasswordConfirm: newPasswords.newpasswordconfirm.value,
            idNumber: profileForm.customer.idnumber.value,
            dateOfBirth: profileForm.customer.dateofbirth.value,
            shoeSize: profileForm.customer.shoesize.value,
            clothingSize: profileForm.customer.clothingsize.value,
            profileForm: profileForm
        };

        var currentPasswordInputed = result.currentPassword != '********';

        res.setViewData(result);

        this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line no-shadow
            var transactionalEmailsHelper = require('*/cartridge/scripts/helpers/transactionalEmailsHelper');
            var formInfo = res.getViewData();
            profileForm = formInfo.profileForm;
            try {
                Transaction.wrap(function () {

                    var customerLogin;
                    var profile = customer.getProfile();

                    if (formInfo.email !== profile.getEmail()) {
                        customerLogin = profile.credentials.setLogin(
                            formInfo.email,
                            formInfo.currentPassword
                        );

                        if (customerLogin) {
                            profile.setEmail(formInfo.email);
                        } else {
                            profileForm.customer.email.valid = false;
                            throw {
                                success: false,
                                errorMsg: Resource.msg('error.message.general', 'forms', null)
                            };
                        }
                    }

                    if (!empty(formInfo.newPassword) && currentPasswordInputed) {
                        var statusChangePassword = profile.credentials.setPassword(
                                                    formInfo.newPassword,
                                                    formInfo.currentPassword,
                                                    true
                                                );
                        if (statusChangePassword.error) {
                            var fieldError = {};
                            fieldError[profileForm.login.currentpassword.htmlName] = Resource.msg('label.personalinfo.wrong.current.password', 'forms', null);
                            res.json({
                                success: false,
                                fields: fieldError,
                                errorMsg: Resource.msg('form.error.general', 'forms', null)
                            });
                            return;
                        }
                        else {
                            customerLogin = profile.credentials.setLogin(
                                formInfo.email,
                                formInfo.newPassword
                            );
                        }
                    }
               
                });
            } catch (e) {
                res.json({
                    success: e.success,
                    errorMsg: e.errorMsg || ''
                });

                return;
            }

            delete formInfo.currentPassword;
            delete formInfo.newPassword;
            delete formInfo.newPasswordConfirm;

            Transaction.wrap(function () {
                profile.setLastName(formInfo.lastName);

                if (!empty(formInfo.idNumber)) {
                    profile.custom.hav_idNumber = formInfo.idNumber;
                }
                if (!empty(formInfo.dateOfBirth)) {
                    var parsedInput = dateUtils.parseDate(formInfo.dateOfBirth);
                    var birthdayDate = new Date(parsedInput.year, parsedInput.month - 1, parsedInput.day);
                    profile.setBirthday(birthdayDate);
                    profile.custom.hav_birthday = birthdayDate;
                }
                if (!empty(formInfo.shoeSize)) {
                    profile.custom.hav_shoeSize = formInfo.shoeSize;
                }
                if (!empty(formInfo.clothingSize)) {
                    profile.custom.hav_clothingSize = formInfo.clothingSize;
                }
            });

            delete formInfo.profileForm;
            delete formInfo.email;

            transactionalEmailsHelper.sendAccountEditedEmail(customer.profile);

            res.json({
                success: true,
                successMessage: Resource.msg('success.profile.edit', 'forms', null),
                redirectUrl: URLUtils.url('Account-EditProfile').toString()
            });
        });

        return next();
    }
);

server.append('PasswordReset', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.passwordReset', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.passwordReset', 'technical', null);
    var resetPasswordForm = server.forms.getForm('profile');
    resetPasswordForm.clear();
    viewData.resetPasswordForm = resetPasswordForm;
    res.setViewData(viewData);
    next();
});

server.replace('PasswordResetDialogForm', server.middleware.https, function (req, res, next) {
    var transactionalEmailsHelper = require('*/cartridge/scripts/helpers/transactionalEmailsHelper');
    var CustomerMgr = require('dw/customer/CustomerMgr');
    var formErrors = require('*/cartridge/scripts/formErrors');
    var { validateEmail } = require('*/cartridge/scripts/helpers/emailHelpers');
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');
    var resetPasswordForm = server.forms.getForm('profile');

    var userEmail = resetPasswordForm.customer.email.value;

    if (!userEmail) {
        resetPasswordForm.customer.email.valid = false;
        resetPasswordForm.customer.email.error = Resource.msg('error.message.required', 'login', null);
        resetPasswordForm.valid = false;
        res.json({
            fields: formErrors.getFormErrors(resetPasswordForm)
        });
        return next();
    }

    if (!validateEmail(userEmail)) {
        resetPasswordForm.customer.email.valid = false;
        resetPasswordForm.customer.email.error = Resource.msg('error.message.passwordreset', 'login', null);
        resetPasswordForm.valid = false;
        res.json({
            fields: formErrors.getFormErrors(resetPasswordForm)
        });

        return next();
    }

    var resettingCustomer = CustomerMgr.getCustomerByLogin(userEmail);

    if (!resettingCustomer) {
        resetPasswordForm.customer.email.valid = false;
        resetPasswordForm.customer.email.error = Resource.msg('error.message.passwordreset.emailnotfound', 'login', null);
        resetPasswordForm.valid = false;
        res.json({
            fields: formErrors.getFormErrors(resetPasswordForm)
        });

        return next();
    }

    transactionalEmailsHelper.sendPasswordResetEmail(userEmail, resettingCustomer);

    res.json({
        success: true,
        receivedMsgHeading: Resource.msg('label.resetpasswordreceived', 'login', null),
        receivedMsgBody: Resource.msg('msg.requestedpasswordreset', 'login', null),
        buttonText: Resource.msg('button.text.loginform', 'login', null),
        mobile: req.querystring.mobile,
        returnUrl: URLUtils.url('Login-Show').toString()
    });
    return next();
});

server.append('SetNewPassword', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.setNewPassword', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.setNewPassword', 'technical', null);
    res.setViewData(viewData);
    next();
});

server.get('PasswordResetRequested', function (req, res, next) {
    res.render('account/password/resetRequestSuccesful', {
        action: 'resetRequestSuccessful'
    });
    next();
});

server.append('Login', function (req, res, next) {

    var viewData = res.getViewData();
    if (viewData.success === true) {
        var profile = session.customer.profile;
        viewData.authenticatedCustomer = {
            lastName: profile.lastName,
            profilePictureURL: profile.custom.hav_profilePictureURL,
            profile: profile,
            email: profile.email,
            id: session.customer.ID
        }
        res.setViewData(viewData);
    }
    next();
},
basket.getPayButtonInfo,
menu.getMenuInfo,
login.getPageComponents);

server.replace('SaveNewPassword', server.middleware.https, function (req, res, next) {
    var CustomerMgr = require('dw/customer/CustomerMgr');
    var Transaction = require('dw/system/Transaction');
    var Resource = require('dw/web/Resource');

    var passwordForm = server.forms.getForm('newPasswords');
    var token = req.querystring.Token;

    var validPassword = true;
    if (passwordForm.newpassword.value !== passwordForm.newpasswordconfirm.value) {
        validPassword = false;
        passwordForm.newpasswordconfirm.error =
            Resource.msg('error.message.mismatch.newpassword', 'forms', null);
    } else if (!passwordForm.newpassword.value || !passwordForm.newpasswordconfirm.value) {
        validPassword = false;
        passwordForm.newpasswordconfirm.error =
            Resource.msg('error.message.password.empty', 'forms', null);
    } else if (!CustomerMgr.isAcceptablePassword(passwordForm.newpassword.value)) {
        validPassword = false;
        passwordForm.newpasswordconfirm.error =
            Resource.msg('error.message.password.constraints.not.matched', 'forms', null);
    }

    if (!validPassword) {
        passwordForm.valid = false;
        passwordForm.newpassword.valid = false;
        passwordForm.newpasswordconfirm.valid = false;
        res.json({
            success: false,
            error: passwordForm.newpasswordconfirm.error
        });
        return next();
    }

    if (passwordForm.valid) {
        var result = {
            newPassword: passwordForm.newpassword.value,
            newPasswordConfirm: passwordForm.newpasswordconfirm.value,
            token: token,
            passwordForm: passwordForm
        };
        res.setViewData(result);
        this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line no-shadow
            var CustomerMgr = require('dw/customer/CustomerMgr');
            var URLUtils = require('dw/web/URLUtils');
            var Site = require('dw/system/Site');
            var emailHelpers = require('*/cartridge/scripts/helpers/emailHelpers');

            var formInfo = res.getViewData();
            var status;
            var resettingCustomer;
            Transaction.wrap(function () {
                resettingCustomer = CustomerMgr.getCustomerByToken(formInfo.token);
                status = resettingCustomer.profile.credentials.setPasswordWithToken(
                    formInfo.token,
                    formInfo.newPassword
                );
                var authenticateCustomerResult = CustomerMgr.authenticateCustomer(resettingCustomer.profile.email, formInfo.newPassword);
                CustomerMgr.loginCustomer(authenticateCustomerResult, false);
            });
            if (status.error) {
                passwordForm.newpassword.valid = false;
                passwordForm.newpasswordconfirm.valid = false;
                passwordForm.newpasswordconfirm.error = passwordForm.newpasswordconfirm.error ?
                    passwordForm.newpasswordconfirm.error :
                    Resource.msg('error.message.resetpassword.invalidformentry', 'forms', null);
                res.json({
                    success: false,
                    error: passwordForm.newpasswordconfirm.error
                });
            } else {
                var email = resettingCustomer.profile.email;

                var transactionalEmailsHelper = require('*/cartridge/scripts/helpers/transactionalEmailsHelper');
                transactionalEmailsHelper.sendAccountEditedEmail(customer.profile);

                res.json({
                    success: true,
                    redirectUrl: URLUtils.url('Home-Show').toString(),
                    modalUrl: URLUtils.url('Account-EditProfile').toString(),
                    authenticatedCustomer: {
                        lastName: resettingCustomer.profile.lastName,
                        profilePictureURL: resettingCustomer.profile.custom.hav_profilePictureURL
                    }
                });
            }
        });
    } else {
        res.json({
            success: false,
            error: passwordForm.newpasswordconfirm.error
        });
    }
    next();
},
basket.getPayButtonInfo,
menu.getMenuInfo,
login.getPageComponents);

module.exports = server.exports();
