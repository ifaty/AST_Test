'use strict';

var server = require('server');
var Home = module.superModule;
server.extend(Home);
var cache = require('*/cartridge/scripts/middleware/cache');
var pageMetaData = require('*/cartridge/scripts/middleware/pageMetaData');

var menu = require('*/cartridge/scripts/middleware/menu');

server.get('MenuHeader', menu.getMenuInfo, function (req, res, next) {
    res.render('components/menu/menuHeader');
    return next();
});

server.get('MenuOrderTracking', menu.getMenuInfo, function (req, res, next) {
    res.render('components/menu/orderTracking');
    return next();
});

server.append('Show', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');

    viewData = res.getViewData();

    var pageFactory = require('*/cartridge/scripts/factories/page');
    var pageModel = pageFactory.get();
    viewData.pageModel = pageModel;

    viewData.action = Resource.msg('pagename.discovery.home', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.discovery.home', 'technical', null);
    // Creating a thin model to polymorphically map the colors matrix colors (see colorMatrixContext.isml)
    viewData.page = {
        ID: storyHelper.getFirstStoryId()
    };
    viewData.redirectLogin = req.querystring.redirectLogin == 'true';
    viewData.pageContext = 'main';
    res.setViewData(viewData);
    next();
});

server.get('ShowCore', cache.applyDefaultCache, function (req, res, next) {
    var Site = require('dw/system/Site');
    var pageMetaHelper = require('*/cartridge/scripts/helpers/pageMetaHelper');

    pageMetaHelper.setPageMetaTags(req.pageMetaData, Site.current);
    var Resource = require('dw/web/Resource');
    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');

    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.discovery.home', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.discovery.home', 'technical', null);
    // Creating a thin model to polymorphically map the colors matrix colors (see colorMatrixContext.isml)
    viewData.page = {
        ID: storyHelper.getFirstStoryId()
    };
    viewData.redirectLogin = req.querystring.redirectLogin == 'true';
    viewData.pageContext = 'main';
    viewData.fallback = true;
    res.render('/home/homePage');
    next();
}, pageMetaData.computedPageMetaData);

server.get('SearchMenu', menu.getMenuInfo, function (req, res, next) {
    res.render('/components/menu/searchMenu', {
        locale: req.locale.id,
        standalone: true
    });
    next();
});

server.append('ErrorNotFound', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.error404', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.error404', 'technical', null);
    res.setViewData(viewData);
    next();
});

module.exports = server.exports();