'use strict';

var server = require('server');
var Default = module.superModule;
server.extend(Default);

/** when sitepath is defined in the site aliases from business manager, homepage will be rendered directly */
server.append('Start', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');

    viewData = res.getViewData();

    var pageFactory = require('*/cartridge/scripts/factories/page');
    var pageModel = pageFactory.get('Home-Show');
    viewData.pageModel = pageModel;
    
    viewData.action = Resource.msg('pagename.discovery.home', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.discovery.home', 'technical', null);
    // Creating a thin model to polymorphically map the colors matrix colors (see colorMatrixContext.isml)
    viewData.page = {
        ID: storyHelper.getFirstStoryId()
    };
    res.setViewData(viewData);
    next();
});


module.exports = server.exports();
