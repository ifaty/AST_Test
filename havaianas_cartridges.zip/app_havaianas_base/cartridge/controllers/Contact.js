'use strict';

var server = require('server');
var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var Resource = require('dw/web/Resource');
var cache = require('*/cartridge/scripts/middleware/cache');

server.get(
    'Show',
    csrfProtection.generateToken,
    server.middleware.https,
    function (req, res, next) {
        var contactForm = server.forms.getForm('contact');

        res.render('contact/contact', {
            contactForm: contactForm,
            action: Resource.msg('pagename.contact', 'technical', null),
            pageContext: Resource.msg('pagecontext.contact', 'technical', null)
        });

        next();
    }
);

server.post(
    'SendContactEmail',
    csrfProtection.validateAjaxRequest,
    function (req, res, next) {
        let contactForm = server.forms.getForm('contact');
        let formErrors = require('*/cartridge/scripts/formErrors');
        let emailHelper = require('*/cartridge/scripts/helpers/emailHelpers.js');
        let institutionalModel = require('*/cartridge/models/institutional/institutional.js');
        let Site = require('dw/system/Site');

        if (!contactForm.valid) {
            res.json({
                success: false,
                fields: formErrors.getFormErrors(contactForm)
            });
            return next();
        }

        try{
            let formData = institutionalModel.parseContactForm(contactForm);
            let email = {
                to: Site.getCurrent().getCustomPreferenceValue('hav_contactEmail') || '',
                from: formData.email.value,
                subject: Resource.msg('contact.title', 'institutional', null) + ' - ' + formData.subject.value
            };

            emailHelper.send(email, 'email/contact', { fields: formData });

            res.json({
                msg: Resource.msg('contact.received', 'institutional', null),
                success: true
            });

            return next();
        }catch (e) {
            res.json({
                msg: Resource.msg('error.message.unexpected', 'forms', null),
                success: false
            });
        }


        next();
    }
);

server.get(
    'NotifyShippingForm',
    csrfProtection.generateToken,
    cache.applyDefaultCache,
    server.middleware.https,
    function (req, res, next) {
        var contactForm = server.forms.getForm('contact');

        res.render('contact/notifyShippingForm', {
            contactForm: contactForm
        });

        next();
    }
);

server.get(
    'BecomeDealer',
    csrfProtection.generateToken,
    server.middleware.https,
    function (req, res, next) {
        var becomeDealerForm = server.forms.getForm('becomeDealer');

        res.render('contact/becomeDealerForm', {
            becomeDealerForm: becomeDealerForm,
            action: Resource.msg('pagename.becomedealer', 'technical', null),
            pageContext: Resource.msg('pagecontext.becomeFranchisee', 'technical', null)
        });

        next();
    }
);

server.post(
    'SaveNotification',
    csrfProtection.validateAjaxRequest,
    function (req, res, next) {
        var contactForm = server.forms.getForm('contact');
        var formErrors = require('*/cartridge/scripts/formErrors');
        var emailHelper = require('*/cartridge/scripts/helpers/emailHelpers.js');
        var Site = require('dw/system/Site');
        var CustomObjectMgr = require('dw/object/CustomObjectMgr');
        var Transaction = require('dw/system/Transaction');
        var notificationHelper = require('*/cartridge/scripts/helpers/notificationHelper.js');

        var email = contactForm.email.value;

        if (!email || !emailHelper.validateEmail(email)) {
            res.json({
                success: false,
                errorMsg: Resource.msgf('error.product.notify.input.email', 'technical', null, userEmail)
            })
            return next();
        }

        if (email) {
            isValid = emailHelper.validateEmail(email);
            if (isValid) {
                var result = notificationHelper.addEmailToNotificationList({
                    email: email,
                    locale: req.locale.id,
                    customObjectID: Site.current.getCustomPreferenceValue('hav_shippingEmailNotificationObjectID') || 'hav_shippingEnabled',
                    errorLogCategory: Site.current.getCustomPreferenceValue('hav_shippingEmailNotificationLogCategory'),
                    customObjectInstance: 'hav_shippingNotificationList'
                });
                res.json({
                    success: result.success,
                    errorMsg: result.errorMsg
                });
            } else {
                contactForm.email.valid = false;
                contactForm.email.error = Resource.msg('error.message.passwordreset', 'login', null);
                contactForm.valid = false;
                res.json({
                    success: false,
                    fields: formErrors.getFormErrors(contactForm)
                });
            }
        } else {
            contactForm.email.valid = false;
            contactForm.email.error = Resource.msg('error.message.required', 'login', null);
            contactForm.valid = false;
            res.json({
                success: false,
                fields: formErrors.getFormErrors(resetPasswordForm)
            });
        }

        next();
    }
);

server.post(
    'SubmitBecomeDealer',
    csrfProtection.validateAjaxRequest,
    function (req, res, next) {
        var becomeDealerForm = server.forms.getForm('becomeDealer');
        var formErrors = require('*/cartridge/scripts/formErrors');
        var emailHelper = require('*/cartridge/scripts/helpers/emailHelpers.js');
        var institutionalModel = require('*/cartridge/models/institutional/institutional.js');
        var Resource = require('dw/web/Resource');
        var Site = require('dw/system/Site');

        var viewData = {};
        viewData.becomeDealerForm = becomeDealerForm;
        res.setViewData(viewData);

        this.on('route:BeforeComplete', function (req, res) {
            var viewData = res.getViewData();
            if (!viewData.becomeDealerForm.valid) {
                res.json({
                    success: false,
                    fields: formErrors.getFormErrors(viewData.becomeDealerForm),
                    msg: Resource.msg('error.message.general', 'institutional', null)
                });
                return;
            }

            var formData = institutionalModel.parseBecomeDealerForm(viewData.becomeDealerForm);

            var email = {
                from: viewData.becomeDealerForm.email.value,
                to: Site.getCurrent().getCustomPreferenceValue('hav_becomeDealerEmail') || 'placeholder@havaianas.com',
                subject: Resource.msg('contact.becomedealer', 'institutional', null)
            };

            emailHelper.send(email, 'email/becomeDealer', { fields: formData });

            res.json({
                success: true,
                sucessMessage: Resource.msg('contact.becomedealer.received', 'institutional', null)
            });
        });

        next();
    }
);

module.exports = server.exports();
