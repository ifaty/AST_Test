'use strict';

var csrfProtection = require('*/cartridge/scripts/middleware/csrf');

var server = require('server');
var Cart = module.superModule;
server.extend(Cart);

var basket = require('*/cartridge/scripts/middleware/basket');

server.append('Show', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.cart', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.cart', 'technical', null);

    res.setViewData(viewData);
    next();
});

server.append('AddProduct', function (req, res, next) {
    var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
    var array = require('*/cartridge/scripts/util/array');
    var viewData = res.getViewData();

    var couponHelpers = require('*/cartridge/scripts/helpers/couponHelper');
    couponHelpers.removeExternalCouponLineItems(true);
    couponHelpers.removeAllInternalCoupons();

    if (!viewData.error) {
        viewData.product = array.find(viewData.cart.items, function (item) {
            if (item.id == req.form.pid)
                return item;
        });
        viewData.currencyCode = session.getCurrency().getCurrencyCode();
        if (req.querystring.context === 'pay') {
            viewData.cart = cartHelper.unrollModel(viewData.cart);
        }
        res.setViewData(viewData);
    }

    next();
},
basket.getPayButtonInfo,
basket.getPayButtonTemplate);

server.append('EditProductLineItem', function (req, res, next) {
    var ProductMgr = require('dw/catalog/ProductMgr');
    var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
    var colorMatrixHelper = require('*/cartridge/scripts/helpers/colorMatrixHelper');
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
    var productCheckoutTile = require('*/cartridge/models/product/productCheckoutTile')
    var URLUtils = require('dw/web/URLUtils');
    var array = require('*/cartridge/scripts/util/array');

    var viewData = res.getViewData();
    if (viewData.error || viewData.errorMessage) {
        return next();
    }

    var apiProduct = ProductMgr.getProduct(req.form.pid);
    var uuid = req.form.uuid;
    var view = req.querystring.view ? req.querystring.view : 'tile';

    viewData.cartModel = cartHelper.unrollModel(viewData.cartModel)

    var itemCartModel = array.find(viewData.cartModel.items, function (item) {
        if (item.id == req.form.pid)
            return item;
    });

    viewData.product = itemCartModel;

    var product = productCheckoutTile({}, apiProduct, 'Cart-EditProductLineItem', itemCartModel?itemCartModel.quantity:null, uuid, view);
    var tileColorMatrix = colorMatrixHelper.get(
        apiProduct.custom.hav_primaryColor,
        'ultralight',//apiProduct.custom.hav_primaryColorTone,
        apiProduct.custom.hav_secondaryColor,
        'ultralight' //apiProduct.custom.hav_secondaryColorTone
    );
    viewData.tileColorMatrix = tileColorMatrix;

    var context = {
        colorMatrix: tileColorMatrix.toJSON(),
        tileColorMatrix: tileColorMatrix,
        product: product,
        uuid: uuid,
        isRefresh: true
    }

    var template = req.querystring.view == 'drawer' ? 'checkout/productCard/drawerTile.isml' : 'checkout/productCard/refreshProductCard.isml';
    var renderedTemplate = renderTemplateHelper.getRenderedHtml(context, template);
    viewData.renderedTemplate = renderedTemplate;
    viewData.productId = product.id;
    viewData.uuid = uuid;
    viewData.success = true;
    viewData.renderedColorMatrix = renderTemplateHelper.getRenderedHtml({
        colorMatrix: colorMatrixHelper.get(
            apiProduct.custom.hav_primaryColor,
            apiProduct.custom.hav_primaryColorTone,
            apiProduct.custom.hav_secondaryColor,
            apiProduct.custom.hav_secondaryColorTone,
            null,
            {
                productColors: true
            }
        ).toJSON()
    }, 'components/color/colorMatrixInclude');
    viewData.productUrl = URLUtils.url('Product-Show', 'pid', product.id).relative().toString();

    return next();
},
basket.getPayButtonInfo,
basket.getPayButtonTemplate);

server.prepend('RemoveProductLineItem', function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var CartModel = require('*/cartridge/models/cart');
    var array = require('*/cartridge/scripts/util/array');

    var couponHelpers = require('*/cartridge/scripts/helpers/couponHelper');
    couponHelpers.removeExternalCouponLineItems(true);
    couponHelpers.removeAllInternalCoupons();

    var currentBasket = BasketMgr.getCurrentBasket();
    var basketModel = new CartModel(currentBasket);

    var viewData = res.getViewData();

    viewData.product = array.find(basketModel.items, function (item) {
        if (item.id == req.querystring.pid)
            return item;
    });

    res.setViewData(viewData);
    next();
});

server.append('RemoveProductLineItem', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
    var viewData = res.getViewData();

    viewData.updateShippingDrawerUrl = URLUtils.url('Checkout-ShippingOverview').toString();
    viewData.usingMultiShipping = req.session.privacyCache.get('usingMultiShipping');
    viewData.cart = cartHelper.unrollModel(viewData.basket);

    res.setViewData(viewData);
    next();
},
basket.getPayButtonInfo,
basket.getPayButtonTemplate);

server.append('UpdateQuantity', function (req, res, next) {
    var array = require('*/cartridge/scripts/util/array');
    var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
    var viewData = res.getViewData();

    var couponHelpers = require('*/cartridge/scripts/helpers/couponHelper');
    couponHelpers.removeExternalCouponLineItems(true);
    couponHelpers.removeAllInternalCoupons();

    if (!viewData.errorMessage) {
        var product = array.find(viewData.items, function (item) {
            if (item.id == req.querystring.pid)
                return item;
        });
        res.setViewData({
            cart: cartHelper.unrollModel(viewData),
            product: product
        });
    }

    next();
},
basket.getPayButtonInfo,
basket.getPayButtonTemplate);

server.append('RemoveCouponLineItem', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var viewData = res.getViewData();

    if (viewData.errorMessage)
        res.setViewData({
            error: true
        });
    else if (!viewData.error)
        res.setViewData({
            error: false,
            errorMessage: '',
            refreshTilesUrl: URLUtils.url('Cart-CouponTiles').toString(),
            basketTotal: viewData.totals.grandTotal
        });

    return next();
});

server.append(
    'AddCoupon',
    server.middleware.https,
    csrfProtection.validateAjaxRequest,
    function (req, res, next) {
        var BasketMgr    = require('dw/order/BasketMgr');
        var couponHelper = require('*/cartridge/scripts/helpers/couponHelper');
        var Resource     = require('dw/web/Resource');
        var URLUtils     = require('dw/web/URLUtils');
        var Transaction = require('dw/system/Transaction');

        var currentBasket = BasketMgr.getCurrentBasket();
        var couponCode    = req.querystring.couponCode;
        var coupon        = couponHelper.getCouponByCode(couponCode);

        if (!coupon || coupon.externalCoupon === false) {
            var viewData = res.getViewData();

            if (!viewData.error && !viewData.errorMessage) {
                var totals = require('*/cartridge/models/totals');
                var { verifyExternalCouponState } = require("*/cartridge/scripts/helpers/couponHelper");

                verifyExternalCouponState();
                var totalsModel = new totals(BasketMgr.getCurrentBasket());

                res.setViewData({
                    basketTotal: totalsModel.grandTotal,
                    error: false,
                    errorMessage: '',
                    refreshTilesUrl: URLUtils.url('Cart-CouponTiles').toString()
                });
            }

            return next();
        }

        if (!coupon.valid) {
            res.setStatusCode(401);
            res.json({
                error: true,
                errorMessage: Resource.msg('error.coupon.invalid', 'checkout', null)
            });
            return next();
        }

        coupon = coupon.coupon;

        var isValidationStoredOnBasket = currentBasket.custom.hav_isValidationStored;

        validationSubject =
            isValidationStoredOnBasket ?
                currentBasket :
                req.querystring

        var validationObj = couponHelper.validateExternalCoupon(coupon, validationSubject);
        if (!validationObj.valid) {
            var errorMessage =
                isValidationStoredOnBasket ?
                    Resource.msg('error.coupon.invalid', 'checkout', null) :
                    ( req.currentCustomer.raw.isAuthenticated() ? Resource.msg('error.coupon.invalid', 'checkout', null):
                                                               Resource.msg('error.coupon.validation', 'checkout', null) );

            res.setStatusCode(401);
            res.json({
                error: true,
                errorMessage: errorMessage,
                fieldErrors: validationObj.fieldErrors
            });
            return next();
        }

        try {
            couponLineItem = couponHelper.createExternalCouponLineItem(coupon);
        } catch (error) {
            res.setStatusCode(406);
            res.json({
                error: true,
                errorMessage: couponHelper.getCouponErrorMessage(error)
            });
            return next();
        }

        var isBalanceUsingEnabled = currentBasket.custom.hav_useCouponBalance;

        if (!isBalanceUsingEnabled) {
            Transaction.wrap(function () {
                currentBasket.custom.hav_useCouponBalance = true;
            });

            /*
                Since we want always to enable the use of coupon balance, we
                also need to make active this newly added coupon and every
                other on storage.
            */
            couponHelper.restoreExternalCouponLineItem();
        }

        if (!isValidationStoredOnBasket) {
            var validations = couponHelper.getSiteEnabledValidations();

            Transaction.wrap(function () {
                validations.forEach(function (validation) {
                    currentBasket.custom[validation.attrName] =
                        req.querystring[validation.htmlName];
                });

                currentBasket.custom.hav_isValidationStored = true;
            });
        }

        res.json({
            error: false,
            errorMessage: '',
            refreshTilesUrl: URLUtils.url('Cart-CouponTiles').toString()
        });

        return next();
    }
);

server.get('EditExternalCoupon', function (req, res, next) {
    var BasketMgr     = require('dw/order/BasketMgr');
    var couponHelper  = require('*/cartridge/scripts/helpers/couponHelper');
    var Decimal       = require('dw/util/Decimal');
    var currentBasket = BasketMgr.getCurrentBasket();
    var Resource      = require('dw/web/Resource');
    var Resource      = require('dw/web/Resource');
    var totals        = require('*/cartridge/models/totals');
    var URLUtils      = require('dw/web/URLUtils');

    var newBalanceUsage = new Decimal(req.querystring.balanceUsage);

    var externalCoupon = couponHelper.getExternalCouponLineItem();

    if (!externalCoupon || !currentBasket.custom.hav_useCouponBalance) {
        res.setStatusCode(404);
        res.json({
            error: true,
            errorMessage: Resource.msg('error.coupon.notfound', 'checkout', null)
        });
        return next();
    }

    var externalCouponMaxBalance = new Decimal(externalCoupon.custom.hav_maxBalance)

    var isThereEnoughBalance =
        newBalanceUsage <= externalCouponMaxBalance;

      if (!isThereEnoughBalance) {
        res.setStatusCode(400);
        res.json({
            error: true,
            errorMessage: Resource.msg('error.coupon.edit.notenoughbalance', 'checkout', null)
        });

        return next();
    }

    var totalWithoutExternalCoupon = couponHelper.getBasketPureTotalAmount();

    var isBalanceAppliable =
        newBalanceUsage <= totalWithoutExternalCoupon;

    if (!isBalanceAppliable) {
        res.setStatusCode(400);
        res.json({
            error: true,
            errorMessage: Resource.msg('error.coupon.edit.higherbalance', 'checkout', null)
        });

        return next();
    }

    couponHelper.changeCouponAppliedAmount(externalCoupon, newBalanceUsage);

    var totals = new totals(currentBasket);

    var isOnlyPickupShipment = currentBasket.shipments.length == 1 ? currentBasket.shipments[0].custom.isPickup : false;

    res.json({
        error: false,
        errorMessage: '',
        isOnlyPickupShipment: isOnlyPickupShipment,
        isPaymentFree: !!couponHelper.getCouponAppliedGiftCertificate(),
        refreshTilesUrl: URLUtils.url('Cart-CouponTiles').toString(),
        basketTotal: totals.grandTotal
    })
    return next();
});

server.append('RemoveCouponLineItem', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var { verifyExternalCouponState } = require("*/cartridge/scripts/helpers/couponHelper");

    var viewData = res.getViewData();

    if (viewData.errorMessage) {
        res.setViewData({
            error: true
        });
        return next();
    }

    verifyExternalCouponState();

    res.setViewData({
        error: false,
        errorMessage: '',
        refreshTilesUrl: URLUtils.url('Cart-CouponTiles').toString(),
        basketTotal: viewData.totals.grandTotal
    });
    return next();
});

server.get('RemoveExternalCoupon', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var BasketMgr = require('dw/order/BasketMgr');
    var totalsModel = require('*/cartridge/models/totals');
    var currentBasket = BasketMgr.getCurrentBasket();
    var { removeExternalCouponLineItems } = require('*/cartridge/scripts/helpers/couponHelper');

    removeExternalCouponLineItems(true);

    var basketTotal = new totalsModel(currentBasket)

    res.json({
        error: false,
        errorMessage: '',
        refreshTilesUrl: URLUtils.url('Cart-CouponTiles').toString(),
        basketTotal: basketTotal.grandTotal
    });

    return next();
});

server.get('CouponInfo',
    server.middleware.https,
    function(req, res, next) {
        var BasketMgr     = require('dw/order/BasketMgr');
        var couponHelper  = require('*/cartridge/scripts/helpers/couponHelper');
        var currentBasket = BasketMgr.getCurrentBasket();
        var Resource      = require('dw/web/Resource');

        var couponCode = req.querystring.couponCode;

        var isValidationStoredOnBasket = currentBasket.custom.hav_isValidationStored;
        if (isValidationStoredOnBasket)  {
            res.json({
                error: false,
                requireValidation: false,
                errorMessage: ''
            });
            return next();
        }

        var coupon = couponHelper.getCouponByCode(couponCode);

        if (!coupon) {
            res.setStatusCode(404);
            res.json({
                error: true,
                fieldErrors: [],
                errorMessage: Resource.msg('error.coupon.notfound', 'checkout', null)
            });
            return next();
        }

        if (!coupon.valid) {
            res.setStatusCode(400);
            res.json({
                error: true,
                fieldErrors: [],
                errorMessage: Resource.msg('error.coupon.invalid', 'checkout', null)
            });

            return next();
        }

        if (coupon.externalCoupon) {
            var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
            var couponHelper = require('*/cartridge/scripts/helpers/couponHelper');
            var validationTemplates = couponHelper.getCouponValidationTemplates();
            var context = res.getViewData();
            context.templates=validationTemplates;
            var renderedTemplate = renderTemplateHelper.getRenderedHtml(context,'validation/validationFields');
            context.renderedTemplate = renderedTemplate;
            context.requireValidation=true;
            res.json(context);

            return next();
        } else {
            res.json({
                error: false,
                requireValidation: false,
                errorMessage: ''
            });
        }

        return next();
    }
);

server.get('CouponTiles', function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var couponHelper = require('*/cartridge/scripts/helpers/couponHelper');
    var currentBasket = BasketMgr.getCurrentBasket();
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');

    /*
      This route plays a important role in the external coupon implementation
      since it determines what the customer should view within the data stored.
     */

    var externalAppliedAmount,
        externalCouponLineItem,
        maxBalance,
        coupons = [];

    var useCouponBalance = currentBasket.custom.hav_useCouponBalance;
    var currentCustomer = req.currentCustomer.raw;

    if (currentCustomer.isAuthenticated()) {
        var customerProfile  = currentCustomer.getProfile();
        var ownedVoucherCode = customerProfile.custom.hav_ownedVoucherCode;
        var couponStorage    = couponHelper.getCouponStorage();

        var isAlreadyOnBasket = couponStorage && couponStorage.code === ownedVoucherCode;

        if (ownedVoucherCode && !isAlreadyOnBasket) {
            var coupon = couponHelper.getCouponByCode(ownedVoucherCode);
            coupon.coupon.isPreSelected = true;
            couponHelper.updateCouponStorage(coupon.coupon);
        }
    }

    currentBasket
        .getCouponLineItems()
        .toArray()
        .forEach(function (couponLineItem) {
            if (couponLineItem.isBasedOnCampaign())
                coupons.push({
                    title: couponLineItem.getCouponCode(),
                    referenceList: [],
                    removeUrl: URLUtils.url('Cart-RemoveCouponLineItem', 'uuid', couponLineItem.getUUID()),
                    value: couponHelper.getInternalCouponDisplayString(couponLineItem),
                    externalCoupon: false
                })
            else if (couponHelper.getCouponAppliedAmount(couponLineItem) > 0)
                externalCouponLineItem = couponLineItem;
                // A external coupon is always a unique object.
        });


    if (!externalCouponLineItem) {
        var couponStorage = couponHelper.getCouponStorage();

        /*
            Refer to cartridge/scripts/helpers/couponHelper to understand why coupon storage is used when there
            is not an applied coupon.
        */

        if (couponStorage) {
            maxBalance = couponStorage.maxBalance;

            if (couponStorage.appliedAmount > 0) {
                externalAppliedAmount = couponStorage.appliedAmount;
                var title = couponStorage.isPendingMerge ?
                    Resource.msg('label.coupon.title.accumulativecoupon', 'checkout', null) :
                    couponStorage.code;

                coupons.push({
                    title: title,
                    referenceList: couponStorage.referenceList,
                    removeUrl: URLUtils.url('Cart-RemoveExternalCoupon'),
                    value: couponHelper.getMoneyFormattedValue(externalAppliedAmount),
                    isPreSelected: couponStorage.isPreSelected,
                    externalCoupon: true
                });
            }
        }
    } else {
        var title = externalCouponLineItem.custom.hav_isPendingMerge ?
            Resource.msg('label.coupon.title.accumulativecoupon', 'checkout', null) :
            externalCouponLineItem.getCouponCode();

        var couponPriceAdjustmentValue = couponHelper.getCouponAppliedAmount(externalCouponLineItem);
        var isGiftCertificateApplied = couponHelper.getCouponAppliedGiftCertificate();

        /*
            Compare the coupon applied value to 1 seems a strange comparison,
            but this is done because it is the value set in purpose to keep the
            coupon on the Order after checkout is done.

            It is set to 1 just when a gift certificate is applied, it occurs when
            the external coupon discounts the entire basket total.

            Refer to cartridge/scripts/helpers/couponHelper to understand why
            Price Adjustment Storage is used.
        */
        externalAppliedAmount = !isGiftCertificateApplied ?
            couponPriceAdjustmentValue :
            externalCouponLineItem.custom.hav_priceAdjustmentStorage;

        maxBalance = externalCouponLineItem.custom.hav_maxBalance;

        var appliedValue = couponHelper.getMoneyFormattedValue(externalAppliedAmount)

        coupons.push({
            title: title,
            referenceList: externalCouponLineItem.custom.hav_referenceList,
            removeUrl: URLUtils.url('Cart-RemoveExternalCoupon'),
            value: appliedValue,
            externalCoupon: true
        });
    }

    var balancePlaceholder = externalAppliedAmount ? externalAppliedAmount : maxBalance;

    var balanceWithoutSymbol = couponHelper.getMoneyFormattedValue(balancePlaceholder, true);
    var formattedMaxBalance = couponHelper.getMoneyFormattedValue(maxBalance);
    var formattedPureTotal = couponHelper.getMoneyFormattedValue(
        couponHelper.getBasketPureTotalAmount()
    );

    res.render('checkout/billing/coupon/activeCoupons', {
        balancePlaceholder: balanceWithoutSymbol,
        coupons: coupons,
        hasExternalCouponApplied: !!externalCouponLineItem,
        zeroBalance: couponHelper.getMoneyFormattedValue(0),
        currencySymbol: session.getCurrency().getSymbol(),
        editExternalCouponUrl: URLUtils.url('Cart-EditExternalCoupon'),
        formattedMaxBalance: formattedMaxBalance,
        formattedPureTotal: formattedPureTotal,
        maxBalance: maxBalance,
        useCouponBalance: useCouponBalance
    });

    return next();
});

server.get('CouponBalance', function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var couponHelper = require('*/cartridge/scripts/helpers/couponHelper');
    var currentBasket = BasketMgr.getCurrentBasket();
    var Transaction = require('dw/system/Transaction');
    var totalsModel = require('*/cartridge/models/totals');
    var URLUtils = require('dw/web/URLUtils');

    var useBalance = JSON.parse(req.querystring.use);

    Transaction.wrap(function () {
        currentBasket.custom.hav_useCouponBalance = useBalance;
    });

    var appliedCoupon = couponHelper.getExternalCouponLineItem();

    if (!useBalance) {
        couponHelper.updateCouponStorage(appliedCoupon);
        couponHelper.removeExternalCouponLineItems();
    } else if (useBalance && !appliedCoupon) {
        couponHelper.restoreExternalCouponLineItem();
    }

    var basketTotal = new totalsModel(currentBasket);

    res.json({
        error: false,
        errorMessage: '',
        refreshTilesUrl: URLUtils.url('Cart-CouponTiles').toString(),
        basketTotal: basketTotal.grandTotal
    });
    return next();
});

server.get('PureTotal', function (req, res, next) {
    var {
        getBasketPureTotalAmount,
        getMoneyFormattedValue
    } = require('*/cartridge/scripts/helpers/couponHelper');

    res.json({
        formattedPureTotal: getMoneyFormattedValue(getBasketPureTotalAmount())
    });
    return next();
});

server.replace('MiniCart', server.middleware.include, basket.getPayButtonInfo, function (req, res, next) {
    
    var { removeExternalCouponLineItems } = require('*/cartridge/scripts/helpers/couponHelper');
    removeExternalCouponLineItems(true);

    res.render('checkout/payButton');
    next();
});

server.replace('Show', function (req, res, next) {
    res.redirect('Home-Show');
    next();
});

module.exports = server.exports();
