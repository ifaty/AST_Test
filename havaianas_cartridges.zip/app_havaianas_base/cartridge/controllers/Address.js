'use strict';

var server = require('server');
var Address = module.superModule;
server.extend(Address);

var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

server.append('List',
    csrfProtection.generateToken,
    consentTracking.consent,
    userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        var addressForm = server.forms.getForm('address');
        addressForm.clear();
        addressForm.lastName.value = req.currentCustomer.profile.lastName;
        addressForm.firstName.value = req.currentCustomer.profile.lastName;
        var Resource = require('dw/web/Resource');
        var viewData = res.getViewData();
        viewData.addressForm = addressForm;
        viewData.action = Resource.msg('pagename.addresses', 'technical', null);
        viewData.pageContext = Resource.msg('pagecontext.addresses', 'technical', null);
        res.setViewData(viewData);
        next();
});

server.append('SaveAddress', function (req, res, next) {
    var CustomerMgr = require('dw/customer/CustomerMgr');
    var Locale = require('dw/util/Locale');
    var Transaction = require('dw/system/Transaction');
    var UUIDUtils = require('dw/util/UUIDUtils');
    var accountHelpers = require('*/cartridge/scripts/helpers/accountHelpers');

    // Setting things up for SaveAddress route executed before this one
    var formInfo = res.getViewData();
    formInfo.addressId = UUIDUtils.createUUID(); // TODO: check whether this stays or not
    formInfo.country = Locale.getLocale(req.locale.id).getCountry(); // TODO: this seems to be broken
    formInfo.firstName = formInfo.lastName;
    res.setViewData(formInfo);

    // Code below deals with 'makeDefault' option
    // It's a copy and paste from Address-SetDefault
    this.on('route:BeforeComplete', function () { // eslint-disable-line no-shadow
        var addressId = formInfo.addressId;
        var customer = CustomerMgr.getCustomerByCustomerNumber(
            req.currentCustomer.profile.customerNo
        );
        var addressBook = customer.getProfile().getAddressBook();
        var address = addressBook.getAddress(addressId);

        if (formInfo.makeDefault != true)
            return;

        Transaction.wrap(function () {
            addressBook.setPreferredAddress(address);
        });

        // Send account edited email
        accountHelpers.sendAccountEditedEmail(customer.profile);

        // No redirects, we don't want to break the flow
        //res.redirect(URLUtils.url('Address-List'));
    });
    next();
});

server.append('EditAddress', function (req, res, next) {
    var CustomerMgr = require('dw/customer/CustomerMgr');
    var Resource = require('dw/web/Resource');

    var viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.editaddress', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.editaddress', 'technical', null);
    // Guaranteeing that every address uses the customer's name.
    viewData.addressForm.lastName.value = req.currentCustomer.profile.lastName;
    viewData.addressForm.firstName.value = req.currentCustomer.profile.lastName;
    var addressId = viewData.addressId;
    var customer = CustomerMgr.getCustomerByCustomerNumber(
        req.currentCustomer.profile.customerNo
    );
    var addressBook = customer.getProfile().getAddressBook();
    if (addressId === addressBook.getAddresses()[0].getID()) {
        viewData.defaultAddress = true;
    }
    res.setViewData(viewData);
    next();
});

server.append('DeleteAddress', function (req, res, next) {
    var CustomerMgr = require('dw/customer/CustomerMgr');
    var Resource = require('dw/web/Resource');

    var data = res.getViewData();
    if (data && !data.loggedin) {
        res.json();
        return next();
    }

    var customer = CustomerMgr.getCustomerByCustomerNumber(
        req.currentCustomer.profile.customerNo
    );
    var addressBook = customer.getProfile().getAddressBook();
    var length = addressBook.getAddresses().length;
    this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line no-shadow
        var newLength = addressBook.getAddresses().length;

        if (length !== 0 && newLength < length) {
            data.success = true;
            data.successMsg = Resource.msg('msg.remove.successful', 'address', null);
        } else {
            data.success = false;
        }
        res.viewData = data;
    });
    return next();
});

// This is a stub route that should be replaced in each country-specific cartridge
server.get('AutoCompleteAddress', function (req, res, next) {
    res.json({});
    next();
});

module.exports = server.exports();
