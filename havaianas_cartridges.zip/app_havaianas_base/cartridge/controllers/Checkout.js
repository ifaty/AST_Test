'use strict';

var server = require('server');

var Checkout = module.superModule;
server.extend(Checkout);

var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');

var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

server.append('Login', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.checkout', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.checkout', 'technical', null);
    res.setViewData(viewData);
    next();
});

server.replace(
    'Begin',
    server.middleware.https,
    consentTracking.consent,
    csrfProtection.generateToken,
    function (req, res, next) {
        var BasketMgr = require('dw/order/BasketMgr');
        var PaymentInstrument = require('dw/order/PaymentInstrument');
        var Order = require('dw/order/Order');
        var OrderMgr = require('dw/order/OrderMgr');
        var ShippingMgr = require('dw/order/ShippingMgr');
        var Transaction = require('dw/system/Transaction');
        var AccountModel = require('*/cartridge/models/account');
        var AddressModel = require('*/cartridge/models/address');
        var OrderModel = require('*/cartridge/models/order');
        var URLUtils = require('dw/web/URLUtils');
        var reportingUrlsHelper = require('*/cartridge/scripts/reportingUrls');
        var Locale = require('dw/util/Locale');
        var Logger = require('dw/system/Logger');
        var collections = require('*/cartridge/scripts/util/collections');
        var validationHelpers = require('*/cartridge/scripts/helpers/basketValidationHelpers');
        var couponHelper = require('*/cartridge/scripts/helpers/couponHelper');

        var currentBasket = BasketMgr.getCurrentBasket();
        if (!currentBasket) {
            res.redirect(URLUtils.url('Cart-Show'));
            return next();
        }

        var validatedProducts = validationHelpers.validateProducts(currentBasket);
        if (validatedProducts.error) {
            res.redirect(URLUtils.url('Cart-Show'));
            return next();
        }

        // We always invalidate this session variable in the first stage of checkout.
        // But only in the first stage, this is to avoid accidentally re-rendering the billing div twice.
        if (!req.querystring.stage) {
            req.session.privacyCache.set('usedPreferredAddress', false);
        }
        var currentStage = req.querystring.stage ? req.querystring.stage : 'shipping';

        var billingAddress = currentBasket.billingAddress;

        var currentCustomer = req.currentCustomer.raw;
        var userAuthenticated = req.currentCustomer.raw.authenticated;
        var currentLocale = Locale.getLocale(req.locale.id);
        var preferredAddress;
        var useCustomerInfo;
        var shipments;
        var paymentInstrument = currentBasket.paymentInstrument;
        var lastPaymentInstrument;

        // The correct is remove the coupon only when the stage is not placeOrder, otherwise will not apply the coupon at end of checkoutprocess
        if ((userAuthenticated && currentBasket.custom.hav_isValidationStored && currentStage != 'placeOrder') || currentStage == 'shipping') {
            couponHelper.removeExternalCouponLineItems(true);
            couponHelper.removeAllInternalCoupons();
        }

        if (userAuthenticated) {
            var paymentInstrumentsCreditCard = req.currentCustomer.raw.getProfile().getWallet().getPaymentInstruments(PaymentInstrument.METHOD_CREDIT_CARD);
            if (paymentInstrumentsCreditCard.length > 0) {
                lastPaymentInstrument = paymentInstrumentsCreditCard[0];
            }
        }
        
        // First we try to get the last order's shipping address.
        if(userAuthenticated && req.currentCustomer.raw.orderHistory.orderCount > 0 && currentBasket){
            var lastOrder = OrderMgr.searchOrders(
                'customerNo={0} AND status!={1}',
                'creationDate desc',
                req.currentCustomer.raw.profile.customerNo,
                Order.ORDER_STATUS_FAILED
            ).first();
            if(lastOrder){
                if (currentStage != 'payment' && currentStage != 'placeOrder') {
                    preferredAddress = new AddressModel(lastOrder.shipments[0].shippingAddress);
                }
                useCustomerInfo = true;
                paymentInstrument = currentBasket.paymentInstrument;
            }

            //By the doc if the last payment was credit_card it should be used
            if(lastOrder && lastOrder.paymentInstrument.paymentMethod == PaymentInstrument.METHOD_CREDIT_CARD){
                collections.forEach(paymentInstrumentsCreditCard, function (paymentInstrumentLoop) {
                    //Verification to make sure that the last used card is saved in the wallet yet
                    if (paymentInstrumentLoop.creditCardToken == lastOrder.paymentInstrument.creditCardToken) {
                        lastPaymentInstrument = lastOrder.paymentInstrument;
                    }
                });
            }
        }

        // If there's no last order, we try to get the preferred address from the address book
        if (!preferredAddress &&
            req.currentCustomer.addressBook && req.currentCustomer.addressBook.preferredAddress
            && currentStage != 'payment'
            && currentStage != 'placeOrder') {
                useCustomerInfo = true;
                preferredAddress = {address: req.currentCustomer.addressBook.preferredAddress};
                req.session.privacyCache.set('usedPreferredAddress', true);
            }

        shipments = currentBasket.shipments;

        if (preferredAddress) {
            Transaction.wrap(function () {
                collections.forEach(shipments, function (shipment) {
                    COHelpers.copyShippingAddressToShipment(preferredAddress, shipment);
                });
            })

            if (!billingAddress) {
                COHelpers.copyCustomerAddressToBilling(preferredAddress.address);
            }
            Transaction.wrap(function () {
                ShippingMgr.applyShippingCost(currentBasket);
                currentBasket.updateTotals();
            });
            // Update shipments passed to view data
            shipments = currentBasket.shipments;
        }

        try {
            Transaction.wrap(function () {
                collections.forEach(shipments, function (shipment) {
                    COHelpers.setupCustomerNameInShippingAddress(shipment.getShippingAddress());
                });
            })
        } catch (e) {
            Logger.warn('Failed to retrieve customer name on checkout. Stack trace: ' + e.stack);
        }

        Transaction.wrap(function () {
            COHelpers.ensureNoEmptyShipments(req);
        });

        if (currentBasket.shipments.length <= 1) {
            req.session.privacyCache.set('usingMultiShipping', false);
        }
        // We start out without a forced merge.
        // Very important!
        if (empty(currentStage)) {
            req.session.privacyCache.set('forcedMerge', false);
        }

        if (currentBasket.currencyCode !== req.session.currency.currencyCode) {
            Transaction.wrap(function () {
                currentBasket.updateCurrency();
            });
        }

        COHelpers.recalculateBasket(currentBasket);

        var shippingForm = COHelpers.prepareShippingForm(currentBasket);
        var billingForm = COHelpers.prepareBillingForm(currentBasket);
        var usingMultiShipping = req.session.privacyCache.get('usingMultiShipping');
        if (preferredAddress && currentStage != 'payment' && currentStage != 'placeOrder') {
            shippingForm.copyFrom(preferredAddress);
            billingForm.copyFrom(preferredAddress);
        }

        // Loop through all shipments and make sure all are valid
        var allValid = COHelpers.ensureValidShipments(currentBasket);

        var orderModel = new OrderModel(
            currentBasket,
            {
                customer: currentCustomer,
                usingMultiShipping: usingMultiShipping,
                shippable: allValid,
                countryCode: currentLocale.country,
                containerView: 'basket'
            }
        );

        // Get rid of this from top-level ... should be part of OrderModel???
        var currentYear = new Date().getFullYear();
        var creditCardExpirationYears = [];

        for (var j = 0; j < 10; j++) {
            creditCardExpirationYears.push(currentYear + j);
        }

        var accountModel = new AccountModel(req.currentCustomer);

        var reportingURLs;
        reportingURLs = reportingUrlsHelper.getCheckoutReportingURLs(
            currentBasket.UUID,
            2,
            'Shipping'
        );

        var usedPreferredAddress = req.session.privacyCache.get('usedPreferredAddress');
        
        var acceptedTerms = userAuthenticated ? req.currentCustomer.raw.profile.custom.hav_termsAndPrivacyPolicy ? req.currentCustomer.raw.profile.custom.hav_termsAndPrivacyPolicy : false  : false;
        
        //For now, only if there is one shipment and it isPickup
        var isOnlyPickupShipment = shipments.length == 1 ? shipments[0].custom.isPickup : false;

        res.render('checkout/checkout', {
            order: orderModel,
            customerNo: userAuthenticated ? req.currentCustomer.profile.customerNo : '',
            customer: accountModel,
            forms: {
                shippingForm: shippingForm,
                billingForm: billingForm
            },
            expirationYears: creditCardExpirationYears,
            currentStage: currentStage,
            reportingURLs: reportingURLs,
            useCustomerInfo: useCustomerInfo,
            usedPreferredAddress: usedPreferredAddress,
            shipments: shipments,
            isOnlyPickupShipment: isOnlyPickupShipment,
            paymentInstrument: paymentInstrument,
            lastPaymentInstrument: lastPaymentInstrument,
            productID: orderModel.productQuantityTotal > 0 ? orderModel.items.items[0].id : null,
            acceptedTerms: acceptedTerms
        });

        return next();
    }
);

server.append('Begin', function (req, res, next) {
    var ProductMgr          = require('dw/catalog/ProductMgr');
    var productCheckoutTile = require('*/cartridge/models/product/productCheckoutTile')
    var Resource            = require('dw/web/Resource');
    var couponHelper = require('*/cartridge/scripts/helpers/couponHelper');
    var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
    var BasketMgr = require('dw/order/BasketMgr');
    var Site = require('dw/system/Site');

    var viewData = res.getViewData();
    var order    = viewData.order;
    if (order.items.totalQuantity > 0) {

        var orderProductLineItems = order.items.items;
        orderProductLineItems.forEach(function(productLineItem) {
            var apiProduct       = ProductMgr.getProduct(productLineItem.id);
            var productTileModel = productCheckoutTile(
                {}, apiProduct, 'Cart-EditProductLineItem', productLineItem.quantity, productLineItem.UUID, 'tile'
            );
            productLineItem.checkoutTileModel = productTileModel;
        });
    }
    
    viewData.action = Resource.msg('pagename.checkout.'+viewData.currentStage, 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.checkout.'+viewData.currentStage, 'technical', null);

    var currentBasket = BasketMgr.getCurrentBasket();
    var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');

    COHelpers.recalculateBasket(currentBasket);   

    viewData.isUserAuthenticated = req.currentCustomer.raw.authenticated;

    var guestData = {};

    couponHelper
       .getSiteEnabledValidations()
       .forEach(function (validation) {
           var validationData = currentBasket.custom[validation.attrName];
           if (validationData)
               guestData[validation.attrName] =
                   currentBasket.custom[validation.attrName];
       });

    var selectedPaymentInstrument = order.billing.payment.selectedPaymentInstruments;
        selectedPaymentInstrument = 
            selectedPaymentInstrument.length ? 
                selectedPaymentInstrument[0] :
                {}

    var selectedGiftCertificateCode = selectedPaymentInstrument.giftCertificateCode

    var hasGiftCertificateFulfill = selectedGiftCertificateCode &&
        selectedGiftCertificateCode ===  couponHelper.getFulFillGiftCertificateCode();

    viewData.guestData = guestData;
    viewData.hasGiftCertificateFulfill = hasGiftCertificateFulfill
    viewData.multiShippingEnabled = Site.getCurrent().getPreferences().getCustom()["hav_enableMultishipping"];

    res.setViewData(viewData);
    next();
});

server.get('SelectShipping',
    server.middleware.https,
    consentTracking.consent,
    csrfProtection.generateToken, function (req, res, next) {
    var Resource            = require('dw/web/Resource');
    var Locale = require('dw/util/Locale');
    var OrderModel = require('*/cartridge/models/order');
    var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
    var BasketMgr = require('dw/order/BasketMgr');
    var shippingForm = server.forms.getForm('shipping');

    var couponHelpers = require('*/cartridge/scripts/helpers/couponHelper');
    couponHelpers.removeExternalCouponLineItems(true);
    couponHelpers.removeAllInternalCoupons();

    var viewData = res.getViewData();
    viewData.modal = true;

    var currentBasket = BasketMgr.getCurrentBasket();

    COHelpers.recalculateBasket(currentBasket);
    var shippingForm = COHelpers.prepareShippingForm(currentBasket);

    var usingMultiShipping = req.session.privacyCache.get('usingMultiShipping');
    var currentLocale = Locale.getLocale(req.locale.id);

    var order = new OrderModel(
        currentBasket,
        { usingMultiShipping: usingMultiShipping, countryCode: currentLocale.country, containerView: 'cached' }
    );

    viewData.action = Resource.msg('pagename.checkout.select-shipping', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.checkout.select-shipping', 'technical', null);

    viewData.order = order;
    var shippingModel;
    order.shipping.forEach(function (e) {
        if (e.UUID == req.querystring.ID) {
            shippingModel = e;
        }
    });
    viewData.shippingModel = shippingModel ? shippingModel : order.shipping[0];
    viewData.forms = {
        shippingForm: shippingForm
    }
    viewData.type = req.querystring.type;
    viewData.currentStage = 'select-shipping';


    res.render('checkout/shipping/shippingModal', viewData);
    next();
});

server.post('EditShippingMethod',
    server.middleware.https,
    consentTracking.consent,
    csrfProtection.generateToken, function (req, res, next) {
        var BasketMgr = require('dw/order/BasketMgr');
        var Transaction = require('dw/system/Transaction');
        var AccountModel = require('*/cartridge/models/account');
        var OrderModel = require('*/cartridge/models/order');
        var URLUtils = require('dw/web/URLUtils');
        var collections = require('*/cartridge/scripts/util/collections');
        var Locale = require('dw/util/Locale');
        var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
        var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
        var shippingHelpers = require('*/cartridge/scripts/checkout/shippingHelpers');
        var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
    
        var currentBasket = BasketMgr.getCurrentBasket();
        if (!currentBasket) {
            res.json({
                error: true,
                cartError: true,
                fieldErrors: [],
                serverErrors: [],
                redirectUrl: URLUtils.url('Cart-Show').toString()
            });
            return;
        }
    
        var usingMultiShipping = req.session.privacyCache.get('usingMultiShipping');
        var shipmentUUID = req.querystring.shipmentUUID;
        if (!shipmentUUID) {
            res.json({
                error: true,
                cartError: true,
                fieldErrors: [],
                serverErrors: [],
                redirectUrl: URLUtils.url('Cart-Show').toString()
            });
            return;
        }
        var shipment = shippingHelpers.getShipmentByUUID(currentBasket, shipmentUUID);

        // This is so we can do integration-specific cleanup if needed
        shippingHelpers.clearShippingMethod(currentBasket, shipment);

        Transaction.wrap(function () {
            shipment.setShippingMethod(null);
            basketCalculationHelpers.calculateTotals(currentBasket);
        });


        var currentLocale = Locale.getLocale(req.locale.id);

        var basketModel = new OrderModel(
            currentBasket,
            { usingMultiShipping: usingMultiShipping,
              countryCode: currentLocale.country,
              containerView: 'basket',
              invalidate: usingMultiShipping,
              edit: shipment.ID }
        );
    
        var context = {
            customer: new AccountModel(req.currentCustomer),
            order: basketModel,
            forms: {
                shippingForm: COHelpers.prepareShippingForm(currentBasket),
            },
            success: true,
            editUUID: shipmentUUID
        };
        var renderedTemplate = renderTemplateHelper.getRenderedHtml(context,'checkout/shipping/components/shippingMethodOverview');
        context.renderedTemplate = renderedTemplate;
        res.json(context);
    
        next();
});

server.get('EditDrawer', function (req, res, next) {
    var colorMatrixHelper    = require('*/cartridge/scripts/helpers/colorMatrixHelper');
    var array                = require('*/cartridge/scripts/util/array');
    var BasketMgr            = require('dw/order/BasketMgr');
    var ProductMgr           = require('dw/catalog/ProductMgr');
    var Resource = require('dw/web/Resource');
    var productCheckoutTile  = require('*/cartridge/models/product/productCheckoutTile')

    var currentBasket = BasketMgr.getCurrentBasket();
    var productId     = req.querystring.pid;
    var uuid          = req.querystring.uuid;

    var productLineItem = currentBasket.allProductLineItems;
    productLineItem = array.find(productLineItem, function (item) {
        return item.UUID === uuid;
    });

    var apiProduct = ProductMgr.getProduct(productId);
    var product    = productCheckoutTile(
        {}, apiProduct, 'Cart-EditProductLineItem', productLineItem.quantityValue, uuid, 'drawer'
    );

    var tileColorMatrix = colorMatrixHelper.get(
        apiProduct.custom.hav_primaryColor,
        'ultralight',//apiProduct.custom.hav_primaryColorTone,
        apiProduct.custom.hav_secondaryColor,
        'ultralight' //apiProduct.custom.hav_secondaryColorTone
    );

    res.render('checkout/productCard/editProductDrawer', {
        product: product,
        colorMatrix: tileColorMatrix.toJSON(),
        uuid: uuid,
        action: Resource.msg('pagename.checkout.editdrawer', 'technical', null),
        pageContext: Resource.msg('pagecontext.checkout.editdrawer', 'technical', null)
    });
    return next();
});

server.get('ShippingOverview',
    server.middleware.https,
    consentTracking.consent, function (req, res, next) {
        var BasketMgr = require('dw/order/BasketMgr');
        var Transaction = require('dw/system/Transaction');
        var AccountModel = require('*/cartridge/models/account');
        var OrderModel = require('*/cartridge/models/order');
        var URLUtils = require('dw/web/URLUtils');
        var Locale = require('dw/util/Locale');
        var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
        var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
        var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
    
        var currentBasket = BasketMgr.getCurrentBasket();
        if (!currentBasket) {
            res.json({
                error: true,
                cartError: true,
                fieldErrors: [],
                serverErrors: [],
                redirectUrl: URLUtils.url('Cart-Show').toString()
            });
            return next();
        }

        var usingMultiShipping;
        if (currentBasket.shipments.length > 1) {
            req.session.privacyCache.set('usingMultiShipping', true);
            usingMultiShipping = req.session.privacyCache.get('usingMultiShipping');
        } else {
            usingMultiShipping = false;
            req.session.privacyCache.set('usingMultiShipping', false);
        }

        Transaction.wrap(function () {
            basketCalculationHelpers.calculateTotals(currentBasket);
        });


        var currentLocale = Locale.getLocale(req.locale.id);

        var basketModel = new OrderModel(
            currentBasket,
            { usingMultiShipping: usingMultiShipping, countryCode: currentLocale.country, containerView: 'basket' }
        );
    
        var context = {
            customer: new AccountModel(req.currentCustomer),
            order: basketModel,
            forms: {
                shippingForm: COHelpers.prepareShippingForm(currentBasket),
            },
            success: true
        };
        var renderedTemplate = renderTemplateHelper.getRenderedHtml(context,'checkout/shipping/components/shippingMethodOverview');
        context.renderedTemplate = renderedTemplate;
        // CHANGE THIS!!!
        context.showEditDrawer = basketModel.shipping[0].applicableShippingMethods.length<=1;
        res.json(context);
    
        next();
});

module.exports = server.exports();