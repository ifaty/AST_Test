'use strict';

var server = require('server');

server.get('Show', function (req, res, next) {
    var reviewsHelper = require('*/cartridge/scripts/helpers/reviewsHelper');

    if (!reviewsHelper.productReviewsEnabled()) {
        return next();
    }
    // Implement core behaviour here.
    return next();
});

module.exports = server.exports();
