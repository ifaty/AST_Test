'use strict';
var server = require('server');

var Login = module.superModule;
server.extend(Login);

var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

var login = require('*/cartridge/scripts/middleware/login');
var menu = require('*/cartridge/scripts/middleware/menu');
var basket = require('*/cartridge/scripts/middleware/basket');

function parseResponse (response) {
    var externalProfile = JSON.parse(response || 'null');

    if (!externalProfile)
        return null;

    var email = externalProfile['email-address'] || externalProfile.email;

    if (!email) {
        var emails = externalProfile.emails;

        if (emails && emails.length) {
            email = externalProfile.emails[0].value;
        }
    }

    var profilePictureURL;

    // Facebook comes with a 'picture' property that's an object
    if (typeof externalProfile.picture === 'object') {
        profilePictureURL = externalProfile.picture.data.url;
    }
    else {
        // While Google's 'picture' object is the URL itself
        profilePictureURL = externalProfile.picture;
    }
    
    return {
        id: externalProfile.id || externalProfile.uid,
        name: externalProfile.name,
        email: email,
        profilePictureURL: profilePictureURL
    };
}

server.get(
    'CreateAccount',
    consentTracking.consent,
    server.middleware.https,
    csrfProtection.generateToken,
    function (req, res, next) {
        var Resource = require('dw/web/Resource');
        var URLUtils = require('dw/web/URLUtils');
        var Site = require('dw/system/Site');
        var sitePrefs = Site.getCurrent().getPreferences();
        var availableShoeSizes = JSON.parse(sitePrefs.getCustom()["hav_availableShoeSizes"] || "[]");
        var availableClothingSizes = JSON.parse(sitePrefs.getCustom()["hav_availableClothingSizes"] || "[]");

        var target = req.querystring.rurl || 1;

        var createAccountUrl = URLUtils.url('Account-SubmitRegistration', 'rurl', target).relative().toString();

        var profileForm = server.forms.getForm('profile');
        profileForm.clear();

        var isFromGuestUser = false;
        if (req.querystring.orderIdNewUser) {
            var dateUtils = require('*/cartridge/config/dateUtils');
            var OrderMgr = require('dw/order/OrderMgr');
            var order = OrderMgr.getOrder(req.querystring.orderIdNewUser);
            profileForm.customer.lastname.value = order.customerName;
            profileForm.customer.email.value = order.customerEmail;
            profileForm.customer.idnumber.value = order.custom.hav_customerIdNumber;
            profileForm.customer.dateofbirth.value = order.custom.hav_customerDateOfBirth ? dateUtils.dateToString(order.custom.hav_customerDateOfBirth) : null;
            isFromGuestUser = true;
        }

        res.render('/account/createAccount', {
            profileForm: profileForm,
            isFromGuestUser: isFromGuestUser,
            orderIdNewUser: req.querystring.orderIdNewUser,
            oAuthReentryEndpoint: 1,
            createAccountUrl: createAccountUrl,
            availableClothingSizes: availableClothingSizes,
            availableShoeSizes: availableShoeSizes,
            action: Resource.msg('pagename.createaccount', 'technical', null),
            pageContext: Resource.msg('pagecontext.createaccount', 'technical', null)
        });

        next();
    }
);

server.replace('OAuthReentry', server.middleware.https, consentTracking.consent, function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var oauthLoginFlowMgr = require('dw/customer/oauth/OAuthLoginFlowMgr');
    var CustomerMgr = require('dw/customer/CustomerMgr');
    var Transaction = require('dw/system/Transaction');
    var Resource = require('dw/web/Resource');

    var destination = req.session.privacyCache.store.oauthLoginTargetEndPoint;

    var finalizeOAuthLoginResult = oauthLoginFlowMgr.finalizeOAuthLogin();
    if (!finalizeOAuthLoginResult) {
        res.redirect(URLUtils.url('Login-Show'));
        return next();
    }

    var response = finalizeOAuthLoginResult.userInfoResponse.userInfo;
    var oauthProviderID = finalizeOAuthLoginResult.accessTokenResponse.oauthProviderId;
    var parsedData = parseResponse(response);
    var userID = parsedData.id;

    if ( !(oauthProviderID && response && parsedData && userID) ) {
        res.render('/error', {
            message: Resource.msg('error.oauth.login.failure', 'login', null)
        });

        return next();
    }

    var customer = CustomerMgr.getCustomerByLogin(parsedData.email);
    var externalProfile = CustomerMgr.getExternallyAuthenticatedCustomerProfile(
        oauthProviderID,
        userID
    );

    if (!externalProfile) {

        // Customer already registered, let's set things up to create a social profile
        if (customer) {
            Transaction.wrap(function () {
                var newExternalProfile = customer.createExternalProfile(oauthProviderID, userID);
                newExternalProfile.setEmail(parsedData.email);
                externalProfile = CustomerMgr.getExternallyAuthenticatedCustomerProfile(
                    oauthProviderID,
                    userID
                );
            });
        } else {
            // Customer doesn't exist
            Transaction.wrap(function () {
                customer = CustomerMgr.createExternallyAuthenticatedCustomer(
                    oauthProviderID,
                    userID
                );

                externalProfile = customer.getProfile();
            });
        }
    }
    
    // Update Info
    Transaction.wrap(function () {
        if (parsedData.profilePictureURL)
            externalProfile.custom.hav_profilePictureURL = parsedData.profilePictureURL;

        externalProfile.setLastName(parsedData.name);
        externalProfile.setEmail(parsedData.email);
    })
    var credentials = externalProfile.getCredentials();
    if (credentials.isEnabled()) {
        Transaction.wrap(function () {
            CustomerMgr.loginExternallyAuthenticatedCustomer(oauthProviderID, userID, false);
        });
    } else {
        res.render('/error', {
            message: Resource.msg('error.oauth.login.failure', 'login', null)
        });

        return next();
    }

    req.session.privacyCache.clear();
    res.redirect(URLUtils.url(destination));

    return next();
});

server.get('LinkSocial', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var CustomerMgr = require('dw/customer/CustomerMgr');
    var Transaction = require('dw/system/Transaction');
    var Resource = require('dw/web/Resource');

    var destination = req.session.privacyCache.store.oauthLoginTargetEndPoint;
    var oauthProviderID = req.session.privacyCache.store.oauthProviderID;
    var userID = req.session.privacyCache.store.userID;
    var email = req.session.privacyCache.store.email;

    var customer = CustomerMgr.getCustomerByLogin(email);

    Transaction.wrap(function () {
        var newExternalProfile = customer.createExternalProfile(oauthProviderID, userID);
        newExternalProfile.setEmail(email);
        authenticatedCustomerProfile = CustomerMgr.getExternallyAuthenticatedCustomerProfile(
            oauthProviderID,
            userID
        );
    });

    var credentials = authenticatedCustomerProfile.getCredentials();
    if (credentials.isEnabled()) {
        Transaction.wrap(function () {
            CustomerMgr.loginExternallyAuthenticatedCustomer(oauthProviderID, userID, false);
        });
    } else {
        res.render('/error', {
            message: Resource.msg('error.oauth.login.failure', 'login', null)
        });

        return next();
    }

    req.session.privacyCache.clear();
    res.redirect(URLUtils.url(destination));

    return next();
});

server.append('Show', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var Site = require('dw/system/Site');
    var sitePrefs = Site.getCurrent().getPreferences();

    var oauthProviders = JSON.parse(sitePrefs.getCustom()["hav_oauthProviders"] || "{}");

    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.login', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.login', 'technical', null);
    viewData.oauthProviders = oauthProviders;
    viewData.oAuthReentryEndpoint = 4; // This corresponds to Home-Show, it's a temporary measure to not break site flow
    res.setViewData(viewData);
    next();
});

server.replace('OAuthLogin', server.middleware.https, consentTracking.consent, function (req, res, next) {
    var oauthLoginFlowMgr = require('dw/customer/oauth/OAuthLoginFlowMgr');
    var Site = require('dw/system/Site');
    var Resource = require('dw/web/Resource');
    var endpoints = require('*/cartridge/config/oAuthRenentryRedirectEndpoints');

    var sitePrefs = Site.getCurrent().getPreferences();
    var oauthProviders = JSON.parse(sitePrefs.getCustom()["hav_oauthProviders"] || "{}");

    if (req.querystring.oauthProvider) {
        var oauthProvider = req.querystring.oauthProvider;
        if (oauthProviders[oauthProvider] !== true) {
            res.render('/error', {
                message: Resource.msg('error.oauth.login.failure', 'login', null)
            });
            return next();
        }
    } else {
        return next();
    }

    var targetEndPoint = req.querystring.oauthLoginTargetEndPoint
        ? parseInt(req.querystring.oauthLoginTargetEndPoint, 10)
        : null;

    if (targetEndPoint && endpoints[targetEndPoint]) {
        req.session.privacyCache.set(
            'oauthLoginTargetEndPoint',
            endpoints[targetEndPoint]
        );
    } else {
        res.render('/error', {
            message: Resource.msg('error.oauth.login.failure', 'login', null)
        });

        return next();
    }

    if (req.querystring.oauthProvider) {
        var oauthProvider = req.querystring.oauthProvider;
        var result = oauthLoginFlowMgr.initiateOAuthLogin(oauthProvider);

        if (result) {
            res.redirect(result.location);
        } else {
            res.render('/error', {
                message: Resource.msg('error.oauth.login.failure', 'login', null)
            });

            return next();
        }
    } else {
        res.render('/error', {
            message: Resource.msg('error.oauth.login.failure', 'login', null)
        });

        return next();
    }

    return next();
});

server.replace('Logout', function (req, res, next) {
    var CustomerMgr = require('dw/customer/CustomerMgr');
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');

    CustomerMgr.logoutCustomer(false);
    res.json({
        success: true,
        redirectUrl: URLUtils.url('Home-Show').toString(),
        successMsg: Resource.msg('msg.logout.successful', 'login', null)
    });
    next();
},
basket.getPayButtonInfo,
menu.getMenuInfo,
login.getPageComponents);

module.exports = server.exports();