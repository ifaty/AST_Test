'use strict';

var server = require('server');
var ErrorController = module.superModule;
server.extend(ErrorController);

server.append('Start', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var colorMatrixHelper = require("*/cartridge/scripts/helpers/colorMatrixHelper");
    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');
    var storySettings = storyHelper.getStorySettings();
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.error', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.error', 'technical', null);
    viewData.failsafeColors = true;
    var customProperties =
        storySettings.stories[storyHelper.getFirstStoryId()]; // color settings are contained in the story object.
    viewData.colorMatrix = colorMatrixHelper.get(
        customProperties.primaryColor,
        customProperties.primaryColorTone,
        customProperties.secondaryColor,
        customProperties.secondaryColorTone,
        {
            secondRainbowColor: customProperties.secondRainbowColor,
            thirdRainbowColor: customProperties.thirdRainbowColor
        }
    ).toJSON();
    res.setViewData(viewData);
    next();
});

server.append('ErrorCode', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.errorcode', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.errorcode', 'technical', null);
    res.setViewData(viewData);
    next();
});

module.exports = server.exports();