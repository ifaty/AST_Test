'use strict';
var server = require('server');
server.get('Show', function (req, res, next) {
    res.render('/components/menu/menu', {
        redirectLogin: req.querystring.redirectLogin == 'true'
    });
    next();
});
module.exports = server.exports();