'use strict';

/**
 * DISCLAIMER:
 *
 * This is a development-only controller.
 * It should be removed once we fix whatever is happening with Page-Show.
 */

var server = require('server');

server.get('Show', function (req, res, next) {
    var System = require('dw/system/System');
    if (System.getInstanceType() != System.DEVELOPMENT_SYSTEM) {
        return next();
    }

    res.render('components/content/contentAssetStripped', {
        aid: req.querystring.cid
    });
    next();
});


module.exports = server.exports();
