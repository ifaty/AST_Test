'use strict';

var server = require('server');
var cache = require('*/cartridge/scripts/middleware/cache');

server.get('Show', cache.applyDefaultCache, function (req, res, next) {
    var { getRainbowColors } = require('*/cartridge/scripts/helpers/rainbowHelper');

    res.render('components/rainbow/rainbow', {
        rainbowColors: getRainbowColors(),
    });

    return next();
});

module.exports = server.exports();