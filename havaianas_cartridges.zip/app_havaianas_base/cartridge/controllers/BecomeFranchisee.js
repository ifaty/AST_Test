'use strict';

const server = require('server');
const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const Resource = require('dw/web/Resource');
const cache = require('*/cartridge/scripts/middleware/cache');
const Logger = require('dw/system/Logger');

server.get(
    'Show',
    csrfProtection.generateToken,
    server.middleware.https,
    function (req, res, next) {
        let franchiseeForm = server.forms.getForm('becomeFranchisee');

        res.render('franchisee/become', {
            franchiseeForm: franchiseeForm,
            action: Resource.msg('pagename.becomeFranchisee', 'technical', null),
            pageContext: Resource.msg('pagecontext.becomeFranchisee', 'technical', null)
        });

        next();
    }
);

// Mocking this for now because we don't have info whether or not a certain region is elligible to cater franchisees.
// TODO: check how to properly do this.
server.get('CheckAvailability', function (req, res, next) {
    return res.json({
        success: true
    });
});

server.post(
    'SendFranchiseeEmail',
    csrfProtection.validateAjaxRequest,
    function (req, res, next) {
        let franchiseeForm = server.forms.getForm('becomeFranchisee');
        let formErrors = require('*/cartridge/scripts/formErrors');
        let emailHelper = require('*/cartridge/scripts/helpers/emailHelpers.js');
        let institutionalModel = require('*/cartridge/models/institutional/institutional.js');
        var institutionalFormsValidator = require('*/cartridge/scripts/validators/institutionalFormsValidator');

        let Site = require('dw/system/Site');

        institutionalFormsValidator.validateFranchiseeForm(franchiseeForm);

        var viewData = {};
        viewData.franchiseeForm = franchiseeForm;

        res.setViewData(viewData);

        this.on('route:BeforeComplete', function (req, res) {
            var viewData = res.getViewData();

            if (!viewData.franchiseeForm.valid) {
                res.json({
                    success: false,
                    fields: formErrors.getFormErrors(viewData.franchiseeForm),
                    msg: Resource.msg('error.message.general', 'institutional', null)
                });
                return;
            }

            let formData = institutionalModel.parseFranchiseeForm(viewData.franchiseeForm);

            let email = {
                from: viewData.franchiseeForm.email.value,
                to: Site.getCurrent().getCustomPreferenceValue('hav_franchiseeEmail') || '',
                subject: Resource.msg('becomeFranchisee.title','institutional',null)
            };

            emailHelper.send(email, 'email/becomeFranchisee', { fields: formData });

            res.json({
                success: true,
                sucessMessage: Resource.msg('contact.becomedealer.received', 'institutional', null)
            });
        });

        next();
    }
);

module.exports = server.exports();
