'use strict';

var server = require('server');
var Product = module.superModule;
server.extend(Product);

server.get('Unavailable', function (req, res, next) {
    var ProductMgr = require('dw/catalog/ProductMgr');
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');

    var productId = req.querystring.pid
    var apiProduct = ProductMgr.getProduct(productId);
    var userProfile = req.currentCustomer.raw.getProfile();

    if (empty(apiProduct)) {
        res.setStatusCode(404);
        res.json({
            success: false,
            errorMsg: Resource.msg('error.controller.request.attributenotfound', 'technical', null)
        });

        return next();
    }

    var productAvailabilityModel = apiProduct.getAvailabilityModel();

    if (productAvailabilityModel.isInStock()) {
        var URLUtils = require('dw/web/URLUtils');
        res.redirect(URLUtils.url('Product-Show', 'pid', productId));
        return next();
    }

    res.render('product/productUnavailable', {
        productId: apiProduct.getID(),
        productName: apiProduct.getName(),
        userEmail: userProfile ? userProfile.getEmail() : ''
    });
    return next();
});

server.post('Notify', function (req, res, next) {
    var ProductMgr = require('dw/catalog/ProductMgr');
    var Resource = require('dw/web/Resource');
    var emailHelpers = require('*/cartridge/scripts/helpers/emailHelpers')
    var pid = req.querystring.pid;
    var userEmail = req.form.userEmail || req.querystring.userEmail;
    var apiProduct = ProductMgr.getProduct(pid);

    if (!userEmail || !emailHelpers.validateEmail(userEmail)) {
        res.json({
            success: false,
            errorMsg: Resource.msgf('error.product.notify.input.email', 'technical', null, userEmail)
        })
        return next();
    }

    if (!apiProduct) {
        res.json({
            success: false,
            errorMsg: Resource.msgf('error.product.notify.notfound', 'technical', 'null', pid)
        })
        return next();
    }

    var productAvailabilityModel = apiProduct.getAvailabilityModel();
    if (productAvailabilityModel.isInStock()) {
        res.json({
            success: false,
            errorMsg: Resource.msg('error.product.notify.instock', 'technical', null)
        });
        return next();
    }

    var Site = require('dw/system/Site');
    var CustomObjectMgr = require('dw/object/CustomObjectMgr');
    var Transaction = require('dw/system/Transaction');
    var notifyEntry = userEmail + '|' + req.locale.id;
    var notifyConfigurations = {
        customObjectID: Site.current.getCustomPreferenceValue('hav_emailNotificationObjectID') || 'BackInStock',
        errorLogCategory: Site.current.getCustomPreferenceValue('hav_emailNotificationLogCategory')
    };

    var response = {
        success: true,
        errorMsg: ''
    };

    try {
        Transaction.wrap(function() {
            var backInStockObject =
                CustomObjectMgr.getCustomObject(notifyConfigurations.customObjectID, pid) ||
                CustomObjectMgr.createCustomObject(notifyConfigurations.customObjectID, pid) ;

            var backInStockObject = backInStockObject.getCustom();
            var emailList = JSON.parse(backInStockObject.emailList || '[]');
            emailList.push(notifyEntry);
            backInStockObject.emailList = JSON.stringify(emailList);
        });
    } catch (e) {
        var Logger = require('dw/system/Logger');
        var { errorLogCategory } = notifyConfigurations;
        if (!empty(errorLogCategory)) {
            Logger = Logger.getLogger(errorLogCategory);
        }

        var errorMsg = Resource.msgf(
            'error.product.notify.customobject.notfound',
            'technical',
            null,
            notifyConfigurations.customObjectID
        );
        Logger.warn(errorMsg);
        response = {
            success: false,
            errorMsg: errorMsg
        };
    }

    res.json(response);
    return next();
});

server.get('SizeGuide', function (req, res, next) {
    var ProductMgr = require('dw/catalog/ProductMgr');
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');
    var { getSizeGuideContent, getVariantAddToCartUrls } = require('*/cartridge/scripts/helpers/productHelpers');
    var params = req.querystring
    var userProfile = req.currentCustomer.raw.profile;

    var apiProduct = ProductMgr.getProduct(params.pid);
    if (!apiProduct)
        throw new TypeError(Resource.msgf('error.request.parameters.product', 'technical', null, params.pid));

    var sizeGuideContent = getSizeGuideContent(apiProduct);
    var table = JSON.parse(sizeGuideContent.custom.hav_sizeGuide_JSON || '{}');

    if (empty(table)) {
        res.setStatusCode(406)
        res.json({
            success: false,
            errorMsg:  Resource.msg('error.controller.request.entitydoesnotmeetrequirements', 'technical', null)
        });
        return next();
    }

    // optionProperties is a object used to define the add-to-cart button necessary properties.
    var optionProperties = getVariantAddToCartUrls(req.querystring.pid, req.querystring.variables, 'pay');
    var sizesAvailable = optionProperties.map(function(size) {
        return size.displayValue;
    });

    var sizeTable = table.generalTable ? table.generalTable : table;

    var response = {
        action: Resource.msg('pagename.productsizeguide', 'technical', null),
        pageContext: Resource.msg('pagecontext.productsizeguide', 'technical', null),
        brandNames: Object.getOwnPropertyNames(table.brands || {}),
        bottomContent: sizeGuideContent.custom.hav_bottomContentFlipFlopSizeGuide,
        modelHeight: {
            cm: apiProduct.custom.hav_modelHeightCm,
            in: apiProduct.custom.hav_modelHeightIn
        },
        learnMore: sizeGuideContent.custom.hav_learnMoreHTML, // attribute used on learn more link in size guide.
        userPreference: userProfile && userProfile.custom.hav_measurePreference ? userProfile.custom.hav_measurePreference : 'cm',
        productUrl: URLUtils.url('Product-Show', 'pid', params.pid)
    };

    // Here we only display the size rows that have a correspondent size in the product,
    // and in the row, we now utilizes the optionProperties on the button property, which will
    // be used in the isml template.
    response.sizeRows = sizeTable.filter(function(row) {
        var index = sizesAvailable.indexOf(row.size);
        var returnValue = index !== -1

        if (returnValue)
            row.button = optionProperties[index];

        return returnValue;
    });


    if (response.brandNames) {
        response.brandValues = response.brandNames.map(function (brandName) {
             return table.brands[brandName];
        });
    }

    res.render(sizeGuideContent.custom.hav_templatePath, response);

    return next();
});

server.get('SimilarProducts', function (req, res, next) {
    var ProductMgr = require('dw/catalog/ProductMgr');
    var Resource = require('dw/web/Resource');
    var Logger = require('dw/system/Logger');
    var apiProduct;
    var params = req.querystring;

    if (!params.pid) {
        res.render('product/components/productRecommendations.isml', {
            success: false,
            errorMsg: Resource.msg('error.controller.request.insufficientarguments', 'technical', null)
        });
        Logger.warn(Resource.msg('error.controller.request.insufficientarguments', 'technical', null))
        return next();
    } else if( (apiProduct = ProductMgr.getProduct(params.pid)) == null ) {
        res.render('product/components/productRecommendations.isml', {
            success: false,
            errorMsg: Resource.msg('error.controller.request.attributenotfound', 'technical', null)
        });
        Logger.warn(Resource.msg('error.controller.request.attributenotfound', 'technical', null))
        return next();
    }

    var productLinks = apiProduct.getAllProductLinks().toArray();

    var productLinksLength = productLinks.length;
    if (productLinksLength > 6)
        productLinks = productLinks.slice(0, 6);
    else if(productLinksLength < 3) {
        res.render('product/components/productRecommendations.isml', {
            success: false,
            errorMsg: Resource.msg('error.controller.request.entitydoesnotmeetrequirements', 'technical', null)
        });
        Logger.warn(Resource.msg('error.controller.request.entitydoesnotmeetrequirements', 'technical', null))
        return next();
    }

    var productLinkIds = [];
    
    productLinks.forEach(function(productLink) {
        var p = productLink.getTargetProduct();
        if (p.isOnline()) {
            productLinkIds.push(p.getID());
        }
    })

    res.render('product/components/productRecommendations.isml', {
        success: true,
        productLinkIds: productLinkIds
    });

    return next();
});

server.get('Info', function (req, res, next) {
    var ProductFactory = require('*/cartridge/scripts/factories/product');
    var params = req.querystring;
    var product = ProductFactory.get(params);
    res.json({
        product: product
    });
    next();
});

server.append('Show', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');
    var colorMatrixHelper = require('*/cartridge/scripts/helpers/colorMatrixHelper');
    var { getSizeGuideContent } = require('*/cartridge/scripts/helpers/productHelpers');
    var wishlistHelper = require('*/cartridge/scripts/helpers/wishlistHelper');
    var productReviewsModel = require('*/cartridge/models/productReviews');

    var viewData = res.getViewData();

    var pageFactory = require('*/cartridge/scripts/factories/page');
    var pageModel = pageFactory.get();
    viewData.pageModel = pageModel;

    var sizes;
    viewData.rating = productReviewsModel.getHistogram(viewData.product.id);
    viewData.action = Resource.msg('pagename.productshow', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.productshow', 'technical', null);
    viewData.sizes = sizes;
    if (viewData.product.productType === 'standard') {
        viewData.buyButtonUrl = URLUtils.url('Cart-AddProduct');
    }
    else {
        viewData.buyButtonUrl = URLUtils.url('Product-Variants', 'pid', viewData.product.id).toString();
    }
    viewData.isWishlistEnabled = wishlistHelper.isWishlistEnabled();
    viewData.sizeGuideUrl = URLUtils.url('Product-SizeGuide', 'pid', viewData.product.id).toString();
    viewData.colorMatrixUrl = URLUtils.url('Colors-Get', 'pid', viewData.product.id);
    viewData.colorMatrix = colorMatrixHelper.getColorSpecification(
        viewData.product.raw.custom.hav_primaryColor,
        viewData.product.raw.custom.hav_primaryColorTone,
        viewData.product.raw.custom.hav_secondaryColor,
        viewData.product.raw.custom.hav_secondaryColorTone
    );

    if (!viewData.product.available) {
        viewData.buyButtonUrl = URLUtils.url('Product-Unavailable', 'pid', viewData.product.id).toString();;
    }

    try {
        getSizeGuideContent(viewData.product.raw);
        viewData.sizeGuide = true;
    } catch (error) {
        viewData.sizeGuide = false;
    }
    res.setViewData(viewData);
    next();
});

server.append('ShowInCategory', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.productshowincategory', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.productshowincategory', 'technical', null);
    res.setViewData(viewData);
    next();
});

server.append('Variation', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.productvariation', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.productvariation', 'technical', null);
    res.setViewData(viewData);
    next();
});

server.get('FunFact', function (req, res, next) {
    var params = req.querystring;
    var funFactID;

    if (!empty(params.pid)) {
        var ProductMgr = require('dw/catalog/ProductMgr');
        var apiProduct = ProductMgr.getProduct(params.pid);
        funFactID = apiProduct.custom ? apiProduct.custom.hav_funFact : null;
    } else {
        funFactID = params.cid;
    }

    var PageMgr = require('dw/experience/PageMgr');
    var page = PageMgr.getPage(funFactID);

    if (page != null && page.isVisible()) {
        if (!page.hasVisibilityRules()) {
            res.cachePeriod = 168; // eslint-disable-line no-param-reassign
            res.cachePeriodUnit = 'hours'; // eslint-disable-line no-param-reassign
        }

        res.page(page.ID);
    }

    return next();
})

server.get('MatchThis', function (req, res, next) {
    var PageMgr = require('dw/experience/PageMgr');

    if(req.querystring.cid && req.querystring.pid) {
        var page = PageMgr.getPage(req.querystring.cid);

        if (page != null && page.isVisible()) {
            if (!page.hasVisibilityRules()) {
                res.cachePeriod = 168; // eslint-disable-line no-param-reassign
                res.cachePeriodUnit = 'hours'; // eslint-disable-line no-param-reassign
            }

            res.page(page.ID, {pid: req.querystring.pid});
        }
    }

    next();
});

server.get('WishlistButton', function (req, res, next) {
    var viewData = {};

    var ProductFactory = require('*/cartridge/scripts/factories/product');
    var product = ProductFactory.get({pid: req.querystring.productId});

    var isWishlistEnabled = req.querystring.isWishlistEnabled;
    var isWishlistPage = req.querystring.isWishlistPage;

    viewData.isWishlistEnabled = isWishlistEnabled === 'true';
    viewData.isWishlistPage = isWishlistPage === 'true';
    viewData.productWish = {};
    viewData.productWish.id = product.id;
    viewData.productWish.isOnWishlist = product.isOnWishlist;
    viewData.productWish.addMessage = product.addMessage;
    viewData.productWish.removeMessage = product.removeMessage;

    res.render('product/components/productTileWishlistButton', viewData);

    next();
});

server.get('WishlistButtonPDP', function (req, res, next) {
    var Site = require('dw/system/Site');

    var viewData = {};

    var ProductFactory = require('*/cartridge/scripts/factories/product');
    var product = ProductFactory.get({pid: req.querystring.productId});

    viewData.isWishlistEnabled = Site.getCurrent().getCustomPreferenceValue('hav_enableWishlist') || false;
    viewData.productWish = {};
    viewData.productWish.id = product.id;
    viewData.productWish.isOnWishlist = product.isOnWishlist;
    viewData.productWish.addMessage = product.addMessage;
    viewData.productWish.removeMessage = product.removeMessage;

    res.render('product/components/productWishlistButton', viewData);

    next();
});

server.get('Variants', function (req, res, next) {
    var productHelpers = require('*/cartridge/scripts/helpers/productHelpers');

    var variants = productHelpers.getVariantAddToCartUrls(req.querystring.pid, req.querystring.variables, req.querystring.context);

    res.setViewData({sizes : variants});

    res.render('product/components/chooseSize');

    next();
});

server.replace('ShowQuickView', function (req, res, next) {
    var ProductMgr           = require('dw/catalog/ProductMgr');
    var productHelpers       = require('*/cartridge/scripts/helpers/productHelpers');
    var colorMatrixHelper    = require('*/cartridge/scripts/helpers/colorMatrixHelper');
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
    var URLUtils             = require('dw/web/URLUtils');
    var Site                 = require('dw/system/Site');
    var productHelpers = require('*/cartridge/scripts/helpers/productHelpers');

    var apiProduct  = ProductMgr.getProduct(req.querystring.pid);
    var product     = productHelpers.getProductTileModel(apiProduct, req.querystring, 'ShowQuickView');
    var productUrl   = URLUtils.url('Product-Show', 'pid', product.id).relative().toString();
    var quickViewUrl = URLUtils.url('Product-ShowQuickView', 'pid', product.id)
            .relative().toString();

    var context = {
        colorMatrix: colorMatrixHelper.get(
            apiProduct.custom.hav_primaryColor,
            'ultralight',//apiProduct.custom.hav_primaryColorTone,
            apiProduct.custom.hav_secondaryColor,
            'ultralight' //apiProduct.custom.hav_secondaryColorTone
        ).toJSON(),
        urls: {
            product: productUrl,
            quickView: quickViewUrl
        },
        addToCartUrl: URLUtils.url('Cart-AddProduct'),
        product: product,
        isWishlistEnabled: Site.getCurrent().getCustomPreferenceValue('hav_enableWishlist') || false,
        variants: productHelpers.getVariantAddToCartUrls(req.querystring.pid, req.querystring.variables, req.querystring.context ? req.querystring.context : 'pay')
    }

    var renderedTemplate = renderTemplateHelper.getRenderedHtml(context,'product/gridTile.isml');

    res.json({
        productId: product.id,
        renderedTemplate: renderedTemplate,
        urls: {
            product: URLUtils.url('Product-Show', 'pid', product.id).relative().toString(),
            addToCart: URLUtils.url('Cart-AddProduct', 'pid', product.id, 'quantity', 1).relative().toString()
        }
    });

    return next();
});


module.exports = server.exports();
