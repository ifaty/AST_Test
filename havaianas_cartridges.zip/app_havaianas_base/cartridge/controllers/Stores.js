'use strict';

var server = require('server');

server.extend(module.superModule);

server.replace('Find', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var Site = require('dw/system/Site');
    var URLUtils = require('dw/web/URLUtils');
    var { getStoredAddress } = require('*/cartridge/scripts/helpers/locationHelper');
    var storeHelper = require('*/cartridge/scripts/helpers/storeHelper');

    var availableFilters = JSON.parse(
        Site.getCurrent().getCustomPreferenceValue('StoreMerchandizeProperties') || '{}'
    );
        availableFilters = Object.getOwnPropertyNames(availableFilters);

    var template = req.querystring.mobile ?
        'findStore/findStoreMobile' :
        'findStore/findStore';

    var storedAddress = getStoredAddress(session);
    var startPoint;

    if (storedAddress.city && storedAddress.stateCode) {
        if (storedAddress.sublocality) {
            startPoint = {
                url: URLUtils.url('Stores-Get'),
                searchValue: Resource.msgf('text.stores.location.suggestion', 'findstore', null, storedAddress.sublocality, storedAddress.stateCode)
            }
        } else if (storeHelper.hasStoreInAddress(storedAddress)){
            startPoint = {
                url: URLUtils.url('Stores-GetSublocalities', 'location', [storedAddress.city, storedAddress.stateCode].toString()),
                searchValue: Resource.msgf('text.stores.location.suggestion', 'findstore', null, storedAddress.city, storedAddress.stateCode)
            };
        }
    }

    res.render(template, {
        action: Resource.msg('pagename.storesfind', 'technical', null),
        availableFilters: availableFilters,
        startPoint: startPoint,
    });
    return next();
});

server.get('GetSuggestions', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var storeHelper = require('*/cartridge/scripts/helpers/storeHelper');
    var input = req.querystring.q;

    if (!input) {
        res.setStatusCode(400);
        res.json({
            error: true,
            errorMsg: Resource.msg('error.controller.request.insufficientarguments', 'technical', null)
        });
        return next();
    }

    var suggestions = storeHelper.getSuggestions(input);

    res.render('findStore/search/suggestions', {
        action: Resource.msg('pagename.storesuggestions', 'technical', null),
        suggestions: suggestions
    });

    return next();
});

server.get('GetLocalities', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var Resource = require('dw/web/Resource');
    var storeHelper = require('*/cartridge/scripts/helpers/storeHelper');

    var query = req.querystring.q ?
        req.querystring.q :
        null;

    var merchandizeFilter = req.querystring.filter ?
        req.querystring.filter.split(',') :
        null;

    if (merchandizeFilter && !Array.isArray(merchandizeFilter)) {
        res.setStatusCode(400);
        res.json({
            error: true,
            errorMsg: Resource.msg('error.controller.request.entitydoesnotmeetrequirements', 'technical', null)
        });
        return next();
    }

    var localities = storeHelper.searchLocalities(query, merchandizeFilter);

    res.render('findStore/search/localities', {
        action: Resource.msg('pagename.storelocalities', 'technical', null),
        lastCall: URLUtils.url('Stores-GetLocalities', 'query', query),
        currentQuery: req.querystring.q,
        filterQuerystring: merchandizeFilter && merchandizeFilter.length ? req.querystring.filter : false,
        localities: localities
    });

    return next();
});

server.get('GetCities', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var Resource = require('dw/web/Resource');
    var storeHelper = require('*/cartridge/scripts/helpers/storeHelper');

    var location = req.querystring.location ?
        req.querystring.location :
        null;

    var merchandizeFilter = req.querystring.filter ?
        req.querystring.filter.split(',') :
        null;

    if (merchandizeFilter && !Array.isArray(merchandizeFilter)) {
        res.setStatusCode(400);
        res.json({
            error: true,
            errorMsg: Resource.msg('error.controller.request.entitydoesnotmeetrequirements', 'technical', null)
        });
        return next();
    }

    if (!location) {
        res.setStatusCode(400);
        res.json({
            error: true,
            errorMsg: Resource.msg('error.controller.request.insufficientarguments', 'technical', null)
        });
        return next();
    }
    //                                                stateCode
    var cities = storeHelper.searchCitiesFromLocality(location, merchandizeFilter);

    res.render('findStore/search/cities', {
        action: Resource.msg('pagename.storecities', 'technical', null),
        lastCall: URLUtils.url('Stores-GetCities', 'location', location),
        currentLocation: req.querystring.location,
        filterQuerystring: merchandizeFilter && merchandizeFilter.length ? req.querystring.filter : false,
        cities: cities
    });

    return next();
});

server.get('GetSublocalities', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var Resource = require('dw/web/Resource');
    var storeHelper = require('*/cartridge/scripts/helpers/storeHelper');

    var location = req.querystring.location ?
        req.querystring.location.split(',') :
        null;

    var merchandizeFilter = req.querystring.filter ?
        req.querystring.filter.split(',') :
        null;

    if (merchandizeFilter && !Array.isArray(merchandizeFilter)) {
        res.setStatusCode(400);
        res.json({
            error: true,
            errorMsg: Resource.msg('error.controller.request.entitydoesnotmeetrequirements', 'technical', null)
        });
        return next();
    }

    if (!location || location.length < 2) {
        res.setStatusCode(400);
        res.json({
            error: true,
            errorMsg: Resource.msg('error.controller.request.insufficientarguments', 'technical', null)
        });
        return next();
    }
    //                                                          city         stateCode
    var sublocalities = storeHelper.searchSublocalitiesFromCity(location[0], location[1], merchandizeFilter);

    res.render('findStore/search/sublocalities', {
        action: Resource.msg('pagename.storesublocalities', 'technical', null),
        lastCall: URLUtils.url('Stores-GetSublocalities', 'location', location),
        currentLocation: req.querystring.location,
        filterQuerystring: merchandizeFilter && merchandizeFilter.length ? req.querystring.filter : false,
        sublocalities: sublocalities
    });

    return next();
});

server.get('Get', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var Resource = require('dw/web/Resource');
    var storeHelper = require('*/cartridge/scripts/helpers/storeHelper');
    var { getStoredAddress } = require('*/cartridge/scripts/helpers/locationHelper');

    // Parameters
    var location = req.querystring.location ?
        req.querystring.location.split(',') :
        null;

    var page = req.querystring.page || 1;

    var filters = req.querystring.filter ?
        req.querystring.filter.split(',') :
        null;
    //----------

    var result;
    var fallbackLocation = getStoredAddress(session);

    if (!(location && location.length === 3) && fallbackLocation.city) {
        result = storeHelper.getStoresByProximity(
            req.geolocation,
            page,
            filters
        );
    } else {
        var address = {
            sublocality: location[0],
            city: location[1],
            stateCode: location[2]
        }

        result = storeHelper.getStoresByAddress(
            address,
            page,
            filters,
            req.geolocation
        );
    }

    fallbackLocation = [fallbackLocation.city, fallbackLocation.stateCode].toString();

    res.render('findStore/search/stores', {
        action: Resource.msg('pagename.storeget', 'technical', null),
        lastCall: req.querystring.location ?
            URLUtils.url('Stores-Get', 'location', req.querystring.location) :
            URLUtils.url('Stores-Get'),
        result: result,
        hasFilter: !!filters,
        fallbackUrl: URLUtils.url('Stores-GetSublocalities', 'location', fallbackLocation)
    });
    return next();
});

server.get('Details', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var StoreMgr = require('dw/catalog/StoreMgr');
    var StoreDetails = require('*/cartridge/models/StoreDetails');

    var storeId = req.querystring.store;

    if (!storeId) {
        res.setStatusCode(400);
        res.json({
            error: true,
            errorMsg: Resource.msg('error.controller.request.insufficientarguments', 'technical', null)
        });
        return next();
    }

    var store = new StoreDetails(StoreMgr.getStore(storeId), req.geolocation);

    res.render('findStore/storeDetails', {
        action: Resource.msg('pagename.storedetails', 'technical', null),
        pageContext: Resource.msg('pagecontext.storedetails', 'technical', null),
        store: store
    });

    return next()
});

server.get('Store', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var Site = require('dw/system/Site');
    var URLUtils = require('dw/web/URLUtils');

    var availableFilters = JSON.parse(
        Site.getCurrent().getCustomPreferenceValue('StoreMerchandizeProperties') || '{}'
    );
        availableFilters = Object.getOwnPropertyNames(availableFilters);

    var template = req.querystring.mobile ?
        'findStore/findStoreMobile' :
        'findStore/findStore';

    res.render(template, {
        action: Resource.msg('pagename.storesfind', 'technical', null),
        availableFilters: availableFilters,
        startPoint: {
            url: URLUtils.url('Stores-Details', 'store', req.querystring.id).toString(),
            searchValue: ''
        }
    });
    return next();
});

module.exports = server.exports();


