'use strict';

var server = require('server');
var cache = require('*/cartridge/scripts/middleware/cache');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');
var pageMetaData = require('*/cartridge/scripts/middleware/pageMetaData');

server.get('Show', consentTracking.consent, cache.applyDefaultCache, function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var Site = require('dw/system/Site');
    var pageMetaHelper = require('*/cartridge/scripts/helpers/pageMetaHelper');

    if(!empty(req.querystring.story)) {
        res.render('/home/story/story' + req.querystring.story, {
            action: Resource.msg('pagename.story', 'technical', null),
            pageContext: Resource.msg('pagecontext.story', 'technical', null)
        });
    }

    pageMetaHelper.setPageMetaTags(req.pageMetaData, Site.current);
    next();
}, pageMetaData.computedPageMetaData);

module.exports = server.exports();