'use strict';

var server = require('server');
var CheckoutShippingServices = module.superModule;
server.extend(CheckoutShippingServices);

server.append('SubmitShipping', function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var Locale = require('dw/util/Locale');
    var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
    var Resource = require('dw/web/Resource');
    var shippingHelpers = require('*/cartridge/scripts/checkout/shippingHelpers');

    var currentBasket = BasketMgr.getCurrentBasket();
    var form = server.forms.getForm('shipping');
    formInfo = res.getViewData();

    if (formInfo.error) {
        return next();
    }
    
    formInfo.address.countryCode = Locale.getLocale(req.locale.id).getCountry();
    formInfo.address.suite = form.shippingAddress.addressFields.suite.value;
    formInfo.address.postBox = form.shippingAddress.addressFields.postBox.value;

    var shippingModels = shippingHelpers.getShippingModels(currentBasket, null, 'basket', {usingMultiShipping: req.session.privacyCache.get('usingMultiShipping')});
    var selectedShippingMethod = shippingModels[0].selectedShippingMethod;
    formInfo.summaryMessage = shippingHelpers.isPickupTypeShippingMethod(selectedShippingMethod) ?
        Resource.msgf('label.pickup.at', 'checkout', null, selectedShippingMethod.store.name) : 
        Resource.msgf('label.delivery.at.full', 'checkout', null, formInfo.address.address1,  formInfo.address.address2);

    res.setViewData(formInfo);

    for each( e in currentBasket.shipments ) {
        COHelpers.copyShippingAddressToShipment(
            formInfo,
            e
        );
    }
    next();
});

server.replace('ToggleMultiShip', server.middleware.https, function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var AccountModel = require('*/cartridge/models/account');
    var OrderModel = require('*/cartridge/models/order');
    var URLUtils = require('dw/web/URLUtils');
    var Locale = require('dw/util/Locale');
    var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
    var Resource = require('dw/web/Resource');
    var Site = require('dw/system/Site');
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
    var config = require('*/cartridge/config/shipping.json');

    var currentBasket = BasketMgr.getCurrentBasket();
    if (!currentBasket) {
        res.json({
            error: true,
            cartError: true,
            fieldErrors: [],
            serverErrors: [],
            redirectUrl: URLUtils.url('Cart-Show').toString()
        });
        return next();
    }

    if (currentBasket.allProductLineItems.length > config.maxProductLineItems) {
        res.json({
            error: true,
            cartError: false,
            fieldErrors: [],
            serverErrors: [],
            redirectUrl: URLUtils.url('Cart-Show').toString(),
            errorMsg: Resource.msgf('error.splitting.maxitems', 'checkout', null, config.maxProductLineItems)
        });
        return next();
    }

    if (!Site.getCurrent().getPreferences().getCustom()["hav_enableMultishipping"]) {
        res.json({
            error: true,
            cartError: false,
            fieldErrors: [],
            serverErrors: [],
            redirectUrl: URLUtils.url('Cart-Show').toString(),
            errorMsg: Resource.msgf('error.splitting.disabled', 'checkout', null, config.maxProductLineItems)
        });
        return next();
    }

    var shipments = currentBasket.shipments;
    var defaultShipment = currentBasket.defaultShipment;
    var defaultPostalCode = defaultShipment.shippingAddress ? defaultShipment.shippingAddress.postalCode : null;
    var usingMultiShipping = req.form.usingMultiShip === 'true';

    req.session.privacyCache.set('usingMultiShipping', usingMultiShipping);
    var forcedMerge;

    if (usingMultiShipping) {
        COHelpers.splitBasketIntoShipments(req);
        forcedMerge = false;
    } else {
        COHelpers.mergeBasketIntoSingleShipment(req);
        forcedMerge = true;
    }

    req.session.privacyCache.set('forcedMerge', forcedMerge);
    var currentLocale = Locale.getLocale(req.locale.id);

    var basketModel = new OrderModel(
        currentBasket,
        { usingMultiShipping: usingMultiShipping, countryCode: currentLocale.country, containerView: 'basket', invalidate: true, forcedMerge: forcedMerge }
    );

    var context = {
        customer: new AccountModel(req.currentCustomer),
        order: basketModel,
        forms: {
            shippingForm: COHelpers.prepareShippingForm(currentBasket),
        },
        success: true
    };
    var renderedTemplate = renderTemplateHelper.getRenderedHtml(context,'checkout/shipping/components/shippingMethodOverview');
    context.renderedTemplate = renderedTemplate;
    res.json(context);

    next();
});

server.append('UpdateShippingMethodsList', function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var Site = require('dw/system/Site');
    var Transaction = require('dw/system/Transaction');
    var ShippingHelper = require('*/cartridge/scripts/checkout/shippingHelpers');
    var collections = require('*/cartridge/scripts/util/collections');
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');

    var context = res.getViewData();
    var renderedTemplate = renderTemplateHelper.getRenderedHtml(context,'checkout/shipping/components/shippingMethodOverview');
    context.currentStage = 'shipping';
    context.multiShippingEnabled = Site.getCurrent().getPreferences().getCustom()["hav_enableMultishipping"];;
    context.updateCall = true;
    var multishipButtonTemplate = renderTemplateHelper.getRenderedHtml(context,'checkout/shipping/components/multiShipButton');
    context.renderedTemplate = renderedTemplate;
    context.multishipButtonTemplate = multishipButtonTemplate;
    if (req.session.privacyCache.get('usingMultiShipping') && context.multiShippingEnabled) {
        // If multishipping is enabled, we need to update all shipments,
        // at least for now.
        var address = ShippingHelper.getAddressFromRequest(req);
        var currentBasket = BasketMgr.getCurrentBasket();
        Transaction.wrap(function () {
            collections.forEach(currentBasket.shipments, function (shipment) {
                if (shipment.default) {
                    return; // Just a small optimization.
                }
                var shippingAddress = shipment.shippingAddress;
        
                if (!shippingAddress) {
                    shippingAddress = shipment.createShippingAddress();
                }
        
                Object.keys(address).forEach(function (key) {
                    var value = address[key];
                    if (value) {
                        shippingAddress[key] = value;
                    } else {
                        shippingAddress[key] = null;
                    }
                });
            });
        });
    }
    res.json(context);

    return next();
});

server.append('SelectShippingMethod', function (req, res, next) {
    this.on('route:BeforeComplete', function (req, res) {
        var URLUtils = require('dw/web/URLUtils');
        var BasketMgr = require('dw/order/BasketMgr');
        var Resource = require('dw/web/Resource');
        var currentBasket = BasketMgr.getCurrentBasket();
        var TotalsModel = require('*/cartridge/models/totals');
        var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
        var shippingHelpers = require('*/cartridge/scripts/checkout/shippingHelpers');
        var { verifyExternalCouponState } = require('*/cartridge/scripts/helpers/couponHelper');
        
        var viewData = res.getViewData();
        if (viewData.error) {
            return;
        }
        var order = viewData.order;

        var isRefreshNeeded = verifyExternalCouponState();

        var totals = new TotalsModel(currentBasket);
        order.priceTotal = totals.grandTotal;

        res.setViewData({
            order: order
        });

        if (isRefreshNeeded) {
            res.setViewData({
                refreshTilesUrl: URLUtils.url('Cart-CouponTiles').toString()
            })
        }
        var context = res.getViewData();

        var isOnlyPickupShipment = context.order.shipping.length == 1 ? context.order.shipping[0].isPickup : false;
        context.isOnlyPickupShipment = isOnlyPickupShipment;

        context.shippingTitle = isOnlyPickupShipment ? Resource.msgf('label.general.delivery.pickup', 'checkout', null, context.order.shipping[0].estimatedArrivalTime) : Resource.msgf('label.general.delivery.notPickup', 'checkout', null, context.order.shipping.length > 0 ? context.order.shipping[0].estimatedArrivalTime : '-');

        var renderedTemplate = renderTemplateHelper.getRenderedHtml(context,'checkout/shipping/components/shippingMethodOverview');
        context.renderedTemplate = renderedTemplate;
        var array = require('*/cartridge/scripts/util/array');
        var shipment = array.find(order.shipping, function (e) {
            return e.UUID == (req.querystring.shipmentUUID || req.form.shipmentUUID)
        });
        var selectedShippingMethod = shipment.selectedShippingMethod;
        context.editAddressUrl = URLUtils.url('Checkout-Begin','stage','payment').toString();
        context.summaryMessage = shippingHelpers.isPickupTypeShippingMethod(selectedShippingMethod) ?
            Resource.msgf('label.pickup.at', 'checkout', null, selectedShippingMethod.store.name) :
            Resource.msgf('label.delivery.at', 'checkout', null, shipment.shippingAddress.postalCode);
        res.setViewData(context);
    });

    return next();
});

module.exports = server.exports();