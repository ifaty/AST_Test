'use strict';
var server = require('server');

var Order = module.superModule;
server.extend(Order);

var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

server.replace(
    'Track',
    consentTracking.consent,
    server.middleware.https,
    function (req, res, next) {
        var OrderMgr = require('dw/order/OrderMgr');
        var OrderHelpers = require('*/cartridge/scripts/order/orderHelpers');
        var OrderModel = require('*/cartridge/models/order');
        var Locale = require('dw/util/Locale');
        var Resource = require('dw/web/Resource');
        var URLUtils = require('dw/web/URLUtils');
        var order;
        var validForm = true;
        var target = req.querystring.rurl || 1;
        var actionUrl = URLUtils.url('Account-Login', 'rurl', target);
        var profileForm = server.forms.getForm('profile');
        profileForm.clear();

        if (req.querystring.trackOrderNumber) {
            order = OrderHelpers.getOrderSafelyByID(req.querystring.trackOrderNumber, req.querystring);
        } else {
            validForm = false;
        }

        if (!order) {
            res.json({
                success: false,
                errorMsg: Resource.msg('order.tracking.incorrectInfo', 'orderTracking', null)
            });
            next();
        } else {
            var redirectUrl = OrderHelpers.getOrderTrackingResultUrl(req);

            if (validForm) {
                var exitLinkText;
                var exitLinkUrl;

                exitLinkText = !req.currentCustomer.profile
                    ? Resource.msg('link.continue.shop', 'order', null)
                    : Resource.msg('link.orderdetails.myaccount', 'account', null);

                exitLinkUrl = !req.currentCustomer.profile
                    ? URLUtils.url('Home-Show')
                    : URLUtils.https('Account-Show');

                res.json({
                    success: true,
                    redirectUrl: redirectUrl,
                    exitLinkText: exitLinkText,
                    exitLinkUrl: exitLinkUrl
                });
            } else {
                res.json({
                    success: false,
                    profileForm: profileForm,
                    orderTrackFormError: !validForm,
                    userName: '',
                    actionUrl: actionUrl
                });
            }

            next();
        }
    }
);

server.replace(
    'Details',
    consentTracking.consent,
    server.middleware.https,
    function (req, res, next) {
        var OrderHelpers = require('*/cartridge/scripts/order/orderHelpers');
        var OrderMgr = require('dw/order/OrderMgr');
        var OrderModel = require('*/cartridge/models/order');
        var Locale = require('dw/util/Locale');
        var Resource = require('dw/web/Resource');

        var order;
        if (!empty(req.querystring.orderUUID)) {
            order = OrderHelpers.getOrderByUUID(req.querystring.orderUUID);
        }
        else {
            order = OrderMgr.getOrder(req.querystring.orderID);
            if (!OrderHelpers.checkIfOrderIsVisible(req, order)) {
                res.redirect('Home-Show');
                return next();
            }
        }

        if (order) {
            var config = {
                numberOfLineItems: '*'
            };

            var currentLocale = Locale.getLocale(req.locale.id);

            var orderModel = new OrderModel(
                order,
                { config: config, countryCode: currentLocale.country, containerView: 'order' }
            );
            res.render('account/orderDetails', {
                order: orderModel,
                overviewUrl: OrderHelpers.getOrderOverviewUrl(req, order),
                action: Resource.msg('pagename.orderdetails', 'technical', null),
                pageContext: Resource.msg('pagecontext.orderdetails', 'technical', null)
            });
        } else {
            res.redirect(URLUtils.url('Account-Show'));
        }
        next();
    }
);

server.get('TrackForm', function (req,res,next) {
    res.render('account/components/trackOrderForm', {
        mobile: req.querystring.mobile
    });
    next();
});

server.get('Cancel', server.middleware.https, function (req, res, next) {
    var OrderMgr = require('dw/order/OrderMgr');
    var OrderModel = require('*/cartridge/models/order');
    var Locale = require('dw/util/Locale');
    var Resource = require('dw/web/Resource');

    var order;
    if (!empty(req.querystring.orderUUID)) {
        order = OrderHelpers.getOrderByUUID(req.querystring.orderUUID);
    }
    else {
        order = OrderMgr.getOrder(req.querystring.orderID);
        if (!OrderHelpers.checkIfOrderIsVisible(req, order)) {
            res.redirect('Home-Show');
            return next();
        }
    }
    var orderCustomerNo = req.currentCustomer.profile.customerNo;
    var currentCustomerNo = order.customer.profile.customerNo;

    if (order && orderCustomerNo === currentCustomerNo) {
        var config = {
            numberOfLineItems: '*'
        };

        var currentLocale = Locale.getLocale(req.locale.id);

        var orderModel = new OrderModel(
            order,
            { config: config, countryCode: currentLocale.country, containerView: 'order' }
        );
        res.render('account/orderCancel', {
            order: orderModel,
            action: Resource.msg('pagename.ordercancel', 'technical', null),
            pageContext: Resource.msg('pagecontext.ordercancel', 'technical', null)
        });
    } else {
        res.redirect(URLUtils.url('Account-Show'));
    }
    next();
});

server.post('CancelConfirm', server.middleware.https, function (req, res, next) {
    var OrderMgr = require('dw/order/OrderMgr');
    var Transaction = require('dw/system/Transaction');
    var URLUtils = require('dw/web/URLUtils');

    var order = OrderMgr.getOrder(req.querystring.orderID);
    var orderCustomerNo = req.currentCustomer.profile.customerNo;
    var currentCustomerNo = order.customer.profile.customerNo;

    if (order && orderCustomerNo === currentCustomerNo) {
        // TODO: extend this route in BR cartridge to use OMS
        this.on('route:BeforeComplete', function (req, res) { 
            var result;
            Transaction.wrap(function () {
                result = OrderMgr.cancelOrder(order);
            });
            if (result && result.getStatus() == result.OK) {
                res.json({
                    success: true,
                    redirectUrl: URLUtils.url('Order-Details', 'orderID', order.UUID)
                });
            }
            else {
                res.json({
                    success: false,
                    errorMessage: result.getMessage()
                })
            }
        });
    } else {
        res.json({
            success: false,
            redirectUrl: URLUtils.url('Home-Show').toString()
        });
    }
    next();
});

server.get('Overview', function (req, res, next) {
    var Locale     = require('dw/util/Locale');
    var OrderMgr = require('dw/order/OrderMgr');
    var OrderModel = require('*/cartridge/models/order');
    var OrderHelpers = require('*/cartridge/scripts/order/orderHelpers');
    var Resource   = require('dw/web/Resource');

    var nameHelper = require('*/cartridge/scripts/helpers/nameHelper');
    var orderStatusConfig = require('*/cartridge/config/orderStatusConfig');

    var currentLocale = Locale.getLocale(req.locale.id);
    var orderNo       = req.querystring.orderNo;

    var order;
    if (!empty(req.querystring.orderUUID)) {
        order = OrderHelpers.getOrderByUUID(req.querystring.orderUUID);
    }
    else {
        order = OrderMgr.getOrder(orderNo);
        if (!OrderHelpers.checkIfOrderIsVisible(req, order)) {
            res.redirect('Home-Show');
            return next();
        }
    }
    if (!order) {
        res.setStatusCode(404);
        res.json({
            success: false,
            errorMsg: Resource.msg('error.controller.request.attributenotfound', 'technical', null)
        });
    }

    var paymentInstrument = order.paymentInstrument;
    var paymentStatus = order.paymentStatus;

    var config = {
        numberOfLineItems: '*'
    };

    var orderModel = new OrderModel(
        order,
        { config: config, countryCode: currentLocale.country, containerView: 'order' }
    );

    var name;
    if (req.currentCustomer.raw.authenticated) {
        name = nameHelper.splitNames(req.currentCustomer.profile.lastName);
    }
    else {
        name = nameHelper.splitNames(order.getCustomerName());
    }

    res.render('account/order/orderOverview', {
        action: Resource.msg('pagename.orderOverview', 'technical', null),
        pageContext: Resource.msg('pagecontext.orderOverview', 'technical', null),
        order: orderModel,
        paymentInstrument: paymentInstrument,
        paymentStatus: paymentStatus,
        name: name,
        hasPickup: orderModel.hasPickup,
        statusOrdering: orderModel.hasPickup ? orderStatusConfig.orderingPickup : orderStatusConfig.orderingShipping,
        isInclude: req.includeRequest,
        orderDetailsUrl: OrderHelpers.getOrderDetailsUrl(req)
    });
    return next();
});

server.replace(
    'History',
    consentTracking.consent,
    server.middleware.https,
    userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        var Resource = require('dw/web/Resource');
        var OrderHelpers = require('*/cartridge/scripts/order/orderHelpers');
        var nameHelper = require('*/cartridge/scripts/helpers/nameHelper');

        // Getting trackable and untrackable orders
        var trackableOrdersResult = OrderHelpers.getFilteredOrders(
            req.currentCustomer,
            req.querystring,
            req.locale.id,
            'trackable'
        );
        var untrackableOrdersResult = OrderHelpers.getFilteredOrders(
            req.currentCustomer,
            req.querystring,
            req.locale.id,
            'untrackable'
        );

        var trackableOrders = trackableOrdersResult.orders;
        var untrackableOrders = untrackableOrdersResult.orders;

        res.render('account/order/history', {
            trackableOrders: trackableOrders || [],
            untrackableOrders: untrackableOrders || [],
            name: nameHelper.splitNames(req.currentCustomer.profile.lastName),
            accountlanding: false,
            orderHistory: true,
            action: Resource.msg('pagename.orderhistory', 'technical', null),
            pageContext: Resource.msg('pagecontext.orderhistory', 'technical', null)
        });
        next();
    }
);

module.exports = server.exports();