'use strict';

var server = require('server');
var PaymentInstruments = module.superModule;
var csrfProtection = require('*/cartridge/scripts/middleware/csrf');

server.extend(PaymentInstruments);

/**
 * Creates a list of expiration years from the current year
 * @returns {List} a plain list of expiration years from current year
 */
function getExpirationYears() {
    var currentYear = new Date().getFullYear();
    var creditCardExpirationYears = [];

    for (var i = 0; i < 10; i++) {
        creditCardExpirationYears.push((currentYear + i).toString());
    }

    return creditCardExpirationYears;
}

server.append('List', csrfProtection.generateToken, function (req, res, next) {
    var Resource = require('dw/web/Resource');
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.paymentinstruments', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.paymentinstruments', 'technical', null);

    var creditCardExpirationYears = getExpirationYears();
    var paymentForm = server.forms.getForm('creditCard');
    paymentForm.clear();
    var months = paymentForm.expirationMonth.options;
    for (var j = 0, k = months.length; j < k; j++) {
        months[j].selected = false;
    }

    viewData.paymentForm= paymentForm;
    viewData.expirationYears=creditCardExpirationYears;

    viewData.pageContextLabel = Resource.msg('label.personalinfo.button.back.default', 'forms', null);

    res.setViewData(viewData);
    next();
});

server.append('DeletePayment', csrfProtection.generateToken, function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var Resource = require('dw/web/Resource');
    
    viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.paymentinstruments', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.paymentinstruments', 'technical', null);

    viewData.redirectUrl = URLUtils.url('PaymentInstruments-List').toString();

    res.setViewData(viewData);
    next();
});

server.append('SavePayment', csrfProtection.generateToken, function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var Resource = require('dw/web/Resource');
    
    this.on('route:BeforeComplete', function (req, res) {
        viewData = res.getViewData();

        var hasError = !viewData.success;

        if (hasError) {
            res.json({
                success: false,
                error: {message: Resource.msg('error.card.information.error', 'creditCard', null)}
            });
        }
        else {
             var CustomerMgr = require('dw/customer/CustomerMgr');
             var accountHelpers = require('*/cartridge/scripts/helpers/accountHelpers');
             var customer = CustomerMgr.getCustomerByCustomerNumber(
                req.currentCustomer.profile.customerNo
            );
            accountHelpers.sendAccountEditedEmail(customer.profile);
        }
    });
    next();
});

module.exports = server.exports();