"use strict";

var server = require("server");

server.get("Get", function (req, res, next) {
    var colorMatrixHelper = require("*/cartridge/scripts/helpers/colorMatrixHelper");
    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');
    var customProperties;
    var productColors, searchColors;
    var storySettings = storyHelper.getStorySettings();

    var modal = req.querystring.modal == 'true' || false;
    var tile = req.querystring.tile == 'true' || false;

    if (req.querystring.cid) {
        customProperties = {
            primaryColor: req.querystring.cid
        }
        searchColors = true;
    } else if (req.querystring.sid) {
        var storyId = req.querystring.sid;
        customProperties = storySettings.stories[storyId];
        if (req.querystring.store === true) {
            req.session.raw.custom.hav_pastColors = JSON.stringify(
                customProperties
            );
        }
    } else if (req.querystring.pid) {
        var ProductMgr = require("dw/catalog/ProductMgr");
        var product = ProductMgr.getProduct(req.querystring.pid);

        customProperties = {
            primaryColor: product.custom.hav_primaryColor,
            primaryColorTone: product.custom.hav_primaryColorTone,
            secondaryColor: product.custom.hav_secondaryColor,
            secondaryColorTone: product.custom.hav_secondaryColorTone
        };
        if (tile) {
            customProperties.primaryColorTone = 'ultralight';
            customProperties.secondaryColorTone = 'ultralight';
        }
        else {
            productColors = true;
        }
    } else if (req.querystring.orderNumber) {
        var OrderMgr = require("dw/order/OrderMgr");
        var order = OrderMgr.getOrder(req.querystring.orderNumber);

        if (!empty(order)) {
            customProperties = colorMatrixHelper.getProductColorByPriority(
                order
            );
        }
    } else if (req.currentCustomer.raw.authenticated) {
        var OrderMgr = require("dw/order/OrderMgr");
        var Order = require("dw/order/Order");
        var lastOrder = OrderMgr.searchOrders(
            "customerNo={0} AND status!={1}",
            "creationDate desc",
            req.currentCustomer.profile.customerNo,
            Order.ORDER_STATUS_REPLACED
        );

        if (!empty(lastOrder)) {
            lastOrder = lastOrder.first();
            customProperties = colorMatrixHelper.getProductColorByPriority(
                lastOrder
            );
        }
    }

    if (empty(customProperties)) {
        var pastColors = JSON.parse(
            req.session.raw.custom.hav_pastColors || "[]"
        );
        if (empty(pastColors)) {
            var customProperties =
                storySettings.stories[storyHelper.getFirstStoryId()]; // color settings are contained in the story object.
        } else {
            customProperties = pastColors;
        }
    }

    var colorQuery;
    try {
        colorQuery = colorMatrixHelper.get(
            customProperties.primaryColor,
            customProperties.primaryColorTone,
            customProperties.secondaryColor,
            customProperties.secondaryColorTone,
            {
                secondRainbowColor: customProperties.secondRainbowColor,
                thirdRainbowColor: customProperties.thirdRainbowColor
            },
            {
                productColors: productColors,
                modal: modal,
                searchColors: searchColors
            }
        );
    } catch (err) {
        res.setStatusCode(404);
        res.json({
            success: false,
            errorMsg: err.message
        });
        return next();
    }

    res.setStatusCode(200);
    res.render("components/color/colorMatrix", colorQuery.toJSON());

    return next();
});

module.exports = server.exports();
