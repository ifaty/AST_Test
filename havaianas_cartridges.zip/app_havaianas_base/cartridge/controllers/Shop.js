'use strict';

var server = require('server');

var cache = require('*/cartridge/scripts/middleware/cache');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');
var pageMetaData = require('*/cartridge/scripts/middleware/pageMetaData');

server.get('Show', consentTracking.consent, cache.applyShortPromotionSensitiveCache, function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');

    res.redirect(URLUtils.url('Page-Show', 'cid', storyHelper.getFirstShopmodeId()));
    return next();
}, pageMetaData.computedPageMetaData);

server.get('Page', consentTracking.consent, cache.applyShortPromotionSensitiveCache, function (req, res, next) {
    var Resource    = require('dw/web/Resource');
    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');
    var storySettings     = storyHelper.getStorySettings();
    var offset      = parseInt(req.querystring.offset, 10) || 0;
    var pagesize    = parseInt(req.querystring.pagesize, 10) || 6;
    var activeId = storyHelper.updateRequestActiveId(req, request);

    if (empty(storySettings)) {
        throw new Error(Resource.msg('error.controller.request.entitydoesnotmeetrequirements', 'technical', null));
    }

    var storyId = activeId ? storyHelper.getStoryInfoFromShopmode(activeId).id : activeId;
    var orderingInfo = storyHelper.getStoryOrderingInfo(storySettings, {
        offset: offset,
        pagesize: pagesize,
        activeId: activeId
    });

    res.render('shop/components/shopModeSections', {
        action: Resource.msg('pagename.shop', 'technical', null),
        pageContext: Resource.msg('pagecontext.shop', 'technical', null),
        offset: offset + pagesize,
        pages: orderingInfo.shopModePages,
        viewMore: orderingInfo.viewMore
    });
    return next();
}, pageMetaData.computedPageMetaData);

server.get('Story', consentTracking.consent, cache.applyShortPromotionSensitiveCache, function (req, res, next) {
    var params = req.querystring;
    var storyID = params.cid;

    var PageMgr = require('dw/experience/PageMgr');
    var page = PageMgr.getPage(storyID);

    if (page != null && page.isVisible()) {
        if (!page.hasVisibilityRules()) {
            res.cachePeriod = 168; // eslint-disable-line no-param-reassign
            res.cachePeriodUnit = 'hours'; // eslint-disable-line no-param-reassign
        }

        res.page(page.ID, {
            paginated: params.paginated == 'true' || false,
            shopMode: true
        });
    }

    return next();
}, pageMetaData.computedPageMetaData);

module.exports = server.exports();
