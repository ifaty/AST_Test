'use strict';

const server = require('server');

server.get('Show', function (req, res, next) {
    var Resource = require('dw/web/Resource');

    if (!req.querystring.cid) {
        return next();
    }

    let PageMgr = require('dw/experience/PageMgr');
    let page = PageMgr.getPage(req.querystring.cid);

    if (page != null && page.isVisible()) {
        if (!page.hasVisibilityRules()) {
            res.cachePeriod = 168; // eslint-disable-line no-param-reassign
            res.cachePeriodUnit = 'hours'; // eslint-disable-line no-param-reassign
        }

        if (req.querystring.selectedModal) {
            res.page(page.ID, {
                cid: req.querystring.cid,
                selectedModal: req.querystring.selectedModal,
                pageName: Resource.msg('pagename.institutional', 'technical', null),
                pageContext: Resource.msg('pagecontext.institutional', 'technical', null)
            });
            return next();
        }

        res.page(page.ID, {
            cid: req.querystring.cid,
            pageName: Resource.msg('pagename.institutional', 'technical', null),
            pageContext: Resource.msg('pagecontext.institutional', 'technical', null)
        });
    }

    next();
});

module.exports = server.exports();
