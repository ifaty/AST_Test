'use strict';

var server = require('server');
var cache = require('*/cartridge/scripts/middleware/cache');

server.extend(module.superModule);

server.replace('GetSuggestions', cache.applyDefaultCache, function (req, res, next) {
    var ShopSuggestions  = require('*/cartridge/models/search/suggestions/shop');
    var ContentSuggestions   = require('*/cartridge/models/search/suggestions/content');
    var HelpSuggestions   = require('*/cartridge/models/search/suggestions/help');
    var DiscoverySuggestions = require('*/cartridge/models/search/suggestions/discovery');
    var Resource             = require('dw/web/Resource');
    var SuggestModel         = require('dw/suggest/SuggestModel');
    var Site                 = require('dw/system/Site');
    var URLUtils             = require('dw/web/URLUtils');
    var Havaianas            = Site.getCurrent();
    var searchQuery          = req.querystring.q;
    var minChar              = Havaianas.getCustomPreferenceValue('hav_searchSuggestionsMinChar') || 1;

    if (!searchQuery || searchQuery.length < minChar) {
        res.json({});
        return next();
    }
        
    var response = {
        action: Resource.msg('pagename.getsuggestions', 'technical', null),
        pageContext: Resource.msg('pagecontext.getsuggestions', 'technical', null),
        results: false,
        searchRedirectURL: URLUtils.url('Search-Show', 'q', searchQuery)
    };
    var maxSuggestions = Havaianas.getCustomPreferenceValue('hav_searchMaxSuggestions') || 3;

    var suggestions = new SuggestModel();
    suggestions.setSearchPhrase(searchQuery);
    // This is defined to not include Page Designer Pages in suggestions,
    // it may change in the future and require changes.
    suggestions.setFilteredByFolder(false); 
    suggestions.setMaxSuggestions(maxSuggestions);
    var shopSuggestions  = new ShopSuggestions(suggestions, maxSuggestions, searchQuery);
    var discoverySuggestions = new DiscoverySuggestions(searchQuery, maxSuggestions);
    var contentSuggestions   = new ContentSuggestions(suggestions, maxSuggestions);
    var helpSuggestions = new HelpSuggestions(suggestions, maxSuggestions);

    if (shopSuggestions.available || helpSuggestions.available || discoverySuggestions.available) {
        response.results = true;
        response.suggestions = {
            shopSection: shopSuggestions,
            discoverySection: discoverySuggestions,
            helpSection: helpSuggestions
        };
    }

    res.render('search/suggestions', response);
    return next();
});

module.exports = server.exports();
