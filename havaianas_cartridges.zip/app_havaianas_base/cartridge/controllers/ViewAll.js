'use strict';

var server = require('server');
var cache = require('*/cartridge/scripts/middleware/cache');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');
var pageMetaData = require('*/cartridge/scripts/middleware/pageMetaData');

server.get('Show', consentTracking.consent, cache.applyDefaultCache, function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var Site = require('dw/system/Site');
    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');

    var pageMetaHelper = require('*/cartridge/scripts/helpers/pageMetaHelper');

    var pageFactory = require('*/cartridge/scripts/factories/page');
    var pageModel = pageFactory.get();

    pageMetaHelper.setPageMetaTags(req.pageMetaData, Site.current);
    res.render('home/viewAll', {
        action: Resource.msg('pagename.discovery.viewall', 'technical', null),
        pageContext: Resource.msg('pagecontext.discovery.viewall', 'technical', null),
        pageModel: pageModel
    });
    return next();
}, pageMetaData.computedPageMetaData);

server.get('Get', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var Resource = require('dw/web/Resource');
    var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');
    var storySettings = storyHelper.getStorySettings();
    var pagesize = parseInt(req.querystring.pagesize, 10) || 6;
    var offset = parseInt(req.querystring.offset, 10) || 0;

    if (empty(storySettings))
        throw new Error(Resource.msg('error.discovery.error.storysettings', 'technical', null));

    var orderingInfo = storyHelper.getStoryOrderingInfo(storySettings, {
        offset: offset,
        pagesize: pagesize
    });
    var sizes50 = new Array(orderingInfo.shapes.length);
    for (var i = 0, len = orderingInfo.shapes.length; i < len; i = i + 2) {
        if (orderingInfo.shapes[i] && orderingInfo.shapes[i+1] &&
            orderingInfo.shapes[i] != 'editorial-shape' && orderingInfo.shapes[i+1] != 'editorial-shape') {
            sizes50[i] = 1;
            sizes50[i+1] = 1;
        }
    }
    var renderColorMatrix = offset == 0;
    var offset = offset + pagesize;
    res.render('components/viewAll/storyGroup', {
        offset: offset,
        renderColorMatrix: renderColorMatrix,
        stories: orderingInfo.ordering,
        viewMore: orderingInfo.viewMore,
        viewMoreUrl: URLUtils.url('ViewAll-Get', 'paginated', 'true', 'offset', offset, 'pagesize', pagesize),
        shapes: orderingInfo.shapes,
        sizes50: sizes50
    });

    return next();
});

module.exports = server.exports();