'use strict';

var server = require('server');
var Search = module.superModule;
server.extend(Search);

var cache = require('*/cartridge/scripts/middleware/cache');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');
var pageMetaData = require('*/cartridge/scripts/middleware/pageMetaData');

function applyNonCollapsedFilters (refinements) {
    var { find } = require('*/cartridge/scripts/util/array');

    return refinements.map(function (refinement) {
        refinement.hasSelectedValue =
            !!find(refinement.values, function (value) {
                return value.selected;
            });

        return refinement;
    })
}

server.append('Show', function (req, res, next) {
    var searchHelper = require('*/cartridge/scripts/helpers/searchHelpers');
    var PageMgr = require('dw/experience/PageMgr');
    var ProductSearchHit = require('dw/catalog/ProductSearchHit');
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');

    var viewData = res.getViewData();
    viewData.action = Resource.msg('pagename.search', 'technical', null);
    viewData.pageContext = Resource.msg('pagecontext.search', 'technical', null);

    var apiProductSearch = viewData.apiProductSearch;
    apiProductSearch.excludeHitType(ProductSearchHit.HIT_TYPE_PRODUCT_MASTER, ProductSearchHit.HIT_TYPE_SIMPLE)
    if (req.querystring.pmin || req.querystring.pmax)
        apiProductSearch.setOrderableProductsOnly(true);

    var pageFactory = require('*/cartridge/scripts/factories/page');
    var pageModel = pageFactory.get();
    viewData.pageModel = pageModel;

    //When Search-Show is called without cgid the search return no results.
    //To avoid this, here is set 'root' as 'default' category.
    //There is no problem to do this, because after the category is changed according filters used
    viewData.apiProductSearch.setCategoryID('root');

    if (req.querystring.pageId) {
        viewData.apiProductSearch = searchHelper.setupStorySearch(viewData.apiProductSearch, req.querystring.pageId);
        viewData.fromShopMode = true;
        var page = PageMgr.getPage(req.querystring.pageId);
        viewData.story = {
            title: page.pageTitle,
            description: page.pageDescription
        }
    }

    viewData.apiProductSearch = searchHelper.setupOnSaleSearch(apiProductSearch, req.querystring);
    res.setViewData(viewData);

    this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line no-shadow
        var ProductSearchModel = require('dw/catalog/ProductSearchModel');

        var viewData = res.getViewData();
        viewData.showResults = viewData.productSearch.productIds.length > 0;
        viewData.resultsLength = viewData.productSearch.productIds.length;
        viewData.refineurl = searchHelper.getRefineUrl(req.querystring);
        //viewData.clearUrls = searchHelper.generateClearUrls(viewData.refineurl, req, viewData.productSearch);
        if (viewData.productSearch.isCategorySearch) {
            if (viewData.productSearch.productSearch.categoryID == 'root') {
                viewData.rootSearch = true;
            }
            else {
                viewData.clearCategoryUrl = searchHelper.getClearCategoryUrl(viewData, req.querystring.pageId);
            }
        }
        viewData.customPriceRefinement = searchHelper.getCustomPriceRefinementObject(req.querystring);
        viewData.onSaleRefinement = searchHelper.getOnSaleRefinementObject(req.querystring);
        viewData.clearAllUrl = searchHelper.getClearAllUrl();
        var clearAllColorsObj = searchHelper.getClearAllColorsObj(req.querystring);
        viewData.clearAllColorsUrl = clearAllColorsObj.url;
        viewData.localizedSelectedColors = JSON.stringify(searchHelper.getLocalizedSelectedColors(req.querystring));
        viewData.prefNumber = clearAllColorsObj.prefNumber;

        var productSearchModel = new ProductSearchModel();
        if (req.querystring.pmin || req.querystring.pmax)
            productSearchModel.setOrderableProductsOnly(true);

        productSearchModel = searchHelper.setupOnSaleSearch(productSearchModel, req.querystring);

        viewData.apiProductSearch = productSearchModel;
        viewData.apiProductSearch.excludeHitType(ProductSearchHit.HIT_TYPE_PRODUCT_MASTER, ProductSearchHit.HIT_TYPE_SIMPLE)

        if (req.querystring.pageId && empty(viewData.productSearch.showMoreUrl)) {
            viewData.otherProductsSearch = searchHelper.searchOtherProducts(req, res, viewData.resultsLength);
        }
        viewData.colorMatrix = searchHelper.getFirstProductColors(viewData);
        viewData.refineBarUrl = URLUtils.url('Search-Refinebar') + '?' + req.querystring.toString();
        viewData.productSearch.refinements = applyNonCollapsedFilters(viewData.productSearch.refinements);
        if (req.querystring.preferences && req.querystring.preferences['hav_colorset']) {
            var selectedColors = req.querystring.preferences['hav_colorset'].split('|');
            viewData.selectedColor = selectedColors[selectedColors.length - 1];
        }
        if (viewData.productSearch.count > 0) {
            viewData.productID = viewData.productSearch.productIds[0].productID;
        }

        res.setViewData(viewData);
    });

    next();
});

server.append('UpdateGrid', function (req, res, next) {
    var ProductSearchHit = require('dw/catalog/ProductSearchHit');
    var searchHelper = require('*/cartridge/scripts/helpers/searchHelpers');
    var viewData = res.getViewData();

    var apiProductSearch = viewData.apiProductSearch;
    if (req.querystring.pmin || req.querystring.pmax)
        apiProductSearch.setOrderableProductsOnly(true);

    apiProductSearch.excludeHitType(ProductSearchHit.HIT_TYPE_PRODUCT_MASTER, ProductSearchHit.HIT_TYPE_SIMPLE)

    if (req.querystring.pageId) {
        viewData.apiProductSearch = searchHelper.setupStorySearch(viewData.apiProductSearch, req.querystring.pageId);
    }

    this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line no-shadow

        var viewData = res.getViewData();
        viewData.showResults = viewData.productSearch.productIds.length > 0;
        viewData.resultsLength = viewData.productSearch.productIds.length;
        viewData.paginated = viewData.productSearch.pageNumber > 0;
        if (req.querystring.pageId && empty(viewData.productSearch.showMoreUrl)) {
            viewData.otherProductsSearch = searchHelper.searchOtherProducts(req, res, viewData.resultsLength);
        }
        res.render('search/components/productTiles', viewData);
    });
    return next();
});

server.replace('Refinebar', cache.applyDefaultCache, function (req, res, next) {
    var CatalogMgr = require('dw/catalog/CatalogMgr');
    var ProductSearchModel = require('dw/catalog/ProductSearchModel');
    var URLUtils = require('dw/web/URLUtils');
    var ProductSearch = require('*/cartridge/models/search/productSearch');
    var searchHelper = require('*/cartridge/scripts/helpers/searchHelpers');

    var apiProductSearch = new ProductSearchModel();
    apiProductSearch = searchHelper.setupSearch(apiProductSearch, req.querystring);
    if (req.querystring.pageId) {
        apiProductSearch = searchHelper.setupStorySearch(apiProductSearch, req.querystring.pageId);
    }
    apiProductSearch.search();
    var productSearch = new ProductSearch(
        apiProductSearch,
        req.querystring,
        req.querystring.srule,
        CatalogMgr.getSortingOptions(),
        CatalogMgr.getSiteCatalog().getRoot()
    );
    var viewData = res.getViewData();
    viewData.productSearch = productSearch;
    viewData.querystring = req.querystring;
    viewData.clearAllUrl = searchHelper.getClearAllUrl();
    viewData.refineurl = URLUtils.url('Search-Show') + '?' + req.querystring.toString();
    viewData.clearCategoryUrl = searchHelper.getClearCategoryUrl(viewData, req.querystring.pageId);
    res.setViewData(viewData);
    res.render('/search/searchRefineBar');

    next();
}, pageMetaData.computedPageMetaData);

server.get(
    'FilterCategories',
    cache.applyDefaultCache,
    function (req, res, next) {
        var catalogMgr = require('dw/catalog/CatalogMgr');
        var Categories = require('*/cartridge/models/categories');
        var siteRootCategory = catalogMgr.getSiteCatalog().getRoot();

        var topLevelCategories = siteRootCategory.hasOnlineSubCategories() ?
            siteRootCategory.getOnlineSubCategories() : null;

        var categoryInfo = req.querystring.categoryId ? {
                id: req.querystring.categoryId,
                url: req.querystring.clearCategoryUrl
            } :
            null;
        var viewData = res.getViewData();
        viewData = new Categories(topLevelCategories, req.querystring.data, categoryInfo);
        viewData.categoryInfo = categoryInfo;
        res.setViewData(viewData);
        res.render('/search/refinements/categories');
        next();
    }
);

module.exports = server.exports();
