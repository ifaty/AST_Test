'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    var imageAlignmentClassMap = {
        "Focus on top left corner": "mobile_top_left",
        "Focus on top right corner": "mobile_top_right",
        "Focus slight left": "mobile_slight_left",
        "Focus slight right": "mobile_slight_right",
        "Focus on center left corner": "mobile_center_left",
        "Focus on center right corner": "mobile_center_right",
        "Focus on center": "mobile_center_crop",
        "Focus on center top": "mobile_center_top",
        "Focus on center bottom": "mobile_center_bottom",
        "Focus on bottom left corner": "mobile_bottom_left",
        "Focus on bottom right corner": "mobile_bottom_right"
    };

    model.has_margin = content.has_margin === 'Yes' ? true : false;
    model.alt = content.alt ? content.alt : '';
    model.link = content.link ? content.link : '';
    model.desktopImage = ImageTransformation.getScaledImage(content.image, 'discoveryImage');
    model.scaleMode = ImageTransformation.getScaleMode(content.scale_mode);
    model.mobileImage = ImageTransformation.getScaledImage(content.image_mobile, 'discoveryImage');
    model.scaleModeMobile = ImageTransformation.getScaleMode(content.scale_mode_mobile);

    model.image_crop = imageAlignmentClassMap[content.image_crop];

    return new Template('experience/components/story_assets/fullWidth').render(model).text;
};