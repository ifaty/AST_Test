'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    var textAlignmentClassMap = {
        'Center Crop': 'center_crop',
        'Crop Vertically': 'crop-vertic',
        'Crop Horizontally': 'crop-horizon',
    }

    model.alt = content.alt ? content.alt : '';
    model.link = content.link ? content.link : '';
    model.image_crop = textAlignmentClassMap[content.image_crop];
    model.desktopImage = ImageTransformation.getScaledImage(content.image);
    model.scaleMode = ImageTransformation.getScaleMode(content.scale_mode);
    model.mobileImage = ImageTransformation.getScaledImage(content.image_mobile);
    model.scaleModeMobile = ImageTransformation.getScaleMode(content.scale_mode_mobile);

    return new Template('experience/components/story_assets/coverComponent').render(model).text;
};
