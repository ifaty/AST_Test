'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
*/
module.exports.render = function (context) {
    var model = new HashMap();
    var component = context.component;
    var content = context.content;

    model.regions = PageRenderHelper.getRegionModelRegistry(component);
    model.title = content.title || '';

    var imageList = content.type == 'Navigation Image List';
    var componentSettings = model.regions.main_region.defaultComponentRenderSettings;
    componentSettings.setAttributes({'imageList': imageList});

    var template = imageList ?
        'experience/components/story_assets/navigationImageList' :
        'experience/components/story_assets/navigationList'

    return new Template(template).render(model).text;
};