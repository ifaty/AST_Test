'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var component = context.component;
    var content = context.content;

    var textAlignmentClassMap = {
        'Center Crop': 'center_crop',
        'Crop Vertically': 'crop-vertic',
        'Crop Horizontally': 'crop-horizon',
    }

    model.title = content.title ? content.title : '';
    model.paragraph_one = content.paragraph_one ? content.paragraph_one : '';
    model.paragraph_second = content.paragraph_second ? content.paragraph_second : '';
    model.alt = content.alt ? content.alt : '';
    model.link = content.link ? content.link : '';
    model.image_crop = textAlignmentClassMap[content.image_crop];
    model.image_focus_mobile = content.image_focus_mobile;
    model.desktopImage = ImageTransformation.getScaledImage(content.image);
    model.mobileImage = ImageTransformation.getScaledImage(content.image_mobile);

    return new Template('experience/components/story_assets/textComponents/textThree').render(model).text;
};
