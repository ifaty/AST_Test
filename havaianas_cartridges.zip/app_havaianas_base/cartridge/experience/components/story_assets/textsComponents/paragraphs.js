'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    model.paragraph_title = content.paragraph_title ? content.paragraph_title : '';
    model.paragraph_one = content.paragraph_one ? content.paragraph_one : '';
    model.paragraph_second = content.paragraph_second ? content.paragraph_second : '';

    return new Template('experience/components/story_assets/textComponents/paragraphs').render(model).text;
};
