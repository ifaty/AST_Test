'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    model.image_left = 
        {
            desktopImage: ImageTransformation.getScaledImage(content.image_left),
            mobileImage: ImageTransformation.getScaledImage(content.image_left_mobile),
            scaleMode: ImageTransformation.getScaleMode(content.scale_mode_left),
            scaleModeMobile: ImageTransformation.getScaleMode(content.scale_mode_left_mobile)
        };

    model.image_right = 
        {
            desktopImage: ImageTransformation.getScaledImage(content.image_right),
            mobileImage: ImageTransformation.getScaledImage(content.image_right_mobile),
            scaleMode: ImageTransformation.getScaleMode(content.scale_mode_right),
            scaleModeMobile: ImageTransformation.getScaleMode(content.scale_mode_right_mobile)
        };

    model.first_title = content.first_title ? content.first_title : '';
    model.second_title = content.second_title ? content.second_title : '';

    return new Template('experience/components/story_assets/animatedWord').render(model).text;
};
