'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

var ProductMgr = require('dw/catalog/ProductMgr');
var ProductShopButton = require('*/cartridge/models/product/productShopButton');


function MatchWithModel(content, target) {

    if(content.bulletsConfig_desktop && content.image_desktop) {

        var itemObj = {
            bullets: {
                desktop: [],
                mobile: []
            },
            image: {
                desktop: ImageTransformation.getScaledImage(content.image_desktop, 'discoveryImage'),
                mobile: ImageTransformation.getScaledImage(content.image_mobile, 'discoveryImage'),
            },
            scaleMode: {
                desktop: ImageTransformation.getScaleMode(content.scale_mode),
                mobile: ImageTransformation.getScaleMode(content.scale_mode_mobile)
            }
        };

        var bulletConfig_desktop = JSON.parse(content.bulletsConfig_desktop);

        bulletConfig_desktop.forEach(function(element, index) {
            var apiProduct = ProductMgr.getProduct(element.pid);
            var product = new ProductShopButton(Object.create(null), apiProduct);
            itemObj.bullets.desktop.push({
                product: product,
                x: element.x,
                y: element.y
            });
        });

        var bulletConfig_mobile = JSON.parse(content.bulletsConfig_mobile);

        bulletConfig_mobile.forEach(function(element, index) {
            var apiProduct = ProductMgr.getProduct(element.pid);
            var product = new ProductShopButton(Object.create(null), apiProduct);
            itemObj.bullets.mobile.push({
                product: product,
                x: element.x,
                y: element.y
            });
        });
    }

    target.image = itemObj.image;
    target.bullets = itemObj.bullets;

}

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    MatchWithModel(content, model);

    return new Template('experience/components/story_assets/matchWith').render(model).text;
};
