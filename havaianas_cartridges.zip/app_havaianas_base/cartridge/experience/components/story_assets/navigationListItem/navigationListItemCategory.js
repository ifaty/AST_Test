'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var URLUtils = require('dw/web/URLUtils');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    var category = content.category;

    model.desktopImage = ImageTransformation.getScaledImage(category.thumbnail, 'shop');
    model.mobileImage = ImageTransformation.getScaledImage(category.thumbnail, 'shop');
    model.link = category.custom && 'alternativeUrl' in category.custom && category.custom.alternativeUrl
        ? (category.custom.alternativeUrl.toString()).replace(/&amp;/g, '&')
        : URLUtils.url('Search-Show', 'cgid', category.getID()).toString();
    model.alt = content.alt ? content.alt : '';
    model.text = content.text ? content.text : '';

    var imageList = context.componentRenderSettings.attributes.imageList == 'true' || false;
    var template = imageList ? 
        'experience/components/story_assets/components/navigationImageListItem' :
        'experience/components/story_assets/components/navigationListItem'

    return new Template(template).render(model).text;
};