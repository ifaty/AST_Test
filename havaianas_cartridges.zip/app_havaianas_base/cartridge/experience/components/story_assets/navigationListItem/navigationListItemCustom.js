'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    var externalLinkMap = {
        'Yes': true,
        'No': false
    }

    model.desktopImage = ImageTransformation.getScaledImage(content.image, 'shop');
    model.scaleMode = ImageTransformation.getScaleMode(content.scale_mode);
    model.mobileImage = ImageTransformation.getScaledImage(content.image_mobile, 'shop');
    model.scaleModeMobile = ImageTransformation.getScaleMode(content.scale_mode_mobile);
    model.link = content.link ? content.link : null;
    model.externalLink = content.externalLink ? externalLinkMap[content.externalLink] : false;
    model.alt = content.alt ? content.alt : '';
    model.text = content.text ? content.text : '';

    var imageList = context.componentRenderSettings.attributes.imageList == 'true' || false;
    var template = imageList ? 
        'experience/components/story_assets/components/navigationImageListItem' :
        'experience/components/story_assets/components/navigationListItem'

    return new Template(template).render(model).text;
};