'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var URLUtils = require('dw/web/URLUtils');
var ProductShopButton = require('*/cartridge/models/product/productShopButton');
var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    var story = storyHelper.getStoryInfo(content.page.ID);

    var image = story.viewAllImage;

    model.desktopImage = {
        src: image
    };
    model.mobileImage = {
        src: image
    };
    model.link = URLUtils.url('Page-Show', 'cid', content.page.ID);
    model.alt = content.alt ? content.alt : '';
    model.text = content.text ? content.text : '';

    var imageList = context.componentRenderSettings.attributes.imageList == 'true' || false;
    var template = imageList ? 
        'experience/components/story_assets/components/navigationImageListItem' :
        'experience/components/story_assets/components/navigationListItem'

    return new Template(template).render(model).text;
};