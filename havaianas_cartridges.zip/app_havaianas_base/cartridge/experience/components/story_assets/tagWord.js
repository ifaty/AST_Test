'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');
var ArrayList = require('dw/util/ArrayList');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    model.tag = content.tag ? content.tag : 'Tagword';

    model.images = [
        {
            desktopImage: ImageTransformation.getScaledImage(content.image_1),
            scaleMode: ImageTransformation.getScaleMode(content.scale_mode_1),
            mobileImage: ImageTransformation.getScaledImage(content.image_mobile_1),
            scaleModeMobile: ImageTransformation.getScaleMode(content.scale_mode_mobile_1)
        },
        {
            desktopImage: ImageTransformation.getScaledImage(content.image_2),
            scaleMode: ImageTransformation.getScaleMode(content.scale_mode_2),
            mobileImage: ImageTransformation.getScaledImage(content.image_mobile_2),
            scaleModeMobile: ImageTransformation.getScaleMode(content.scale_mode_mobile_2)
        },
        {
            desktopImage: ImageTransformation.getScaledImage(content.image_3),
            scaleMode: ImageTransformation.getScaleMode(content.scale_mode_3),
            mobileImage: ImageTransformation.getScaledImage(content.image_mobile_3),
            scaleModeMobile: ImageTransformation.getScaleMode(content.scale_mode_mobile_3)
        },
        {
            desktopImage: ImageTransformation.getScaledImage(content.image_4),
            scaleMode: ImageTransformation.getScaleMode(content.scale_mode_4),
            mobileImage: ImageTransformation.getScaledImage(content.image_mobile_4),
            scaleModeMobile: ImageTransformation.getScaleMode(content.scale_mode_mobile_4)
        },
        {
            desktopImage: ImageTransformation.getScaledImage(content.image_5),
            scaleMode: ImageTransformation.getScaleMode(content.scale_mode_5),
            mobileImage: ImageTransformation.getScaledImage(content.image_mobile_5),
            scaleModeMobile: ImageTransformation.getScaleMode(content.scale_mode_mobile_5)
        }
    ];

    return new Template('experience/components/story_assets/tagWord').render(model).text;
};
