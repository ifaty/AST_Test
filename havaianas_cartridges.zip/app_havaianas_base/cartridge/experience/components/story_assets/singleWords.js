'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

/**
 * Render singleWords component
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;
    var fields = ['title', 'subtitle', 'contrastColor'];

    fields.forEach(function (field) { model[field] = content[field] || ''; });
    model.image = ImageTransformation.getScaledImage(content.image, 'discoveryImage');

    return new Template('experience/components/story_assets/compoundTitle').render(model).text;
};
