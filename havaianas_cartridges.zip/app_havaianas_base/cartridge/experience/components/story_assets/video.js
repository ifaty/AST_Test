'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var imageHelper = require('*/cartridge/scripts/helpers/imageHelper');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    model.video = content.video.value;
    model.poster = imageHelper.getScaledImage(content.poster);

    return new Template('experience/components/story_assets/video').render(model).text;
};
