'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    model.text_1 = content.text_1 ? content.text_1 : 'Text 1';
    model.text_2 = content.text_2 ? content.text_2 : 'Text 2';

    model.desktopImage = ImageTransformation.getScaledImage(content.image);
    model.scaleMode = ImageTransformation.getScaleMode(content.scale_mode);
    model.mobileImage = ImageTransformation.getScaledImage(content.image_mobile);
    model.scaleModeMobile = ImageTransformation.getScaleMode(content.scale_mode_mobile);

    return new Template('experience/components/story_assets/maskedImage').render(model).text;
};