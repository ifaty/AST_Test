'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    model.text = content.text ? content.text : '';
    model.alt = content.alt ? content.alt : '';
    model.link = content.link ? content.link : '';
    model.desktopImage = ImageTransformation.getScaledImage(content.image);
    model.scaleMode = ImageTransformation.getScaleMode(content.scale_mode);
    model.mobileImage = ImageTransformation.getScaledImage(content.image_mobile);
    model.scaleModeMobile = ImageTransformation.getScaleMode(content.scale_mode_mobile);

    return new Template('experience/components/story_assets/marqueTextBackgroundWithImage').render(model).text;
};
