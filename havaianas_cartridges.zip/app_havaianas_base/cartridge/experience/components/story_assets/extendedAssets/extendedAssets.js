'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var component = context.component;
    var content = context.content;

    model.orientation = content.orientation;
    model.regions = PageRenderHelper.getRegionModelRegistry(component);
    model.desktopImage = ImageTransformation.getScaledImage(content.image);
    model.mobileImage = ImageTransformation.getScaledImage(content.image_mobile);

    return new Template('experience/components/story_assets/extendedAssets').render(model).text;
};
