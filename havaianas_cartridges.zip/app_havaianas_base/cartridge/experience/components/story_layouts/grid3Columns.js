'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');


var gutterTypeClassMap = {
    'Small Gap': 'gutter_1_column',
    'Medium Gap': 'gutter_2_column',
    'Large Gap': 'gutter_3_column',
    'Extra Large Gap': 'gutter_4_column',
    'No Gap': 'no_gutter',
}

var textAligmnetClassMap = {
    'Top': 'aligment_top',
    'Center': 'aligment_middle',
    'Bottom': 'aligment_bottom',
    'None': 'no_aligment',
}

/**
 * Render logic for the storefront.1 Row x 1 Col (Mobile) 1 Row x 1 Col (Desktop) layout
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var component = context.component;
    var content = context.content;

    model.regions = PageRenderHelper.getRegionModelRegistry(component);

    model.row_gutter = gutterTypeClassMap[content.row_gutter];
    model.margin_top = textAligmnetClassMap[content.margin_top];


    return new Template('experience/components/story_layouts/grid3Columns').render(model).text;
};
