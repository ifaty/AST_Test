'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');

var marginTypeClassMap = {
    'Small (Left Right)': 'margin_2_columns',
    'Medium (Left Right)': 'margin_3_columns',
    'Large (Left Right)': 'margin_4_columns',
    'None (Left Right)': 'full_height',
}

var marginTopBottomClassMap = {
    'Small (Top Bottom)': 'margin_2_tb',
    'Medium (Top Bottom)': 'margin_3_tb',
    'Large (Top Bottom)': 'margin_4_tb',
    'Extra Large (Top) Large (Bottom)': 'margin_xl_top',
    'None (Top Bottom)': 'no_margin_tb',
}

/**
 * Render logic for the storefront.1 Row x 1 Col (Mobile) 1 Row x 1 Col (Desktop) layout
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var component = context.component;
    var content = context.content;

    model.regions = PageRenderHelper.getRegionModelRegistry(component);

    model.row_global_margin = marginTypeClassMap[content.row_global_margin];
    model.row_margin_top_bottom = marginTopBottomClassMap[content.row_margin_top_bottom];

    return new Template('experience/components/story_layouts/grid1Column').render(model).text;
};

