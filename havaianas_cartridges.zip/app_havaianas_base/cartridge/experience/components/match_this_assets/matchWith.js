'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');

var ProductMgr = require('dw/catalog/ProductMgr');
var ProductShopButton = require('*/cartridge/models/product/productShopButton');


function MatchWithModel(content, target) {
    var matchWithModel = [];

    for(var i = 1; i <=3; i++) {
        if( content["title" + i] && content["bulletsConfig" + i] && content["image" + i]) {

            var itemObj = {
                title: content["title" + i],
                bullets: [],
                image: content["image" + i]
            };

            var bulletConfig = JSON.parse(content["bulletsConfig" + i]);

            bulletConfig.forEach(function(element, index) {
                var apiProduct = ProductMgr.getProduct(element.pid);
                var product = new ProductShopButton(Object.create(null), apiProduct);
                itemObj.bullets.push({
                    product: product,
                    x: element.x,
                    y: element.y
                });
            });

            matchWithModel.push(itemObj);
        }
    }

    target.matchElements = matchWithModel;
}

/**
 * Render logic for storefront.imageAndText component.
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    MatchWithModel(content, model);

    return new Template('experience/components/match_this_assets/matchWith').render(model).text;
};
