'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');

/**
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    model.address = content.address;
    model.email = content.email;
    model.phone = content.phone;

    return new Template('experience/components/institutional_assets/officeAddress').render(model).text;
};
