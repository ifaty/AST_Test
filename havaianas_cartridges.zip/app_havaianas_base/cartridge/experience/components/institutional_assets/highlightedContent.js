'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

/**
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    model.title = content.title;
    model.description = content.description;
    model.linkText = content.linkText;
    model.link = content.link;
    model.desktopImage = ImageTransformation.getScaledImage(content.image);
    model.mobileImage = ImageTransformation.getScaledImage(content.imageMobile);
    model.imageOrientation = content.imageOrientation;
    model.imageInsideOrientation = content.imageInsideOrientation;

    return new Template('experience/components/institutional_assets/highlightedContent').render(model).text;
};
