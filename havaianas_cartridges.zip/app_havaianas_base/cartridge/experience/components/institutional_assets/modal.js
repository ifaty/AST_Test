'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var RegionModelRegistry = require('*/cartridge/experience/utilities/RegionModelRegistry.js');

/**
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} The template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;
    var metaDefinition = require('*/cartridge/experience/components/institutional_assets/modal.json');

    model.regions = new RegionModelRegistry(context.component, metaDefinition);
    model.modalLink = content.modalLink;
    model.selectedModal = 'default';

    if (context.componentRenderSettings.attributes) {
        if (context.componentRenderSettings.attributes.cid) {
            model.cid = context.componentRenderSettings.attributes.cid;
        }

        if (context.componentRenderSettings.attributes.selectedModal) {
            model.selectedModal = content.modalLink === context.componentRenderSettings.attributes.selectedModal;
        }
    }

    return new Template('experience/components/institutional_assets/modal').render(model).text;
};
