'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');

var gridTypeClassMap = {
    'pd-grid-1': '',
    'pd-grid-2': 'shopmode__cell__large-horizontal__desktop',
    'pd-grid-3': 'shopmode__cell__large-vertical__desktop',
    'pd-grid-4': 'shopmode__cell__largest__desktop',
    'pd-grid-5': 'shopmode__cell__two-per-row__desktop',
    'Regular (1x1)': '',
    'Horizontal (2x1)': 'shopmode__cell__large-horizontal__desktop',
    'Vertical (1x2)': 'shopmode__cell__large-vertical__desktop',
    'Large (2x2)': 'shopmode__cell__largest__desktop',
    'Half (1/2)': 'shopmode__cell__two-per-row__desktop',
}

module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    model.product = content.product ? content.product : {};
    if (!model.product.ID) {
        return '';
    }
    model.gridType = gridTypeClassMap[content.gridType];
    switch (content.gridType) {
        case 'Horizontal (2x1)':
            model.imgContext = 'tileHorizontal';
            break;
        case 'Vertical (1x2)':
        model.imgContext = 'tileVertical';
        default:
            break;
    }
    model.expandOnHover = content.expandOnHover === 'Yes' ? true : false;
    context.componentRenderSettings.setAttributes({
        'class': "shopmode__cell" + " " + model.gridType + " " + (model.expandOnHover ? 'expand__hover' : ''),
        'data-category': "1"
    });

    return new Template('experience/components/shopmode_assets/storyProductTile').render(model).text;
};