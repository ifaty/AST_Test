'use strict';

var TemplateISML = require('dw/template/ISML');
var HashMap = require('dw/util/HashMap');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

/**
 * Render logic for the storefront.editorialRichText component
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    model.question = content.question;
    model.answer = content.answer
    model.desktop = ImageTransformation.getScaledImage(content.desktopImage);
    model.mobile = ImageTransformation.getScaledImage(content.mobileImage);

    return new TemplateISML.renderTemplate('experience/components/fun_fact_assets/fun_fact', model);
};
