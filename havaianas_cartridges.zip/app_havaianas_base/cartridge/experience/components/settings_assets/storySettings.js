'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

var storyAttributes = require('*/cartridge/config/storyMetadataAttributes');
var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');
/**
 * Render logic for the storefront.editorialRichText component
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    if (PageRenderHelper.isInEditMode()) {
        storyAttributes.forEach(function (e) {
            model[e] = content[e] ? content[e] : null;
        });

        if (model.searchBackground) {
            model.searchBackground = ImageTransformation.getScaledImage(content.searchBackground, 'discoveryImage');
        }

        if (model.searchIcon) {
            model.searchIcon = ImageTransformation.getScaledImage(content.searchIcon, 'shop');
        }

        if (model.category) {
            model.category = model.category.ID;
        }
        if (!model.primaryColorTone) {
            model.primaryColorTone = 'regular';
        }

        var HookManager = require('dw/system/HookMgr');
        if (session.custom.PDCurrentStoryID) {
            storyHelper.saveStorySettings(session.custom.PDCurrentStoryID, model, content);
        }
        HookManager.callHook('app.experience.editmode', 'editmode');
        model.resetEditPDMode = true;
    }

    return new Template('experience/components/story_assets/settings').render(model).text;
};
