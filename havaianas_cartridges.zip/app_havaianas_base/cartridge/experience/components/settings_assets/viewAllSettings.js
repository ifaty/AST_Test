'use strict';

var Template = require('dw/util/Template');
var HashMap = require('dw/util/HashMap');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');
var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');
var colorMatrixHelper = require('*/cartridge/scripts/helpers/colorMatrixHelper');
var ImageTransformation = require('*/cartridge/experience/utilities/ImageTransformation.js');

/**
 * Render logic for the storefront.editorialRichText component
 * @param {dw.experience.ComponentScriptContext} context The Component script context object.
 * @returns {string} template to be displayed
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var content = context.content;

    var storyInfo = JSON.parse(context.componentRenderSettings.attributes.storyInfo || '{}');

    model.viewAllImage = ImageTransformation.getScaledImage(content.viewAllImage, 'viewAllImage');
    model.viewAllVideo = !empty(content.viewAllVideo) ? content.viewAllVideo : null;
    model.viewAllText1 = content.viewAllText1;
    model.viewAllText2 = content.viewAllText2;
    model.storyInfo = storyInfo;
    model.colorMatrix = colorMatrixHelper.getColorSpecification(storyInfo.primaryColor, storyInfo.primaryColorTone);
    model.shapeIndex = (Math.floor(Math.random() * 5) + 1).toFixed(0);

    if (PageRenderHelper.isInEditMode()) {
        var HookManager = require('dw/system/HookMgr');
        HookManager.callHook('app.experience.editmode', 'editmode');
        model.resetEditPDMode = true;

        if (storyHelper.viewAllDataChanged(storyInfo, content.viewAllImage, model.viewAllVideo)) {
            storyHelper.updateViewAllData(storyInfo.id, content.viewAllImage, model.viewAllVideo);
        }
    }

    return new Template('experience/components/story_assets/viewAllTile').render(model).text;
};
