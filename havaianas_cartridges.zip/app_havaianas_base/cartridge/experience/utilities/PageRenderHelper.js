'use strict';

var PageRenderHelper = module.superModule;

/**
 * Parse Render Parameters
 *
 * @param {Object} renderParametersJson The json render parameters
 *
 * @returns {Object} render parameters
 */
function parseRenderParameters(renderParametersJson) {
    var renderParameters = {};
    if (renderParametersJson) {
        try {
            renderParameters = JSON.parse(renderParametersJson);
        } catch (e) {
            var Logger = require('dw.system.Logger');
            Logger.error('Unable to parse renderParameters: ' + renderParametersJson);
        }
    }
    return renderParameters;
}

PageRenderHelper.getRenderParam = function (attribute, renderParams) {
    var renderParamValue;
    if (attribute && renderParams) {
        try {
            var renderParams = parseRenderParameters(renderParams);
            var renderParamValue = renderParams[attribute];
        } catch (e) {
            var error = e;
            var Logger = require('dw.system.Logger');
            Logger.error('Unable to retrive render param: ' + attribute);
        }
    }
    return renderParamValue;
}

module.exports = PageRenderHelper;