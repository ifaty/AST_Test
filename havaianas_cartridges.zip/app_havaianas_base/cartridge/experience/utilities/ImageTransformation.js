var ImageTransformation = module.superModule;
var imageHelper = require('*/cartridge/scripts/helpers/imageHelper');

function getScaleMode(sm) {
    var scaleModeMap = {
        'Scale to fit': 'resize',
        'Crop to fit': 'crop'
    }

    return scaleModeMap[sm];
}

ImageTransformation.scale = imageHelper.scale;
ImageTransformation.url = imageHelper.url;
ImageTransformation.getScaledImage = imageHelper.getScaledImage;
ImageTransformation.getScaleMode = getScaleMode;

module.exports = ImageTransformation;