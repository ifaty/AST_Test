'use strict';
var TemplateISML = require('dw/template/ISML');
var CatalogMgr = require('dw/catalog/CatalogMgr');
var HashMap = require('dw/util/HashMap');
var ProductMgr = require('dw/catalog/ProductMgr');
var Resource = require('dw/web/Resource');
var ComponentRenderSettings = require('dw/experience/ComponentRenderSettings');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');
var RegionModelRegistry = require('*/cartridge/experience/utilities/RegionModelRegistry.js');
var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');
var shopModeHelper = require('*/cartridge/scripts/helpers/shopModeHelper');
var ProductShopButton = require('*/cartridge/models/product/productShopButton');
var colorMatrixHelper = require('*/cartridge/scripts/helpers/colorMatrixHelper');

/**
 * Render logic for the storepage.
 *
 * @param {dw.experience.PageScriptContext} context The page script context object.
 *
 * @returns {string} The template text
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var page = context.page;
    var params = JSON.parse(context.renderParameters || '{}'); // Context passed through the controller
    model.page = page;
    var storySettings = storyHelper.getStorySettings();

    // automatically register configured regions
    var metaDefinition = require('*/cartridge/experience/pages/story.json');
    model.regions = new RegionModelRegistry(page, metaDefinition);

    // Determine seo meta data.
    // Used in htmlHead.isml via common/layout/page.isml decorator.
    model.CurrentPageMetaData = PageRenderHelper.getPageMetaData(page);
    model.CurrentPageMetaData = {};
    model.CurrentPageMetaData.title = page.pageTitle;
    model.CurrentPageMetaData.description = page.pageDescription;
    model.CurrentPageMetaData.keywords = page.pageKeywords;

    model.paginated = params.paginated || false; // Adds 'page' decorator if true
    model.viewAll = params.viewAll || false; // Switch to View All tile if true
    model.action = Resource.msg('pagename.discovery.home', 'technical', null); // Pagename
    model.pageContext = Resource.msg('pagecontext.discovery.home', 'technical', null); // Pagecontext
    model.activeId = params.activeId || null;
    if (!model.viewAll) {
        var orderingInfo = storyHelper.getStoryOrderingInfo(storySettings, {
            activeId: page.ID,
            previous: params.previous != false && true,
            next: params.next != false && true
        });

        model.previous = !empty(orderingInfo.previous) ? orderingInfo.previous : '';
        model.next = !empty(orderingInfo.next) ? orderingInfo.next : '';
        model.ordering = model.paginated ? [page.ID] : orderingInfo.ordering;
        model.viewMore = orderingInfo.viewMore;
    }
    model.storyInfo = storyHelper.getStoryInfo(page.ID, 'frontend');

    var viewAllComponentSettings = model.regions.view_all_region.defaultComponentRenderSettings;
    viewAllComponentSettings.setAttributes({'storyInfo': JSON.stringify(model.storyInfo)});

    // Uncomment the code below if the story content components also end up needing story metadata
    //var mainComponentSettings = model.regions.main_region.defaultComponentRenderSettings;
    // mainComponentSettings.setAttributes({'storyInfo': JSON.stringify(model.storyInfo)});

    if (PageRenderHelper.isInEditMode()) {
        var HookManager = require('dw/system/HookMgr');
        session.custom.PDCurrentStoryID = page.ID;
        var Transaction = require('dw/system/Transaction');
        var requestStage;
        Transaction.wrap(function () {
            session.custom.requestStage = empty(session.custom.requestStage) || (session.custom.requestStage == 3) ? 1 : session.custom.requestStage;
            requestStage = session.custom.requestStage;
        });
        if (requestStage == 1) {
            Transaction.wrap(function () {
                session.custom.storyDataLock = 0;
                session.custom.viewAllDataLock = 0;
                session.custom.requestStage = 2;
            });
        } else if (requestStage == 2) {
            Transaction.wrap(function () {
                session.custom.requestStage = 3;
            });
        }

        model.ordering = [page.ID];
        model.viewMore = false;
        HookManager.callHook('app.experience.editmode', 'editmode');
        model.resetEditPDMode = true;
    }

    var previewImages = {
        items: []
    };
    try {
        var productIds = shopModeHelper.getProductList(model.storyInfo.shopModePage);
        var max = 5;
        var i = 0;
        productIds.forEach(function (e) {
            if (i < max) {
                var product = ProductMgr.getProduct(e);
                if (product) {
                    var tmp = ProductShopButton(Object.create(null), product);
                    if (tmp && tmp.shopImages) {
                        previewImages.items.push(tmp.shopImages.items[0].src.mobile.toString());
                    }
                }
            }
            i++;
        });
    } catch (error) {
    }

    model.previewImages = previewImages;

    model.pageModel = params.pageModel;

    model.colorMatrix = colorMatrixHelper.getColorSpecification(
        model.storyInfo.primaryColor,
        model.storyInfo.primaryColorTone,
        null,
        null
    );

    // render the page
    return TemplateISML.renderTemplate('experience/pages/story',model);
}
