'use strict';
var TemplateISML = require('dw/template/ISML');
var HashMap = require('dw/util/HashMap');
var Resource = require('dw/web/Resource');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');
var RegionModelRegistry = require('*/cartridge/experience/utilities/RegionModelRegistry.js');

/**
 * Render logic for the storepage.
 *
 * @param {dw.experience.PageScriptContext} context The page script context object.
 *
 * @returns {string} The template text
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var page = context.page;
    var params = JSON.parse(context.renderParameters || '{}');
    var metaDefinition = require('*/cartridge/experience/pages/institutional.json');
    var config = require('*/cartridge/config/institutionalConfig')
    var customPrefs = require('dw/system/Site').current.preferences.custom;

    model.CurrentPageMetaData = PageRenderHelper.getPageMetaData(page);
    model.CurrentPageMetaData = {};
    model.CurrentPageMetaData.title = page.pageTitle;
    model.CurrentPageMetaData.description = page.pageDescription;
    model.CurrentPageMetaData.keywords = page.pageKeywords;

    var pageName;
    Object.keys(config.pageName).forEach(function(key) {
        if (customPrefs[key] == params.cid) {
            pageName = config.pageName[key]
        }
    });
    model.action = Resource.msg('pagename.' + (pageName || 'institutional'), 'technical', 'page-institutional');
    model.pageContext = Resource.msg('pagecontext.' + (pageName || 'institutional'), 'technical', 'searchMenu');
    model.regions = new RegionModelRegistry(page, metaDefinition);
    model.page = page;

    var componentSettings = model.regions.content_modules_region.defaultComponentRenderSettings;
    componentSettings.setAttributes({ cid: params.cid });

    if (params.selectedModal) {
        model.pageContext = "modal";
        componentSettings.setAttributes({ selectedModal: params.selectedModal });
        model.selectedModal = true;
    }

    model.pageModel = params.pageModel;

    if (PageRenderHelper.isInEditMode()) {
        var HookManager = require('dw/system/HookMgr');
        HookManager.callHook('app.experience.editmode', 'editmode');
        model.resetEditPDMode = true;
    }

    return TemplateISML.renderTemplate('experience/pages/institutional', model);
};