'use strict';
var TemplateISML = require('dw/template/ISML');
var HashMap = require('dw/util/HashMap');
var CatalogMgr = require('dw/catalog/CatalogMgr');
var Logger = require('dw/system/Logger');
var ProductMgr = require('dw/catalog/ProductMgr');
var ProductSearchModel = require('dw/catalog/ProductSearchModel');
var Resource    = require('dw/web/Resource');
var URLUtils = require('dw/web/URLUtils');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');
var ProductSearch = require('*/cartridge/models/search/productSearch');
var searchHelper = require('*/cartridge/scripts/helpers/searchHelpers');
var QueryString = require('server').querystring;
var RegionModelRegistry = require('*/cartridge/experience/utilities/RegionModelRegistry.js');
var preferences = require('*/cartridge/config/preferences');
var storyHelper = require('*/cartridge/scripts/helpers/storyHelper');
var shopModeHelper = require('*/cartridge/scripts/helpers/shopModeHelper');
var searchHelper = require('*/cartridge/scripts/helpers/searchHelpers');
var colorMatrixHelper = require('*/cartridge/scripts/helpers/colorMatrixHelper');

var DEFAULT_PAGE_SIZE = preferences.defaultPageSize ? preferences.defaultPageSize : 12;

/**
 * Render logic for the storepage.
 *
 * @param {dw.experience.PageScriptContext} context The page script context object.
 *
 * @returns {string} The template text
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var page = context.page;
    var params = JSON.parse(context.renderParameters || '{}'); // Context passed through the controller
    model.page = page;
    var storySettings = storyHelper.getStorySettings();

    // automatically register configured regions
    var metaDefinition = require('*/cartridge/experience/pages/storyShopMode.json');
    model.regions = new RegionModelRegistry(page, metaDefinition);

    model.action = Resource.msg('pagename.shop', 'technical', null); // Pagename
    model.pageContext = Resource.msg('pagecontext.shop', 'technical', null); // Pagename

    // Determine seo meta data.
    // Used in htmlHead.isml via common/layout/page.isml decorator.
    model.CurrentPageMetaData = PageRenderHelper.getPageMetaData(page);
    model.CurrentPageMetaData = {};
    model.CurrentPageMetaData.title = page.pageTitle;
    model.CurrentPageMetaData.description = page.pageDescription;
    model.CurrentPageMetaData.keywords = page.pageKeywords;

    model.paginated = params.paginated || false; // Adds 'page' decorator if true

    if (PageRenderHelper.isInEditMode()) {
        var HookManager = require('dw/system/HookMgr');
        session.custom.PDCurrentStoryID = page.ID;
        HookManager.callHook('app.experience.editmode', 'editmode');
        model.resetEditPDMode = true;
        shopModeHelper.updateProductList(page.ID, model);
    }

    // var shopModeComponentSettings = model.regions.shop_region.defaultComponentRenderSettings;
    // shopModeComponentSettings.setAttributes({
    //     'class': "shopmode__cell ",
    //     'data-category': "1"
    // });

    model.showResults = model.regions.shop_region.region.size > 0;
    model.resultsLength = model.regions.shop_region.region.size;

    var storyInfo = storyHelper.getStoryInfoFromShopmode(page.ID);
    model.buttonImage = !empty(storyInfo) && !empty(storyInfo.viewAllImage) && Object.keys(storyInfo.viewAllImage).length ? storyInfo.viewAllImage : {};
    model.buttonVideo = !empty(storyInfo) && !empty(storyInfo.viewAllVideo) ? storyInfo.viewAllVideo : "";
    model.activeId = params.activeId || null;
    var activeStoryId = model.activeId ? storyHelper.getStoryInfoFromShopmode(model.activeId).id : null;
    var orderingInfo = storyHelper.getStoryOrderingInfo(storySettings, {
        activeId: activeStoryId,
        activeShopId: page.ID,
        previous: params.previous != false && true,
        next: params.next != false && true
    });
    model.previous = !empty(orderingInfo.previousShop) ? orderingInfo.previousShop : '';
    model.next = !empty(orderingInfo.nextShop) ? orderingInfo.nextShop : '';
    model.pages = params.paginated ? [page.ID] : orderingInfo.shopModePages;
    model.viewMore = orderingInfo.viewMore;

    // We need all of this because of the filters
    try {
        var productSearchModel = new ProductSearchModel();
        productSearchModel = searchHelper.setupStorySearch(productSearchModel, page.ID);
        productSearchModel.search();
        var productSearch = new ProductSearch(
            productSearchModel,
            {pageId: page.ID},
            {},
            CatalogMgr.getSortingOptions(),
            CatalogMgr.getSiteCatalog().getRoot()
        )
        model.productSearch = productSearch;
        model.storyId = storyInfo.id;
        var querystring = new QueryString('pageId='+page.ID);
        model.refineurl = URLUtils.url('Search-Show', 'pageId', page.ID);
        model.refineBarUrl = URLUtils.url('Search-Refinebar', 'cgid', 'root');
        model.categoryRefinements = 'pageId='+page.ID;
        model.onSaleRefinement = searchHelper.getOnSaleRefinementObject(querystring);
    } catch (error) {
        Logger.error('Error rendering story shop mode: ' + error.stack);
    }

    model.shopmode = true;
    if (model.regions.shop_region.region.visibleComponents.length > 0) {
        var firstTile = model.regions.shop_region.region.visibleComponents[0]
    }
    if (firstTile && firstTile.typeID === 'shopmode_assets.storyProductTile') {
        var firstProductId = model.regions.shop_region.region.visibleComponents[0].getAttribute('product');
        var product = ProductMgr.getProduct(firstProductId);
        try {
            model.colorMatrix = colorMatrixHelper.getColorSpecification(
                product.custom.hav_primaryColor,
                product.custom.hav_primaryColorTone,
                product.custom.hav_secondaryColor,
                product.custom.hav_secondaryColorTone
            );
        } catch (e) {
            // TODO: add default colors
        }
    }

    model.pageModel = params.pageModel;

    // render the page
    return TemplateISML.renderTemplate('experience/pages/storyShopMode',model);
}
