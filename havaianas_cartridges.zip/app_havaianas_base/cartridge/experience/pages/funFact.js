'use strict';
var TemplateISML = require('dw/template/ISML');
var HashMap = require('dw/util/HashMap');
var PageRenderHelper = require('*/cartridge/experience/utilities/PageRenderHelper.js');
var RegionModelRegistry = require('*/cartridge/experience/utilities/RegionModelRegistry.js');

/**
 * Render logic for the storepage.
 *
 * @param {dw.experience.PageScriptContext} context The page script context object.
 *
 * @returns {string} The template text
 */
module.exports.render = function (context) {
    var model = new HashMap();
    var page = context.page;
    model.page = page;

    // automatically register configured regions
    var metaDefinition = require('*/cartridge/experience/pages/funFact.json');
    model.regions = new RegionModelRegistry(page, metaDefinition);

    // var product = PageRenderHelper.getRenderParam('product', context.renderParameters);
    if (PageRenderHelper.isInEditMode()) {
        var HookManager = require('dw/system/HookMgr');
        HookManager.callHook('app.experience.editmode', 'editmode');
        model.resetEditPDMode = true;
    }
    //var x = model.regions.main_region.render(model.renderData)
    // render the page
    return TemplateISML.renderTemplate('experience/pages/funFact', model);
}
