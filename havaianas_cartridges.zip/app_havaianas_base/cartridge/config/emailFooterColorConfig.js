'use strict';

function footerColorConfig(template){
    var ContentMgr = require('dw/content/ContentMgr');
    var asset = ContentMgr.getContent(template);
    
    var footerColorConfig = {
        textColor : asset.custom.hav_emailTextColor,
        backgroundColor : asset.custom.hav_emailBackgroundColor,
        hyperLinkColor : asset.custom.hav_emailHyperlinkColor,
        footerIconColor : asset.custom.hav_emailFooterIconColor
    };

    return footerColorConfig;
};


module.exports = footerColorConfig;

