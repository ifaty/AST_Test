'use strict';

var Resource = require('dw/web/Resource');

var statusMap = {
    'WAITING': Resource.msg('order.status.waiting', 'orderTracking', null),
    'SEND_READY': Resource.msg('order.status.sendready', 'orderTracking', null),
    'SHIPPED': Resource.msg('order.status.shipped', 'orderTracking', null),
    'IN_TRANSIT': Resource.msg('order.status.intransit', 'orderTracking', null),
    'DELIVERED': Resource.msg('order.status.delivered', 'orderTracking', null),
    'PICKING': Resource.msg('order.status.picking', 'orderTracking', null),
    'CHECKED': Resource.msg('order.status.picking', 'orderTracking', null),
    'BILLING_CONFIRMATION': Resource.msg('order.status.billingconfirmation', 'orderTracking', null),
    'PICKUP_READY': Resource.msg('order.status.pickupready', 'orderTracking', null),
    'DEFAULT': Resource.msg('order.status.waiting', 'orderTracking', null),
    '': Resource.msg('order.status.unknown', 'orderTracking', null)
};

var storefrontMap = {
    'WAITING': Resource.msg('order.statusCode.placed', 'orderTracking', null),
    'SEND_READY': Resource.msg('order.statusCode.placed', 'orderTracking', null),
    'SHIPPED': Resource.msg('order.statusCode.shipped', 'orderTracking', null),
    'IN_TRANSIT': Resource.msg('order.statusCode.intransit', 'orderTracking', null),
    'DELIVERED': Resource.msg('order.statusCode.delivered', 'orderTracking', null),
    'PICKUP_READY': Resource.msg('order.statusCode.pickupready', 'orderTracking', null),
    'PICKUP_DONE': Resource.msg('order.statusCode.pickupdone', 'orderTracking', null),
    'DEFAULT': Resource.msg('order.status.waiting', 'orderTracking', null),
    '': Resource.msg('order.status.unknown', 'orderTracking', null)
};

var orderingShipping = [
    Resource.msg('order.statusCode.placed', 'orderTracking', null),   // PLACED
    Resource.msg('order.statusCode.shipped', 'orderTracking', null),  // SHIPPED
    Resource.msg('order.statusCode.intransit', 'orderTracking', null),// IN_TRANSIT
    Resource.msg('order.statusCode.delivered', 'orderTracking', null) // DELIVERED
];

var orderingPickup = [
    Resource.msg('order.statusCode.placed', 'orderTracking', null),     // PLACED
    Resource.msg('order.statusCode.shipped', 'orderTracking', null),    // SHIPPED
    Resource.msg('order.statusCode.pickupready', 'orderTracking', null),// PICKUP_READY,
    Resource.msg('order.statusCode.delivered', 'orderTracking', null)   // DELIVERED
];

var statusMapForOCAPI = {
    '6' : 'CANCELLED'//6 is the int of constant ORDER_STATUS_CANCELLED on BM
}

module.exports = {
    statusMapForOCAPI: statusMapForOCAPI,
    statusMap: statusMap,
    orderingShipping: orderingShipping,
    orderingPickup: orderingPickup,
    storefrontMap: storefrontMap
};
