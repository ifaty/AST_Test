'use strict';

function getTypes() {
    var OrgPreferences = dw.system.System.getPreferences().getCustom();
    var types = OrgPreferences['hav_madeInBrazilTypes'] || [];
    return types;
}

module.exports = getTypes();