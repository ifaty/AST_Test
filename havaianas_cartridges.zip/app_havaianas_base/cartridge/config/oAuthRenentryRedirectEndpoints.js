'use strict';

module.exports = {
    1: 'Account-EditProfile',
    2: 'Checkout-Begin',
    3: 'Account-Show',
    4: 'Home-Show'
};
