'use strict';

var Resource = require('dw/web/Resource');

var pageNames = {
    accountProfile: Resource.msg('pagename.myaccount', 'technical', null), // Account-Show
    accountEditProfile: Resource.msg('pagename.profile', 'technical', null), // Account-EditProfile
    accountCreateProfile: Resource.msg('pagename.createaccount', 'technical', null), //
    accountPasswordReset: Resource.msg('pagename.passwordReset', 'technical', null),
    accountPasswordResetSuccessful: Resource.msg('pagename.resetrequestsuccessful', 'technical', null),
    accountSetNewPassword: Resource.msg('pagename.setNewPassword', 'technical', null),
    addressList: Resource.msg('pagename.addresses', 'technical', null),
    addressEdit: Resource.msg('pagename.editaddress', 'technical', null),
    cart: Resource.msg('pagename.cart', 'technical', null),
    checkout: Resource.msg('pagename.checkout', 'technical', null),
    home: Resource.msg('pagename.discovery.home', 'technical', null),
    homeNavigation: Resource.msg('pagename.home.navigation', 'technical', null),
    viewAll: Resource.msg('pagename.discovery.viewall', 'technical', null),
    error: Resource.msg('pagename.error', 'technical', null),
    error404: Resource.msg('pagename.error404', 'technical', null),
    login: Resource.msg('pagename.login', 'technical', null),
    loginLinkRequest: Resource.msg('pagename.linkrequest', 'technical', null),
    paymentMethods: Resource.msg('pagename.paymentinstruments', 'technical', null),
    product: Resource.msg('pagename.productshow', 'technical', null),
    productSizeGuide: Resource.msg('pagename.productsizeguide', 'technical', null),
    reviews: Resource.msg('pagename.review.reviews', 'technical', null),
    search: Resource.msg('pagename.search', 'technical', null),
    shopMode: Resource.msg('pagename.shop', 'technical', null),
    story: Resource.msg('pagename.story', 'technical', null),
    wishlist: Resource.msg('pagename.wishlistshow', 'technical', null),
    internationalOffices: Resource.msg('pagename.internationaloffices', 'technical', null),
    orderHistory: Resource.msg('pagename.orderHistory', 'technical', null),
    order: Resource.msg('pagename.order', 'technical', null),
    institutional: Resource.msg('pagename.institutional', 'technical', null),
    contact: Resource.msg('pagename.contact', 'technical', null)
}

module.exports = pageNames;