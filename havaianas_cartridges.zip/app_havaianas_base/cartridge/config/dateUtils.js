'use strict';

function parseDate (dateString) {
    var date = dateString.split('/').map(function (date) {
        return parseInt(date, 10);
    });

    var now = new Date();

    var response = {
        month: date[0],
        day: date[1],
        year: now.getFullYear()
    }

    if (date.length > 2)
        response.year = date[2];

    return response;
}

function dateToString (dateObject) {
    var month = (dateObject.getMonth() + 1);
    var day = dateObject.getDate();

    // Prepending zero when needed. e.g. 9 -> 09
    month = month % 10 === month ? '0' + month : month;
    day = day % 10 === day ? '0' + day : day;

    return month + '/' + day + '/' + dateObject.getFullYear();
}

function dateToLongString (dateObject) {
    if (dateObject instanceof Date) {
        var Calendar = require('dw/util/Calendar');
        var calendar = new Calendar(dateObject);
        var StringUtils = require('dw/util/StringUtils');
        var Site = require('dw/system/Site');
        var estimatedDeliveryDateToString = StringUtils.formatCalendar(calendar,request.httpLocale,calendar.LONG_DATE_PATTERN);
        return estimatedDeliveryDateToString;
    }
    else
    {
        return '';
    }
}

module.exports = {
    parseDate: parseDate,
    dateToString: dateToString,
    dateToLongString: dateToLongString
}