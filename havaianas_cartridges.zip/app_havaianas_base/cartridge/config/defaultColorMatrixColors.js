'use strict';

module.exports = {
    DEFAULT_COLORS: {background:"#1059e6", text:"#4ffcff", ui:"#4ffcff", uiText:"#1059e6", primaryColor: "aqua", default:true},
    DEFAULT_VARIATION_COLORS: {
        gradientFirstColors: {background:"#acdbff", text:"#005d5f", ui:"#005d5f", uiText:"#ffffff", default: true},
        gradientSecondColors: {background:"#defeff", text:"#005d5f", ui:"#02e4e8", uiText:"#005d5f", default: true}
    }
}