'use strict';

module.exports = [
    'position',
    'searchBackground',
    'searchIcon',
    'primaryColor',
    'primaryColorTone',
    'secondRainbowColor',
    'thirdRainbowColor',
    'type',
    'shopModePage',
    'persist'];
