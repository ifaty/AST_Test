function mapTemplateToStatus(status) {
    var HashMap = require('dw/util/HashMap');
    var statusMap = new HashMap();
    statusMap.put('PICKING', 'hav_sendOrderStatusEmail_Picking');
    statusMap.put('SEND_READY', 'hav_sendOrderStatusEmail_Picking');
    statusMap.put('DELIVERED', 'hav_sendOrderStatusEmail_Delivered');
    statusMap.put('CANCELLED', 'hav_sendOrderStatusEmail_Cancelled');
    statusMap.put('CANCELED', 'hav_sendOrderStatusEmail_Cancelled');
    statusMap.put('SHIPPED', 'hav_sendOrderStatusEmail_Shipped');
    statusMap.put('PICKUP_READY', 'hav_sendOrderStatusEmail_PickupReady');
    statusMap.put('DELIVERY_FAILED', 'hav_sendOrderStatusEmail_Failure');
    statusMap.put('DELIVERY_LOST', 'hav_sendOrderStatusEmail_Lost');
    statusMap.put('DELIVERY_REFUSED', 'hav_sendOrderStatusEmail_Failure');

    var template = '';
    template = statusMap[status];

    return template;
};

module.exports = mapTemplateToStatus;