'use strict';

var havaianasDecorators = require('*/cartridge/models/product/decorators/havaianasIndex');
var productHelper = require('*/cartridge/scripts/helpers/productHelpers');
var orderLineItemBase = module.superModule;

module.exports = function orderLineItem(product, apiProduct, options) {
    product = orderLineItemBase(product, apiProduct, options);
    havaianasDecorators.transformedImages(product, apiProduct, 'shop');
    havaianasDecorators.transformedImages(product, apiProduct, 'hero');
    havaianasDecorators.colorMatrix(product, apiProduct);
    return product;
};