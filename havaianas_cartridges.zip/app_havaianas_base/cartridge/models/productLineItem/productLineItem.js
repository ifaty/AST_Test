'use strict';

var havaianasDecorators = require('*/cartridge/models/product/decorators/havaianasIndex');
var productHelper = require('*/cartridge/scripts/helpers/productHelpers');
var productLineItemBase = module.superModule;

module.exports = function productLineItem(product, apiProduct, options) {
    product = productLineItemBase(product, apiProduct, options);
    havaianasDecorators.transformedImages(product, apiProduct, 'shop');
    product.variantUrls = productHelper.getVariantAddToCartUrls(apiProduct.ID, null, 'checkout');
    havaianasDecorators.colorMatrix(product, apiProduct);
    havaianasDecorators.category(product, apiProduct);
    havaianasDecorators.selectedVariationGroup(product, apiProduct);
    return product;
};