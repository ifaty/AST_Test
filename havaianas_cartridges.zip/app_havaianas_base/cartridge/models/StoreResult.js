'use strict';

function StoreResult (store, geolocation) {
    var Store = require('*/cartridge/models/store');
    var UUIDUtils = require('dw/util/UUIDUtils');
    var storeModel = new Store(store);

    var storeGeolocation = storeModel.getGeolocation();
    var storeName = storeModel.getName();
    var storeType = storeModel.getType();

    return {
        id: storeModel.getID(),
        uuid: UUIDUtils.createUUID(),
        name: storeName,
        rating: storeModel.getRating(),
        marker: JSON.stringify({
            name: storeName,
            type: storeType,
            geolocation: storeGeolocation
        }),
        type: storeType,
        geolocation: storeGeolocation,
        storeModel: storeModel,
        distance: storeModel.calculateDistance(geolocation),
        address: storeModel.getAddress(),
        openPeriod: storeModel.getTodayOpenPeriod()
    }
}

module.exports = StoreResult;