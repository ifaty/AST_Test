'use strict';

module.exports = function (store, shippingMethodModel) {
    Object.defineProperty(store, 'shippingMethod', {
        enumerable: true,
        value: shippingMethodModel
    })
}