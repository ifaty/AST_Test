importPackage(dw.web);

module.exports = function (object, pageId) {
    var urls = [];

    var PageMgr = require('dw/experience/PageMgr');
    var URLUtils = require('dw/web/URLUtils');
    var Logger = require('dw/system/Logger');

    var page = PageMgr.getPage(pageId);

    if (!empty(page)) {
        try {
            var OrgPreferences = dw.system.System.getPreferences().getCustom();
            var objPagesOnlineOn = JSON.parse(OrgPreferences.hav_pageIsOnlineOn);

            if (objPagesOnlineOn && objPagesOnlineOn[pageId]) {
                var sites = dw.system.Site.getAllSites();
                for each (var site : dw.system.Site in sites) {
                    if(objPagesOnlineOn[pageId].indexOf(site.ID) == -1 || (site.status != dw.system.Site.SITE_STATUS_ONLINE && dw.system.System.getInstanceType() == dw.system.System.PRODUCTION_SYSTEM)) {
                        continue;
                    }

                    for each(var locale : String in site.getAllowedLocales()) {
                        if(locale != 'default') {
                            var pageAction = new URLAction('Page-Show', site.ID, locale);
                            var url = URLUtils.abs(pageAction, new URLParameter('cid', pageId));
                            locale = locale.toLowerCase().replace('_', '-');//hareflang tag must be separated by '-', for example: pt-br and not pt_br.
                            urls.push( { "locale" : locale, "url" : url.toString() } );
                        }
                    }
                }
            }
        }
        catch (e) {//if JSON.parse fail when hav_pageIsOnlineOn is not a JSON
            Logger.error('Fail to try parse hav_pageIsOnlineOn JSON for Page Designer hreflang:  ' + e.message);
        }
    }

    Object.defineProperty(object, 'hreflangs', {
        enumerable: true,
        value: urls
    });
}