importPackage(dw.web);

module.exports = function (object, productId) {
    var ProductMgr = require('dw/catalog/ProductMgr');
    var URLUtils = require('dw/web/URLUtils');

    var product = ProductMgr.getProduct(productId);
    var urlCanonical = '';

    if (product.isVariant()) {    
        var productHelpers = require('*/cartridge/scripts/helpers/productHelpers');
        var options = {productType:'variant'};
        var normalizedProduct = productHelpers.normalizeProduct(product, options);
        var productIdGroup = normalizedProduct.apiProduct.ID;
        urlCanonical = URLUtils.http('Product-Show','pid', productIdGroup).toString();
    } 
    else {    
        urlCanonical = URLUtils.http('Product-Show','pid', product.ID).toString();
    }

    Object.defineProperty(object, 'urlCanonical', {
        enumerable: true,
        value: urlCanonical
    });
}