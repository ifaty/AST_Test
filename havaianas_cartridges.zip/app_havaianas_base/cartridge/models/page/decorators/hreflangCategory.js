importPackage(dw.web);

module.exports = function (object, categoryId) {
    var urls = [];

    var CatalogMgr = require('dw/catalog/CatalogMgr');
    var URLUtils = require('dw/web/URLUtils');

    var category = CatalogMgr.getCategory(categoryId);

    if (!empty(category)) {
        var isOnlineOn = [];
        for each(var siteID in category.custom.hav_isOnlineOn) {
            isOnlineOn.push(siteID.value);
        }

        var sites = dw.system.Site.getAllSites();
        for each (var site : dw.system.Site in sites) {
            if(isOnlineOn.indexOf(site.ID) == -1 || (site.status != dw.system.Site.SITE_STATUS_ONLINE && dw.system.System.getInstanceType() == dw.system.System.PRODUCTION_SYSTEM)) {
                continue;
            }

            for each(var locale : String in site.getAllowedLocales()) {
                if(locale != 'default') {
                    var categoryAction = new URLAction('Search-Show', site.ID, locale);
                    var url = URLUtils.abs(categoryAction, new URLParameter('cgid', categoryId));
                    locale = locale.toLowerCase().replace('_', '-');//hareflang tag must be separated by '-', for example: pt-br and not pt_br.
                    urls.push( { "locale" : locale, "url" : url.toString() } );
                }
            }
        }
    }

    Object.defineProperty(object, 'hreflangs', {
        enumerable: true,
        value: urls
    });
}