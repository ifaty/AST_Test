importPackage(dw.web);

module.exports = function (object, categoryId) {
    var URLUtils = require('dw/web/URLUtils');
    
    var urlCanonical = URLUtils.http('ViewAll-Show').toString();

    Object.defineProperty(object, 'urlCanonical', {
        enumerable: true,
        value: urlCanonical
    });   
}