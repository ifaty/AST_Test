importPackage(dw.web);

module.exports = function (object, requestPath) {
    var urls = [];
  
    var sites = dw.system.Site.getAllSites();
    for each (var site : dw.system.Site in sites) {
        if(site.status != dw.system.Site.SITE_STATUS_ONLINE && dw.system.System.getInstanceType() == dw.system.System.PRODUCTION_SYSTEM) {
            continue;
        }

        for each(var locale : String in site.getAllowedLocales()) {
            if(locale != 'default') {
                var pageAction = new URLAction(requestPath, site.ID, locale);
                var url = URLUtils.abs(pageAction);
                locale = locale.toLowerCase().replace('_', '-');//hareflang tag must be separated by '-', for example: pt-br and not pt_br.
                urls.push( { "locale" : locale, "url" : url.toString() } );
            }
        }
    }

    Object.defineProperty(object, 'hreflangs', {
        enumerable: true,
        value: urls
    });
}