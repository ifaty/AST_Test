importPackage(dw.web);

module.exports = function (object, requestParameters) {
    var URLUtils = require('dw/web/URLUtils');
    var params = [];
    for each(var param in requestParameters.parameterNames) {
        if(requestParameters[param] != 'root') {
            params.push(param);
            params.push(requestParameters[param].value);
        }
    }

    var urlCanonical = URLUtils.http('Search-Show', params).toString();

    Object.defineProperty(object, 'urlCanonical', {
        enumerable: true,
        value: urlCanonical
    });
}