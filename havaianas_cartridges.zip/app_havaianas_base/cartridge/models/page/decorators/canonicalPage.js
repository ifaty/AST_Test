importPackage(dw.web);

module.exports = function (object, pageId) {
    var PageMgr = require('dw/experience/PageMgr');
    var URLUtils = require('dw/web/URLUtils');
    
    var page = PageMgr.getPage(pageId);
    var urlCanonical = '';

    if (page.typeID == 'story' || page.typeID == 'storyShopMode') {
        urlCanonical = URLUtils.http('Page-Show','cid', pageId).toString();
    }

    Object.defineProperty(object, 'urlCanonical', {
        enumerable: true,
        value: urlCanonical
    });
}