'use strict';

module.exports = {
    hreflangProduct: require('*/cartridge/models/page/decorators/hreflangProduct'),
    hreflangCategory: require('*/cartridge/models/page/decorators/hreflangCategory'),
    hreflangPageDesigner: require('*/cartridge/models/page/decorators/hreflangPageDesigner'),
    hreflangPageDefault: require('*/cartridge/models/page/decorators/hreflangPageDefault'),
    canonicalProduct: require('*/cartridge/models/page/decorators/canonicalProduct'),
    canonicalHome: require('*/cartridge/models/page/decorators/canonicalHome'),
    canonicalPage: require('*/cartridge/models/page/decorators/canonicalPage'),
    canonicalCategory: require('*/cartridge/models/page/decorators/canonicalCategory'),
    canonicalViewAll: require('*/cartridge/models/page/decorators/canonicalViewAll'),
}