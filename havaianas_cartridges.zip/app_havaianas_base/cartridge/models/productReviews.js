'use strict';

/**
 * STUB FUNCTION - JUST PREVENTS CORE FROM BREAKING.
 * @param {pid}
 * @returns {ProductReviews}
 */

function getReviews(pid){
    return [];
}

/**
 * STUB FUNCTION - JUST PREVENTS CORE FROM BREAKING.
 * @param {pid}
 * @returns {ProductReviews}
 */

function getHistogram(pid){
    return {};

};

module.exports = {
    getReviews : getReviews,
    getHistogram : getHistogram
}