'use strict';

var ShippingMgr = require('dw/order/ShippingMgr');

/**
 * Returns shippingCost property for a specific Shipment / ShippingMethod pair
 * @param {dw.order.ShippingMethod} shippingMethod - the default shipment of the current basket
 * @param {dw.order.Shipment} shipment - a shipment of the current basket
 * @returns {string} String representation of Shipping Cost without currency
 */
function getShippingCostWithoutCurrency(shippingMethod, shipment) {
    var shipmentShippingModel = ShippingMgr.getShipmentShippingModel(shipment);
    var shippingCost = shipmentShippingModel.getShippingCost(shippingMethod);

    return shippingCost.amount.value;
}

module.exports = function(shippingMethodModel, shippingMethod, shipment) {
    Object.defineProperty(shippingMethodModel, 'shippingCostWithoutCurrency', {
        enumerable: true,
        value: getShippingCostWithoutCurrency(shippingMethod, shipment)
    });
}