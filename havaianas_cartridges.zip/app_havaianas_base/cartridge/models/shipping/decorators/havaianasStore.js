'use strict';


module.exports = function(shippingMethodModel) {
    var shippingHelpers = require('*/cartridge/scripts/checkout/shippingHelpers');
    Object.defineProperty(shippingMethodModel, 'store', {
        enumerable: true,
        value: shippingHelpers.getStoreFromShippingMethod(shippingMethodModel)
    });
}