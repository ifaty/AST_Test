'use strict';

module.exports = {
    havaianasStore: require('*/cartridge/models/shipping/decorators/havaianasStore'),
    shippingCostWithoutCurrency: require('*/cartridge/models/shipping/decorators/shippingCostWithoutCurrency')
}