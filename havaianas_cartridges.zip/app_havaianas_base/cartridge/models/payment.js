'use strict';

var paymentBase = module.superModule;

/**
 * Payment class that represents payment information for the current basket
 * @param {dw.order.Basket} currentBasket - the target Basket object
 * @param {dw.customer.Customer} currentCustomer - the associated Customer object
 * @param {string} countryCode - the associated Site countryCode
 * @constructor
 */
function Payment(currentBasket, currentCustomer, countryCode) {
    var Resource = require('dw/web/Resource');
    var { find } = require('*/cartridge/scripts/util/array');
    var { getFulFillGiftCertificateCode } = require('*/cartridge/scripts/helpers/couponHelper');

    var fulfillGiftCert = getFulFillGiftCertificateCode();
    var payment = new paymentBase(currentBasket, currentCustomer, countryCode);

    find(payment.selectedPaymentInstruments, function (paymentInstrument, index) {
        if (paymentInstrument.paymentMethod === 'GIFT_CERTIFICATE' &&
            paymentInstrument.giftCertificateCode === fulfillGiftCert)
            return payment.selectedPaymentInstruments[index].type = 
                Resource.msg('payment.type.voucher', 'order', null);
    });
    
    return payment;
}

module.exports = Payment;