'use strict';

var QueryString = require('server').querystring;
var collections = require('*/cartridge/scripts/util/collections');
var URLUtils = require('dw/web/URLUtils');

var ACTION_ENDPOINT = 'Search-Show';

/**
 * Get category url
 * @param {dw.catalog.Category} category - Current category
 * @returns {string} - Url of the category
 */
function getCategoryUrl(category, data) {
    var whitelistedParams = ['q', 'pmin', 'pmax', 'srule', 'preferences', 'pageId', 'onSale'];
    if (!data) {
        return category.custom && 'alternativeUrl' in category.custom && category.custom.alternativeUrl
            ? (category.custom.alternativeUrl.toString()).replace(/&amp;/g, '&')
            : URLUtils.url(ACTION_ENDPOINT, 'cgid', category.getID()).toString();;
    }
    var url = URLUtils.url(ACTION_ENDPOINT, 'cgid', category.getID()).toString();
    // This requires an absolute url
    //return urlHelper.appendQueryParams(url, data.split('&'));

    // Removing pagination params
    var querystring = new QueryString(data);
    Object.keys(querystring).forEach(function (e) {
        if (whitelistedParams.indexOf(e) === -1) {
            delete querystring[e];
        }
    });
    return url.indexOf('?') > -1 ? url + '&' + querystring.toString() : url + '?' + querystring.toString();
}

/**
 * Converts a given category from dw.catalog.Category to plain object
 * @param {dw.catalog.Category} category - A single category
 * @returns {Object} plain object that represents a category
 */
function categoryToObject(category, data, selectedCategoryInfo) {
    var searchHelper = require('*/cartridge/scripts/helpers/searchHelpers');
    if (!category.custom || !category.custom.showInMenu) {
        return null;
    }
    var selected = selectedCategoryInfo && selectedCategoryInfo.id === category.ID;
    var result = {
        name: category.getDisplayName(),
        url: selectedCategoryInfo && selectedCategoryInfo.id === category.ID ?
                    selectedCategoryInfo.url :
                    getCategoryUrl(category, data),
        id: category.ID,
        thumbnail: category.thumbnail ? category.thumbnail.getURL() : null,
        selected: selected
    };
    var subCategories = category.hasOnlineSubCategories() ?
        category.getOnlineSubCategories() : null;

    if (subCategories) {
        collections.forEach(subCategories, function (subcategory) {
            var converted = null;
            if (subcategory.hasOnlineProducts() || subcategory.hasOnlineSubCategories()) {
                converted = categoryToObject(subcategory, data, selectedCategoryInfo);
            }
            if (converted) {
                if (!result.subCategories) {
                    result.subCategories = [];
                }
                result.subCategories.push(converted);
            }
        });
        if (result.subCategories) {
            result.complexSubCategories = result.subCategories.some(function (item) {
                return !!item.subCategories;
            });
        }
    }

    return result;
}


/**
 * Represents a single category with all of it's children
 * @param {dw.util.ArrayList<dw.catalog.Category>} items - Top level categories
 * @constructor
 */
function categories(items, data, selectedCategoryInfo) {
    this.categories = [];
    collections.forEach(items, function (item) {
        if (item.custom && item.custom.showInMenu &&
                (item.hasOnlineProducts() || item.hasOnlineSubCategories())) {
            this.categories.push(categoryToObject(item, data, selectedCategoryInfo));
        }
    }, this);
}

module.exports = categories;
