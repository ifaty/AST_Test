'use strict'

/**
 * @constructor
 * @classdesc The lock model
 * @param {Object} sessionVariable - a session variable we'll use to store data
 */
function lock (sessionVariable) {
    this.variableName = sessionVariable;
    this.localValue = session.custom[sessionVariable];
}

lock.prototype.wait = function () {
    var t1 = Date.now();
    var hadToWait = false;
    var timeout = false;
    while (this.localValue > 1) {
        hadToWait = true;
        this.localValue = session.custom[this.variableName];
        if (Date.now() - t1 > 1000) { // Beware the magic number, most of the time we end up timing out...
            timeout = true;
            break;
        }
    };
    // We return whether or not we had to wait.
    return hadToWait;
}

lock.prototype.isReady = function () {
    return this.localValue == 1;
}

lock.prototype.signal = function (i) {
    var Transaction = require('dw/system/Transaction');
    Transaction.begin();
    session.custom[this.variableName] = (session.custom[this.variableName] || 0) + i;
    this.localValue = session.custom[this.variableName];
    Transaction.commit();
}

module.exports = lock;