'use strict';

function StoreDetails (store, geolocation) {
    var URLUtils = require('dw/web/URLUtils');
    var Store = require('*/cartridge/models/store');
    var storeModel = new Store(store);

    this.name = storeModel.getName();
    this.rating = storeModel.getRating();
    this.distance = storeModel.calculateDistance(geolocation);
    this.address = storeModel.getAddress();
    this.phone = storeModel.getPhone();
    this.openPeriods = storeModel.getDisplayOpenPeriods();
    this.availableMerchandize = storeModel.getAvailableMerchandize();
    this.directUrl = URLUtils.url('Stores-Store', 'id', storeModel.getID());
    this.marker = storeModel.getMarker();
}

module.exports = StoreDetails