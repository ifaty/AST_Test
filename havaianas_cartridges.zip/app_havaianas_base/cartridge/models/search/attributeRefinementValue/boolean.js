'use strict';

var BaseAttributeValue = require('*/cartridge/models/search/attributeRefinementValue/base');
var Resource = require('dw/web/Resource');

var COLOR_ATTRIBUTE_ID = 'hav_colorset';

/**
 * @constructor
 * @classdesc Boolean attribute refinement value model
 *
 * @param {dw.catalog.ProductSearchModel} productSearch - ProductSearchModel instance
 * @param {dw.catalog.ProductSearchRefinementDefinition} refinementDefinition - Refinement
 *     definition
 * @param {dw.catalog.ProductSearchRefinementValue} refinementValue - Raw DW refinement value
 */
function BooleanAttributeValue(productSearch, refinementDefinition, refinementValue, pageId) {
    this.productSearch = productSearch;
    this.refinementDefinition = refinementDefinition;
    this.refinementValue = refinementValue;
    this.pageId = pageId;

    this.initialize();
}

BooleanAttributeValue.prototype = Object.create(BaseAttributeValue.prototype);

BooleanAttributeValue.prototype.initialize = function () {
    BaseAttributeValue.prototype.initialize.call(this);

    this.type = 'boolean';
    this.displayValue = this.getDisplayValue(
        this.refinementDefinition.attributeID,
        this.refinementValue.displayValue
    );
    this.selected = this.isSelected(
        this.productSearch,
        this.refinementDefinition.attributeID,
        this.refinementValue.value
    );
    this.url = this.getUrl(
        this.productSearch,
        this.actionEndpoint,
        this.id,
        this.value,
        this.selected,
        this.selectable,
        this.pageId
    );
    this.title = this.getTitle(
        this.selected,
        this.selectable,
        this.refinementDefinition.displayName,
        this.displayValue
    );
    this.isColorRefinement = this.isColorRefinement(this.refinementDefinition.attributeID);
    this.rainbowColor = this.isColorRefinement ? this.getColorObject(this.refinementValue.value) : this.refinementValue.value;
};

BooleanAttributeValue.prototype.getDisplayValue = function (attributeID, displayValue) {
    return Resource.msg(
        ['label.refinement', attributeID, displayValue].join('.'),
        'search',
        displayValue
    );
};

BooleanAttributeValue.prototype.isColorRefinement = function (attributeID) {
    return attributeID == COLOR_ATTRIBUTE_ID;
};

BooleanAttributeValue.prototype.getColorObject = function (colorValue) {
    var { getRainbowValue } = require('*/cartridge/scripts/helpers/rainbowHelper');
    return getRainbowValue(colorValue, 'dark');
};

/**
 * @constructor
 * @classdesc Boolean attribute refinement value model
 *
 * @param {dw.catalog.ProductSearchModel} productSearch - ProductSearchModel instance
 * @param {dw.catalog.ProductSearchRefinementDefinition} refinementDefinition - Refinement
 *     definition
 * @param {dw.catalog.ProductSearchRefinementValue} refinementValue - Raw DW refinement value
 */
function BooleanRefinementValueWrapper(productSearch, refinementDefinition, refinementValue, pageId) {
    var value = new BooleanAttributeValue(
        productSearch,
        refinementDefinition,
        refinementValue,
        pageId
    );
    var items = [
        'id',
        'type',
        'displayValue',
        'selected',
        'selectable',
        'title',
        'url',
        'rainbowColor',
        'isColorRefinement'
    ];
    items.forEach(function (item) {
        this[item] = value[item];
    }, this);
}

module.exports = BooleanRefinementValueWrapper;
