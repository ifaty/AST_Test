'use strict';

var BaseAttributeValue = require('*/cartridge/models/search/attributeRefinementValue/base');
var URLUtils = require('dw/web/URLUtils');

var ACTION_ENDPOINT = 'Search-Show';

/**
 * @constructor
 * @classdesc Category attribute refinement value model
 *
 * @param {dw.catalog.ProductSearchModel} productSearch - ProductSearchModel instance
 * @param {dw.catalog.ProductSearchRefinementDefinition} refinementDefinition - Refinement
 *     definition
 * @param {dw.catalog.ProductSearchRefinementValue} refinementValue - Raw DW refinement value
 * @param {boolean} selected - Selected flag
 */
function CategoryAttributeValue(productSearch, refinementDefinition, refinementValue, selected, pageId) {
    this.productSearch = productSearch;
    this.refinementDefinition = refinementDefinition;
    this.refinementValue = refinementValue;
    this.subCategories = [];
    this.selected = selected;
    this.pageId = pageId;

    this.initialize();
}

CategoryAttributeValue.prototype = Object.create(BaseAttributeValue.prototype);

CategoryAttributeValue.prototype.initialize = function () {
    this.type = 'category';
    this.selectable = true;
    this.id = this.refinementValue.ID;
    this.actionEndpoint = ACTION_ENDPOINT;

    this.displayValue = this.refinementValue.displayName;

    this.url = this.getUrl(
        this.productSearch,
        this.actionEndpoint,
        this.id,
        this.value,
        this.selected,
        this.selectable,
        this.pageId
    );
    this.title = this.getTitle(
        this.selected,
        this.selectable,
        this.refinementDefinition.displayName,
        this.displayValue
    );
    this.thumbnail = this.getThumbnail(
        this.refinementValue
    )
};

CategoryAttributeValue.prototype.getUrl = function (
    productSearch,
    actionEndpoint,
    id,
    value,
    selected) {
    var url = '';

    if (selected) {
        if (productSearch.category && productSearch.category.parent) {
            url = URLUtils.url(ACTION_ENDPOINT, 'cgid', productSearch.category.parent.ID).toString();
        } else {
            url = URLUtils.url(ACTION_ENDPOINT, 'cgid', id).toString();
        }
    } else {
        url = URLUtils.url(ACTION_ENDPOINT, 'cgid', id).toString();
    }

    return url;
};

CategoryAttributeValue.prototype.getThumbnail = function (value) {
    return value.thumbnail ? value.thumbnail.getURL().toString() : null;
};

/**
 * @constructor
 * @classdesc Category attribute refinement value model
 *
 * @param {dw.catalog.ProductSearchModel} productSearch - ProductSearchModel instance
 * @param {dw.catalog.ProductSearchRefinementDefinition} refinementDefinition - Refinement
 *     definition
 * @param {dw.catalog.ProductSearchRefinementValue} refinementValue - Raw DW refinement value
 * @param {boolean} selected - Selected flag
 */
function CategoryRefinementValueWrapper(
    productSearch,
    refinementDefinition,
    refinementValue,
    selected,
    pageId) {
    var value = new CategoryAttributeValue(
        productSearch,
        refinementDefinition,
        refinementValue,
        selected,
        pageId
    );
    var items = [
        'id',
        'type',
        'displayValue',
        'selected',
        'selectable',
        'title',
        'url',
        'subCategories',
        'thumbnail'
    ];
    items.forEach(function (item) {
        this[item] = value[item];
    }, this);
}

module.exports = CategoryRefinementValueWrapper;
