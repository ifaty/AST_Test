'use strict';

var URLUtils = require('dw/web/URLUtils');
var endpoint = 'Search-Show';
var extraAttrs = ['hav_colorset', 'size', 'hav_gender', 'hav_age', 'hav_family'];
var collections = require('*/cartridge/scripts/util/collections');

var ProductSearchModel = require('dw/catalog/ProductSearchModel');
var SearchRefinements = require('dw/catalog/SearchRefinements');
var ProductSuggestion= require('*/cartridge/models/product/productSuggestion');

/**
 * @constructor
 * @classdesc ShopSuggestions class
 *
 * @param {dw.suggest.SuggestModel} suggestions - Suggest Model
 * @param {number} maxItems - Maximum number of shop tags to retrieve
 */
function ShopSuggestions(suggestions, maxItems, searchQuery) {
    var imageHelper = require('*/cartridge/scripts/helpers/imageHelper');
    this.shopTags = [];

    if (!suggestions.categorySuggestions) {
        return;
    }

    var categorySuggestions = suggestions.categorySuggestions;
    var iter = categorySuggestions.suggestedCategories;

    this.available = categorySuggestions.hasSuggestions();

    for (var i = 0; i < maxItems; i++) {
        var category = null;

        if (iter.hasNext()) {
            category = iter.next().category;
            if (category.getProducts().length) {
                var productChosen;
                var productConfigured = category.custom.hav_searchFeaturedProductID;
                if (productConfigured) {
                    var CatalogMgr = require('dw/catalog/CatalogMgr');
                    productChosen = CatalogMgr.getProduct(productConfigured)
                } else {
                    productChosen = category.getProducts()[0];
                }

                var productSuggestion = ProductSuggestion(Object.create(null), productChosen);

                this.shopTags.push({
                    heroImageUrl: productSuggestion.heroImages.count > 0 ? productSuggestion.heroImages.items[0].src : null,
                    productId: productChosen.getID(),
                    name: category.displayName,
                    imageUrl: category.image ? imageHelper.getScaledImage(category.image, 'shop').src : '',
                    url: URLUtils.url(endpoint, 'cgid', category.ID)
                });
            }
        }
    }

    var productSuggestions = suggestions.productSuggestions;
    var iter = productSuggestions.suggestedProducts;

    var product = null;
    var productIds = [];
    for (var i = 0; i < maxItems && this.shopTags.length < maxItems; i++) {

        if (iter.hasNext()) {
            product = iter.next().getProductSearchHit().getProduct();
            var productVariationModel = product.variationModel;
            if (!product.variationGroup) {
                if (!productVariationModel.variationGroups.empty) {
                    product = productVariationModel.variationGroups[0];
                }
                else {
                    break;
                }
            }
            if (productIds.indexOf(product.getID()) > -1) {
                break;
            }
            var productModel = ProductSuggestion(Object.create(null), product);

            this.shopTags.push({
                heroImageUrl: productModel.heroImages.count > 0 ? productModel.heroImages.items[0].src : '',
                productId: product.getID(),
                name: product.name,
                imageUrl: productModel.shopImages.count > 0 ? productModel.shopImages.items[0].src : '',
                url: URLUtils.url('Product-Show', 'pid', product.getID())
            });

            var psm = new ProductSearchModel();
            psm.setSearchPhrase(searchQuery);
            psm.search();
            for (var i = 0, len = extraAttrs.length; i < len; i++) {
                var searchRefinementValues = psm.getRefinements().getRefinementValues(extraAttrs[i], SearchRefinements.SORT_VALUE_COUNT, SearchRefinements.DESCENDING);
                var count = 0;
                collections.forEach(searchRefinementValues, function (e) {
                    if (count >= maxItems) {
                        return;
                    }
                    count++;
                    if (e.displayValue.toLowerCase().indexOf(searchQuery) > -1) {
                        this.shopTags.push(createAttributeTag(extraAttrs[i], e));
                    }
                }, this)
            }

            productIds.push(product.getID());
        }
    }

    this.available = (categorySuggestions.hasSuggestions() || productSuggestions.hasSuggestions()) && this.shopTags.length > 0;
}

function createAttributeTag(attribute, searchRefinementValue) {
    var psm = new ProductSearchModel();
    try {
        var obj = {
            heroImageUrl: '',
            name: searchRefinementValue.displayValue,
            imageUrl: '',
            url: psm.urlForRefine(endpoint, attribute, searchRefinementValue.value)
        };
        return obj;
    } catch (e) {
        var a = e;
        var b = 1;
    }
}

module.exports = ShopSuggestions;
