'use strict';

/**
 * A function that accepts up to three arguments.
 * Similar to the filter method, calls the callbackfn function one time for each element in the array.
 * 
 * Returns the elements of an array that meets with the condition in the callbackfn and while it does not
 * exceed the limit of returned items.
 * @param {Array} array 
 * @param {Function} callback 
 * @param {[Number]} limit - especifies how many items it is allowed to return.
 */
function filterWhile (array, callbackfn, limit) {
    if (!limit || limit > array.length)
        limit = array.length;

    var result = [];
    var itemsYield = 0;
    for (var i = 0; i < array.length && itemsYield <= limit; ++i) {
        if (callbackfn(array[i])) {
            result.push(array[i]);
            itemsYield++;
        }
    }

    return result;
}

/**
 * @constructor
 * @classdesc DiscoverySuggestions class
 *
 * @param {String} query - Suggest Query
 * @param {number} maxItems - Maximum number of content items to retrieve, if none is supplied, it uses
 * the defined max suggestions site preference.
 */
function DiscoverySuggestions(query, maxItems) {
    var URLUtils        = require('dw/web/URLUtils');
    var PageMgr         = require('dw/experience/PageMgr');
    var storyHelper     = require('*/cartridge/scripts/helpers/storyHelper');
    var queryRegex      = new RegExp("\\b(\\w*" + query + "\\w*)\\b", "gi");

    var stories = storyHelper.getStorySettings().stories;
    var storyIDs = Object.getOwnPropertyNames(stories || {});

    if (!storyIDs.length || !query || !maxItems) {
        this.available = false;
        return null;
    }

    var storyMatches = filterWhile(storyIDs,
        function(storyId) {
            var storyObject = PageMgr.getPage(storyId);
            if (storyObject && storyObject.visible) {
                var storyDisplayName = storyObject.getName();
                if (storyDisplayName.match(queryRegex)) {
                    stories[storyId].displayName = storyDisplayName;
                    return true;
                }
            }
        }, maxItems);

    storyMatches = storyMatches.map(function(storyId) {
        var story = stories[storyId];
        return {
            name: story.displayName,
            icon: story.searchIcon,
            background: story.searchBackground,
            storyId: storyId,
            url: URLUtils.url('Page-Show', 'cid', storyId).toString()
        }
    });


    this.stories = storyMatches || [];
    this.available = storyMatches.length ? true : false;
}

module.exports = DiscoverySuggestions;
