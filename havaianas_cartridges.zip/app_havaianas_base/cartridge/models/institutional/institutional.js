'use strict';
const Resource = require('dw/web/Resource');

function parseContactForm(contactForm) {
    return {
        name: {
            value: contactForm.name.htmlValue,
            label: contactForm.name.label
        },
        dob: {
            value: contactForm.dob.htmlValue,
            label: contactForm.dob.label
        },
        gender: {
            value: contactForm.gender.htmlValue,
            label: contactForm.gender.label
        },
        zipcode: {
            value: contactForm.zipcode.htmlValue,
            label: contactForm.zipcode.label
        },
        street: {
            value: contactForm.street.htmlValue,
            label: contactForm.street.label
        },
        complement: {
            value: contactForm.complement.htmlValue,
            label: contactForm.complement.label
        },
        neighborhood: {
            value: contactForm.neighborhood.htmlValue,
            label: contactForm.neighborhood.label
        },
        city: {
            value: contactForm.city.htmlValue,
            label: contactForm.city.label
        },
        state: {
            value: contactForm.state.htmlValue,
            label: contactForm.state.label
        },
        phone: {
            value: contactForm.phone.htmlValue,
            label: contactForm.phone.label
        },
        email: {
            value: contactForm.email.htmlValue,
            label: contactForm.email.label
        },
        subject: {
            value: contactForm.subject.htmlValue,
            label: contactForm.subject.label
        },
        message: {
            value: contactForm.message.htmlValue,
            label: contactForm.message.label
        }
    };
}

function parseFranchiseeForm(franchiseeForm) {
    return {
        businessState: {
            label: franchiseeForm.businessState.label,
            value: franchiseeForm.businessState.htmlValue
        },
        businessCity: {
            label: franchiseeForm.businessCity.label,
            value: franchiseeForm.businessCity.htmlValue
        },
        name: {
            label: franchiseeForm.name.label,
            value: franchiseeForm.name.htmlValue
        },
        dob: {
            label: franchiseeForm.dob.label,
            value: franchiseeForm.dob.htmlValue
        },
        gender: {
            label: franchiseeForm.gender.label,
            value: Resource.msg(franchiseeForm.gender.htmlValue, 'forms', null),
        },
        zipcode: {
            label: franchiseeForm.zipcode.label,
            value: franchiseeForm.zipcode.htmlValue
        },
        street: {
            label: franchiseeForm.street.label,
            value: franchiseeForm.street.htmlValue
        },
        complement: {
            label: franchiseeForm.complement.label,
            value: franchiseeForm.complement.htmlValue
        },
        neighborhood: {
            label: franchiseeForm.neighborhood.label,
            value: franchiseeForm.neighborhood.htmlValue
        },
        city: {
            label: franchiseeForm.city.label,
            value: franchiseeForm.city.htmlValue
        },
        state: {
            label: franchiseeForm.state.label,
            value: franchiseeForm.state.htmlValue
        },
        phone: {
            label: franchiseeForm.phone.label,
            value: franchiseeForm.phone.htmlValue
        },
        email: {
            label: franchiseeForm.email.label,
            value: franchiseeForm.email.htmlValue
        },
        schooling: {
            label: franchiseeForm.schooling.label,
            value: Resource.msg(franchiseeForm.schooling.htmlValue, 'forms', null)
        },
        knowledge: {
            label: franchiseeForm.knowledge.label,
            value: Resource.msg(franchiseeForm.knowledge.htmlValue, 'forms', null)
        },
        professional: {
            label: franchiseeForm.professional.label,
            value: Resource.msg(franchiseeForm.professional.htmlValue, 'forms', null)
        },
        businessOwner: {
            label: franchiseeForm.businessOwner.label,
            value: Resource.msg(franchiseeForm.businessOwner.htmlValue, 'forms', null)
        },
        businessExperience: {
            label: franchiseeForm.businessExperience.label,
            value: Resource.msg(franchiseeForm.businessExperience.htmlValue, 'forms', null)
        },
        howFound: {
            label: franchiseeForm.howFound.label,
            value: Resource.msg(franchiseeForm.howFound.htmlValue, 'forms', null)
        },
        availability: {
            label: franchiseeForm.availability.label,
            value: franchiseeForm.availability.label === 'true' ? Resource.msg('label.boolean.true', 'forms', null) : Resource.msg('label.boolean.false', 'forms', null),
        },
        searchingBusinesses: {
            label: franchiseeForm.searchingBusinesses.label,
            value: franchiseeForm.searchingBusinesses.htmlValue === 'true' ? Resource.msg('label.boolean.true', 'forms', null) : Resource.msg('label.boolean.false', 'forms', null),
        },
        partners: {
            label: franchiseeForm.partners.label,
            value: franchiseeForm.partners.htmlValue === 'true' ? Resource.msg('label.boolean.true', 'forms', null) : Resource.msg('label.boolean.false', 'forms', null),
        },
        employeeRelated: {
            label: franchiseeForm.employeeRelated.label,
            value: franchiseeForm.employeeRelated.htmlValue === 'true' ? Resource.msg('label.boolean.true', 'forms', null) : Resource.msg('label.boolean.false', 'forms', null),
        },
        trueInformation: {
            label: franchiseeForm.trueInformation.label,
            value: franchiseeForm.trueInformation.htmlValue === 'true' ? Resource.msg('label.boolean.true', 'forms', null) : Resource.msg('label.boolean.false', 'forms', null),
        },
        termsAndConditions: {
            label: franchiseeForm.termsAndConditions.label,
            value: franchiseeForm.termsAndConditions.htmlValue === 'true' ? Resource.msg('label.boolean.true', 'forms', null) : Resource.msg('label.boolean.false', 'forms', null),
        }
    };
}

function parseBecomeDealerForm(becomeDealerForm) {
    return {
        country: {
            value: becomeDealerForm.country.htmlValue,
            label: becomeDealerForm.country.label
        },
        cnpj: {
            value: becomeDealerForm.cnpj.htmlValue,
            label: becomeDealerForm.cnpj.label
        },
        companyName: {
            value: becomeDealerForm.companyName.htmlValue,
            label: becomeDealerForm.companyName.label
        },
        purchaseIntention: {
            value: becomeDealerForm.purchaseIntention.htmlValue,
            label: becomeDealerForm.purchaseIntention.label
        },
        companyOwner: {
            value: becomeDealerForm.companyOwner.htmlValue,
            label: becomeDealerForm.companyOwner.label
        },
        zipcode: {
            value: becomeDealerForm.zipcode.htmlValue,
            label: becomeDealerForm.zipcode.label
        },
        street: {
            value: becomeDealerForm.street.htmlValue,
            label: becomeDealerForm.street.label
        },
        complement: {
            value: becomeDealerForm.complement.htmlValue,
            label: becomeDealerForm.complement.label
        },
        neighborhood: {
            value: becomeDealerForm.neighborhood.htmlValue,
            label: becomeDealerForm.neighborhood.label
        },
        city: {
            value: becomeDealerForm.city.htmlValue,
            label: becomeDealerForm.city.label
        },
        state: {
            value: becomeDealerForm.state.htmlValue,
            label: becomeDealerForm.state.label
        },
        phone: {
            value: becomeDealerForm.phone.htmlValue,
            label: becomeDealerForm.phone.label
        },
        email: {
            value: becomeDealerForm.email.htmlValue,
            label: becomeDealerForm.email.label
        },
        activityBranch: {
            value: becomeDealerForm.activityBranch.htmlValue,
            label: becomeDealerForm.activityBranch.label
        },
        storeCount: {
            value: becomeDealerForm.storeCount.htmlValue,
            label: becomeDealerForm.storeCount.label
        },
        brands: {
            value: becomeDealerForm.brands.htmlValue,
            label: becomeDealerForm.brands.label
        },
        additionalInfo: {
            value: becomeDealerForm.additionalInfo.htmlValue,
            label: becomeDealerForm.additionalInfo.label
        },
        applicantDeclaration: {
            value: becomeDealerForm.applicantDeclaration.htmlValue,
            label: becomeDealerForm.applicantDeclaration.label
        },
        termsAndConditions: {
            value: becomeDealerForm.termsAndConditions.htmlValue,
            label: becomeDealerForm.termsAndConditions.label
        }
    };
}

module.exports = {
    parseContactForm: parseContactForm,
    parseFranchiseeForm: parseFranchiseeForm,
    parseBecomeDealerForm: parseBecomeDealerForm
};
