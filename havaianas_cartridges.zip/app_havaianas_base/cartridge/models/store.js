'use strict'

var storeModelBase = module.superModule;

/**
 * @constructor
 * @classdesc The stores model
 * @param {dw.catalog.Store} storeObject - a Store objects
 */
function store (apiObject) {
    if (!(apiObject instanceof dw.catalog.Store))
        throw new TypeError('invalid store argument');

    storeModelBase.call(this, apiObject);

    this.apiStore = apiObject;
    try {
        this.openPeriods = JSON.parse(apiObject.custom.openPeriods);
    } catch (e) {
        this.openPeriods = {};
    }
}

store.prototype = storeModelBase.prototype;

/**
 * Returns the dw.catalog.Store associated with this model.
 * @returns {dw.catalog.Store}
 */
store.prototype.getAPIObject = function () {
    return this.apiStore;
}

/**
 * Returns the store ID.
 * @returns {String}
 */
store.prototype.getID = function () {
    return this.getAPIObject().getID();
};

/**
 * Returns the store external ID.
 * @returns {String}
 */
store.prototype.getExternalID = function () {
    return this.getAPIObject().custom.externalId;
};

/**
 * Returns the name of the store.
 * @returns {String}
 */
store.prototype.getName = function () {
    return this.name;
};

store.prototype.getType = function () {
    return (this.getAPIObject().custom.storeType || 'store').toLowerCase();
}

/**
 * Returns the rating of the store.
 * @returns {String}
 */
store.prototype.getRating = function () {
    return this.getAPIObject().custom.rating || '-';
};

/**
 * Returns the phone of the store.
 * @returns {String}
 */
store.prototype.getPhone = function () {
    return this.phone;
};

/**
 * Returns the address of the store.
 *
 * @returns {Object} { value, html, getValue(), getHTML() }
 */
store.prototype.getAddress = function () {
    return {
        value: this.getAPIObject().address1,
        html: this.getAPIObject().custom.storeAddressHTML,
        /**
         * Returns the formatted address with HTML semantics
         * @returns {string}
         */
        getHTML: function () {
            return this.html;
        },
        /**
         * Returns the formatted address
         * @returns {string}
         */
        getValue: function () {
            return this.value;
        }
    };
}

/**
 * Returns the city of the store
 * @returns {String}
 */
store.prototype.getCity = function () {
    return this.city;
}

/**
 * Returns the state code of the store
 * @param {String}
 */
store.prototype.getStateCode = function () {
    return this.stateCode;
}

/**
 * Returns the locality of the store.
 * This is used for indexing purposes.
 * @param {String}
 */
store.prototype.getLocality = function () {
    return this.stateCode;
}

/**
 * Returns the sublocality of the store
 * @param {String}
 */
store.prototype.getSublocality = function () {
    return this.address2;
}

/**
 * Returns the store available merchandize.
 * @returns {Array}
 */
store.prototype.getAvailableMerchandize = function () {
    var Site = require('dw/system/Site');
    var definedMerchandizes = JSON.parse(Site.getCurrent().getCustomPreferenceValue('StoreMerchandizeProperties') || '{}');
    var storeClientProperties = Object.getOwnPropertyNames(definedMerchandizes);
    var properties = this.getAPIObject().custom;

    return storeClientProperties.filter(function (merchandize) {
        var internalValue = definedMerchandizes[merchandize];
        return properties[internalValue] === true;
    });
}

/**
 * Returns the today's store open period.
 * @returns {Object}
 */
store.prototype.getTodayOpenPeriod = function () {
    var now = new Date()
    var today = now.getDay();

    var storeOpenPeriods = this.getOpenPeriods();

    if (empty(storeOpenPeriods))
        return null;

    var todayOpenPeriod = storeOpenPeriods[today];

    return todayOpenPeriod;
};

/**
 * Checks if the store is currently open.
 * @returns {String}
 */
store.prototype.isOpen = function () {
    var hour = now.getHours() * 100 + now.getMinutes();

    var todayOpenPeriod = this.getTodayOpenPeriod();

    if (!todayOpenPeriod)
        return false;

    return hour >= todayOpenPeriod[0] && hour <= todayOpenPeriod[1];
};

/**
 * Returns the open periods of the store.
 * @returns {Object}
 */
store.prototype.getOpenPeriods = function () {
    try {
        return this.openPeriods;
    } catch (e) {
        return {};
    }
}

/**
 * Returns the open periods of the store.
 * @returns {Object}
 */
store.prototype.getDisplayOpenPeriods = function () {
    try {
        return JSON.parse(this.getAPIObject().custom.displayOpenPeriods || 'null')
    } catch (e) {
        return {};
    }
}

/**
 *  Returns the geolocation coordinates of the store
 *  @returns {Object} { latitude<Number>, longitude<Number> }
 */
store.prototype.getGeolocation = function () {
    return {
        latitude: this.getAPIObject().latitude,
        longitude: this.getAPIObject().longitude
    }
}

/**
 * Returns marker to be used in find a store page
 * @returns {Object} { id<Number>, geolocation: { latitude<Number>, longitude<Number> }, type<String>}
 */
store.prototype.getMarker = function () {
    return JSON.stringify({
        id: this.getID(),
        geolocation: this.getGeolocation(),
        type: this.getType()
    });
}


/**
 * Calculates the distance in meters between the store geolocation
 * and the supplied geolocation.
 * @param {Object} { latitude, longitude }
 * @returns {Object} { displayValue<String>, value<Number> }
 */
store.prototype.calculateDistance = function (geolocation) {
    var Site = require('dw/system/Site');
    var distanceUnit = Site.getCurrent().getCustomPreferenceValue('hav_distanceUnit').getValue();

    var { calculateDistance } = require('*/cartridge/scripts/helpers/locationHelper');
    var storeGeolocation = this.getGeolocation();

    var distanceInMeters = calculateDistance(geolocation, storeGeolocation);

    var result;
    if (distanceUnit === 'km') {
        result = distanceInMeters / 1000;
        result = result.toFixed(1) + ' km';
    } else {
        result = distanceInMeters / 1609;
        result = result.toFixed(1) + ' mi';
    }

    return {
        displayValue: result,
        value: distanceInMeters
    };
}

module.exports = store;
