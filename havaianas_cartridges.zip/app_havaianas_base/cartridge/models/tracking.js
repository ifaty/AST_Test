'use strict';

function getOrderFinalStatuses () {
    var Order = require('dw/order/Order');
    return [
        Order.ORDER_STATUS_COMPLETED,
        Order.ORDER_STATUS_CANCELLED,
        Order.ORDER_STATUS_FAILED,
        Order.ORDER_STATUS_REPLACED
    ];
}

function getInitialTimelineStructure (order) {
    var orderShipments = order.getShipments();

}

function TrackingModel (order) {
    var Order = require('dw/order/Order');
    var orderStatus = order.getStatus();
    this.timeline;
}