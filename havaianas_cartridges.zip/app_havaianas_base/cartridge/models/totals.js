'use strict';

var totalsBase = module.superModule;
var formatMoney = require('dw/util/StringUtils').formatMoney;
var couponHelper = require('*/cartridge/scripts/helpers/couponHelper');

/**
 * Accepts a total object and formats the value
 * @param {dw.value.Money} total - Total price of the cart
 * @returns {string} the formatted money value
 */
function getTotals(total) {
    return !total.available ? '-' : formatMoney(total);
}

/**
 * Gets the order discount amount by subtracting the basket's total including the discount from
 *      the basket's total excluding the order discount.
 * @param {dw.order.LineItemCtnr} lineItemContainer - Current users's basket
 * @returns {Object} an object that contains the value and formatted value of the order discount
 */
function getOrderLevelDiscountTotal(lineItemContainer) {
    var Money = require('dw/value/Money');

    var totalExcludingOrderDiscount = lineItemContainer.getAdjustedMerchandizeTotalPrice(false);
    var totalIncludingOrderDiscount = lineItemContainer.getAdjustedMerchandizeTotalPrice(true);
    var orderDiscount = totalExcludingOrderDiscount.subtract(totalIncludingOrderDiscount);

    var externalCoupon = couponHelper.getExternalCouponLineItem(lineItemContainer);
    if (externalCoupon) {
        var couponDiscount = externalCoupon.getPriceAdjustments().toArray()
            .reduce(function (acc, priceAdjustment) {
                return acc.add(priceAdjustment.getPrice());
            }, new Money(0, session.getCurrency()));

        orderDiscount = orderDiscount.add(couponDiscount);
    }

    return {
        value: orderDiscount.value,
        formatted: formatMoney(orderDiscount)
    };
}


function getGrandTotal (lineItemCtnr) {        
    var appliedGiftCertificate = couponHelper.getCouponAppliedGiftCertificate(lineItemCtnr);
    var totalGrossPrice = lineItemCtnr.getTotalGrossPrice();
    if (appliedGiftCertificate) {
        totalGrossPrice = couponHelper.getMoneyFormattedValue(0);
    } else if (totalGrossPrice.getValue() === 0) {
        totalGrossPrice = '-'
    } else {
        totalGrossPrice = totalGrossPrice.toFormattedString()
    }

    return totalGrossPrice;
}

function getItensTotal (lineItemCtnr) {        
    var Money = require('dw/value/Money');
    var sessionCurrency = session.getCurrency();

    var lineItensTotal =
    lineItemCtnr
        .getAllProductLineItems()
        .toArray()
        .reduce(function (acc,productLineItem) {
            var product = productLineItem.getProduct();
            return acc.add(product ? product.getPriceModel().getPrice() : productLineItem.getAdjustedPrice());
            }, new Money(0, sessionCurrency));
        
        return  lineItensTotal.toFormattedString();        
}

function getCouponDiscountTotal(lineItemCtnr) {
    var Money = require('dw/value/Money');
    var sessionCurrency = session.getCurrency();

    var couponDiscountTotal =
        lineItemCtnr
            .getCouponLineItems()
            .toArray()
            .map(function (couponLineItem) {
                return couponLineItem.getPriceAdjustments().toArray()
                    .reduce(function (acc, priceAdjustment) {
                        return acc.add(priceAdjustment.getPrice());
                    }, new Money(0, sessionCurrency));
            })
            .reduce(function (acc, couponAppliedMoney) {
                return acc.add(couponAppliedMoney);
            }, new Money(0, sessionCurrency));

    var giftCertificate = couponHelper.getCouponAppliedGiftCertificate(lineItemCtnr);

    if (giftCertificate) {
        couponDiscountTotal = couponDiscountTotal.subtract(
            giftCertificate.getPaymentTransaction().getAmount()
        );
    }

    return {
        value: couponDiscountTotal.getValue(),
        formatted: couponDiscountTotal.toFormattedString()
    }
}

function totals (lineItemCtnr) {
    var totals = new totalsBase(lineItemCtnr);
    
    totals.grandTotal = getGrandTotal(lineItemCtnr);
    totals.couponDiscountTotal = getCouponDiscountTotal(lineItemCtnr);
    totals.subTotal = getTotals(lineItemCtnr.getAdjustedMerchandizeTotalPrice());
    totals.orderLevelDiscountTotal = getOrderLevelDiscountTotal(lineItemCtnr);
    totals.itensTotal = getItensTotal(lineItemCtnr);
    if(totals.shippingLevelDiscountTotal.value && lineItemCtnr.shippingPriceAdjustments.length > 0){
        var orderDiscounts = totals.orderLevelDiscountTotal;
        var shippingLevelDiscount = couponHelper.sumValues(orderDiscounts.value, totals.shippingLevelDiscountTotal.value)
        totals.orderLevelDiscountTotal.value = shippingLevelDiscount.get();
        totals.orderLevelDiscountTotal.formatted = couponHelper.getMoneyFormattedValue(shippingLevelDiscount);
    }

    return totals;
}

module.exports = totals;