'use strict';

var productHelpers = require('*/cartridge/scripts/helpers/productHelpers');

var ATTRIBUTE_NAME = "color";
var SIZE_ATTRIBUTE_ID = "size";
var productAttributeBase = module.superModule;

function getProcessedValues(processedValues, variationModel, endpoint, context) {
    var ImageModel = require('*/cartridge/models/product/productImages');
    var URLUtils = require('dw/web/URLUtils');
    var colorHelper = require('*/cartridge/scripts/helpers/colorMatrixHelper');
    var rainbowHelper = require('*/cartridge/scripts/helpers/rainbowHelper');
    var havaianasDecorators = require('*/cartridge/models/product/decorators/havaianasIndex');
    return processedValues.filter(function (value) {
        var variationByFilter = 
            productHelpers.getVariationGroupByFilter(variationModel, value.value);

        if (!variationByFilter || !variationByFilter.isOnline())
            return false;


        value.images = new ImageModel(variationByFilter, { });
        if (context != 'tile') {
            havaianasDecorators.transformedImages(value, variationByFilter, 'variation');
            value.imagesProduct = value.variationImages;
        }
        value.colorMatrix = colorHelper.getColorSpecification(
            variationByFilter.custom.hav_primaryColor || '',
            variationByFilter.custom.hav_primaryColorTone,
            variationByFilter.custom.hav_secondaryColor,
            variationByFilter.custom.hav_secondaryColorTone,
            {
                variationColor: context != 'tile'
            }
        );
        value.backgroundColor = value.colorMatrix.background;
        value.rainbowColor = rainbowHelper.getRainbowValue(variationByFilter.custom.hav_primaryColor, variationByFilter.custom.hav_primaryColorTone || 'regular');
        var fallbackTone = colorHelper.getFallbackTone(variationByFilter.custom.hav_primaryColorTone || 'regular');
        value.fallbackColor = rainbowHelper.getRainbowValue(variationByFilter.custom.hav_primaryColor, fallbackTone);
        value.availability = variationByFilter.getAvailabilityModel().isInStock();

        var route = 'Product-' + (endpoint || 'Show');
        route = route == 'Product-Variation' ? 'Product-Show' : route;

        value.url = URLUtils.url(
            route,
            'pid',
            variationByFilter.ID
        ).toString();
        
        return true;
    });
}

/**
 * @constructor
 * @classdesc Get a list of available attributes that matches provided config
 *
 * @param {dw.catalog.ProductVariationModel} variationModel - current product variation
 * @param {Object} attrConfig - attributes to select
 * @param {Array} attrConfig.attributes - an array of strings,representing the
 *                                        id's of product attributes.
 * @param {string} attrConfig.attributes - If this is a string and equal to '*' it signifies
 *                                         that all attributes should be returned.
 *                                         If the string is 'selected', then this is comming
 *                                         from something like a product line item, in that
 *                                         all the attributes have been selected.
 *
 * @param {string} attrConfig.endPoint - the endpoint to use when generating urls for
 *                                       product attributes
 * @param {string} selectedOptionsQueryParams - Selected options query params
 * @param {string} quantity - Quantity selected
 */
function VariationAttributesModel(variationModel, attrConfig, selectedOptionsQueryParams, quantity) {
    var variationAttributes = new productAttributeBase(variationModel, attrConfig, selectedOptionsQueryParams, quantity);

    variationAttributes.forEach(function (variation) {
        if (variation.swatchable && variation.values) {
            variation.values = getProcessedValues(variation.values, variationModel, attrConfig.endPoint, attrConfig.context);
        }
        if (variation.attributeId == SIZE_ATTRIBUTE_ID && variation.values) {
            variation.values = productHelpers.sortAttributesByValue(variation.values);
        }

        if (attrConfig.endPoint != 'Variation')
            variation.values = productHelpers.prioritizeSelectedAttribute(variation.values, 2);
    }, this);
    
    return variationAttributes;
}

module.exports = VariationAttributesModel;