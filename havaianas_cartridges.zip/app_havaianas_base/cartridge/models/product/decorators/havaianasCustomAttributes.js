'use strict';

var madeInBrazilTypes = require('*/cartridge/config/madeInBrazilTypes');
var caresMap = require('*/cartridge/config/caresMap.json');

function setOfStringsToArray(setOfStrings) {
    var array = [];
    setOfStrings.forEach(function (e) { array.push(e)});
    return array;
}

function mapCares(cares) {
  var array = [];
  cares.forEach(function (e) { array.push(caresMap[e] || e)});
  return array;
}

function getDisplayColorValue(apiProduct){
  var variationModel = apiProduct.getVariationModel();

  var colorAttribute = variationModel.getProductVariationAttribute('color');
  var colorValue = variationModel.getSelectedValue(colorAttribute);
  
  return colorValue ? colorValue.displayValue : '';
}

var PageMgr = require('dw/experience/PageMgr');

module.exports = function (object, apiProduct) {
    var matchThisPage = apiProduct.custom.hav_matchThis ? PageMgr.getPage(apiProduct.custom.hav_matchThis) : null;
    var funFactPage = apiProduct.custom.hav_funFact ? PageMgr.getPage(apiProduct.custom.hav_funFact) : null;

    Object.defineProperties(object, {
        'detailedDescriptions': {
            enumerable: true,
            value: [
                { title: apiProduct.custom.hav_detailedDescriptionTitle1,
                  text: apiProduct.custom.hav_detailedDescription1 },
                { title: apiProduct.custom.hav_detailedDescriptionTitle2,
                  text: apiProduct.custom.hav_detailedDescription2 },
                { title: apiProduct.custom.hav_detailedDescriptionTitle3,
                  text: apiProduct.custom.hav_detailedDescription3 }
                ]
            },
        'technicalDescription': {
            enumerable: true,
            value: {
                title: apiProduct.custom.hav_technicalDescriptionTitle,
                text: apiProduct.custom.hav_technicalDescription,
                soleType: apiProduct.custom.hav_soleType,
                solePrint: apiProduct.custom.hav_solePrint,
                strapType: setOfStringsToArray(apiProduct.custom.hav_strapType),
                cares: mapCares(apiProduct.custom.hav_cares)
            }
        },
        'gender': {
          enumerable: true,
          value: apiProduct.custom.hav_gender
        },
        'age': {
          enumerable: true,
          value: apiProduct.custom.hav_age
        },
        'colors': {
          enumerable: true,
          value: {
            primary: {
              value: apiProduct.custom.hav_primaryColor,
              tone: apiProduct.custom.hav_primaryColorTone
            },
            secondary: {
              value: apiProduct.custom.hav_secondaryColor,
              tone: apiProduct.custom.hav_secondaryColorTone
            },
            all: setOfStringsToArray(apiProduct.custom.hav_colorset),
            displayColorValue: getDisplayColorValue(apiProduct)
          }
        },
        'dimensions': {
          enumerable: true,
          value: {
            weight: apiProduct.custom.dimWeight,
            width: apiProduct.custom.dimWidth,
            height: apiProduct.custom.dimHeight,
            depth: apiProduct.custom.dimDepth
          }
        },
        'primaryCategory': {
          enumerable: true,
          value: apiProduct.primaryCategory ? apiProduct.primaryCategory.displayName : ''
        },
        'isNew': {
          enumerable: true,
          value: apiProduct.custom.hav_productNew
        },
        'type': {
          enumerable: true,
          value: apiProduct.custom.hav_productType
        },
        'madeInBrazil': {
          enumerable: true,
          value: madeInBrazilTypes.indexOf(apiProduct.custom.hav_productType) >= 0
        },
        'matchThisPage': {
          enumerable: true,
          value: matchThisPage && matchThisPage.visible ? apiProduct.custom.hav_matchThis : null
        },
        'funFactPage': {
          enumerable: true,
          value: funFactPage && funFactPage.visible ? apiProduct.custom.hav_funFact : null
        },
        'mainDescription': {
          enumerable: true,
          value: apiProduct.custom.hav_mainDescription
        }
    });
};
