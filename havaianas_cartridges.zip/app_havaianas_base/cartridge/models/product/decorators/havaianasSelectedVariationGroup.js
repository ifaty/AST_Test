'use strict';

/**
 * This decorator adds information about a product line item's variation group.
 * @param {Object} product 
 * @param {dw.catalog.Product} apiProduct 
 */
module.exports = function (product, apiProduct) {
    var { getVariationGroupByFilter } = require('*/cartridge/scripts/helpers/productHelpers');
    var selectedVariationGroup = getVariationGroupByFilter(apiProduct.variationModel, apiProduct.custom.color);
    Object.defineProperty(product, 'selectedVariationGroupID', {
        enumerable: true,
        value: selectedVariationGroup ? selectedVariationGroup.getID() : apiProduct.getID() // Just a fallback for safety...
    })
}