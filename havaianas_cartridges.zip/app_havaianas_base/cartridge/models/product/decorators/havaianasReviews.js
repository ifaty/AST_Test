'use strict';

/**
 * Returns whether or not the product has reviews.
 * @param {Object} product 
 */
function hasReviews (product) {
    // This is a temporary measure until we implement the Adapter-Façade-Builder architecture
    // We should *NOT* directly call the service.
    try {
        var reviewServiceHelper = require('*/cartridge/scripts/services/reviewService');
        var reviewsHelper = require('*/cartridge/scripts/helpers/reviewsHelper');

        if (!reviewsHelper.productReviewsEnabled()) {
            return false;
        }

        var productReviews = reviewServiceHelper.getReviewsByProduct(product.id);
        return !empty(productReviews.items);
    } catch (e) {
        // Change the logging message once we refactor things.
        var Logger = require('dw/system/Logger');
        Logger.warn('Could not retrieve reviews for product ' + product.id + '.\nProbable cause: no review service implemented.\n Stack trace: ' + e.stack);
        return false;
    }
}

/**
 * This decorator adds information about a product's reviews.
 * @param {Object} product 
 * @param {dw.catalog.Product} apiProduct 
 */
module.exports = function (product, apiProduct) {
    Object.defineProperty(product, 'hasReviews', {
        enumerable: true,
        value: hasReviews(product)
    })
}