'use strict';
var imageHelper = require('*/cartridge/scripts/helpers/imageHelper');
var imageTypes = require('*/cartridge/config/imageTypes');

function detectImage(name, identifier) {
    return name.match('_' + identifier + '\\..*$') != null;
}

// We expect the filename to be [SKU]_*_*..._${identifier}.XXX;
function getTransformedImages (productModel, product, type) {
    var propertyName;
    var largeImages;
    var fallback = false;
    var transformedImages = {
        items: new Array(imageTypes[type].count),
        empty: true,
        count: 0
    };

    try {
        largeImages = product.getImages('large');
    } catch (e) {
        largeImages = getFallbackImages();
        fallback = true;
    }

    if (!largeImages || largeImages.length == 0) {
        largeImages = getFallbackImages();
        fallback = true;
    }

    for (var i = 0, len = imageTypes[type].identifiers.length; i < len; i++) {
        var identifier = imageTypes[type].identifiers[i];
        largeImages.toArray().forEach(function (e) {
            var stringifiedUrl = e.URL.toString();
            if (detectImage(stringifiedUrl, identifier) && transformedImages.count < imageTypes[type].count) {
                transformedImages.empty = false;

                transformedImages.items[transformedImages.count] = {
                    file: e,
                    url: e.URL,
                    title: e.title,
                    alt: e.alt,
                };

                transformedImages.count++;
            }
        });
    }

    // We default to show the first large images if we can't detect the '${identifier}' pattern.
    if (imageTypes[type].mandatory &&
        (transformedImages.empty ||
        (imageTypes[type].count < largeImages.length &&
        transformedImages.count != imageTypes[type].count))) {
        for (var i = transformedImages.count, len = imageTypes[type].count; i < len && i < largeImages.length; i++) {
            var curUrl = largeImages[i].URL;
            var curTitle = largeImages[i].title;
            var curAlt = largeImages[i].alt;
            transformedImages.items[i] = {
                file: largeImages[i],
                url: curUrl,
                title: curTitle,
                alt: curAlt
            }
            transformedImages.empty = false;
            transformedImages.count++;
        }
    }

    for (var i = 0, len = transformedImages.count; i < len; i++) {
        var url = transformedImages.items[i].url;
        var obj = fallback ? transformedImages.items[i].url : transformedImages.items[i].file;
        var mediaType = url.toString().indexOf('mp4') >= 0 ? 'video' : 'image'
        switch (type) {
            case 'hero':
                propertyName = 'heroImages';
                transformedImages.items[i].src = imageHelper.getScaledImage(obj, 'hero-'+(i+1)).src;
                break;
            case 'tile':
                propertyName = 'tileImages';
                transformedImages.items[i].src = imageHelper.getScaledImage(obj, 'productTile-'+ (i == 1 ? '1' : '2')).src;
                break;
            case 'tileVertical':
                propertyName = 'tileImages';
                transformedImages.items[i].src = imageHelper.getScaledImage(obj, 'productTileVertical-'+ (i == 1 ? '1' : '2')).src;
                break;
            case 'tileHorizontal':
                propertyName = 'tileImages';
                transformedImages.items[i].src = imageHelper.getScaledImage(obj, 'productTileHorizontal-'+ (i == 1 ? '1' : '2')).src;
                break;
            case 'variation':
                propertyName = 'variationImages';
                transformedImages.items[i].src = imageHelper.getScaledImage(obj, 'productVariation').src;
                break;
            case 'grid':
                propertyName = 'gridImages';
                if (mediaType === 'image') {
                    transformedImages.items[i].src = imageHelper.getScaledImage(obj, 'hero-2').src;
                }
                break;
            case 'shop':
                propertyName = 'shopImages';
                transformedImages.items[i].src = imageHelper.getScaledImage(obj, 'shop').src;
                break;
        }
    }

    return {
        transformedImages: transformedImages,
        propertyName: propertyName
    }
}

function getFallbackImages() {
    var ArrayList = require('dw/util/ArrayList');
    var URLUtils = require('dw/web/URLUtils');
    var largeImages = new ArrayList();
    ['A', 'B', 'C', 'D'].forEach(function (e) {
        var url = 'images/product/sample_' + e + '.png';
        largeImages.add({
            file: null,
            URL: url,
            title: 'Sample',
            alt: 'Sample'
        })
    });
    return largeImages;
}

module.exports = function (object, apiObject, type) {
    var obj = getTransformedImages(object, apiObject, type);
    if (!obj.transformedImages.empty) {
        Object.defineProperty(object,
            obj.propertyName, {
                enumerable: true,
                value: obj.transformedImages
            });
    }
};
