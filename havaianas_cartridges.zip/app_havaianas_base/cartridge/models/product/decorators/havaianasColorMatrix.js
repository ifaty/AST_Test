'use strict';

var colorMatrixHelper = require('*/cartridge/scripts/helpers/colorMatrixHelper');

module.exports = function (object, apiProduct) {

    Object.defineProperties(object, {
        'colorMatrix': {
            enumerable: true,
            value: colorMatrixHelper.getColorSpecification(
                apiProduct.custom.hav_primaryColor,
                apiProduct.custom.hav_primaryColorTone,
                apiProduct.custom.hav_secondaryColor,
                apiProduct.custom.hav_secondaryColorTone,
                {
                    productColors: true
                }
                )
            },
        'tileColorMatrix': {
            enumerable: true,
            value: colorMatrixHelper.getColorSpecification(
                apiProduct.custom.hav_primaryColor,
                'ultralight',
                apiProduct.custom.hav_secondaryColor,
                'ultralight'
                )
            },
        });
};
