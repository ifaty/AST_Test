'use strict';

var APPAREL_CATEGORY_ID = 'APPAREL';

function hasModelPicture (apiProduct) {
    var categories = apiProduct.getAllCategories();
    var collections = require('*/cartridge/scripts/util/collections');

    var apparelCategory = collections.find(categories, function(item){ return item.ID == APPAREL_CATEGORY_ID; })

    return !!apparelCategory;
}

module.exports = function (product, apiProduct) {
    Object.defineProperty(product, 'hasModelPicture', {
        enumerable: true,
        value: hasModelPicture(apiProduct)
    })
}