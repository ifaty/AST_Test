'use strict';

var { getVariationAttributeValues } = require('*/cartridge/scripts/helpers/productHelpers');

module.exports = function(product, apiProduct) {
    Object.defineProperty(product, 'selectedAttributes', {
        enumerable: true,
        value: getVariationAttributeValues(apiProduct)
    });
}