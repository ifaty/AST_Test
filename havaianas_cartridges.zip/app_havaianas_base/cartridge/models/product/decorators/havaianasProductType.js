'use strict';

function getProductType (apiProduct) {
    var { assureMasterProduct } = require('*/cartridge/scripts/helpers/productHelpers');

    var masterProduct = assureMasterProduct(apiProduct);
    var productType = masterProduct.custom.hav_productType;

    return productType;
}

module.exports = function (product, apiProduct) {
    Object.defineProperty(product, 'hav_productType', {
        enumerable: true,
        value: getProductType(apiProduct)
    })
}