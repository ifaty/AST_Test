'use strict';

module.exports = {
    colorMatrix: require('*/cartridge/models/product/decorators/havaianasColorMatrix'),
    checkoutVariationAttributes: require('*/cartridge/models/product/decorators/checkoutVariationAttributes'),
    customAttributes: require('*/cartridge/models/product/decorators/havaianasCustomAttributes'),
    transformedImages: require('*/cartridge/models/product/decorators/havaianasImages'),
    selectedAttributes: require('*/cartridge/models/product/decorators/selectedAttributes'),
    productType: require('*/cartridge/models/product/decorators/havaianasProductType'),
    searchPricePromotions: require('*/cartridge/models/product/decorators/searchPricePromotions'),
    hasModelPicture: require('*/cartridge/models/product/decorators/havaianasHasModelPicture'),
    productReviews: require('*/cartridge/models/product/decorators/havaianasReviews'),
    category: require('*/cartridge/models/product/decorators/havaianasCategory'),
    selectedVariationGroup: require('*/cartridge/models/product/decorators/havaianasSelectedVariationGroup')
}