var CheckoutVariationAttributesModel = require('*/cartridge/models/product/checkoutProductAttributes');

module.exports = function (product, apiProduct, endPoint, uuid, view) {
    Object.defineProperty(product, 'variationAttributes', {
        enumerable: true,
        value: new CheckoutVariationAttributesModel(apiProduct, endPoint, uuid, view)
    });
}