'use strict';

/**
 * This decorator adds information about a product's reviews.
 * @param {Object} product 
 * @param {dw.catalog.Product} apiProduct 
 */
module.exports = function (product, apiProduct) {
    Object.defineProperty(product, 'category', {
        enumerable: true,
        value: apiProduct.primaryCategory.ID
    })
}