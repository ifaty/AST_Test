'use strict';

var array = require('*/cartridge/scripts/util/array')
var {
    getVariationAttributeValues,
    prioritizeSelectedAttribute,
    prioritizeSizeSelected,
    getVariationGroupByFilter
} = require('*/cartridge/scripts/helpers/productHelpers');

var SIZE_ATTRIBUTE_ID = "size";

function getAllValues(variationModel, relatedProducts, selectedValues, endPoint, UUID, view) {
    var URLUtils = require('dw/web/URLUtils');
    var colorHelper = require('*/cartridge/scripts/helpers/colorMatrixHelper');
    var rainbowHelper = require('*/cartridge/scripts/helpers/rainbowHelper');
    var productAttributes = Object.getOwnPropertyNames(relatedProducts);
    
    return productAttributes.map(function (productAttributeID) {
        var attributeRelatedProducts = relatedProducts[productAttributeID];
        var selectedValue = selectedValues[productAttributeID];
        
        var values = attributeRelatedProducts.map(function (relatedProduct) {
            var relatedProductValue = getVariationAttributeValues(relatedProduct)[productAttributeID];

            var isSelected = (selectedValue && selectedValue.equals(relatedProductValue)) || false;
            var availabilityModel = relatedProduct.getAvailabilityModel();
            var result = {
                id: relatedProductValue.ID,
                description: relatedProductValue.description,
                displayValue: relatedProductValue.displayValue,
                value: relatedProductValue.value,
                selected: isSelected,
                selectable: availabilityModel.isOrderable(),
                available: availabilityModel.isOrderable(),
                pid: relatedProduct.getID(),
                uuid: UUID,
                url: URLUtils.url(endPoint, 'view', view || 'tile').toString()
            };

            result.url = result.selectable ?
                URLUtils.url(endPoint, 'view', view || 'tile').toString() :
                URLUtils.url(
                    'Product-Unavailable',
                    'pid', relatedProduct.getID(),
                    'attr', result.id,
                    'value', result.value
                );

            if (productAttributeID === 'color') {
                var variationByFilter = getVariationGroupByFilter(variationModel, result.value);
                result.colorMatrix = colorHelper.getColorSpecification(
                    variationByFilter.custom.hav_primaryColor || '',
                    variationByFilter.custom.hav_primaryColorTone,
                    variationByFilter.custom.hav_secondaryColor,
                    variationByFilter.custom.hav_secondaryColorTone
                );
                result.rainbowColor = rainbowHelper.getRainbowValue(variationByFilter.custom.hav_primaryColor, variationByFilter.custom.hav_primaryColorTone || 'regular');
                var fallbackTone = colorHelper.getFallbackTone(variationByFilter.custom.hav_primaryColorTone || 'regular');
                result.fallbackColor = rainbowHelper.getRainbowValue(variationByFilter.custom.hav_primaryColor, fallbackTone);
            }

            return result;
        });

        var productAttribute = variationModel.getProductVariationAttribute(productAttributeID);

        return {
            displayName: productAttribute.displayName,
            attributeId: productAttribute.attributeID,
            id: productAttribute.ID,
            values: productAttribute.ID == SIZE_ATTRIBUTE_ID ? prioritizeSizeSelected(values) : prioritizeSelectedAttribute(values, 2)
        }
    })
}


function CheckoutVariationAttributesModel (apiProduct, endPoint, uuid, view) {
    var variationModel             = apiProduct.getVariationModel();
    var relatedVariationGroups     = variationModel.getVariationGroups().toArray();
    var productVariationAttributes = getVariationAttributeValues(apiProduct);

    var acceptableColorVariations = [];
    
    relatedVariationGroups.forEach(function (variationGroup) {
        var groupVariationModel = variationGroup.getVariationModel();
        var variants            = groupVariationModel.getSelectedVariants().toArray();

        // This size comparison was done in order to present only those products
        // that contains the same selected size 
        var variantSizeMatch =
            array.find(variants, function(variant) {
                var variantAttributeValues = getVariationAttributeValues(variant);

                return variantAttributeValues.size.equals(productVariationAttributes.size);
            })

        if (!empty(variantSizeMatch)) {
            acceptableColorVariations.push(variantSizeMatch)
        }

    });

    var motherVariationGroup =
        array.find(relatedVariationGroups, function (variationGroup) {
            var variationGroupAttributes = getVariationAttributeValues(variationGroup);

            return variationGroupAttributes.color ? variationGroupAttributes.color.equals(productVariationAttributes.color) : false;
        });

    var relatedProducts = {
        color: acceptableColorVariations,
        size: motherVariationGroup.getVariationModel().getSelectedVariants().toArray() // Getting only online variants
    }

    return getAllValues(variationModel, relatedProducts, productVariationAttributes, endPoint, uuid ? uuid : apiProduct.UUID, view)
}

module.exports = CheckoutVariationAttributesModel;
