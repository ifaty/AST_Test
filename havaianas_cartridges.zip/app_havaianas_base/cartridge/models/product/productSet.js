'use strict';

var havaianasDecorators = require('*/cartridge/models/product/decorators/havaianasIndex');
var productSetBase = module.superModule;

module.exports = function productSet(product, apiProduct, options) {
    product = productSetBase(product, apiProduct, options);
    havaianasDecorators.transformedImages(product, apiProduct, 'hero');
    havaianasDecorators.customAttributes(product, apiProduct);
    return product;
};