'use strict';

var decorators = require('*/cartridge/models/product/decorators/index');
var havaianasDecorators = require('*/cartridge/models/product/decorators/havaianasIndex');

module.exports = function productSuggestion(product, apiProduct) {
    decorators.images(product, apiProduct, {});
    havaianasDecorators.transformedImages(product, apiProduct, 'hero');
    havaianasDecorators.transformedImages(product, apiProduct, 'shop');
    return product;
};