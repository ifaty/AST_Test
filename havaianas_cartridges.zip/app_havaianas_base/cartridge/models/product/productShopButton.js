'use strict';

var decorators = require('*/cartridge/models/product/decorators/index');
var havaianasDecorators = require('*/cartridge/models/product/decorators/havaianasIndex');

module.exports = function productShopButton(product, apiProduct) {
    decorators.base(product, apiProduct, {});
    decorators.images(product, apiProduct, {});
    havaianasDecorators.transformedImages(product, apiProduct, 'shop');
    havaianasDecorators.colorMatrix(product, apiProduct);
    return product;
};