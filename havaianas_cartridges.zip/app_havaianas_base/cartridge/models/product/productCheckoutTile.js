'use strict';

var { getProductType, getConfig } = require('*/cartridge/scripts/helpers/productHelpers');
var decorators = require('*/cartridge/models/product/decorators/index');
var havaianasDecorators = require('*/cartridge/models/product/decorators/havaianasIndex');
var productFlags = require('*/cartridge/scripts/product/productFlag');

module.exports = function productCheckoutTile (product, apiProduct, endPoint, quantity, uuid, view) {
    var options = getConfig(apiProduct, {});

    decorators.base(product, apiProduct, getProductType(apiProduct));
    decorators.quantity(product, apiProduct, quantity || 1);
    decorators.price(product, apiProduct, options.promotions, false, options.optionModel);
    havaianasDecorators.productType(product, apiProduct);
    havaianasDecorators.selectedAttributes(product, apiProduct);
    havaianasDecorators.transformedImages(product, apiProduct, 'tile');
    havaianasDecorators.checkoutVariationAttributes(product, apiProduct, endPoint, uuid, view);
    havaianasDecorators.colorMatrix(product, apiProduct);

    //check if has flags
    product.flags = productFlags(apiProduct);

    return product;
}