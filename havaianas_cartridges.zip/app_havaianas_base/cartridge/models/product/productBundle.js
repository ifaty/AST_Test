'use strict';

var havaianasDecorators = require('*/cartridge/models/product/decorators/havaianasIndex');
var productBundleBase = module.superModule;

module.exports = function productBundle(product, apiProduct, options) {
    product = productBundleBase(product, apiProduct, options);
    havaianasDecorators.customAttributes(product, apiProduct);
    havaianasDecorators.transformedImages(product, apiProduct, 'hero');
    return product;
};