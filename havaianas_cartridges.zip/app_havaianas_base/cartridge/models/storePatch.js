'use strict'

// All setters here are strictly used to construct an object that is used by OCAPI.
// That's why all custom attributes are prefixed with 'c_'.

/**
 * @constructor
 * @classdesc The store patch model
 */
function storePatch () {
}

/**
 * Sets the name of the store.
 * @param {String} name
 * @returns {String}
 */
storePatch.prototype.setName = function (name) {
    this.name = name;
};

storePatch.prototype.setType = function (storeType) {
    this.c_storeType = storeType;
}

/**
 * Sets the rating of the store.
 * @returns {Rating}
 */
storePatch.prototype.setRating = function (rating) {
    if (!rating || !(rating >= 0 && rating <= 5)) {
        this.rating = 0;
        return;
    }

    this.c_rating = rating;
};

/**
 * Sets the phone of the store.
 * @param {String} phone
 */
storePatch.prototype.setPhone = function (phone) {
    if (typeof phone !== 'string' || phone.length === 0)
        throw new Error('invalid argument, phone must be of type string and length greater than zero');

    this.phone = phone;
}

/**
 * Sets the address of the store.
 * @param {string} formattedAddress
 * @param {string} addressHTML - semantic address in HTML form
 */
storePatch.prototype.setAddress = function (formattedAddress, addressHTML) {
    this.address1 = formattedAddress;
    this.c_storeAddressHTML = addressHTML;
}

/**
 * Sets the city of the store
 * @param {String}
 */
storePatch.prototype.setCity = function (cityName) {
    this.city = cityName;
}

/**
 * Sets the state code of the store
 * @param {String}
 */
storePatch.prototype.setStateCode = function (stateCode) {
    this.state_code = stateCode
}

/**
 * Sets the sublocality of the store
 * @param {String}
 */
storePatch.prototype.setSublocality = function (sublocality) {
    this.address2 = sublocality;
}

/**
 * Sets the open periods of the store.
 * @param {Object} openPeriods
 */
storePatch.prototype.setOpenPeriods = function (openPeriods) {
    var expectedStructure = {
        default: {
            _type: 'markup_text',
            markup: JSON.stringify(openPeriods),
            source: JSON.stringify(openPeriods)
        }
    };
    this.c_openPeriods =
        expectedStructure;
}

/**
 * Sets the open periods of the store.
 * @param {Object} openPeriods
 */
storePatch.prototype.setDisplayOpenPeriods = function (hourSequences) {
    if (!Array.isArray(hourSequences))
        return;

    this.c_displayOpenPeriods =
        JSON.stringify(hourSequences, null, 2);
}

/**
 * Sets the geolocation coordinates of the store
 * @param {Object} { latitude<Number>, longitude<Number> }
 */
storePatch.prototype.setGeolocation = function (geolocation) {
    this.latitude = geolocation.latitude,
    this.longitude = geolocation.longitude
}

module.exports = storePatch;
