export default class ASYNC {
    constructor(options) {

        const defaultOptions = {}

        this.options = Object.assign({}, defaultOptions, options);
        this.timeouts = [];
    }

    async wait(ms) {
        return new Promise(resolve => {
            setTimeout(resolve, ms);
        });
    }

    async clearableWait(ms = 300, timeoutName = "internalTimeout") {
        return new Promise(resolve => {
            this.timeouts[timeoutName] = setTimeout(resolve, ms);
        });
    }

    clearTimeout(timeoutName = "internalTimeout") {
        clearTimeout(this.timeouts[timeoutName]);
        return this;
    }
}