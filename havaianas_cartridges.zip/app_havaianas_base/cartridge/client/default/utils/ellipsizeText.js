export default function ellipsizeTextBox(selector) {
    var el = $(selector);

    $.each(el, function(idx, el) {

        var wordArray = el.innerHTML.split(' ');
        while(el.scrollHeight > el.offsetHeight) {
            wordArray.pop();
            el.innerHTML = wordArray.join(' ') + '...';
        }
    });
}