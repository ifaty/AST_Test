export default class EventStream {
   constructor(options) {

        const defaultOptions = {
            eventTarget: "body",

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);

        this.$ = this.options.selectorEngine;
   }

   fire(event) {

        console.log("firing", event);

        return new Promise(resolve => {

            this.$(this.options.eventTarget).trigger(event);
            resolve();

        });
   }

   on(event, callback) {
       return new Promise(resolve => {

           this.$(this.options.eventTarget).on(event, resolve(callback));

       });
   }

}