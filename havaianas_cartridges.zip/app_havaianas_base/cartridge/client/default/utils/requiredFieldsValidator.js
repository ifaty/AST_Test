export default class requiredFieldsValidator {
    constructor(options) {

        const defaultOptions = {
            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.watching = false;
    }

    validateRequiredFields(form) {
        let valid = true;

        this.$(form).addClass('required-filled');

        if (this.$(form).length) {

            this.$(this.$(form).find('input[required]')).each((idx, el) =>{
                if (this.$(el).val() == ''){
                    valid = false;

                    this.$(form).removeClass('required-filled');
                }
            });

        } else {
            valid = false;

            this.$(form).removeClass('required-filled');

            //console.log(`form ${form} not found`);
        }

        return valid;
    }

    listen() {

        if (this.watching) return this.reload();

        //receive input targets from javascript event
        this.$(document).on('app:fieldsValidator:required', (ev, data) => {
            this.validateRequiredFields(data.target);
        });

        this.watching = true;

        return this;
    }

    reload() {

        this.watching = false;

        return this.destroy().listen();

    }

    destroy() {

        this.$(document).off('app:fieldsValidator:required');

        return this;
    }
}
