let log = (message) => {
    return (message) ? console.log(message) : null;
}

export default log;