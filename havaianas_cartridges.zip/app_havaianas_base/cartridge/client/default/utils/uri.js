export default class URI {

    constructor() {}

    matchHash(url, callback) {
        var hash = window.location.hash;

        if(hash == url) {
          if (typeof callback === 'function') {
            return callback(arguments);
          }
        } else {
          return false;
        }
    }

    hasHash(url, callback) {
        var hash = window.location.hash;
        var segments = hash.split('/').splice(1,5);
        var has = false;
        var segment;

        if(hash.toLowerCase().indexOf(url) >= 0) {
          if (typeof callback === 'function') {
            return callback(segments.pop());
          }
        } else {
          return false;
        }
    }

    matchSegment(name, callback) {
        var names = [].concat([], name);
        var pathname = window.location.pathname;

        //create an array with pathname with an limit of 100 segments
        //and remove last segment if is empty (caused by last "/" ex: /contact vs /contact/ )
        var segments = pathname.split('/').splice(1,100);

        if(segments.slice(0, -1) === '')
          segments.slice(0, -1);

        //if has no segments add an "/" to segments
        if (segments[0].length === 0)
          segments.push('/');

        for (var j = names.length - 1; j >= 0; j--) {
          for (var i = segments.length - 1; i >= 0; i--) {

            if(segments[i].toLowerCase() === names[j].toLowerCase()) {
              if (typeof callback === 'function') {
                  return callback(arguments);
              }
            }
          }
        }
    }

    getSegments() {
        var url = window.location.href.replace(window.location.origin, '').split('/');
        return url.splice(1, url.length);
    }

}