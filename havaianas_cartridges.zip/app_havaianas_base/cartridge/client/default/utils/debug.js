import isMobile from "./isMobile";

export default class Debug {
    constructor(options) {
        const defaultOptions = {
            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.listen();
    }

    listen () {

        document.body.addEventListener("keydown", (e) => {
            e = e || window.event;
            var key = e.which || e.keyCode; // keyCode detection
            var ctrl = e.ctrlKey ? e.ctrlKey : ((key === 17) ? true : false); // ctrl detection
            var shift = e.shiftKey ? e.shiftKey : ((key === 16) ? true : false); // shift detection

            if (key == 67 && ctrl && shift) {
                console.warn("Ctrl + Shift + C Pressed! Starging grid debugger...");
                this.$('html').toggleClass('grid-debug');
            }

        }, false);

    }
}
