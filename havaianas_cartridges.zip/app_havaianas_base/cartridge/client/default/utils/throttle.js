export default function Throttle(callback, limit, data = {}) {
  var wait = false;
  return function () {
      var context = this, args = arguments;
    if (!wait) {
      callback.apply(context, args);
      wait = true;
      setTimeout(function () {
        wait = false;
      }, limit);
    }
  };
}
