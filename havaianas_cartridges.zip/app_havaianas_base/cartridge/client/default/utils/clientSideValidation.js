import isMobile from './isMobile';

export default class FormValidator {
    constructor(options) {

        const defaultOptions = {
            formControlInvalid: '.form-control.is-invalid',
            formInpSelect: 'form input, form select',
            inputSelect: 'input, select',
            invalidFeedback: '.invalid-feedback',
            submitButton: '.account__register-submit',
            // forgottenPasswordBtn: '.account__forgotten-email-submit',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";
    }

    //Clears all form errors and validations
    //Needs to be called firstly on every submit
    clearForm(form) {
        this.$(form).find(this.options.invalidFeedback).html('');
        this.$(form).find(this.options.formControlInvalid).removeClass(this.options.isInvalid);
    }
    /**
     * Validate whole form. Requires `this` to be set to form object
     * @param {jQuery.event} event - Event to be canceled if form is invalid.
     * @returns {boolean} - Flag to indicate if form is valid
     */
    validateForm(currentForm, submited = false, backendErrors = null) {
        var valid = true;
        var errors = this.options.invalidFeedback;
        let incorrectInputs = 0;
        let toastMessage;
        let toastError;

        currentForm.find(this.options.inputSelect).each(function () {// Looping through form inputs and checking validity
            var backendError =  backendErrors ?
                                    backendErrors instanceof Array
                                        ? backendErrors[0][$(this).attr('name')]
                                        : backendErrors[$(this).attr('name')]
                                    : null;

            if (!this.validity.valid || backendError) {
                valid = false;
                //Trigger Invalid Error Messages Here
                $(this).trigger('invalid', this.validity);

                var validationMessage = this.validationMessage;
                $(this).addClass('is-invalid');

                if (this.validity.patternMismatch && $(this).data('pattern-mismatch')) {
                    validationMessage = $(this).data('pattern-mismatch');
                }
                if ((this.validity.rangeOverflow || this.validity.rangeUnderflow) && $(this).data('range-error')) {
                    validationMessage = $(this).data('range-error');
                }
                if ((this.validity.tooLong || this.validity.tooShort) && $(this).data('range-error')) {
                    validationMessage = $(this).data('range-error');
                }
                if (this.validity.valueMissing && $(this).data('missing-error')) {
                    validationMessage = $(this).data('missing-error');
                }
                if (backendError) {
                    validationMessage = backendError;
                }

                if($(this).is(':visible')) {
                    incorrectInputs++;
                    if($(this).data('toasterror')) toastError = validationMessage;
                };

                // Showing Error Message if form is submited
                if(submited) $(this).siblings(errors).html(`<i class="icon-alert"></i> <span>${validationMessage}</span>`);

            }
        });

        toastMessage = $(currentForm).data('form-error');

        // if it's only 1 input you have and if this error is really to show in toast
        if(incorrectInputs == 1 && toastError) { toastMessage = toastError; }

        // trigger if form is submit e form is invalid
        if(!valid && submited) {
            $(currentForm).trigger('invalid-form');
            if(toastMessage) {
                this.options.toast
                            .setOptions({
                                type: 'error',
                                buttonMsg: 'Close',
                                msgText: toastMessage
                            })
                            .openToast();
            }
        }

        return valid;
    }

    //Method that handles form button click
    buttonClickHandler(clickedElement) {
        //clearForm(form);
        var currentForm = clickedElement.closest('form'); //Form Selector
        this.clearForm(currentForm);
        return this.validateForm(currentForm, true);
    }

    setOptions(options) {

        this.options = Object.assign({}, this.options, options);

        return this;
    }

    //Listener binding events
    listenSubmitButton() {
        //Binding on Register Form Button
        this.$(document).on(this.tapEvent, this.options.submitButton,(e) => {
            e.preventDefault();
            if (this.buttonClickHandler(this.$(e.currentTarget))) {
                this.$(e.currentTarget).closest('form').submit();
            }
        });

        // //Binding on Register Forgotten Password Button
        // //TODO: FIX BINDING TO CLICK AND TAP AVOIDING ERRORS ON JQUERY
        //  this.$(document).on(this.tapEvent, this.options.forgottenPasswordBtn,(e) => {
        //      e.preventDefault();
        //      this.buttonClickHandler(this.$(this.options.forgottenPasswordBtn));
        //  });
    }
}
