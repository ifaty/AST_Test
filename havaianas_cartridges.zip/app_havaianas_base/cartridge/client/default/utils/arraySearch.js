
/*

function search(nameKey, myArray){
    for (var i=0; i < myArray.length; i++) {
        if (myArray[i].name === nameKey) {
            return myArray[i];
        }
    }
}

var array = [
    { name:"string 1", value:"this", other: "that" },
    { name:"string 2", value:"this", other: "that" }
];

var resultObject = search("string 1", array);

*/

export default function search(nameKey, targetArray, key) {
    for (var i=0; i < targetArray.length; i++) {
        if (nameKey.includes(targetArray[i][key])) {
            return targetArray[i];
        }
    }
}