import isMobile from '../../utils/isMobile';
import debounce from '../../utils/debounce';
import isotopeLayout from 'isotope-layout';
import "isotope-packery";
import scrollMagic from 'scrollmagic';
import ASYNC from '../../utils/async';

// import 'scrollmagic/scrollmagic/minified/plugins/debug.addIndicators.min';

export default class ShopMode extends ASYNC {
    constructor(options) {

        super(options);

        const defaultOptions = {
            myPage: '',
            shopMode: ".shopmode",
            storySection: '.page-shop .story__section',
            firstStorySection: '.page-shop .story__section.first',
            grid: '.shopmode__grid',
            gridCell: '.shopmode__cell',
            gridCellGutter: '.shopmode__cell-gutter',
            sizesItem: '.size-item',
            sizesShowMore: '.size-item.size-more',
            sizesOpenedClassName: 'sizes__opened',
            sizesCloseButton: '.size__attribute .close__button',
            sizeShowMoreClassName: 'size-more',
            sizeAttribute: '.size__attribute',
            displayableSizes: '.displayable__swatches > .sizes',

            colorsShowMore: '.color__swatch.show-more-colors',
            colorsShowMoreClose: '.color__attribute .close__button',
            colorSwatch: '.swatch-circle',
            product: '.product',
            quickViewImage: '.quickview-image',
            productHover: '.product__tile-background-hover',
            productNewFlag: ".product__tile-flag",
            productTileBuyButton: '.product__tile-buy-btn',
            productDisplayableSwatches: '.displayable__swatches',
            productTileWishlistBtn: '.product__tile-wishlist-btn',
            viewMoreBtn: '.btn__view-more-products',
            filterContainer: ".shopmode__filter-modal",

            inWishListClass: '.in-wishlist',
            showMoreProductsUrl: '#showmore-container',
            inFrame: '.in-frame',
            outFrame: '.out-frame',

            payButtonCounter: ".superActions .product__pay-button__counter",

            btnShopMode: '.superActions__btnShopMode',
            btnShopVideo: '.superActions__btnShopMode__video',
            btnShopModeTitle: '.shopmode__header h1',
            animatedClass: 'animated',

            btnShopModeSubTitle: '.shopmode__header h2',

            shopButton: '.superActions__btnShopMode',

            colorMatrix: '.color-matrix',
            shopModeButtonInfo: '#buttonInfo',

            nextPlaceholder: '.shopmode__next',
            previousPlaceholder: '.shopmode__previous',

            productFlagSelector: '.product__tile-flag',
            productCellSelector: '.shopmode__cell',
            productFlagClasses: 'product__product--is-new',

            paginationOffset: 0,
            productsPerPage: 12
        }

        this.options = Object.assign({}, defaultOptions, options);
        /** @type {JQueryStatic} this.$ */
        this.$ = this.options.selectorEngine;

        this.viewportWidth = this.$("body").outerWidth();
        this.colDesk = this.viewportWidth / 79;

        this.animatingContent = false;

        this.tapEvent = "click";

        this.keepFilter = true;

        this.productTiles = [];

    }

    listenWishListChange() {

        this.$('body').on(this.tapEvent, this.options.productTileWishlistBtn, (e) => {

            let target = this.$(e.currentTarget);

            if (target.hasClass('active')) {
                this.removeWishList(target)
            } else {
                this.addWishList(target)
            }

        })

    }

    findColorMatrix(target) {
        return (target.find(".color-matrix").data() || {}).colormatrix;
    }

    findFallbackColorMatrix(target) {
        return (target.find(".color-matrix").data() || {}).fallbackcolormatrix;
    }

    configTileColors() {
        this.$(this.options.product).map((i, el) => this.setProductColors(this.$(el)));
    }

    resetSelectedSize(el, id) {

        el.closest(this.options.grid).find(`[data-pid='${id}']`).each((i, e) => {
            this.$(e).find(this.options.sizesItem).removeClass("active").removeAttr("style");
        })

        this.productTiles.filter(product => { if (product.id === id) delete product.selectedSize; });
    }

    setSelectedSize(pid, id) {

        const updateSize = this.productTiles.find(product => product.id === id);

        updateSize ? updateSize.selectedSize = pid : this.productTiles.push({ id, selectedSize: pid });

    }

    rebuildIsotope() {

        this.$(this.options.grid).map((i, el) => {
            this.buildIsotopeLayout(el)
        })

    }

    /**
     * Add grid items CSS classes
     * TODO: call this whenever grid items change (EG load new items)
     * @memberof ShopMode
     */
    addGridItemsClass() {
        this.$(this.options.grid).find(this.options.productFlagSelector).each((i, el) => {
            this.$(el).closest(this.options.productCellSelector).addClass(this.options.productFlagClasses);
        });
    }

    buildIsotopeLayout(grid) {
        this.addGridItemsClass();

        this.isotope = new isotopeLayout(grid, {
            itemSelector: this.options.gridCell,
            layoutMode: 'packery',
            percentPosition: true,
            packery: {
                gutter: this.options.gridCellGutter
            }
        });

    }

    setStorySectionScenes() {

        let firstScene = new scrollMagic.Scene({
            triggerElement: this.$(this.options.firstStorySection)[0],
            triggerHook: 0.5,
            duration: this.$(this.options.firstStorySection).outerHeight()
        })
        .addTo(this.scrollMagicController)
        // .addIndicators()
        .on("leave", (e) => {
            firstScene.off("progress");
        })
        .on('progress', (e) => {

            if (e.scrollDirection == "REVERSE") {
                let target = this.$(e.target.triggerElement());

                this.loadPreviousShop(target).then(() => {

                    this.scrollMyPage(this.$(this.options.myPage).scrollTop() + target.prevAll(this.options.storySection).first().outerHeight());

                    this.destroy().listen();
                });

                firstScene.destroy(true)
            }
        });

        // loop on story sections to create scene for each one to scroll magic
        this.$(this.options.storySection).map((i, el) => {

            let scene = new scrollMagic.Scene({
                triggerElement: el,
                triggerHook: 0.5,
                duration: this.$(el).outerHeight()
            })
            .addTo(this.scrollMagicController)
            // .addIndicators()
            .on("enter", (e) => {

                let target = this.$(e.target.triggerElement());
                this.$(this.options.storySection).removeClass('is-current');
                target.addClass('is-current');

                if (e.state  == "DURING") {

                    if (e.scrollDirection == "REVERSE") {
                        this.loadPreviousShop(target).then(() => {

                            this.scrollMyPage(this.$(this.options.myPage).scrollTop() + target.prevAll(this.options.storySection).first().outerHeight());
                            this.destroy().listen();
                        });
                    }

                    this.loadNextShop(target).then(() => {
                        this.destroy().listen();
                    });

                    this.changeStoryComponents(el);

                    this.$(document)
                    .trigger('app:colors:setcolors', target.find(".color-matrix"))
                    .trigger('app:frame:changeHistory', [{url: target.data('shopmodeurl')}])
                    .trigger('app:rainbow:storyColorsToRainbow', el);

                }

            })

        })
    }

    destroyPageScrollActions() {

        if (this.scrollMagicController) {
            this.scrollMagicController.destroy(true);
        }

        return this;

    }

    setPageScrollActions() {


        this.scrollMagicController = new scrollMagic.Controller({
            container: this.options.myPage
        });


        if (this.options.myPage == '.page-shop') {
            this.setStorySectionScenes();
        }

    }

    loadPreviousShop(el = this.$(this.options.storySection).first()) {

        return new Promise((resolve, reject) => {

            let currentStory = this.$(el);

            if (currentStory.prev(this.options.previousPlaceholder).length) {

                this.$(document).trigger('app:contextLoader:init', [{
                    target: currentStory.prev(this.options.previousPlaceholder)
                }]);

                let url = currentStory.data('previousurl');

                this.$.get(url, {
                        ajax: true
                    }).then((data) => {

                    currentStory.prev(this.options.previousPlaceholder).remove();
                    this.$(document).trigger('app:contextLoader:finish');

                    this.$(this.options.myPage).prepend(data);
                    currentStory.prevAll(this.options.nextPlaceholder).remove();

                    this.buildIsotopeLayout(currentStory.prevAll(this.options.storySection).first().find(this.options.grid)[0]);

                    resolve();
                })

            }

        })

    }



    loadNextShop(el = this.$(this.options.storySection).first()) {

        return new Promise((resolve, reject) => {

            let currentStory = this.$(el);

            if (currentStory.next(this.options.nextPlaceholder).length) {

                let url = currentStory.data('nexturl');

                currentStory.next(this.options.nextPlaceholder).remove();

                this.$.get(url, {
                        ajax: true
                    }).then((data) => {
                    this.$(this.options.myPage).append(data);
                    currentStory.nextAll(this.options.previousPlaceholder).remove();

                    this.buildIsotopeLayout(currentStory.nextAll(this.options.storySection).first().find(this.options.grid)[0]);

                    resolve();
                })

            }

        })

    }

    addWishList(target, openToast = true) {

        let url = target.data().hrefAdd;

        this.$.get(url, {
                ajax: true
            }).then(() => {
            target.addClass("active")

            if (openToast) {
                this.options.toast
                .setOptions({
                    buttonOk: true,
                    msgText: target.data().toastAdd,
                    type: "default"
                }).openToast();
            }
        })

    }

    removeWishList(target) {

        let url = target.data().hrefRemove;

        this.$.get(url, {
                ajax: true
            }).then(() => {
            target.removeClass("active");

            this.options.toast
                .setOptions({
                    buttonOk: true,
                    buttonMsg: target.data().toastButton,
                    msgText: target.data().toastRemove,
                    type: "default",
                    closeUser: () => this.addWishList(target, false)
                }).openToast();
        })

    }

    deactivateProductsHover() {
        this.$(this.options.gridCell).map((i, el) => {
            this.$(el).css("pointer-events", "none")
        })
    }

    activateProductsHover() {
        this.$(this.options.gridCell).map((i, el) => {
            this.$(el).css("pointer-events", "all")
        })
    }

    listenProductHover() {

        this.$(this.options.gridCell)
        .on("mouseover", (e) => {

            let target = this.$(e.currentTarget);
            let colors = this.findColorMatrix(target);
            let fallbackColors = this.findFallbackColorMatrix(target);

            // The check below is very ad hoc.
            // We should implement a better solution.
            target
            .find(this.options.productHover)
            .css({
                backgroundColor: colors.background
            })

            target
            .find(this.options.product)
            .css({
                color: colors.text,
                borderColor: colors.text,
            })
            .find(this.options.productTileBuyButton).css({
                color: colors.ui,
            })
            .find("span")
            .css({
                color: colors.uiText
            })

            target
            .find(this.options.productNewFlag)
            .css({
                color: colors.background,
                backgroundColor: colors.text
            })


        })
        .on('mouseleave', (e) => {

            let target = this.$(e.currentTarget);

            target.removeClass(this.sizesOpenedClassName);

            target.find(this.options.productHover).removeAttr("style");
            target.find(this.options.product).removeAttr("style");
            target.find(this.options.productNewFlag).removeAttr("style");
        })

    }

    listenColorSwatch() {
        this.$('body').on(this.tapEvent, this.options.colorSwatch, (e) => {
            let element = this.$(e.target);
            let url = element.data().url;
            let target = element.closest(this.options.gridCell);

            if (!url) return;

            this.$.get(url, {
                    ajax: true
                }).then(({
                renderedTemplate
            }) => {
                target.append(renderedTemplate).find(this.options.product).first().remove();
                this.listenProductHover();
                this.listenSizeHover();
                this.singleHiddenSizesBackground(target);
                setTimeout(() => {
                    this.$(this.options.myPage).trigger("scroll");
                }, 500)
            })

        })
    }

    listenSizeHover() {

        this.$(this.options.sizesItem)
        .hover((e) => {

            let target = this.$(e.currentTarget);
            let colors = this.findColorMatrix(target.closest(this.options.gridCell));

            target.css({
                color: colors.uiText,
                borderColor: colors.ui,
                backgroundColor: colors.ui
            })

        }, (e) => {

            let target = this.$(e.currentTarget);
            if (!target.hasClass("active")) {
                target.removeAttr("style");
            }

        })
    }

    listenSizeClick() {

        this.$('body')
        .on(this.tapEvent, this.options.sizesItem, (e) => {

            let target = this.$(e.currentTarget);
            let url = target.data().url;
            let pid = target.data().pid;
            let id = target.closest('.product').data('pid');
            let colors = this.findColorMatrix(target.closest(this.options.gridCell));

            if (!target.hasClass("active")) {
                this.resetSelectedSize(target, id)
            }

            target.toggleClass("active");

            if (target.hasClass("active")) {

                this.setSelectedSize(pid, id);

                target.css({
                    color: colors.uiText,
                    borderColor: colors.ui,
                    backgroundColor: colors.ui
                })

            } else {
                this.productTiles.filter(product => { if (product.id === id) delete product.selectedSize; });
                target.removeAttr("style");
            }


            if (this.$(target).parents('.hidden__swatches').length) {
                this.updateSelectedSizeWithHiddenSwatch(target);
            }

            return this;
        })
    }

    updateSelectedSizeWithHiddenSwatch(target) {
        let targetCell = this.$(target)
                            .parents(this.options.gridCell);

        let sizesContainer = this.$(target)
                                .parents(this.options.sizeAttribute)
                                .find(this.options.displayableSizes);

        let sizes = this.$(sizesContainer)
                        .find(`${this.options.sizesItem}:not(.${this.options.sizeShowMoreClassName})`);


        this.$(sizes).remove();
        this.$(sizesContainer).prepend(this.$(target)[0].outerHTML);
        this.$(targetCell).removeClass(this.options.sizesOpenedClassName);

        return this;
    }

    listenBuyClick() {

        this.$('body').on(this.tapEvent, this.options.productTileBuyButton, (e) => {

            let element = this.$(e.currentTarget);
            let pid;
            let id = element.closest('.product').data('pid');

            let scopeSelected = element.closest('.product__tile-body').find('.size-item.active');

            this.productTiles.filter(product => { if (product.id === id && product.selectedSize != false && scopeSelected.length)  pid = product.selectedSize; });

            if (!pid) return;

            element.closest(this.options.gridCell).addClass("animating").off('mouseleave')
            let url = element.data().href+'?context=pay';

            this.options.productPayButton.addItem(url, pid)
            .then(async (data) => {

                this.$(document).trigger("app:gtm:addToCart", {product: data.product, currencyCode: data.currencyCode, quantity: 1});
                this.$(document).trigger("app:gtm:cartStatus", {products: data.cart ? data.cart.items : []});

                this.resetSelectedSize(element, id);

                this.options.productPayButton.refreshCart(data.cart.items, data.cart.totals.subTotal, data.cart.actionUrls.updateQuantityUrl, data.cart.actionUrls.removeProductLineItemUrl);

                this.options.productBuyButton.animateProductTileToCart(data.quantityTotal);

                await this.productBuyAnimation(element);

                this.destroy().listen();

            })
            .catch((data) => {

                this.options.toast
                .setOptions({
                    buttonOk: true,
                    buttonMsg: "Ok",
                    msgText: "Sorry! Something went wrong",
                    type: "error",
                }).openToast();
            })

        })

    }


    productBuyAnimation(element){
        return new Promise((resolve, reject) => {

            let target = element.closest(this.options.gridCell);
            let quickview = target.find(this.options.quickViewImage);
            let clone = quickview.clone();
            let counterElement = this.$(this.options.payButtonCounter);

            quickview.fadeOut('fast');

            clone.css({
                'background': target.find(this.options.productHover).css("background-color"),
                'top': quickview.offset().top,
                'left': quickview.offset().left,
                'width':quickview.outerWidth(),
                'height': quickview.outerHeight()
            });

            target.prepend(clone);
            clone.fadeIn('fast');

            let timeline = anime.timeline({
                easing: 'linear'
            });

            timeline.add({
                targets: [clone[0]],
                clipPath: ['circle(100%)', 'circle(20%)'],
                duration: 1500
            });

            timeline.add({
                targets: [clone[0]],
                width: 32,
                height: 32,
                top: `${counterElement.offset().top}px`,
                left: `${counterElement.offset().left}px`,
                duration: 500,
                complete: () => {
                    quickview.fadeIn('fast');
                    clone.remove();
                    target.removeClass("animating");
                    this.$(document).trigger('app:update:counter');
                    resolve(this);
                }
            });
        })
    }

    listenShowMoreSizesButton() {
        this.$('body').on(this.tapEvent, this.options.sizesShowMore, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.$(ev.target)
                .closest(this.options.gridCell)
                .addClass(this.options.sizesOpenedClassName);
        });

        return this;
    }

    listenSizesClose(){
        this.$('body').on(this.tapEvent, this.options.sizesCloseButton, (ev) => {
            this.$(ev.target)
                .closest(this.options.gridCell)
                .removeClass(this.options.sizesOpenedClassName);
        });

        return this;
    }

    listenShowMoreColorsButton() {
        this.$('body')
        .on(this.tapEvent, this.options.colorsShowMore, (e) => {
            let target = this.$(e.target);
            let product = target.closest('.product');
            product.addClass("colors-open");
        })
    }

    listenCloseMoreColorsButton() {
        this.$('body')
        .on(this.tapEvent, this.options.colorsShowMoreClose, (e) => {
            let target = this.$(e.target);
            let product = target.closest(this.options.product);
            product.removeClass("colors-open");
        })
    }

    listenViewMoreBtn() {
        this.$('body').on(this.tapEvent, this.options.viewMoreBtn, (e) => {

            this.getMoreProducts(this.$(e.target))
            this.keepFilter = this.$('body.is-filter-open').length ? true : false;
        })
    }

    getMoreProducts(target){

        this.options.paginationOffset += this.options.productsPerPage;

        let input;

        if (this.$(this.options.outFrame).length) {
            input = this.$(this.options.inFrame).find(this.options.showMoreProductsUrl);
        } else {
            input = this.$(this.options.showMoreProductsUrl);
        }
        let url = target.data('url');

        if (input.length) {

            url = input.data("showmore-url") || input.data("url");
            target.attr('data-url', url);

            input.remove();

        } else {

            input.remove();
            target.remove();
            return this;
        }

        const parent = target.closest(this.options.shopMode);
        const pageSearch = parent.parent();
        const pageSearchScrollTop = pageSearch.scrollTop();

        this.$.ajax({
            type: 'get',
            url: url,

            success: (data) => {

                this.$(this.options.grid).append(data);

                this.destroy().listen();

                this.rebuildIsotope();

                this.hiddenSizesBackground();

                //reset scrollTop then go to last product before click in viewMore
                pageSearch.scrollTop(pageSearchScrollTop);

                if (data && (!data.length || data.length <= 10)) this.$(this.options.viewMoreBtn).remove();
            },

            error: () => {
                this.$(this.options.viewMoreBtn).remove();
            }
        })
    }

    setDiscoveryObject(discovery) {
        this.options.discovery = discovery;
    }

    changeStoryComponents(el) {
        this.$(this.options.btnShopMode).attr('data-storyid', this.$(el).data('storyid'));
        this.$(this.options.btnShopMode).attr('data-shopmodeid', this.$(el).data('shopmodeid'));
        this.$(this.options.btnShopMode).attr('href', this.$(el).data('storyurl'));

        var colorMatrixData = this.$(el).data('backgroundui');

        var buttonImageObject = this.$(el).data('buttonimage');
        var buttonVideoObject = this.$(el).data('buttonvideo');

        if (buttonImageObject) {
            this.changeImageBtnShop(buttonImageObject, colorMatrixData);
        }

        if (buttonVideoObject) {
            this.changeVideoBtnShop(buttonImbuttonVideoObjectageObject);
        }

    }

    changeImageBtnShop(buttonImageObject, colorMatrixData) {

        var buttonImage = "";

        if (typeof (buttonImageObject) != 'undefined' && buttonImageObject) {

            if (isMobile()) {
                if (window.devicePixelRatio >= 2 && buttonImageObject.hasOwnProperty('mobileRetina')) {
                    buttonImage = buttonImageObject.mobileRetina.replace(/ /g, "%20");
                } else if (buttonImageObject.hasOwnProperty('mobile')) {
                    buttonImage = buttonImageObject.mobile.replace(/ /g, "%20");
                }
            } else {
                if (window.devicePixelRatio >= 2 && buttonImageObject.hasOwnProperty('desktopRetina')) {
                    buttonImage = buttonImageObject.desktopRetina.replace(/ /g, "%20");
                } else if (buttonImageObject.hasOwnProperty('desktop')) {
                    buttonImage = buttonImageObject.desktop.replace(/ /g, "%20");
                }
            }
        }

        if (buttonImage.length > 0) {

            this.$(this.options.btnShopMode)
            .addClass('is-shopmode shopmode-animation')
            .css({
                'background-color': `${colorMatrixData}`
            })
            .css('background-image', "url(" + buttonImage + ")");
        } else {
            this.$(this.options.btnShopMode)
            .addClass('is-shopmode shopmode-animation')
            .css({
                'background-color': `${colorMatrixData}`
            });
        }
    }

    changeVideoBtnShop(buttonVideoObject) {

        var buttonVideo = "";

        if (typeof (buttonVideoObject) != 'undefined' && buttonVideoObject) {

            if (isMobile()) {
                if (window.devicePixelRatio >= 2 && buttonImageObject.hasOwnProperty('mobileRetina')) {
                    buttonImage = buttonImageObject.mobileRetina.replace(/ /g, "%20");
                } else if (buttonImageObject.hasOwnProperty('mobile')) {
                    buttonImage = buttonImageObject.mobile.replace(/ /g, "%20");
                }
            } else {
                if (window.devicePixelRatio >= 2 && buttonImageObject.hasOwnProperty('desktopRetina')) {
                    buttonImage = buttonImageObject.desktopRetina.replace(/ /g, "%20");
                } else if (buttonImageObject.hasOwnProperty('desktop')) {
                    buttonImage = buttonImageObject.desktop.replace(/ /g, "%20");
                }
            }
        }

        if (buttonVideo.length > 0) {
            this.$(this.options.shopButtonVideo).attr('src', buttonVideo);
        }
    }

    showContent() {
        super.clearTimeout('resetShowContent').clearableWait(300, 'resetShowContent').then(() => {
            this.showShopModeTitle().then(() => {
                this.showShopModeGrid();
            });

            this.showShopModeSubTitle();
        });


        return this;
    }

    showShopModeGrid() {
        return new Promise((resolve, reject) => {
            anime({
                targets: this.options.grid,
                opacity: 1,
                top: 0,
                easing: 'cubicBezier(0.25,0.1,0.25,1)',
                duration: 600,
                complete: () => {
                    this.animatingContent = false;

                    resolve();
                }
            });
        });
    }

    showShopModeTitle() {
        const { Promise } = window;
        return Promise.all(
            this.$(this.options.btnShopModeTitle).map((i, element) => new Promise(
                resolve => {
                    if (this.$(element).hasClass(this.options.animatedClass)) return resolve();

                    anime.remove(element);

                    let titleHeight = this.$(element).height();

                    this.$(element).addClass(this.options.animatedClass);

                    this.$(element).css({
                        'height' : 0,
                        'opacity' : 1
                    });

                    anime({
                        targets: element,
                        height: titleHeight,
                        top: 0,
                        easing: 'cubicBezier(0.25,0.1,0.25,1)',
                        duration: 600,
                        complete: resolve
                    });
                }
            ))
        );
    }

    showShopModeSubTitle() {
        const { Promise } = window;

        return Promise.all(
            this.$(this.options.btnShopModeSubTitle).map((i, element) => new Promise(resolve => {
                if (this.$(element).hasClass(this.options.animatedClass)) return resolve();

                anime.remove(element);

                let subTitleHeight = this.$(element).height();

                this.$(element).addClass(this.options.animatedClass);

                this.$(element).css({
                    'height' : 0,
                    'opacity' : 1
                });

                anime({
                    targets: element,
                    height: subTitleHeight,
                    top: 0,
                    easing: 'cubicBezier(0.25,0.1,0.25,1)',
                    duration: 600,
                    complete: resolve
                });
            }))
        );
    }

    /**
     * Add hidden sizes background to ALL gridCell product
     * @returns {this} instance
     * @memberof ShopMode
     */
    hiddenSizesBackground() {
        this.$(this.options.gridCell).each(
            (i, element) => this.singleHiddenSizesBackground(this.$(element))
        );

        return this;
    }

    /**
     * Add hidden sizes background to ONE gridCell product
     * @param {JQuery} $gridCell gridCell jQuery element
     * @returns {this} Instance
     * @memberof ShopMode
     */
    singleHiddenSizesBackground($gridCell) {
        const colors = this.findColorMatrix($gridCell);

        const hiddenSizes = $gridCell.find('.size__attribute .hidden__swatches');

        this.$(hiddenSizes).css('background', colors.background);

        return this;
    }

    setPageName(pageName = "page-shop") {

        this.options.myPage = `.${pageName}`;

        return this;
    }

    scrollMyPage(scroll){
        console.log(`Scrolling to ${scroll}`);
        this.$(this.options.myPage).scrollTop(scroll)
    }

    init() {
        this.scrollMyPage(10);
        this.keepFilter = true;

        this.$(this.options.storySection)
        .first()
        .addClass("first");

        this.changeStoryComponents(this.options.firstStorySection);

        setTimeout(() => {
            this.buildIsotopeLayout(this.$(this.options.grid).first()[0]);
        }, 500)

        if (this.options.myPage == ".page-search" && this.keepFilter) {
            this.$(document).trigger("app:filter:open");
        }
        if (this.options.myPage == ".page-shop" || this.options.myPage == ".page-wishlist") {
            this.$(document).trigger("app:filter:close");
        }

        this.destroy().listen();
        return this;
    }

    listen() {
        this.options.discovery.setupShopModeActions();

        if (!isMobile()) {

            this.listenProductHover();

            this.listenShowMoreSizesButton();
            this.listenSizesClose();

            this.listenShowMoreColorsButton();
            this.listenCloseMoreColorsButton();

            this.listenColorSwatch();

            this.listenSizeClick();
            this.listenSizeHover();

            this.listenBuyClick();

            this.listenWishListChange();

            this.hiddenSizesBackground();
        }

        this.showContent();

        this.listenViewMoreBtn();
        this.setPageScrollActions();

        this.$(document)
        .on("app:filter:closing", () => {
            this.deactivateProductsHover();
        })
        .on("app:filter:closed", () => {
            setTimeout(() => {
                this.rebuildIsotope();
                this.activateProductsHover();
            }, 300)
        })
        .on("app:filter:opening", () => {
            this.deactivateProductsHover();
        })
        .on("app:filter:opened", () =>  {
            setTimeout(() => {
                this.rebuildIsotope();
                this.activateProductsHover();
            }, 300)
        });

        setTimeout(() => {
            this.activateProductsHover();
        },500)

        return this;

    }

    destroy() {

        this.$(document)
        .off("app:filter:opening")
        .off("app:filter:opened")
        .off("app:filter:closing")
        .off("app:filter:closed");

        this.$('body')
        .off(this.tapEvent, this.options.productTileWishlistBtn)
        .off(this.tapEvent, this.options.colorSwatch)
        .off(this.tapEvent, this.options.sizesItem)
        .off(this.tapEvent, this.options.productTileBuyButton)
        .off(this.tapEvent, this.options.sizesShowMore)
        .off(this.tapEvent, this.options.colorsShowMore)
        .off(this.tapEvent, this.options.colorsShowMoreClose)
        .off(this.tapEvent, this.options.viewMoreBtn)
        .off(this.tapEvent, this.options.sizesCloseButton);

        this.$(this.options.gridCell)
        .off("mouseover")
        .off("mouseleave")

        this.destroyPageScrollActions()

        return this;

    }
}
