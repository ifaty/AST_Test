import isMobile from '../../utils/isMobile';
import Debounce from '../../utils/debounce';

import MarkerClusterer from '@google/markerclustererplus';

export default class Institutional {
    constructor(options) {
        const defaultOptions = {
            selectorEngine: {},

            spoilerBlock: ".spoiler-block",
            findStore: ".findStore",
            map: "#map",
            searchResults: ".search__results-container"

        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.map = {
            map: null,
            zoom: 5,
            markers: [],
            defaultLat: -23.5551665,
            defaultLng: -46.6604785,
            bounds: null,
            markerClusterer: null
        }

        this.tapEvent = "click";
    }

    setZoom(){}

    setNewBound() {
        this.map.bounds = new google.maps.LatLngBounds();
    }

    setNewMarkerClusterer() {

        let options =  {
            styles: [
                {
                    url: window.app.resources.mapIcons.find((el, i) => el.name == "default").url,
                    textColor: 'white',
                    textSize: 40,
                    textLineHeight: 40,
                    width: 60,
                    height: 60,
                },
            ]
        }

        this.map.markerClusterer = new MarkerClusterer(this.map.map, this.map.markers, options);

    }

    removeMarkerClusterer() {

        this.map.markerClusterer.setMap(null)
    }

    setMarker(lat, lng, type){

        let icon = ((window.app.resources.mapIcons.filter((el, i) => el.name == type) || [])[0] || {}).url
        let latLng = new google.maps.LatLng(lat, lng);
        let marker = new google.maps.Marker({
            position: latLng,
            icon: icon,
            draggable: true,
            map: this.map.map
        })

        this.map.markers.push(marker);
        this.map.bounds.extend(latLng);
        this.map.map.fitBounds(this.map.bounds);

    }

    removeMarker(){

        if (this.map.markerClusterer) {
            this.removeMarkerClusterer();
        }

        this.map.markers.map((el, i) => {
            this.map.markerClusterer.removeMarker({marker: el})
            el.setMap(null);
        });

        this.map.markers = [];

        this.setNewBound();
        this.map.map.fitBounds(this.map.bounds);
    }

    searchSubmit() {
        var data = this.$('.findstore__form').serialize();
        var url = this.$('.findstore__form').attr('action');

        this.$(document).trigger('app:contextLoader:init', [{
            target: this.$(this.options.searchResults)
        }]);


        this.$.ajax({
            url: url,
            data: data,
            success: (response) => {
                this.$(this.options.searchResults).html(response);
                this.$(document).trigger('app:contextLoader:finish', [{
                    target: this.$(this.options.searchResults)
                }]);
            }
        })
    }

    searchSugestions() {
        var data = this.$('.findStore_input').val();
        var url = window.app.urls.storeSuggestions;

        this.$(document).trigger('app:contextLoader:init', [{
            target: this.$(this.options.searchResults)
        }]);

        this.$(this.options.searchResults).empty();

        this.$.ajax({
            url: url,
            type: 'get',
            data: {
                q: data
            },
            success: (response) => {
                this.$(this.options.searchResults).html(response);
                this.$(document).trigger('app:contextLoader:finish', [{
                    target: this.$(this.options.searchResults)
                }]);
            }
        })
    }

    getCities(target) {

        var url = this.$(target).data('url');

        this.$(document).trigger('app:contextLoader:init', [{
            target: this.$(this.options.searchResults)
        }]);

        this.fetchResults(url).then((response) => {

            this.removeMarker();

            this.$(this.options.searchResults).first().prepend(response);

            this.$('.search__cities .city__result')
            .map((i, el) => this.$(el).data('marker').geolocation.items)
            .map((i, el) => Object.values(el)[0].stores)
            .map((i,el) => this.setMarker(el.geolocation.latitude, el.geolocation.longitude, el.type.toLowerCase()))

            this.setNewMarkerClusterer();

            this.$(document).trigger('app:contextLoader:finish', [{
                target: this.$(this.options.searchResults)
            }]);
        })

    }

    getSublocalities(target) {

        var url = this.$(target).data('url');

        this.$(document).trigger('app:contextLoader:init', [{
            target: this.$(this.options.searchResults)
        }]);

        this.fetchResults(url).then((response) => {

            this.removeMarker();

            this.$(this.options.searchResults).first().prepend(response);

            this.$('.search__sublocalities .sublocality__result')
            .map((i, el) => this.$(el).data('marker').geolocation.stores)
            .map((i, el) => this.setMarker(el.geolocation.latitude, el.geolocation.longitude, el.type.toLowerCase()));

            this.setNewMarkerClusterer();

            this.$(document).trigger('app:contextLoader:finish', [{
                target: this.$(this.options.searchResults)
            }]);
        })

    }

    getStores(target) {

        var url = this.$(target).data('url');

        this.$(document).trigger('app:contextLoader:init', [{
            target: this.$(this.options.searchResults)
        }]);

        this.fetchResults(url).then((response) => {

            this.removeMarker();

            this.$(this.options.searchResults).first().prepend(response);

            this.$('.search__stores-detail .store__result').map((i, el) => {
                let store = this.$(el).data('marker');

                this.setMarker(store.geolocation.latitude, store.geolocation.longitude, store.type.toLowerCase());
            })

            this.setNewMarkerClusterer();

            this.$(document).trigger('app:contextLoader:finish', [{
                target: this.$(this.options.searchResults)
            }]);
        })

    }

    getStoreDetails(target) {

        var url = this.$(target).data('url');

        this.$(document).trigger('app:contextLoader:init', [{
            target: this.$(this.options.searchResults)
        }]);

        this.fetchResults(url).then((response) => {

            this.removeMarker();

            this.$(this.options.searchResults).first().prepend(response);

            let store = this.$(".store__details").data('marker');

            this.setMarker(store.geolocation.latitude, store.geolocation.longitude, store.type.toLowerCase());

            this.$(document).trigger('app:contextLoader:finish', [{
                target: this.$(this.options.searchResults)
            }]);
        })
    }

    hasLocation() {
        var location = this.$(".findStore_input").val();
        let url = window.app.urls.storeResults;

        if(location) {
            this.fetchResults(`${url}?location=${location}`).then((response) => {

                this.$(this.options.searchResults).prepend(response);

                this.$(response).find('.search__store-detail').map((i, el) => {
                    let store = this.$(el).data('marker');
                    this.setMarker(store.geolocation.latitude, store.geolocation.longitude, store.type.toLowerCase());
                });

                this.setNewMarkerClusterer();

                this.$(document).trigger('app:contextLoader:finish', [{
                    target: this.$(this.options.searchResults)
                }]);
            })
        }
    }

    backBtnListener() {
        this.$('.site-search').css('display', 'block');
        this.$('.findStore__storeImage').css('display', 'none');

        var cities = this.$('.search__cities');
        var localities = this.$('.search__localities');
        var sublocalities = this.$('.search__sublocalities');
        var stores = this.$('.search__stores-details');
        var storedetail = this.$('.store__details');

        if (storedetail.length) {
            storedetail.remove();
            return;
        } else if(stores.length) {
            stores.remove();
            return;
        } else if (sublocalities.length) {
            sublocalities.remove();
            return;
        } else if (cities.length) {
            cities.remove();
            return;
        } else if (localities.length) {
            localities.remove();
            return;
        }else {
            history.back()
        }
    }

    initMap() {
        let map = isMobile() ? this.$('.mobile-map')[0] : this.$('.desk-map')[0]
        this.map.map = new google.maps.Map(map, {
            center: new google.maps.LatLng(this.map.defaultLat,this.map.defaultLng),
            zoom: this.map.zoom,
        });
    }

    fetchResults(url) {
        return this.$.ajax({url: url})
    }

    listen() {

        this.$('body').off('click', '.findStore__back-button').on('click', '.findStore__back-button', (ev) => {
            this.backBtnListener();
        });

        this.$('body').off('submit', '.findstore__form').on('submit', '.findstore__form', (ev) => {
            ev.preventDefault();
            this.searchSubmit();
        });

        this.$('body').off('keyup', '.findStore_input').on('keyup', '.findStore_input', Debounce((ev) => {
            if (ev.key == "Enter") return;
            ev.preventDefault();
            this.searchSugestions();
        }, 400));

        this.$('body').off('click', '.locality__result').on('click', '.locality__result', Debounce((ev) => {
            this.getCities(ev.currentTarget);
        }, 400));

        this.$('body').off('click', '.city__result').on('click', '.city__result', Debounce((ev) => {
            this.getSublocalities(ev.currentTarget);
        }, 400));

        this.$('body').off('click', '.sublocality__result').on('click', '.sublocality__result', Debounce((ev) => {
            this.getStores(ev.currentTarget);
        }, 400));

        this.$('body').off('click', '.pickup__store').on('click', '.pickup__store', Debounce((ev) => {
            this.getStoreDetails(ev.currentTarget);
        }, 400));

        this.$('body').off('click', '.store__result').on('click', '.store__result', Debounce((ev) => {
            this.getStoreDetails(ev.currentTarget);
        }, 400));

        this.$('body').off('click', '.search__store-detail').on('click', '.search__store-detail', (ev) => {
            this.$('.site-search').css('display', 'none');
        });

        this.$(document).on('remove', () => {
            this.removeMarker();
        })

        this.hasLocation();
    }

    initMapsLoaded() {
        this.setNewBound();
        this.listen();
        this.initMap();
        this.setNewMarkerClusterer();

    }

    init() {
        let loadInterval = setInterval(() => {
            if (window.google.maps) {
                this.initMapsLoaded()
                clearInterval(loadInterval);
            }
        }, 100);

    }

    destroy() {
        return this;
    }
}
