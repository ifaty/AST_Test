import isMobile from '../../utils/isMobile';

export default class ShopButton {
    constructor(options) {

        const defaultOptions = {
            shopButton: '.superActions__btnShopMode',
            shopButtonWrapper: '.superActions',
            shopButtonVideo: '.superActions__btnShopMode__video',
            shopButtonHiddenClass: 'superActions__btnShopMode-hidden',
            previewWrapper: '.superActions__btnShopMode__previewStory',
            previewWrapperImage: '.superActions__btnShopMode__previewStory img',
            previewImages: [],
            previewInterval: null,

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
    }

    mouseenterShopBtn(el) {
        this.$(this.options.shopButtonWrapper).addClass('is-hovered');

        anime({
            targets: this.options.shopButton,
            scale: 1.2,
            easing: 'cubicBezier(0.25,0.1,0.25,1)',
            duration: 600
        });

        if(!this.$(this.options.shopButton).hasClass('is-shopmode')) this.animateImageCarousel();

        this.$(el).addClass('is-hovered');

        if(isMobile()) {
            setTimeout(() => {
                this.mouseleaveShopBtn(this.$(this.options.shopButton))
            }, 5000);
        }
    }

    mouseleaveShopBtn(el) {
        this.$(this.options.shopButtonWrapper).removeClass('is-hovered');

        anime({
            targets: this.options.shopButton,
            scale: 1,
            easing: 'cubicBezier(0.25,0.1,0.25,1)',
            duration: 600
        });

        this.stopImageCarousel();

        this.$(el).removeClass('is-hovered');
    }

    changePreviewImages(images) {
        this.options.previewImages = images;
    }

    changeImageAndVideo(image, video) {
        this.$(this.options.shopButton)
            .attr('style', `background-image: url("${image}");`);
        this.$(this.options.shopButtonVideo).attr('src', video);
    }

    changeUrl(url) {
        this.$(this.options.shopButton).attr('href', url);
    }

    hide() {
        this.$(this.options.shopButton).addClass(this.options.shopButtonHiddenClass);
    }

    show() {
        this.$(this.options.shopButton).removeClass(this.options.shopButtonHiddenClass);
    }

    // TODO: MAKE THIS USE AN ANIMATION LIBRARY
    // WARNING: VERY RUDIMENTARY
    animateImageCarousel() {
        let idx = 0;
        const
            images = this.options.previewImages,
            bgImage = this.$(this.options.previewWrapper);

        bgImage.css('background-image', `url(${images[0]})`);

        this.options.previewInterval = window.setInterval(function () {
            idx = idx + 1 >= images.length ? 0 : idx + 1;
            bgImage.css('background-image', `url(${images[idx]})`);
        }, 800);
    }

    stopImageCarousel() {
        clearInterval(this.options.previewInterval);
    }

    resetDefaultSettings() {
        this.$(this.options.shopButton)
            .removeClass('is-shopmode')
            .removeAttr('style');
    }

    changeShopButtonColor(color) {
        anime({
            targets: this.options.shopButton,
            color,
            easing: 'linear',
            duration: 300,
        });
    }

    listen() {
        this.$(document).trigger('app:contextLoader:finish');

        if(!isMobile()) {
            this.$(this.options.shopButton).on('mouseenter', (ev) => {
                this.mouseenterShopBtn(ev.currentTarget);
            });

            this.$(this.options.shopButton).on('mouseleave', (ev) => {
                this.mouseleaveShopBtn(ev.currentTarget);
            });
        } else {
            // setTimeout to wait rainbow animation before start button animation
            setTimeout(() => {
                this.mouseenterShopBtn(this.$(this.options.shopButton));

                let
                    mouseenterInterval = window.setInterval(() => {
                        this.mouseenterShopBtn(this.$(this.options.shopButton))
                    }, 15000);

                // if user interact clear intervals
                this.$(document).on('app:frame:ready', () => {
                    clearInterval(mouseenterInterval);
                });

            }, 5000)
        }
    }
}
