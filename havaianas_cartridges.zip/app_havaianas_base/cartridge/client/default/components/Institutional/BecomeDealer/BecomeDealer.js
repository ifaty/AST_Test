
import debounce from '../../../utils/debounce';
import isMobile from '../../../utils/isMobile';
export default class BecomeFranchisee {
    constructor(options) {

        const defaultOptions = {
            dealerForm: '#becomeDealerForm',
            contactFloatingLabel: '.contact__floating-label',
            customFloatingLabel: '.js-custom__select--active',
            customFloatingLabelClass: 'js-custom__select--active',
            customSelectLabel: '.custom__select-floating-label',
            cleanCustomSelected: ".custom__select-content > .custom__select-choosen-item",
            customSelectContent: ".custom__select-content",
            customSelectHiddenInput: ".custom__select-hidden-input",
            customSelectDrawerItem: ".custom__select-drawer-items",
            customChoosenItem: '.custom__select-choosen-item',
            formInputs: '.form-control',
            inputZipCode: '#zipcode',
            inputStreet: '#street',
            inputNeighborhood: '#neighborhood',
            inputCity: '#city',
            inputState: '#state',
            inputPhone: '#phone',
            inputEmail: '#email',
            invalidFeedback: '.invalid-feedback',
            iconAlert: '.icon-alert',
            submitBtn: '.submit__dealer',
            menu: '.menu',
            selectorEngine: {},
            toast: {},
        };

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.watching = false;
    }

    submitDealerListener() {
        if (!this.options.validator.validateForm(this.$(this.options.dealerForm), true)) {
            return;
        }

        this.$.ajax({
            url: this.$(this.options.dealerForm).attr('action'),
            type: 'post',
            dataType: 'json',
            data: this.$(this.options.dealerForm).serialize(),
            success: (data) => {
                if (data.success) {
                    this.options.toast.setOptions({
                        msgText: data.sucessMessage,
                        positionX: "left"
                    }).openToast();

                    this.$(this.options.dealerForm).trigger('reset');
                    this.$(this.options.contactFloatingLabel).removeClass('active').addClass('empty');
                    this.$(this.options.customSelectLabel).removeClass(this.options.customFloatingLabelClass);
                    this.$(this.options.cleanCustomSelected).html('');
                    this.$(this.options.submitBtn).removeClass('is-active').attr('disable', 'disable');
                    this.$(this.options.invalidFeedback).html('');

                    this.$(this.options.menu).animate({
                        scrollTop: 0
                    }, 'slow');

                } else {
                    this.options.validator.validateForm(this.$(this.options.dealerForm), true, data.fields);

                    if (this.$(this.options.dealerForm).find(this.options.iconAlert).length > 0) {
                        this.$(this.options.dealerForm).find(this.options.iconAlert).first()[0].scrollIntoView({
                            behavior: "smooth",
                            block: "center"
                        })
                    }

                    this.options.toast.setOptions({
                        msgText: data.msg,
                        positionX: "left"
                    }).openToast();
                }
            },
            error: () => {
                this.options.toast
                    .setOptions({
                        type: "error",
                        msgText: "Sorry! something went wrong."
                    })
                    .openToast();
            }
        });
        return false;
    }

    verifyPostalCode() {
        let inputPostalCode = this.$(this.options.inputZipCode);
        let patternCEP = inputPostalCode.attr('pattern');
        let cep = inputPostalCode.val();
        let regexCEP = cep.match(patternCEP);
        let minLenght = inputPostalCode.attr('minlength');

        // removes all characters that are not numbers or -
        let regexLetter = cep.substring(cep.length - 1).match(/^[0-9]?-?$/);

        if(!regexLetter) {
            inputPostalCode.val(cep.substring(0, cep.length - 1));
            return;
        }

        if(!cep.length) return;

        if(cep.length >= minLenght && regexCEP) {
            this.options.validator.clearForm(this.options.dealerForm);
            this.submitAutoCompleteAddress(cep);
        }
    }

    submitAutoCompleteAddress(zipCode) {
        let url = window.app.urls.autoCompleteAddress;
        this.$.ajax({
            type: 'GET',
            url: url,
            data: {
                postalCode: zipCode
            },
            success: (data) => {
                if (data.success) {
                    this.$(this.options.inputZipCode).val(zipCode);
                    this.checkFloatingLabel(this.options.inputZipCode);
                    this.$(this.options.inputStreet).val(data.address.address);
                    this.checkFloatingLabel(this.options.inputStreet);
                    this.$(this.options.inputNeighborhood).val(data.address.bairro);
                    this.checkFloatingLabel(this.options.inputNeighborhood);
                    this.$(this.options.inputCity).val(data.address.city);
                    this.checkFloatingLabel(this.options.inputCity);
                    this.$(this.options.inputState).val(data.address.uf);
                    this.checkFloatingLabel(this.options.inputState);
                }
                else {
                    this.options.toast
                        .setOptions({
                            type: 'error',
                            buttonMsg: 'Close',
                            msgText: JSON.stringify(data.errorMsg)
                        })
                        .openToast();
                }
            },
            error: () => {
                this.options.toast
                    .setOptions({
                        buttonOk: true,
                        buttonMsg: "Ok",
                        msgText: "Sorry! Something went wrong",
                        type: "error",
                    }).openToast();
            }
        });
    }

    validateDealerForm(form, button) {
        if(this.options.validator.validateForm(this.$(form))) {
            this.$(button).addClass('is-active matrixTxtAsBgColor').removeAttr("disabled");
        } else {
            this.$(button).removeClass('is-active matrixTxtAsBgColor').attr( "disabled", "disabled" );
        }
    }

    activeSubmitButton(form, button) {
        this.$(form).find(this.options.formInputs).on('keyup change', () => {
            this.validateDealerForm(form, button);
        });
    }

    checkFloatingLabel(input) {
        if (this.$(input).val().length >= 1) {
            this.$(input).siblings(this.options.contactFloatingLabel).removeClass('empty').addClass('active');
        } else {
            this.$(input).siblings(this.options.contactFloatingLabel).removeClass('active').addClass('empty');
        }
    }

    checkValues(input) {
        let errors = this.options.invalidFeedback;

        this.$(input).on('blur', function(e) {
            if ($(e.currentTarget).attr("pattern")) {
                let error = $(e.currentTarget).data("pattern-mismatch");
                let pattern = $(e.currentTarget).attr("pattern");

                if (this.value.match(pattern)) {
                    $(this).siblings(errors).html("");
                } else {
                    $(this).siblings(errors).html(`<i class="icon-alert"></i> <span>${error}</span>`);
                }
            } else {
                let error = $(e.currentTarget).data("missing-error");
                if (this.value != '') {
                    $(this).siblings(errors).html("");
                } else {
                    $(this).siblings(errors).html(`<i class="icon-alert"></i> <span>${error}</span>`);
                }
            }
        });

    }

    listen() {

        if(this.watching) return this.reload();

        this.$(document).on('app:form:becomeDealerCaptcha', () => {
            this.validateDealerForm(this.options.dealerForm, this.options.submitBtn);
            dealerSubmitDebounced();
        });

        let dealerSubmitDebounced = debounce(() => {
            this.submitDealerListener();
        }, 800, true);

        this.watching = true;

        this.$(this.options.formInputs).on('click blur', (ev) => {
            this.checkFloatingLabel(ev.target);
            this.checkValues(ev.target);
            this.activeSubmitButton(this.options.dealerForm, this.options.submitBtn);
        });

        let debouncePostalCode = debounce((ev) => {
            if (ev.key == 'Control' || ev.key == 'Shift' || ev.ctrlKey || ev.shiftKey) return this;

            this.verifyPostalCode();
        }, 300);

        this.$(this.options.inputZipCode).on("keyup paste", debouncePostalCode);

        this.$(this.options.inputZipCode).on('blur', () => {
            this.verifyPostalCode(true);
        });

        return this;
    }

    reload() {

        this.watching = false;

        return this.destroy().listen();
    }

    // Any event used by the class, must be disabled
    destroy() {
        this.$(this.options.dealerForm).off('submit');

        return this;
    }


}
