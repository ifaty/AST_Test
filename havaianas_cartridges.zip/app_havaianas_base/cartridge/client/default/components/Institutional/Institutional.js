import isMobile from '../../utils/isMobile';
export default class Institutional {
    constructor(options) {
        const defaultOptions = {
            selectorEngine: {},

            spoilerBlock: ".spoiler-block",
            spoilerContent: ".spoiler-content",
            spoilerTitle: ".faq__modalcontainer-main--question",
            faqReviewLike: ".js-review-block-like",
            faqReviewDeslike: ".js-review-block-deslike",
            submitContactBtn: ".contact__submit",
            contactReceivedWrapper: "contact__received",
            hiddenClass: 'institutional__hidden',

            drawerlabelClick: '.choose-installment',
            installmentNumber: '.installment__number',
            labelinstallment: '.checkout__cc-label.inside_drawer',
            installmentBox: '.checkout__cc-form-group.installment',

            installmentDrawer: '.installment-drawer',

            changeBillingAddressCheckBox: '.payment-options__billing-address__checkbox',
            quickQuestionsLabel: '.quick-questions-group_label',

            inputBusinessState: '#businessState',
            inputBusinessCity: '#businessCity',
            inputEmail: '#email',
            firstInputGroup: '.institutional__hidden_firstGroup',
            secondInputGroup: '.institutional__hidden_secondGroup',

            spoilerDropdown: '.spoiler-title',

            footerContent: '#footercontent',
            footerItem: '.footer__item',
            menuClass: '.menu'

        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";
    }


    toggleFaqReviewLike(el) {
        this.$(el).toggleClass("js-review-block-likeFull");
    }

    toggleFaqReviewDeslike(el) {
        this.$(el).toggleClass("js-review-block-deslikeFull");

    }
    updateContactPage(form) {
        this.$(form).toggleClass(hiddenClass);
        this.$(form).parent().find(this.options.contactReceivedWrapper).toggleClass(hiddenClass);
    }

    submitContactForm(el) {
        var form = this.$(el).closest('form');
        form.submit(function() { // catch the form's submit event
            $.ajax({ // create an AJAX call...
                data: $(this).serialize(),
                type: $(this).attr('method'),
                url: $(this).attr('action'),
                success: function(data) {
                    if (data.success) {
                        this.updateContactPage(this);
                    } else {
                        this.options.validator.validateForm(this, true, data.fields);
                    }
                }
            });
            return false;
        });
    }

    submitButtonListener() {
        this.$(document).on(this.tapEvent, this.options.submitContactBtn, (ev) => {
            ev.preventDefault();
            this.submitContactForm(ev.currentTarget);
        });
    }

    openDrawerCheckout() {
        this.$(this.options.installmentDrawer).addClass("drawer--isOpen")
        this.$(this.options.labelinstallment).css("display", "block");
        this.$(this.options.installmentNumber).addClass("installment__number-show")

        setTimeout(() => {
            this.$(this.options.installmentDrawer).addClass("drawer--isVisible")
        }, 200);

        this.isDrawerOpen = true;
    }

    closeDrawerCheckout() {
        if(isMobile()) {
            this.$(this.options.installmentDrawer)
                .removeClass("drawer--isOpen")
                .removeClass("drawer--isVisible")

            this.isDrawerOpen = false;
        } else {
            this.$(this.options.installmentDrawer).css("display", "none");
            this.$(this.options.installmentBox).removeClass("dropdown-label");
            this.$(this.options.drawerlabelClick).removeClass("installment-drawer");
            this.$(this.options.drawerlabelClick).css("display", "block");
        }
    }

    checkRadioBtn(ev) {
        this.$(ev.currentTarget).closest(this.options.quickQuestionsLabel).find(this.options.changeBillingAddressCheckBox).removeClass('is-active');
        this.$(ev.currentTarget).stop().toggleClass('is-active');
    }

    openDescription(ev) {
        this.$(ev.currentTarget).siblings(this.options.spoilerContent).slideToggle();
        this.$(ev.currentTarget).toggleClass('spoiler__is-open');
    }

    showFooter() {
        this.$(this.options.footerContent).show();
    }

    footerLinks() {
        this.$(this.options.footerItem).on(this.tapEvent, () => {
            this.$(this.options.menuClass).animate({
                scrollTop: 0
            })
        })
    }

    listen() {

        this.$('body').off(this.tapEvent, this.options.spoilerDropdown).on(this.tapEvent, this.options.spoilerDropdown, (ev) => {
            this.openDescription(ev);
        });

        this.$('body').on(this.tapEvent, this.options.spoilerContent, (ev) => {
            ev.stopPropagation();
        });

        this.$('body').on(this.tapEvent, this.options.faqReviewLike, (ev) => {
            this.toggleFaqReviewLike(ev.currentTarget);
        });

        this.$('body').on(this.tapEvent, this.options.faqReviewDeslike, (ev) => {
            this.toggleFaqReviewDeslike(ev.currentTarget);
        });

        //Dropdown input OPEN
        this.$('body').on(this.tapEvent, this.options.installmentBox, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            if (isMobile()) {
                this.openDrawerCheckout();
            } else {
                let target = this.$(ev.currentTarget);
                target.find(this.options.installmentDrawer).removeClass("drawer");
                target.find(this.options.installmentDrawer).css("display", "block");
                target.find(this.options.drawerlabelClick).css("display", "none");
                target.addClass("dropdown-label");
            }
        });

        //Dropdown input CLOSE
        this.$('body').on(this.tapEvent, this.options.installmentNumber, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            let target = this.$(ev.currentTarget);
            let parent = target.closest(this.options.installmentBox);

            const installmentsText = target.text();
            const installmentValue = parseInt(target.data('installmentnumbers'));

            parent.find(this.options.drawerlabelClick).html(installmentsText);
            parent.find(this.options.installmentInput).val(installmentValue);

            this.closeDrawerCheckout();
            this.$(document).trigger('app:checkout:verifyShippingForm');
        });

        this.$('body').on(this.tapEvent, this.options.changeBillingAddressCheckBox, (ev) => {
            this.checkRadioBtn(ev);
        });


        this.$(this.options.accountInput).each((i, element) => {
            this.floating(element);
        });

        this.showFooter();

        this.footerLinks();

        this.$(document).trigger("app:rainbow:collapse");

        if (isMobile()) this.$(document).trigger("app:submenu:collapse");
    }

    destroy() {

        this.$('body')
        .off(this.tapEvent, this.options.spoilerDropdown)
        .off(this.tapEvent, this.options.spoilerContent)
        .off(this.tapEvent, this.options.faqReviewLike)
        .off(this.tapEvent, this.options.faqReviewDeslike)
        .off(this.tapEvent, this.options.installmentBox)
        .off(this.tapEvent, this.options.installmentNumber)
        .off(this.tapEvent, this.options.footerItem);

        return this;
    }
}
