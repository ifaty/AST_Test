import isMobile from '../../../utils/isMobile';

export default class faq {
    constructor(options) {
        const defaultOptions = {
            selectorEngine: {},

            reviewLink: ".js-review-link",
            reviewBlock: ".js-review-block",
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";
    }

    readCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for(var i=0;i < ca.length;i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1,c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
        }
        return null;
    }

    handleIcons(){

        let reviews = this.readCookie('hav_faq_reviews');
        let links = this.options.reviewLink;

        if( reviews ){

            try {
                reviews = JSON.parse(reviews);
                let questions = Object.keys(reviews.questions);

                questions.forEach(function (question) {

                    $(`${links}[data-question='${question}'][data-review='${reviews.questions[question].review}']`).addClass('is-active');

                });

            }catch (e) {
                console.error(e);
            }
        }
    }

    sendReview(event, target) {
        event.preventDefault();
        event.stopPropagation();

        let options = this.options;
        let self = this;
        let linkElement = this.$(target);
        let url = linkElement.data('url');

        $.ajax({
            url: url,
            type: 'POST',
            dataType: 'json',
            data: {
                question: linkElement.data('question'),
                review: linkElement.data('review'),
                cookieReviews: self.readCookie('hav_faq_reviews')
            },
            success: (data) => {

                if (data.success) {

                    linkElement.addClass('is-active');
                    document.cookie = 'hav_faq_reviews='+JSON.stringify(data.reviews);

                }else{

                    this.options.toast.setOptions({
                        type: 'error',
                        msgText: data.msg
                    })
                }

            },

            error: () => {

                options.toast
                    .setOptions({
                        type: 'error',
                        msgText: "Sorry! something went wrong."
                    })
                    .openToast();
            }
        });
        return false;
    }


    listen() {

        this.$(document).on(this.tapEvent, this.options.reviewLink, (event) => {
            this.sendReview(event, event.target);
        });

        this.handleIcons();
    }
}
