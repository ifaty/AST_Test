export default class GoogleTagManager {

    constructor(options){

        const defaultOptions = {
            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

    }

    pushCartStatus(data) {

        /////////////////// @payload
        // {
        //     'products': [
        //         {
        //             'name': 'Havaianas Brasil Logo',
        //             'id': '4110850_0001',
        //             'price': '34.90',
        //             'category': 'Chinelo',
        //             'variant': '4110850_0001_234',
        //             'quantity': 1
        //         },
        //         {
        //             'name': 'Havaianas Slim Sparkle',
        //             'id': '4144734_0001',
        //             'price': '55.99',
        //             'category': 'Chinelo',
        //             'variant': '4144734_0001_356',
        //             'quantity': 1
        //         }
        //     ]
        // }

        try {
            let products = data.products.map((el, i) => {
                let product = {
                    name: el.productName,
                    id: el.selectedVariationGroupID,
                    price: el.price.list ? el.price.list.decimalPrice : el.price.sales.decimalPrice,
                    category: el.category,
                    variant: el.id,
                    quantity: 1,
                }

                return product;
            })

            let pushEvent = {
                'event': 'cartStatus',
                'currentCart': products
            }

            window.dataLayer.push(pushEvent);


        } catch (e) {

            console.warn("GTM catch:",  e);

        }

        return this;

    }

    pushLoginStatus(data) {

        /////////////////// @payload
        // {
        //     'user': {
        //         'id': '123456', // Internal id. Can NOT be PII (personally identifiable information) like CPF or email
        //         'email': 'example@email.com',
        //         'name': 'Full name here'
        //     }
        // }

        try {

            let user = {
                id: data.user.id,
                email: data.user.email,
                name: data.user.lastName
            }

            let pushEvent = {
                'event': 'loginStatus',
                'userId': user.id,
                'email': user.email,
                'name': user.name
            }

            window.dataLayer.push(pushEvent);


        } catch (e) {
            console.warn("GTM catch:",  e);
        }

        return this;

    }

    pushAddToCart(data) {

        /////////////////// @payload
        // {
            // 'product': {
            //     'name': 'Havaianas Brasil Logo',
            //     'id': '4110850_0001',
            //     'price': '34.90',
            //     'category': 'Chinelo',
            //     'variant': '4110850_0001_234',
            //     'quantity': 1
            // },
            // 'currencyCode': 'BRL'
        // }

        try {

            let product = {
                name: data.product.productName,
                id: data.product.selectedVariationGroupID,
                price: data.product.price.list ? data.product.price.list.decimalPrice : data.product.price.sales.decimalPrice,
                category: data.product.category,
                variant: data.product.id,
                quantity: data.quantity
            }

            let pushEvent = {
                'event': 'ga_enhanced_ecommerce_data_ready',
                'ecommerce': {
                    'currencyCode': data.currencyCode,
                    'add': {
                        'products': [{
                            'name': product.name,
                            'id': product.id,
                            'price': product.price,
                            'category': product.category,
                            'variant': product.variant,
                            'quantity': product.quantity
                        }]
                    }
                }
            }

            window.dataLayer.push(pushEvent);


        } catch (e) {

            console.warn("GTM catch:",  e);

        }

        return this;
    }

    pushRemoveFromCart(data) {

        /////////////////// @payload
        // {
            // 'product': {
            //     'name': 'Havaianas Brasil Logo',
            //     'id': '4110850_0001',
            //     'price': '34.90',
            //     'category': 'Chinelo',
            //     'variant': '4110850_0001_234',
            //     'quantity': 1
            // },
            // 'currencyCode': 'BRL'
        // }

        try {

            let product = {
                name: data.product.productName,
                id: data.product.selectedVariationGroupID,
                price: data.product.price.list ? data.product.price.list.decimalPrice : data.product.price.sales.decimalPrice,
                category: data.product.category,
                variant: data.product.id,
                quantity: data.quantity
            }

            let pushEvent = {
                'event': 'ga_enhanced_ecommerce_data_ready',
                'ecommerce': {
                    'currencyCode': data.currencyCode,
                    'remove': {
                        'products': [{
                            'name': product.name,
                            'id': product.id,
                            'price': product.price,
                            'category': product.category,
                            'variant': product.variant,
                            'quantity': product.quantity
                        }]
                    }
                }
            }

            window.dataLayer.push(pushEvent);

        } catch (e) {

            console.warn("GTM catch:",  e);

        }

        return this;
    }

    pushTransactionDone(data) {

        /////////////////// @payload
        // {
        //     'purchase': {
        //         'actionField': {
        //             'id': 'HVBR00001508',
        //             'revenue': '136.29', // Total transaction value (including shipping)
        //             'shipping': '10.50',
        //             'coupon': 'SUMMER_SALE'
        //         },
        //         'products': [{
        //             'name': 'Havaianas Brasil Logo',
        //             'id': '4110850_0001',
        //             'price': '34.90',
        //             'category': 'Chinelo',
        //             'variant': '4110850_0001_234',
        //             'quantity': 2
        //         },
        //         {
        //             'name': 'Havaianas Slim Sparkle',
        //             'id': '4144734_0001',
        //             'price': '55.99',
        //             'category': 'Chinelo',
        //             'variant': '4144734_0001_356',
        //             'quantity': 1
        //         }]
        //     }
        // }


        try {

            if (!data.orderDetails || !data.orderId) {
                throw new Error("missing orderDetails and orderID");
            }

            let products = data.orderDetails.items.items.map((el, i) => {
                let product = {
                    name: el.productName,
                    id: el.selectedVariationGroupID,
                    price: el.price.list ? el.price.list.decimalPrice : el.price.sales.decimalPrice,
                    category: el.category,
                    variant: el.id,
                    quantity: el.quantity
                }

                return product;
            });

            let purchase = {
                products: products,
                actionField: {
                    id: data.orderId,
                    revenue: Number(data.orderDetails.totals.subTotal.replace(',' , '.').replace(/[^0-9.-]+/g,"")).toString(),
                    shipping: Number(data.orderDetails.totals.totalShippingCost.replace(',' , '.').replace(/[^0-9.-]+/g,"")).toString(),
                    coupon: ''
                }
            }

            let pushEvent = {
                'event': 'ga_enhanced_ecommerce_data_ready',
                'ecommerce': {
                    'purchase': {
                        'actionField': purchase.actionField,
                        'products': purchase.products
                    }
                }
            }

            window.dataLayer.push(pushEvent)
            this.pushCartStatus({products: []});

        } catch (e) {

            console.warn("GTM catch:", e);

        }

        return this;
    }


    listen(){

        this.$(document).on("app:gtm:cartStatus", (ev, data) => {
            this.pushCartStatus(data);
        })

        this.$(document).on("app:gtm:loginStatus", (ev, data) => {
            this.pushLoginStatus(data);
        })

        this.$(document).on("app:gtm:addToCart", (ev, data) => {
            this.pushAddToCart(data);
        })

        this.$(document).on("app:gtm:removeFromCart", (ev, data) => {
            this.pushRemoveFromCart(data);
        })

        this.$(document).on("app:gtm:transactionDone", (ev, data) => {
            this.pushTransactionDone(data);
        })

        return this;

    }
}
