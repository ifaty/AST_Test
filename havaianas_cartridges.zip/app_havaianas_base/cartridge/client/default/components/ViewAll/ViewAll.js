import isMobile from '../../utils/isMobile';
import inView from 'in-view-custom';
import throttle from '../../utils/throttle';
import scrollMagic from 'scrollmagic';
// import 'scrollmagic/scrollmagic/minified/plugins/debug.addIndicators.min';

export default class ViewAll {
    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},

            body: "body",
            page: ".container.page-viewAll",
            shape: ".shape",

            viewAllWrapper: '.view-all .content-noRainbow',
            storyOdd: '.story-item.odd',
            storyItem: '.story-item',
            storieSection: '.view-all__section',
            activeStorieSection: '.story-item.in-viewport',
            colorMatrix: '.color-matrix',

            viewAllWrapper: ".view-all .content-noRainbow",
            viewAllbgContent: '.view-all-content',
            viewAllbg: '.view-all-background',
            viewAllContainer: '#view-all.view-all',
            footerContent: '#footercontent',
            pagesViewport: '.pages-viewport',
            btnViewMoreStoryTiles: '.btn__view-more-story-tiles',
            btnShopMode: ".superActions__btnShopMode",
            showMoreLink: '.show__more-link',
            paginationOffset: 0,
            storiesPerPage: 6,

            storyLink: '.view-all__link',
            btnShopMode: '.superActions__btnShopMode'

        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";

        this.viewportWidth = this.$("body").outerWidth();
        this.colDesk = this.viewportWidth / 79;
        this.scrollMagicController = null;
        this.currentColorMatrix = null;

        this.chosenColorsGradient = [];
        this.bgHeader = '';
        this.bgFooter = '';

    }

    setOffset(offset) {
        this.options.paginationOffset += offset;
    }

    cerateViewAllBackground() {

        this.$(this.options.viewAllContainer).wrap("<div class='view-all-background'></div>");
        this.$(this.options.viewAllbg).append(this.$(this.options.footerContent));
        this.$(this.options.viewAllbg).wrap("<div class='view-all-content'></div>");

    }

    generateArrayColorsGradient() {
        this.chosenColorsGradient = [];

        this.$(this.options.storieSection).each((i, index) => {
            if (i % 2 == 0) {
                this.chosenColorsGradient.push(this.$(index).attr("data-bodyBackground"));
            }
        });
    }

    generateBackgroundGradient() {
        let gradient = this.chosenColorsGradient.join(",");

        this.bgHeader = gradient.split(',');
        this.bgHeader = this.bgHeader[0];

        this.bgFooter = gradient.split(',');
        this.bgFooter = this.bgFooter[this.bgFooter.length - 1];

        gradient = this.bgHeader + ',' + gradient + ',' + this.bgFooter;

        this.currentBackgroundColor = `linear-gradient(180deg,${gradient})`;

        this.$(this.options.viewAllbg).css({
            background: this.currentBackgroundColor
        });
        this.$(this.options.viewAllbgContent).css({
            background: this.currentBackgroundColor
        });

    }

    storyHover() {
        this.$('body')
            .on("mouseenter", this.options.storieSection, (ev) => {
                let color = this.$(ev.currentTarget).find('.color-matrix')
                this.$(document).trigger("app:colors:setcolors", color);
            })
            .on('mouseleave', this.options.storieSection, (ev) => {
                this.$(document).trigger("app:colors:setcolors", this.currentColorMatrix);
            })

        return this;
    }

    storyBackgroundColor(stories) {
        this.$(stories).each((i, elem) => {
            elem = this.$(elem)

            if (elem.data('colorbackground')) {
                let color = elem.data('colorbackground');
                elem.find(this.options.shape).css({
                    backgroundColor: color,
                    backgroundImage: 'none'
                });
            }
        });

        return this;
    }

    buildLoadMoreStoryTile() {
        var url = this.$(this.options.btnViewMoreStoryTiles).data("url");
        return url;
    }

    getMoreStoryTiles() {

        let lastStory = this.$(this.options.storyItem).last();

        this.$(document).trigger('app:contextLoader:init', [{
            target: this.$(this.options.page)
        }]);

        this.options.frame.setTargetToAppend(this.options.viewAllWrapper);
        this.options.frame.loadPage(this.buildLoadMoreStoryTile())
            .then(() => {

                this.$(this.options.page).animate({
                    scrollTop: this.$(this.options.page).scrollTop() + lastStory.nextAll(this.options.storyItem).first().offset().top
                });

                this.$(this.options.showMoreLink).eq(0).remove();

                this.$(document).trigger('app:contextLoader:finish');

                this.destroy().listen();

            }).catch((error) => this.$(this.options.showMoreLink).remove())

        return this;
    }

    viewMoreButtonListener() {
        this.$('body')
            .on(this.tapEvent, this.options.btnViewMoreStoryTiles, (ev) => this.getMoreStoryTiles());

        return this;
    }

    setStorySectionScenes() {

        this.scrollMagicController = new scrollMagic.Controller({
            container: '.container.page-viewAll'
        });

        let stories = isMobile() ? this.options.storyItem : this.options.storyOdd;

        // loop on story sections to create scene for each one to scroll magic
        this.$(stories).map((i, el) => {

            let scene = new scrollMagic.Scene({
                    triggerElement: el,
                    triggerHook: 0.5,
                    duration: this.$(el).outerHeight()
                })
                .addTo(this.scrollMagicController)
                // .addIndicators()
                .on("enter", (e) => {

                    let target = this.$(e.target.triggerElement());
                    target.addClass("in-viewport");

                    this.currentColorMatrix = target.find(".color-matrix");
                    this.$(document).trigger("app:colors:setcolors", this.currentColorMatrix);

                    this.$(this.options.btnShopMode).attr("href", target.find(this.options.storieSection).data('shopmodeurl'));


                })
                .on("leave", (e) => {

                    let target = this.$(e.target.triggerElement());
                    target.removeClass("in-viewport");

                })

        })

        return this;
    }

    destroyPageScrollActions() {

        if (this.scrollMagicController) {
            this.scrollMagicController.destroy(true);
        }

        return this;

    }

    init() {

        return this;
    }

    listen() {
        this.storyHover();
        this.viewMoreButtonListener();

        this.setStorySectionScenes();

        return this;
    }

    destroy() {

        this.$('body')
            .off('mouseenter', this.options.storieSection)
            .off('mouseleave', this.options.storieSection)
            .off(this.tapEvent, this.options.btnViewMoreStoryTiles)
            .off(this.tapEvent, this.options.storyLink);

        this.destroyPageScrollActions();

        return this;

    }


}