import isMobile from '../../utils/isMobile';

export default class LightBox {
    constructor(options) {

        const defaultOptions = {
            lightboxContainer: '.lightbox-container',
            lightboxImages: '.lightbox-container__images',
            lightboxArrows: '.lightbox-container__arrows',
            lightboxArrow: '.lightbox-container__arrow',
            lightboxClose: '.lightbox-container__close',
            lightboxCounter: '.lightbox-container__counter',
            lightboxCounterTotal: '.lightbox-container__counter-total',
            lightboxCounterCurrent: '.lightbox-container__counter-current',

            //Classes
            lightbox: 'lightbox',
            currentImage: 'active',
            nextImage: 'is-next',
            previousImage: 'is-previous',

            selectorEngine: {}
        }

        this.tapEvent = isMobile() ? "tap" : "click";

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.touchstartX = 0;
        this.touchstartY = 0;
        this.touchendX = 0;
        this.touchendY = 0;
    }

    openLightBox() {
        this.$(this.options.lightboxImages).children().eq(0).addClass('active');
        this.$(this.options.lightboxImages).children().eq(1).addClass('is-next');
        this.$(this.options.lightboxContainer).fadeIn(300);
    }

    closeLightBox() {
        this.$(this.options.lightboxContainer).fadeOut(300);
        this.resetDefaults();
    }

    setImages(parent) {
        const lightboxImages = this.$(this.options.lightboxImages);
        lightboxImages.html('');

        parent.find(`.${this.options.lightbox}`).each((ev, item) => {
            const image = this.$(item).clone().removeClass(this.options.lightbox);
            lightboxImages.append(image);
        });

        const totalImages = lightboxImages.children().length;

        this.$(this.options.lightboxCounterCurrent).html('1');
        this.$(this.options.lightboxCounterTotal).html(totalImages);

        if(totalImages > 1) {
            this.$(this.options.lightboxCounter).fadeIn();

            if(!isMobile()) this.$(this.options.lightboxArrows).fadeIn();
        }

        this.openLightBox();
    }

    resetDefaults() {
        this.$(this.options.lightboxCounter).fadeOut();
        this.$(this.options.lightboxArrows).fadeOut();
    }

    changeImage(next = false) {
        const nextImage = this.$(this.options.lightboxImages).find(`.${this.options.nextImage}`);
        const currentImage = this.$(this.options.lightboxImages).find(`.${this.options.currentImage}`);
        const previousImage = this.$(this.options.lightboxImages).find(`.${this.options.previousImage}`);

        let counter = parseInt(this.$(this.options.lightboxCounterCurrent).html());

        if(next) {
            if(!currentImage.next().length) return;

            counter++;
            nextImage.next().addClass(this.options.nextImage);
            nextImage.addClass(this.options.currentImage).removeClass(this.options.nextImage);
            currentImage.addClass(this.options.previousImage).removeClass(this.options.currentImage);
            previousImage.removeClass(this.options.previousImage);
        } else if(!next) {
            if(!currentImage.prev().length) return;

            counter--;
            previousImage.prev().addClass(this.options.previousImage);
            previousImage.addClass(this.options.currentImage).removeClass(this.options.previousImage);
            currentImage.addClass(this.options.nextImage).removeClass(this.options.currentImage);
            nextImage.removeClass(this.options.nextImage);
        }

        this.$(this.options.lightboxCounterCurrent).html(counter);
    }

    getTouches(ev) {
        return ev.touches[0] || ev.changedTouches[0];
    }

    listenSwipe() {
        const lightboxImages = this.options.lightboxImages;

        let touchstartX = 0;
        let touchendX = 0;
        let moving = false;

        document.querySelector(lightboxImages).addEventListener('touchstart', (ev) => {
            touchstartX = this.getTouches(ev).clientX;
        }, false);

        document.querySelector(lightboxImages).addEventListener('touchmove', (ev) => {
            moving = true;
        }, false);

        document.querySelector(lightboxImages).addEventListener('touchend', (ev) => {
            if(!moving) return;

            touchendX = this.getTouches(ev).clientX;
            const xDiff = touchstartX - touchendX;

            if ( xDiff > 0 ) {
                this.changeImage(true);
            } else {
                this.changeImage();
            }

            touchstartX = 0;
            touchendX = 0;
            moving = false;
        }, false);
    }

    listen() {
        this.$('body').on(this.tapEvent, `.${this.options.lightbox}`, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            const parent = this.$(ev.target).parent();
            this.setImages(parent);
        });

        this.$('body').on(this.tapEvent, this.options.lightboxClose, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.closeLightBox();
        });

        if(!isMobile()) {
            this.$('body').on(this.tapEvent, this.options.lightboxArrow, (ev) => {
                ev.preventDefault();
                ev.stopPropagation();

                const target = this.$(ev.target);

                if(target.hasClass('arrow-right')) {
                    this.changeImage(true);
                } else if(target.hasClass('arrow-left')) {
                    this.changeImage();
                }
            });
        } else {
            this.listenSwipe();
        }
    }
}
