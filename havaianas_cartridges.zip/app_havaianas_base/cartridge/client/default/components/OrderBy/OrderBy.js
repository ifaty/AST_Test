import isMobile from '../../utils/isMobile';

export default class OrderBy {

    constructor(options){

        const defaultOptions = {
            selectorEngine: '',
            headerFilter: '.superActions__header__filter',
            filterHeader: '.filter-header',
            orderByContainer: '.orderBy',
            orderByContainerMobile: '.orderBy--mobile',
            orderByMenu: '.orderBy__menu',
            orderByMenuList: '.orderBy__list',
            orderByMenuCurrentItem: '.orderBy__current',
            orderByMenuListItem: '.orderBy__item',
            orderByMenuListItemSelected: '.orderBy__item.selected',

        };

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.tapEvent = isMobile() ? 'click' : 'tap';
    }

    setOrder(target){
        target.addClass("selected").siblings().removeClass("selected");
        this.$(this.options.orderByMenu).removeClass("visible");
        this.$(this.options.orderByContainer).removeClass("visible");
        if (!isMobile()) {
            this.$(this.options.orderByMenuCurrentItem).html(target.find('span').html());
        }
    }

    updateSortBy(data) {

        let updatedList = "";
        let page = $(data.page)[0] || $(data)[0];

        if (isMobile()) {
            updatedList = this.options.orderByContainerMobile;
        } else {
            updatedList = this.options.orderByContainer;
        }
        this.$(`${updatedList}`).replaceWith(this.$(`${updatedList}`, page)[0]);

    }

    chooseSortingOption(ev) {
        var optionUrl = this.$(ev.currentTarget).data('url');

        this.$(document).on("app:frame:pageLoaded", (ev, data) => {
            this.updateSortBy(data);
            this.$(document).off("app:frame:pageLoaded");
        });

        // WARNING: CHECK CORRECTNESS
        this.$(document).trigger('app:frame:loadPage', [{
            link: optionUrl
        }]);
        this.setOrder(this.$(ev.currentTarget))
    }

    sortingOptionListener() {
        this.$('body').on(this.tapEvent, this.options.orderByMenuListItem, ev => {
            this.chooseSortingOption(ev);
        });
        this.runOnce = true;
    }

    listenOrderByShowClick(){

        this.$('body').on('click', (e) => {
            e.stopPropagation();
            this.$(this.options.orderByMenu).removeClass("visible")
            this.$(this.options.orderByContainer).removeClass("visible")

        }).off('click', this.options.orderByContainer).on('click', this.options.orderByContainer, (e) => {
            e.stopPropagation();
            this.$(e.currentTarget).find(this.options.orderByMenu).first().toggleClass("visible")
            this.$(this.options.orderByContainer).toggleClass("visible")

        }).on('click', this.options.orderByMenuList, (e) => {
            e.stopPropagation();
        });

    }

    appendOrderByOnFilter() {
        $(this.options.orderByContainer).first().insertAfter(this.options.filterHeader);
    }

    appendOrderLinks() {
        this.$(this.options.orderByContainer).first().insertBefore(".filter-icon")
    }

    listen(){
        if (this.watching) return this.reload();

        if (!isMobile()) {

            this.listenOrderByShowClick();

            if (!this.$(this.options.headerFilter).find(this.options.orderByContainer).length) {
                this.appendOrderLinks();
            }

        } else {
            this.appendOrderByOnFilter()
        }

        if (!this.runOnce) {
            this.sortingOptionListener();
        }
        this.setOrder(this.$(this.options.orderByMenuListItemSelected).first());

        this.$(document).on("app:orderBy:update", (ev, data) => {
            this.updateSortBy(data);
        })

        this.watching = true;
        return this;

    }

    reload() {

        this.watching = false;

        return this.destroy().listen();

    }

    destroy() {

        this.$(document)
            .off("app:orderBy:update");

        return this;
    }
}
