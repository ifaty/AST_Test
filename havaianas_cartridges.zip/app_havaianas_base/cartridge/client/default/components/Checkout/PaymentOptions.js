import isMobile from '../../utils/isMobile';
import Debounce from '../../utils/debounce';

export default class PaymentOptions {
    constructor(options) {

        const defaultOptions = {
            shippingAddressUpdateBtn: '.btn-update-shippingAddress',
            inputPostalCode: '.shippingZipCode',
            shippingSelectedPostalCode: '.shippingSelectedPostalCode',
            shippingForm: '.shipping-form',
            shippingAddressBlock: '.shipping-address-block',

            shippingSelectedContainer: '.checkout__shipping-options__selected__container',

            shippingOptionsEdit: '.checkout__shipping-options__selected-edit',
            shippingPostalCodeContainer: '.checkout__shipping-address__zip-code',
            shippingPostalCodeReturn: '.checkout__shippint-address__zip-code__return',
            inputShippingPostalCode: '#zipCode',

            checkoutLastStepLogged: '.checkout_last-step_logged',

            inputShippingStreet: '#address1',
            inputShippingNumber: '#number',
            inputShippingStateCode: '#stateCode',
            inputShippingCity: '#city',

            inputBoletId: '.boleto__tab-content #cpf',

            rainbow: '.rainbow',
            headerActions: '.header, .superActions__header',

            checkoutPaymentMethods: '.checkout__payment-methods',

            shippingMethods: '.checkout__shipping-method__select',
            shippingMethodList: '.checkout__shipping-method__select-container',
            shippingMethodViewMore: '.checkout__shipping-method__view-more',

            billingIsPaymentFree: '.billing_isPaymentFree',

            // NOVOS A PARTIR DAQUI
            paymentTabsTrigger: '.payment-option__tabs',
            paymentTabsTriggerCredit: '.payment-option__tabs__credit-card',
            paymentTabsTriggerBoleto: '.payment-option__tabs__boleto',
            paymentTabsContent: '.payment-options__tab__content',

            paymentMethodInputHidden: '#paymentMethod',

            creditCardTabContent: '.credit-card__tab-content',
            boletoTabContent: '.boleto__tab-content',

            changeBillingAddressCheckBox: '.payment-options__billing-address__checkbox',
            shippingAddressUseAsBillingAddress: '#dwfrm_billing_shippingAddressUseAsBillingAddress',
            billingAddressContent: '.payment-options__billing-address__content',

            buttonPaymentConfirm: '.checkout__actions__button.stage-payment',
            buttonLabelPaymentConfirm: '.stage-payment > .checkout__actions__button-label',

            buttonPlaceOrder: '.checkout__actions__button.stage-placeOrder',
            buttonLabelPlaceOrder: '.stage-placeOrder > .checkout__actions__button-label',

            billingForm: '.checkout__billing-form',
            shippingForm: '#dwfrm_shipping',

            cardOwnerAdyenForm: '.cardOwner_adyenForm',
            cardOwnerPaymentFormSerialized: '.cardOwner_paymentFormSerialized',

            installmentNumber: '.installment__number',
            installmentsAdyenForm: '.installments_adyenForm',

            paymentFormSerialized: '#paymentFormSerialized',
            finishFormSerialized: '#finishFormSerialized',

            inputBillingPostalCode: '#billingZipCode',
            inputBillingStreet: '.billingAddressOne',
            inputBillingCity: '.billingcity',
            labelBillingState: '.billing-state-label',
            inputBillingStateCode: '.billingState',
            inputBillingStateCodeOption: '.billing_stateCode-option',
            inputBillingCountryCode: '#billingCountryCode',
            inputBillingPostBox: '.billingpostBox',
            inputBillingNumber: '.billingAddressTwo',
            inputBillingAddressSuite: '.billingAddressSuite',
            inputBillingName: '.billingfirstName',

            billingCpf: 'dwfrm_billing_cpf',

            selectorEngine: {},
            toast: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.reloadCounter = 0;

        // Form validators
        this.shippingAddressIsValid = false;
        this.billingAddressIsValid = false;
        this.boletoIsValid = false;
        this.creditCardIsValid = false;

        this.tapEvent = "click";
        this.isListening = false;
    }

    submitBillingForm() {
        let finishModalUrl = this.$(`${this.options.buttonPaymentConfirm} > a`).attr('href');

        var shippingEditedForm = this.$("[id=dwfrm_shipping][class*=is-right]");
        var shippingForm = this.$("[id=dwfrm_shipping]");
        var shippingRightForm = shippingEditedForm.length ? shippingEditedForm : this.$(shippingForm[shippingForm.length - 1]);

        this.$.ajax({
            type: 'post',
            dataType: 'json',
            url: this.$(this.options.billingForm).attr('action'),
            data: this.$(this.options.billingForm).serialize() + '&' + shippingRightForm.serialize(),
        }).done((data) => {
            if (data.error) {
                this.options.validator.clearForm(this.$(this.options.billingForm));
                if (typeof(data.fieldErrors) != 'undefined' && data.fieldErrors.length > 0) {
                    var firstInputError = Object.getOwnPropertyNames(data.fieldErrors[0]);
                    firstInputError = firstInputError.length > 1 ? firstInputError[0] : firstInputError;
                    var inputFocus = $("[name='"+firstInputError+"']");
                    inputFocus.focus();
                    console.log(data.fieldErrors);
                    this.options.validator.validateForm(this.$(this.options.billingForm), true, data.fieldErrors);
                }
                if (typeof(data.serverErrors) != 'undefined' && data.serverErrors.length > 0) {
                     var msgError = '';
                     msgError = data.serverErrors[0];
                     this.options.toast.setOptions({
                           type: 'error',
                           buttonMsg: 'Ok',
                           msgText: msgError
                       }).openToast();
                }
            }
            else {
                this.$(document).trigger('app:frame:loadPage', [{
                    isModal: true,
                    link: finishModalUrl
                }]);
            }
        }).fail((error) => {
        }).always(() => {
            this.$(document).trigger('app:contextLoader:finish');
        });
    }

    submitPlaceOrderForm() {
        if(!this.options.validator.validateForm(this.$(this.options.finishFormSerialized), true)) return;

        this.$(document).trigger('app:contextLoader:init', [{
            target: this.$(`${this.options.buttonPlaceOrder}:visible`, '.is-current')
        }]);

        let dataFinishForm;
        const cpfBillingInput = this.$(`${this.options.finishFormSerialized} input[name=${this.options.billingCpf}]`);

        if(cpfBillingInput.length) {
            const cpf = cpfBillingInput.val().replace(/[^\w]+/g, "");
            dataFinishForm = this.$(`[name!="${this.options.billingCpf}"]`, this.options.finishFormSerialized).serialize();
            dataFinishForm += `&${this.options.billingCpf}=${cpf}`;
        } else {
            dataFinishForm = this.$(this.options.finishFormSerialized).serialize();
        }

        this.$.ajax({
            url: this.$(this.options.buttonPlaceOrder).attr('data-action'),
            method: 'POST',
            data: this.$(this.options.paymentFormSerialized).serialize() + '&' + dataFinishForm,
        }).done((data) => {

            if (data.error) {
                this.options.validator.clearForm(this.$(this.options.finishFormSerialized));
                if (typeof(data.fieldErrors) != 'undefined' && data.fieldErrors.length > 0) {
                    var firstInputError = Object.getOwnPropertyNames(data.fieldErrors[0]);
                    firstInputError = firstInputError.length > 1 ? firstInputError[0] : firstInputError;
                    var inputFocus = $("[name='"+firstInputError+"']");
                    inputFocus.focus();

                    this.options.validator.validateForm(this.$(this.options.finishFormSerialized), true, data.fieldErrors);
                }
                if (typeof(data.serverErrors) != 'undefined' && data.serverErrors.length > 0) {
                     var msgError = '';
                     msgError = data.serverErrors[0];
                     this.options.toast.setOptions({
                           type: 'error',
                           buttonMsg: 'Ok',
                           msgText: msgError
                       }).openToast();
                }

                if (data.errorMessage) {
                    this.options.toast.setOptions({
                        buttonMsg: 'Ok',
                        type: 'error',
                        msgText: data.errorMessage
                    }).openToast();
                }
            } else {
                this.$(document).trigger("app:gtm:transactionDone", {
                    orderId: data.orderID,
                    orderDetails: data.orderModel
                });
                this.$(document).trigger('app:paybutton:hide');

                // close modal and reappears with rainbown loading
                this.$(document).trigger('app:frame:closeModal');
                this.$('body').removeClass('is-rainbowReady collapseRainbow');
                this.$('.rainbowLoading').fadeIn(300);

                // send user to home then open searchMenu
                this.$(document).trigger('app:frame:loadPage', [{ link: window.app.urls.home }]);
                this.$(document).one("app:frame:ready", () => {
                    // to prevent errors
                    setTimeout(() => {
                        this.$(document).trigger('app:frame:loadPage', [{
                            isModal: 'searchMenu',
                            link: data.continueUrl
                        }]);

                        this.$(document).one("app:frame:ready", () => {
                            // hide with rainbown loading
                            this.$('.rainbowLoading').fadeOut(300);
                            this.$('body').addClass('is-rainbowReady collapseRainbow');
                            // update menu components when orderTracking is ready
                            this.$(document).trigger('app:menu:canUpdateComponents');
                        });

                        // reset checkout
                        this.$(document).trigger('app:checkout:reset');
                    }, 300);
                });
            }
        }).fail((data) => {
            if(data.responseJSON.message) {
                this.options.toast.setOptions({
                    type: 'error',
                    buttonMsg: 'Ok',
                    msgText: data.responseJSON.message
                }).openToast();
            }
        }).always(() => {
            this.$(document).trigger('app:contextLoader:finish');
        });
    }

    changeTab(elem) {
        let tabContentToShow = this.$(elem).data('element-to-show');

        this.$(this.options.paymentTabsTrigger).removeClass('is-active');
        this.$(elem).addClass('is-active');

        this.$(this.options.paymentTabsContent).stop().hide();
        this.$(tabContentToShow).stop().fadeIn();
    }

    showBillingAddress() {
        this.$(this.options.changeBillingAddressCheckBox).stop().toggleClass('is-active');
        this.$(this.options.billingAddressContent).stop().fadeToggle();
    }

    changeUseDifferentBillingAddressValue() {
        if (this.$(this.options.shippingAddressUseAsBillingAddress).val() == 'true'){
            this.$(this.options.shippingAddressUseAsBillingAddress).val('false');
        }
        else {
            this.$(this.options.shippingAddressUseAsBillingAddress).val('true');
        }
    }

    checkIfBoletoIsValid() {
        const cpf = this.$(this.options.inputBoletId);

        // Check if Boleto input is filled and if if the option is selected
        if (this.$(this.options.paymentTabsTriggerBoleto).hasClass('is-active')) {

            if(cpf.length) {
                if (cpf.val().length < 14) {
                    this.boletoIsValid = false;
                } else {
                    this.boletoIsValid = true;
                }
            }

        } else {
            this.boletoIsValid = true;
        }
    }

    checkIfBillingAddressIsValid() {
        // Check if different billing address fields are filled and if the option is selected
        if (this.$(this.options.shippingAddressUseAsBillingAddress).val() === 'true') {
            this.billingAddressIsValid = this.options.requiredFieldsValidator.validateRequiredFields(this.options.billingForm);

            this.$(document).trigger('app:fieldsValidator:required', [{target: this.options.billingForm}]);
        } else {
            this.billingAddressIsValid = true;
        }
    }

    checkIfShippingAddressIsValid() {
        if (this.$(this.options.checkoutLastStepLogged).length || !this.$(this.options.shippingAddressBlock).length) {
            this.shippingAddressIsValid = true;
        } else {
            this.shippingAddressIsValid = this.options.requiredFieldsValidator.validateRequiredFields(this.options.shippingAddressBlock);
        }

        this.$(document).trigger('app:fieldsValidator:required', [{target: this.options.shippingAddressBlock}]);
    }

    checkIfCreditCardIsValid() {
        let valid = true;

        if(this.$(this.options.paymentTabsTriggerCredit).hasClass('is-active')) {
            if(!this.verifyInstallment() || !this.$(this.options.creditCardTabContent).hasClass('is-card-correct')) {
                valid = false;
            }
        }

        this.creditCardIsValid = valid;
    }

    validateAndAvailableBtnStagePayment() {
        this.checkIfShippingAddressIsValid();
        this.checkIfBillingAddressIsValid();
        this.checkIfBoletoIsValid();
        this.checkIfCreditCardIsValid();

        const billingIsPaymentFree = this.$(this.options.billingIsPaymentFree).val();

        if(billingIsPaymentFree == 'true') {
            this.boletoIsValid = true;
            this.creditCardIsValid = true;
        }

        if (this.shippingAddressIsValid && this.billingAddressIsValid && this.boletoIsValid && this.creditCardIsValid) {
            this.$(this.options.buttonPaymentConfirm).addClass('is-active');
        } else {
            this.$(this.options.buttonPaymentConfirm).removeClass('is-active');
        }
    }

    submitAutoCompleteAddress(postalCode) {
        let url = window.app.urls.autoCompleteAddress;
        this.$.ajax({
            type: 'GET',
            url: url,
            data: {
                postalCode: postalCode
            },
            success: (data) => {
                if (data.success) {
                    this.options.validator.clearForm(this.$(this.options.billingForm));
                    this.$(this.options.inputBillingPostalCode).attr('value', postalCode);
                    this.$(this.options.inputBillingStreet).attr('value', data.address.address);
                    this.$(this.options.inputBillingCity).attr('value', data.address.city);
                    this.$(this.options.inputBillingStateCode).attr('value', data.address.uf);
                    this.$(this.options.inputBillingCountryCode).attr('value', data.address.countryCode);
                    this.$(this.options.inputBillingPostBox).attr('value', data.address.bairro);

                    if (this.$(this.options.inputBillingPostBox).val().length >= 1) {
                        this.$(this.options.inputBillingPostBox).siblings(this.options.accountFloatingLabel).removeClass('empty').addClass('active');
                    }
                    if (this.$(this.options.inputBillingCity).val().length >= 1) {
                        this.$(this.options.inputBillingCity).siblings(this.options.accountFloatingLabel).removeClass('empty').addClass('active');
                    }
                    if (this.$(this.options.inputBillingStreet).val().length >= 1) {
                        this.$(this.options.inputBillingStreet).siblings(this.options.accountFloatingLabel).removeClass('empty').addClass('active');
                    }

                    this.$(this.options.inputBillingAddressSuite).val('');
                    this.$(this.options.inputBillingNumber).val('');
                    // get the last inputBillingStateCodeOption selected text
                    this.setBillingState(data.address.uf);

                    this.$(this.options.inputBillingName).focus();
                }
            },
            error: () => {
                this.options.toast
                    .setOptions({
                        buttonOk: true,
                        buttonMsg: "Ok",
                        msgText: "Sorry! Something went wrong",
                        type: "error",
                    }).openToast();
            }
        });
    }

    setBillingState(stateCode = '') {
        if(!stateCode) return;

        const inputsState = this.$(`${this.options.inputBillingStateCodeOption}[value=${stateCode}]`);
        const stateText = this.$(inputsState[inputsState.length - 1]).text();
        this.$(this.options.labelBillingState).text(stateText);

        return this;
    }

    submitUpdateAddress(ev) {
        var shippingEditedForm = this.$("[id=dwfrm_shipping][class*=is-right]");
        var shippingForm = this.$("[id=dwfrm_shipping]");
        var shippingRightForm = shippingEditedForm.length ? shippingEditedForm : this.$(shippingForm[shippingForm.length - 1]);
        var formData = new FormData(shippingRightForm[0]);

        this.$.ajax({
            type: 'POST',
            url: shippingRightForm.attr('action'),
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            dataType: 'json',
        }).done((result) => {
            if (!result.form.shippingAddress.valid) {
                if (typeof(result.fieldErrors) != 'undefined' && result.fieldErrors.length > 0) {
                    this.options.validator.clearForm(shippingRightForm);
                    var firstInputError = Object.getOwnPropertyNames(result.fieldErrors[0]);
                    firstInputError = firstInputError.length > 1 ? firstInputError[0] : firstInputError;
                    var inputFocus = $("[name='"+firstInputError+"']");
                    inputFocus.focus();
                    this.options.validator.validateForm(shippingRightForm, true, result.fieldErrors);
                 }
            } else{
                this.submitBillingForm();
            }
        }).fail((error) => {
            this.options.toast.setOptions({
                type: 'error',
                buttonMsg: 'Ok',
                msgText: "Sorry! something went wrong."
            }).openToast();
        }).always(() => {
            this.$(document).trigger('app:contextLoader:finish');
        });
    }

    verifyInstallment() {
        const installments = this.$(this.options.installmentsAdyenForm);

        if(!this.$(this.options.checkoutPaymentMethods).hasClass('d-none') && this.$(this.options.paymentTabsTriggerCredit).hasClass('is-active')) {
            if(installments.val() == '') {
                const error = installments.parent().data('error');
                installments.parent().find('.invalid-feedback').html(`<i class="icon-alert"></i> <span>${error}<span/>`).show();
                return false;
            } else {
                installments.parent().find('.invalid-feedback').hide();
                return true;
            }
        } else {
            return true;
        }
    };

    verifyBillingPostalCode() {
        const inputPostalCode = this.$(this.options.inputBillingPostalCode);
        const patternCEP = inputPostalCode.attr('pattern');
        const cep = inputPostalCode.val();
        const regexCEP = cep.match(patternCEP);
        const minLenght = inputPostalCode.attr('minlength');

        // removes all characters that are not numbers or -
        const regexLetra = cep.substring(cep.length - 1).match(/^[0-9]?-?$/);
        if(!regexLetra) {
            inputPostalCode.val(cep.substring(0, cep.length - 1));
            return;
        }

        if(!cep.length) return;

        if(cep.length >= minLenght && regexCEP) { this.submitAutoCompleteAddress(cep); }
    }

    listen() {
        let debounceBillingPostalCode = Debounce((ev) => {
            if (ev.key == 'Control' || ev.key == 'Shift' || ev.ctrlKey || ev.shiftKey) return this;

            this.verifyBillingPostalCode();
        }, 300);

        this.$(this.options.inputBillingPostalCode).on('keyup paste', debounceBillingPostalCode);

        this.$(this.options.paymentTabsTriggerBoleto).on(this.tapEvent, () => {
            this.$(this.options.paymentMethodInputHidden).val('Boleto');
        });

        this.$(document).on('app:checkout:verifyShippingForm', () => {
            this.validateAndAvailableBtnStagePayment();
        });

        this.$(document).on('app:checkout:verifyBillingAddress', () => {
            const stateCode = this.$(this.options.inputBillingStateCode).val();
            this.setBillingState(stateCode);
        });

        this.$(this.options.installmentNumber).on('click', (ev) => {
            let numberOfInstallments = this.$(ev.target).data('installmentnumbers');
            this.$(this.options.installmentsAdyenForm).val(parseInt(numberOfInstallments));
            this.$(this.options.installmentsAdyenForm).parent().find('.invalid-feedback').hide();
        });

        this.$(this.options.paymentTabsTriggerCredit).on(this.tapEvent, () => {
            this.$(this.options.paymentMethodInputHidden).val('CREDIT_CARD');
        });

        this.$(this.options.paymentTabsTrigger).on(this.tapEvent, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.changeTab(ev.target);

            this.validateAndAvailableBtnStagePayment();
        });

        this.$(`${this.options.shippingForm} input`).on('keyup', () => {
            this.validateAndAvailableBtnStagePayment();
        });

        this.$(`${this.options.billingForm} input`).on('keyup', () => {
            this.validateAndAvailableBtnStagePayment();
        });

        this.$(this.options.buttonPaymentConfirm).off(this.tapEvent).on(this.tapEvent, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.submitUpdateAddress(ev);
        });

        this.$(this.options.buttonPlaceOrder).off(this.tapEvent).on(this.tapEvent, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.submitPlaceOrderForm();
        });

        this.$(this.options.inputBoletId).on('keyup', (ev) => {
            this.validateAndAvailableBtnStagePayment();
        });

        this.$(this.options.cardOwnerAdyenForm).on('change paste keyup', (ev) => {
            this.$(this.options.cardOwnerPaymentFormSerialized).val(this.$(this.options.cardOwnerAdyenForm).val());
        });

        this.$('body').on(this.tapEvent, this.options.changeBillingAddressCheckBox, () => {
            this.showBillingAddress();
            this.changeUseDifferentBillingAddressValue();
            this.validateAndAvailableBtnStagePayment();
        });

        this.$('body').on('submit', this.options.finishFormSerialized, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.submitPlaceOrderForm();
        });

        // from here thing that can or should be called only once
        if(this.isListening) return;
        this.isListening = true;
    }

    init() {
        this.listen();
    }

    destroy() {
        this.$('body')
            .off(this.tapEvent, this.options.changeBillingAddressCheckBox)
            .off('submit', this.options.finishFormSerialized);

        return this;
    }
}
