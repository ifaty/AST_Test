import isMobile from '../../utils/isMobile';

import checkoutProductTile from './CheckoutProductTile'; // will only be used here

export default class CheckoutEditProduct {
    constructor(options) {

        const defaultOptions = {
            modalPageContainer: '.modal-page-container[data-pagename="page-checkout-editDrawer"]',

            removeLink: '.page-checkout-editDrawer .remove__link',
            removeConfirmationContainer: '.page-checkout-editDrawer .remove__confirmation',
            removeConfirmButton: '.page-checkout-editDrawer .remove__confirm',
            removeCancelButton: '.page-checkout-editDrawer .remove__cancel',

            selectedSize: '.page-checkout-editDrawer .size__selected',
            selectSizeButton: '.page-checkout-editDrawer .size__button',

            drawerChooseSize: '.page-checkout-editDrawer .drawer__choose-size',
            drawerChooseSizeOverlay: '.page-checkout-editDrawer .drawer-overlay',
            editProductDrawer: 'edit-product-drawer',
            editProductDrawerBg: 'edit-product-drawer-bg',

            productTile: 'drawer-product__tile',
            productTileBody: '.page-checkout-editDrawer .product__tile-body',
            productTileMobile: '.edit-product-drawer.product__tile-body',

            drawerChooseColor: '.page-checkout-editDrawer .drawer__choose-color',
            colorsCloseButton: '.page-checkout-editDrawer .drawer-overlay',
            colorsShowMoreButton: '.edit-product-drawer .show-more-colors',
            colorSwatch: 'swatch-circle',
            sizeSwatch: 'size__swatch',

            quantity:'product__quantity',
            quantitySelector:'quantity-selector',
            quantityInput: '.quantity-selector',
            quantityPlus: 'product__quantity-plus',
            quantityMinus: 'product__quantity-minus',

            colorMatrix: '.page-checkout-editDrawer > .color-matrix',
            colorMatrixInsideProductTile: '.drawer-product__tile .color-matrix',

            drawerProductTile: '.drawer-product__tile',
            checkoutKeepShopping: '.checkout__keep-shopping',

            selectorEngine: {}
        }

        this.colorMatrixData;

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.checkoutProductTile = new checkoutProductTile({selectorEngine: this.$});

        this.tapEvent = "click";
    }

    openRemoveConfirmation() {
        this.$(`${this.options.productTileBody}, ${this.options.removeLink}`).fadeOut(300, () => {
            this.$(this.options.removeConfirmationContainer).fadeIn(300);
        });
    }

    closeRemoveConfirmation() {
        this.$(this.options.removeConfirmationContainer).fadeOut(300, () => {
            this.$(`${this.options.productTileBody}, ${this.options.removeLink}`).fadeIn(300)
        });
    }

    openSizeDrawer() {
        this.$(this.options.drawerChooseSize).addClass("drawer--isOpen");

        setTimeout(() => {
            this.$(this.options.drawerChooseSize).addClass("drawer--isVisible")
        }, 200);
    }

    closeSizeDrawer() {
        this.$(this.options.drawerChooseSize).removeClass("drawer--isVisible drawer--isOpen")
    }

    openColorDrawer() {
        this.$(this.options.drawerChooseColor).addClass("drawer--isOpen");

        setTimeout(() => {
            this.$(this.options.drawerChooseColor).addClass("drawer--isVisible")
        }, 200);
    }

    closeColorDrawer() {
        this.$(this.options.drawerChooseColor).removeClass("drawer--isVisible drawer--isOpen")
    }

    removeProduct() {
        const url = this.$(this.options.removeConfirmButton).data('url');

        this.$.ajax({
            type: 'get',
            url,

            success: (data) => {
                // if is last product go back to previous url
                if(data.basket.numItems == 0) {
                    this.$(document).trigger('app:contextLoader:init', [{
                        target: this.$(this.options.removeConfirmButton)
                    }]);

                    // hide paybutton
                    this.$(document).trigger('app:paybutton:hide');

                    //const previousURL = this.$(this.options.checkoutKeepShopping).attr('href');
                    const previousURL = window.app.urls.shopmode;
                    this.$(document).trigger('app:frame:loadPage', [{ link: previousURL }]);

                    return;
                }

                if(data.payButtonTemplate) {
                    this.$(document).trigger('app:payButton:update', [{
                        template: data.payButtonTemplate
                    }]);
                }

                this.closeRemoveConfirmation();
                this.$(document).trigger('app:frame:loadPage', [{
                    link: this.$(this.options.removeConfirmButton).data('redirect')
                }]);
            }
        });
    }

    listenColorsMore() {
        this.$('body')
            .off(this.tapEvent, this.options.colorsShowMoreButton)
            .on(this.tapEvent, this.options.colorsShowMoreButton, () => this.openColorDrawer());
        return this;
    }

    listenColorsClose() {
        this.$('body')
            .off(this.tapEvent, this.options.colorsCloseButton)
            .on(this.tapEvent, this.options.colorsCloseButton, () => this.closeColorDrawer());
        return this;
    }

    listenColorSwatch() {
        this.$('body')
        .off(this.tapEvent, `.${this.options.colorSwatch}`)
        .on(this.tapEvent, `.${this.options.colorSwatch}`, (e) => this.productUpdate(e, true))
    }

    listenSizeSwatch() {
        this.$('body')
        .off(this.tapEvent, `.${this.options.sizeSwatch}`)
        .on(this.tapEvent, `.${this.options.sizeSwatch}`, (e) => this.productUpdate(e))
    }

    listenQuantityChange(){
        // removes all characters that are not numbers
        this.$('body')
            .off('keyup', this.options.quantityInput)
            .on('keyup', this.options.quantityInput, (ev) => {
                const input = this.$(ev.currentTarget);
                const quantity = input.val();
                const regexLetra = quantity.match(/^[0-9]$/);
                if(!regexLetra) {
                    const newQuantity = quantity.replace(/\D+/g, '');
                    input.val(newQuantity);

                    return;
                }
        });

        this.$('body')
            .off('change', this.options.quantityInput)
            .on('change', this.options.quantityInput, (e) => {
                const defaultValue = e.currentTarget.defaultValue;

                const input = this.$(e.currentTarget);
                const pid = input.closest(`.${this.options.productTile}`).data('pid');
                const uuid = input.closest(`.${this.options.productTile}`).data('uuid');
                const quantity = input.val();
                const url = `${input.data('action')}`;

                this.quantityChange(url, pid, uuid, quantity)
                .then((data) => {

                    let url = this.$(".checkout__updateshipping-url").val();
                    // Checkout.updateShippingDrawer()
                    this.$(document).trigger('app:checkout:refresh', [{ url }]);

                    if(data.payButtonTemplate) {
                        this.$(document).trigger('app:payButton:update', [{
                            template: data.payButtonTemplate
                        }]);
                    }

                    this.refreshTotals(data.totals.grandTotal);

                })
                .catch(() => {
                    input.val(defaultValue);
                });
        });

        this.$('body')
        .off(this.tapEvent, `.${this.options.quantityMinus}`)
        .on(this.tapEvent, `.${this.options.quantityMinus}`, (e) => {

            let input = this.$(e.currentTarget).closest(`.${this.options.quantity}`).find(`.${this.options.quantitySelector}`)
            let pid = this.$(e.currentTarget).closest(`.${this.options.productTile}`).data('pid');
            let uuid = this.$(e.currentTarget).closest(`.${this.options.productTile}`).data('uuid');
            input.val(parseInt(input.val()) - parseInt(1))
            let quantity = input.val();
            let url = `${input.data('action')}`;

            this.quantityChange(url, pid, uuid, quantity)
            .then((data) => {

                let url = this.$(".checkout__updateshipping-url").val();
                // Checkout.updateShippingDrawer()
                this.$(document).trigger('app:checkout:refresh', [[url]]);

                if(data.payButtonTemplate) {
                    this.$(document).trigger('app:payButton:update', [{
                        template: data.payButtonTemplate
                    }]);
                }

                this.refreshTotals(data.totals.grandTotal);

            })
            .catch((data) => {
                input.val(parseInt(input.val()) + parseInt(1))
            })
        })

        this.$('body')
        .off(this.tapEvent, `.${this.options.quantityPlus}`)
        .on(this.tapEvent, `.${this.options.quantityPlus}`, (e) => {

            let input = this.$(e.currentTarget).closest(`.${this.options.quantity}`).find(`.${this.options.quantitySelector}`)
            let pid = this.$(e.currentTarget).closest(`.${this.options.productTile}`).data('pid');
            let uuid = this.$(e.currentTarget).closest(`.${this.options.productTile}`).data('uuid');
            input.val(parseInt(input.val()) + parseInt(1))
            let quantity = input.val();
            let url = `${input.data('action')}`;

            this.quantityChange(url, pid, uuid, quantity)
            .then((data) => {

                let url = this.$(".checkout__updateshipping-url").val();
                // Checkout.updateShippingDrawer()
                this.$(document).trigger('app:checkout:refresh', [[url]]);

                if(data.payButtonTemplate) {
                    this.$(document).trigger('app:payButton:update', [{
                        template: data.payButtonTemplate
                    }]);
                }

                this.refreshTotals(data.totals.grandTotal);

            })
            .catch((data) => {
                input.val(parseInt(input.val()) - parseInt(1))
            })
        })

        return this;
    }

    quantityChange(url, pid, uuid, quantity){
        return this.$.get(url, {pid, uuid, quantity});
    }

    productUpdate(e, changeColors = false) {
        this.$(document).trigger('app:contextLoader:init', [{
            target: this.$(this.options.productTileMobile)
        }]);

        let target = this.$(e.currentTarget);
        let productCell = target.closest(`.${this.options.editProductDrawer}`);

        let url = target.data().url;
        let uuid = target.data().uuid;
        let pid = target.data().pid;
        let quantity = this.$(`.${this.options.productTile} ${this.options.quantityInput}`).val();

        if (!url) return;

        if (target.data().selectable == false) {
            return;
        }

        this.$.ajax({
            type: 'post',
            dataType: 'json',
            url: url,
            data: { pid, uuid, quantity },

            success: (data) => {

                if (data.success) {

                    let url = this.$(".checkout__updateshipping-url").val();

                    productCell.find(`.${this.options.productTile}`).first().remove();
                    productCell.append(data.renderedTemplate);

                    // Checkout.updateShippingDrawer()
                    this.$(document).trigger('app:checkout:refresh', [[url]]);

                    if(changeColors) {
                        const colorMatrix = data.renderedColorMatrix || '';
                        const colorMatrixTile = this.$.parseJSON(data.tileColorMatrix.colors);
                        const textColor = colorMatrixTile.text;
                        const offWhite = colorMatrixTile.offwhite;
                        productCell.css({ 'color': textColor });

                        productCell.find(`.${this.options.editProductDrawerBg}`)
                                   .css({ 'background-color': offWhite });

                        this.$(document).trigger('app:colors:setcolors', [ colorMatrix ]);
                    }

                    if(data.payButtonTemplate) {
                        this.$(document).trigger('app:payButton:update', [{
                            template: data.payButtonTemplate
                        }]);
                    }

                    this.refreshTotals(data.cartModel.totals.grandTotal);


                } else {
                    this.options.toast
                        .setOptions({
                            msgText: "Sorry! something went wrong."
                        })
                        .openToast();
                }

                this.$(document).trigger('app:contextLoader:finish');
            },

            error: () => {
                this.$(document).trigger('app:contextLoader:finish');

                this.options.toast
                    .setOptions({
                        msgText: "Sorry! something went wrong."
                    })
                    .openToast();
            }
        });

    }

    refreshTotals(value){
        this.$(".checkout__actions__total__price").html(value)
    }

    listen() {
        this.$('body').off('click', this.options.removeLink)
                      .on('click', this.options.removeLink, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.openRemoveConfirmation();
        });

        this.$('body').off('click', this.options.removeCancelButton)
                      .on('click', this.options.removeCancelButton, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.closeRemoveConfirmation();
        });

        this.$('body').off('click', this.options.selectedSize)
                      .on('click', this.options.selectedSize, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.openSizeDrawer();
        });

        this.$('body').off('click', this.options.drawerChooseSizeOverlay)
                      .on('click', this.options.drawerChooseSizeOverlay, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.closeSizeDrawer();
        });

        this.$('body').off('click', this.options.removeConfirmButton)
                      .on('click', this.options.removeConfirmButton, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.removeProduct();
        });

        this.listenColorsMore();
        this.listenColorsClose();

        if (isMobile()) {
            this.listenColorSwatch();
            this.listenSizeSwatch();
            this.listenQuantityChange();
        }


    }

    init() {
        this.listen();
    }
}
