import isMobile from '../../utils/isMobile';
import VMasker from 'vanilla-masker';
import Debounce from '../../utils/debounce';

import checkoutProductTile from './CheckoutProductTile'; // will only be used here

export default class Checkout {
    constructor(options) {

        const defaultOptions = {
            inputPostalCode: '.shippingZipCode',
            shippingForm: '.shipping-form',
            billingForm: '.checkout__billing-form',

            shippingSelectedContainer: '.checkout__shipping-options__selected__container',

            shippingOptionsEdit: '.checkout__shipping-options__selected-edit',
            shippingPostalCodeContainer: '.checkout__shipping-address__zip-code',
            shippingPostalCodeReturn: '.checkout__shippint-address__zip-code__return',
            shippingPostalCodeClear: '.checkout__shippint-address__zip-code__clear',
            inputShippingPostalCode: '.shipping-address-zipcode',

            shippingTitle: '.checkout__shipping-options__selected-title',
            shippingTitlePostalCode: '.checkout__shipping-options__selected-title-postalCode',

            accountStateLabel: '.account__floating-label-state',

            inputShippingName: '.shipping_firstName',
            inputShippingStreet: '.shipping_address1',
            inputShippingNumber: '.shipping_number',
            inputShippingStateCode: '.shipping_stateCode',
            inputShippingStateCodeOption: '.shipping_stateCode-option',
            inputShippingCity: '.shipping_city',
            inputShippingCountryCode: '.shipping_countryCode',
            inputShippingPostBox: '.shipping_postBox',
            inputShippingSuite: '.shipping_suite',

            inputBillingState: '.billing_stateCode',
            inputBillingStateCodeOption: '.billing_stateCode-option',
            labelBillingState: '.billing-state-label',

            keepShoppingLink: '.checkout__keep-shopping',

            shippingMethods: '.checkout__shipping-method__select-container .checkout__shipping-method__select',
            shippingMethodList: '.checkout__shipping-method__select-container',
            shippingMethodViewMore: '.checkout__shipping-method__view-more',

            inputRadioShippingMethod:'.checkout__shipping-method__select > input[type="radio"]',
            pickupMethodSelect: '.pickup__method-select',

            checkoutAciontsShippingDate: '.checkout__actions__total__shipping-date',

            containerPageCheckout: '.container[class*="page-checkout"]',
            checkoutActionsStagePlaceOrder: '.stage-placeOrder',
            checkoutActionsStagePayment: '.stage-payment',
            checkoutActionsStageBilling: '.stage-billing',
            checkoutActionsSaveDelivery: '.checkout__actions__button.save-delivery',
            checkoutActionsSaveDeliveryButton: '.checkout__actions__button.save-delivery > .checkout__actions__button-label',

            checkoutActionsLabelSubTotal: '.checkout__actions-label-subtotal',
            checkoutActionsLabelTotal: '.checkout__actions-label-total',

            checkoutPaymentMethods: '.checkout__payment-methods',
            billingIsPaymentFree: '.billing_isPaymentFree',
            checkoutPaymentMethodsTitle: '.checkout__payment-methods-title',

            placeOrderEmailInput: '.placeOrder__email-input',
            cpfInput: 'input.cpf',
            placeOrderCpfInput: '#finishFormSerialized #cpf',
            placeOrderBirthDate: '#finishFormSerialized  #dateofbirth',

            checkoutActionsTotalPrice: '.checkout__actions__total__price',

            buttonLabelStageBilling: '.stage-billing > .checkout__actions__button-label',

            drawerlabelClick: '.choose-installment',
            installmentNumber: '.installment__number',
            labelinstallment: '.checkout__cc-label.inside_drawer',
            installmentBox: '.checkout__cc-form-group.installment',

            installmentDrawer: '.installment-drawer',
            stateDrawer: '.state-drawer',
            chooseStateDrawer: '.choose-state-drawer',

            shippingEditAddress: '.shipping__edit-address',
            checkoutShipping: '.checkout__shipping',
            checkoutShippingSummary: '.checkout__shipping-summary',
            checkoutActionsInitial: '.checkout__actions-initial',
            checkoutActionsButton: '.checkout__actions__button',
            checkoutActionsLabel: '.checkout__actions__button-label',

            checkoutLastInfo: '.checkout__last-',
            checkoutLastText: '.checkout__last-address',
            checkoutLastStepLogged: '.checkout_last-step_logged',
            checkoutLastShippingValue: '.checkout__last-shippingCost',
            checkoutLastShippingValuePickup: '.checkout__last-shippingCost-pickup',
            checkoutLastDeliveryDays: '.checkout__last-delivery-days',
            checkoutLastPostalCode: '.checkout__last-postalCode',
            checkoutSummaryText: '.checkout__summary-text',
            checkoutLastShippingForm: '.checkout_last-shipping-form',
            shippingSummaryTitle: '.checkout__shipping-summary .checkout__shipping-options__selected-title, .placeOrder__shipping .checkout__shipping-options__selected-title',

            checkoutTile: '.checkout_tile',

            checkoutCouponOpenForm: '.checkout__coupon-open-form',
            checkoutCouponAdd: '.checkout__coupon-input-submit',
            checkoutCouponCancel: '.checkout__coupon-code__cancel',
            checkoutCouponForm: '.checkout__coupon-form',
            checkoutCouponField: '.checkout__coupon-field',
            checkoutCouponValidationFields: '.checkout__coupon-validation-fields',
            checkoutCouponValidationSubmit: '.checkout__coupon-validation-submit',
            checkoutCouponCpf: '.checkout__coupon-cpf-field',
            checkoutCouponEmail: '.checkout__coupon-email-field',
            checkoutCouponRemove: '.checkout__coupon-card-remove',
            checkoutCouponTiles: '.checkout__coupon-tiles',

            checkoutCouponCardValue: '.checkout__coupon-card-display-value',

            checkoutBalanceUsage: '.checkout__balance-usage',
            checkoutBalanceUseForm: '.checkout__balance-use',
            checkoutBalanceUse: '.checkout__balance-use-input',
            checkoutBalanceSubmit: '.checkout__balance-submit',
            checkoutBalanceForm: '.checkout__balance-edit-form',
            checkoutBalanceEdit: '.checkout__balance-edit-button',
            checkoutBalanceGroup: '.checkout__balance-group',

            colorMatrix: '.color-matrix',

            shippingMethodBlock: '.shipping-method-block',
            multishippingOrderButton: '.checkout__multishipping-order-button',
            multishipButtonContainer: '.multiship-button__container',
            editMultishipItemButton: '.checkout__shipping-selected-place-edit',
            checkoutShippingPlaceButton: '.checkout__shipping-place-button',
            selectShippingInfo: "#checkout__select-shipping-info",

            creditCardInstallmentsContainer: '.checkout__payment-installments-container',
            installmentInput: '.installments_adyenForm',

            checkoutModal: '.checkout__modal',
            checkoutActionsModal: '.checkout__actions-modal',

            checkout_labelTitle:'.checkout_label',

            checkoutPlaceLink: '.checkout__shipping-place-link',

            checkoutMultishippingTitle: '.checkout__multishipping-shipping-options__selected-title',
            checkoutMultishippintLastText: '.checkout__multishipping-last-text',
            checkoutMultishippingMethods: '.checkout__multishipping-methods',
            checkoutMultishippingTotalMethods: '.checkout__multishipping-total-methods',

            paymentOptionsEdit: '.checkout__edit-selected-payment-method',
            checkoutLastUserCardEdit: '.checkout__last-user-card-edit',
            paymentOptionsTabs: '.payment-options__tabs',
            paymentOptionsTabContent: '.payment-options__tab__content',
            checkoutCardInput: '.checkout__cc-form-group__adyen',
            checkoutLastUserCard: '.checkout__last-user-card',
            creditCardTabContent: '.credit-card__tab-content',
            paymentCreditCardToken: '#creditCardToken',
            storedPaymentInstrumentsList: '#storedPaymentInstrumentsList',

            changeBillingAddressCheckBox: '.payment-options__billing-address__checkbox',
            shippingAddressUseAsBillingAddress: '#dwfrm_billing_shippingAddressUseAsBillingAddress',
            billingAddressContent: '.payment-options__billing-address__content',
            billingAddressTitle: '.checkout__billing-address-title',

            checkoutRightCol: '.checkout__right-col',
            checkoutHeader: '.checkout__header',

            termsAndPrivacy: '.termsandprivacy',

            checkoutChatModalOpen: 'checkout-modal-chat-open',

            splitClass: 'is-split',
            mergeClass: 'is-merge',

            selectorEngine: {},
            toast: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.checkoutProductTile = new checkoutProductTile({selectorEngine: this.$});

        this.reloadCounter = 0;

        this.isDrawerOpen = false;

        this.postalCode = '';
        this.isEditing;
        this.shippingValue = '';
        this.shippingDays = '';

        this.colorMatrixData;

        this.tapEvent = "click";
        this.isSpliting = this.$(this.options.multishippingOrderButton).hasClass(this.options.mergeClass);
        this.isLogged = false;
        this.isListening = false;
        this.firstPage = false;
        this.hasPickup = false;
        this.isEditingPayment = false;
    }

    submitAutoCompleteAddress(postalCode) {
        let url = window.app.urls.autoCompleteAddress;

        this.$.ajax({
            type: 'GET',
            url: url,
            data: {
                postalCode: postalCode
            }
        }).done((data) => {
            if (data.success) {
                this.$(this.options.inputShippingStreet).attr('value', data.address.address);
                this.$(this.options.inputShippingCity).attr('value', data.address.city);
                this.$(this.options.inputShippingStateCode).attr('value', data.address.uf);
                this.$(this.options.inputShippingCountryCode).attr('value', data.address.countryCode);
                this.$(this.options.inputShippingPostBox).attr('value', data.address.bairro);

                this.$(this.options.inputShippingSuite).attr('value', '');
                this.$(this.options.inputShippingNumber).attr('value', '');

                // get the last inputShippingStateCodeOption selected text
                const inputsState = this.$(`${this.options.inputShippingStateCodeOption}[value=${data.address.uf}]`);
                const stateText = this.$(inputsState[inputsState.length - 1]).text();
                this.$(this.options.accountStateLabel).text(stateText);

                this.$(this.options.inputShippingName).focus();
            }
        }).fail((data) => {
            if(data.responseJSON && data.responseJSON.message) {
                this.options.toast
                            .setOptions({
                                buttonOk: true,
                                buttonMsg: "Ok",
                                type: "error",
                                msgText: data.responseJSON.message,
                            }).openToast();
            }

            this.$(this.options.inputShippingStreet).focus();
        }).always(() => {
            this.$(this.options.inputShippingPostalCode).val(postalCode);
        });
    }

    submitUpdateShipmentList(input, initialCheck) {
        var postalCode = input.val();
        var formData = new FormData();
        formData.append("postalCode", postalCode);
        this.$.ajax({
            type: 'POST',
            url: this.$(this.options.shippingForm).data('update-shipments-url'),
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            dataType: 'json',
        }).done((result) => {
            this.options.validator.clearForm(this.$(this.options.shippingForm));
            if (typeof(result.error) != 'undefined' && result.error == true) {
                this.options.validator.validateForm(this.$(this.options.shippingForm), true, result.fieldErrors);

                if(result.fieldErrors && result.fieldErrors[0].dwfrm_address_postalCode) {
                    this.options.toast.setOptions({
                        buttonMsg: 'Ok',
                        type: 'error',
                        msgText: result.fieldErrors[0].dwfrm_address_postalCode
                    }).openToast();
                }

                if (result.errorMessage) {
                    this.options.toast.setOptions({
                        buttonMsg: 'Ok',
                        type: 'error',
                        msgText: result.errorMessage
                    }).openToast();
                    this.$(this.options.shippingPostalCodeContainer).removeClass('d-none');
                }

                this.$(this.options.shippingMethodBlock).removeClass('d-none');
            }

            if (typeof(result.order) != 'undefined' && result.order.shipping.length > 0 && result.error != true) {
                this.$(this.options.shippingMethodBlock).removeClass('d-none').html(result.renderedTemplate);
                this.$(this.options.multishippingOrderButton).removeClass('d-none');
                this.$(this.options.shippingTitlePostalCode).text(postalCode);

                if(initialCheck) {
                    this.$(this.options.shippingPostalCodeContainer).addClass('d-none');
                    this.$(this.options.shippingSelectedContainer).removeClass('d-none');
                }

                this.$(this.options.multishipButtonContainer).replaceWith(result.multishipButtonTemplate);
                this.isSpliting = result.order.usingMultiShipping;
            }
        }).fail((data) => {
            if(data.responseJSON && data.responseJSON.message) {
                this.options.toast.setOptions({
                    buttonMsg: 'Ok',
                    type: 'error',
                    msgText: data.responseJSON.message
                }).openToast();
            }
        }).always(() => {});
    }

    hideShippingPostalCode() {
        this.$(this.options.shippingSelectedContainer).removeClass('d-none');
        this.$(this.options.multishippingOrderButton).removeClass('d-none');
        this.$(this.options.shippingMethodBlock).removeClass('d-none');
        this.$(this.options.shippingPostalCodeContainer).addClass('d-none');
    }

    hideShippingMethods() {
        let shippingMethodsLength = this.$(this.options.shippingMethods).length;

        if (shippingMethodsLength > 3) {
            this.$(this.options.shippingMethodViewMore).removeClass('d-none');

            this.$(this.options.shippingMethods).each((index, item) => {
                index++;

                if (index > 3) this.$(item).addClass('d-none');
            });
        } else {
            this.$(this.options.shippingMethodViewMore).addClass('d-none');
        }
    }

    showAllShippingMethods() {
        this.$(this.options.shippingMethods).removeClass('d-none');
        this.$(this.options.shippingMethodViewMore).addClass('d-none');
    }

    submitSelectedShippingMethod(input) {
        if(!input) return;

        const inputChecked = this.$(input).eq(0);
        const isPickup = this.$(input).parents(this.options.pickupMethodSelect).length;

        var shippingEditedForm = this.$("[id=dwfrm_shipping][class*=is-right]");
        var shippingForm = this.$("[id=dwfrm_shipping]");
        var shippingRightForm = shippingEditedForm.length ? shippingEditedForm : this.$(shippingForm[shippingForm.length - 1]);

        var $shippingForm = this.isLogged && !this.isEditing ? shippingRightForm : this.$(".postalCode-selector");
        var methodID = inputChecked.val();
        var shipmentUUID = this.$(this.options.selectShippingInfo).find('[name=shipmentUUID]').val();
        var urlParams = this.getAddressFieldsFromUI($shippingForm);
        urlParams.shipmentUUID = shipmentUUID;
        urlParams.methodID = methodID;
        var url = this.$(this.options.shippingMethodList).data('select-shipping-method-url');
        var shippingDays = inputChecked.parent().find('.working-days').text() || inputChecked.parent().find('.arrival-time').text().match(/\d+/)[0];


        if(this.isLogged && this.isEditing) {
            this.$(document).trigger('app:contextLoader:init', [{
                target: this.$(`${this.options.checkoutActionsStageBilling}:visible`, '.is-current')
            }]);
        } else {
            this.$(document).trigger('app:contextLoader:init', [{
                target: this.$(`${this.options.checkoutActionsSaveDelivery}:visible`, '.is-current')
            }]);
        }

        this.$.ajax({
            url: url,
            type: 'post',
            dataType: 'json',
            data: urlParams
        }).done((data) => {

            if (data.responseJSON && data.responseJSON.error) {
                this.options.toast
                .setOptions({
                    type: 'error',
                    buttonMsg: 'Ok',
                    msgText: data.responseJSON.errorMessage
                })
                .openToast();

                return;
            }

            // replace old informations about installments and adjust colors
            if(data.installmentsTemplate) {
                this.$(this.options.creditCardInstallmentsContainer).html(data.installmentsTemplate);
            };

            // active buttons
            this.$(this.options.checkoutActionsStageBilling).addClass('is-active');
            this.$(this.options.checkoutActionsSaveDelivery).addClass('is-active');

            // set days, shipping value and postal code
            this.shippingValue = data.order.totals.totalShippingCost;
            this.shippingDays = shippingDays;

            // set shippment name and value
            this.$(this.options.checkoutAciontsShippingDate).html(shippingDays);
            this.$(this.options.checkoutActionsTotalPrice).html(data.order.priceTotal);

            // set title checkout
            this.$(this.options.checkout_labelTitle).html(data.checkoutTitleTemplate);

            this.$(this.options.checkoutSummaryText).html(data.summaryMessage);

            if(data.isOnlyPickupShipment) {
                this.$(this.options.changeBillingAddressCheckBox).addClass('d-none');
                this.$(this.options.shippingAddressUseAsBillingAddress).val('true');
                this.$(this.options.billingAddressContent).addClass('d-block');
                this.$(this.options.billingAddressTitle).removeClass('d-none');
                this.$(document).trigger('app:checkout:verifyBillingAddress');
            } else {
                this.$(this.options.changeBillingAddressCheckBox).removeClass('d-none');
                this.$(this.options.shippingAddressUseAsBillingAddress).val('false');
                this.$(this.options.billingAddressContent).removeClass('d-block');
                this.$(this.options.billingAddressTitle).addClass('d-none');
            }

            this.$(this.options.shippingSummaryTitle).html(data.shippingTitle);

            if(isPickup) {
                this.hasPickup = true;

                if(this.isLogged && !this.isSpliting) {
                    this.$(this.options.checkoutLastText).addClass('d-none');
                    this.$(this.options.checkoutSummaryText).removeClass('d-none');
                }

                if(this.isSpliting) {
                    return this.saveSelecteShippingSpliting(data.renderedTemplate);
                } else {
                    this.$(this.options.checkoutLastShippingValue).addClass('d-none');
                    this.$(this.options.checkoutLastShippingValuePickup).removeClass('d-none');
                    this.$(this.options.checkoutLastDeliveryDays).html(shippingDays);

                    this.$(this.options.checkoutActionsLabelSubTotal).addClass('d-none');
                    this.$(this.options.checkoutActionsLabelTotal).removeClass('d-none');

                    if(this.isLogged && this.isEditing && !data.isOnlyPickupShipment) {
                        // get link to edit cep
                        const link = data.editAddressUrl;
                        this.$(document).trigger('app:frame:loadPage', [{ link, isModal: true }]);

                        return;
                    }
                }

                this.$(document).trigger('app:frame:closeModal');
                this.finishSaveSelectedShipping();
            } else {
                this.hasPickup = false;
            }

        }).fail((data) => {

            if(data.responseJSON && data.responseJSON.error) {
                this.options.toast
                            .setOptions({
                                type: 'error',
                                buttonMsg: 'Ok',
                                msgText: data.responseJSON.errorMessage
                            })
                            .openToast();
            }

        }).always(() => {
            this.$(document).trigger('app:contextLoader:finish');
        });
    }

    /**
    * returns address properties from a UI form
    * @param {Form} form - the Form element
    * @returns {Object} - a JSON object with all values
    */
    getAddressFieldsFromUI(form) {
        var address = {
            firstName: $('input[name$=_firstName]', form).val(),
            lastName: $('input[name$=_lastName]', form).val(),
            address1: $('input[name$=_address1]', form).val(),
            address2: $('input[name$=_address2]', form).val(),
            suite: $('input[name$=_suite]', form).val(),
            city: $('input[name$=_city]', form).val(),
            postalCode: $('input[name$=_postalCode]', form).val(),
            stateCode: $('select[name$=_stateCode],input[name$=_stateCode]', form).val(),
            countryCode: $('select[name$=_country]', form).val(),
            phone: $('input[name$=_phone]', form).val()
        };
        return address;
    }

    openDrawerCheckout() {
        this.$(this.options.installmentDrawer).addClass("drawer--isOpen")
        this.$(this.options.labelinstallment).css("display", "block");
        this.$(this.options.installmentNumber).addClass("installment__number-show")

        setTimeout(() => {
            this.$(this.options.installmentDrawer).addClass("drawer--isVisible")
        }, 200);

        this.isDrawerOpen = true;
    }

    closeDrawerCheckout() {
        if(isMobile()) {
            this.$(this.options.installmentDrawer)
                .removeClass("drawer--isOpen")
                .removeClass("drawer--isVisible")

            this.isDrawerOpen = false;
        } else {
            this.$(this.options.installmentDrawer).css("display", "none");
            this.$(this.options.installmentBox).removeClass("dropdown-label");
            this.$(this.options.drawerlabelClick).removeClass("installment-drawer");
        }
    }

    openDrawerState() {
        this.$(this.options.stateDrawer).addClass("drawer--isOpen")

        setTimeout(() => {
            this.$(this.options.stateDrawer).addClass("drawer--isVisible")
        }, 200);
    }

    closeDrawerState() {
        if(isMobile()) {
            this.$(this.options.stateDrawer)
                .removeClass("drawer--isOpen")
                .removeClass("drawer--isVisible")

            this.isDrawerOpen = false;
        } else {
            this.$(this.options.stateDrawer).css("display", "none");
            this.$(this.options.chooseStateDrawer).removeClass("dropdown-label");
        }
    }

    setShippingError(error) {
        const feedback = this.$(this.options.inputPostalCode).parent().find('.invalid-feedback');
        feedback.html(error || feedback.data('error')).removeClass('d-none');
    }

    saveSelecteShippingSpliting(renderedTemplate) {
        this.$(this.options.shippingMethodBlock).html(renderedTemplate);
        this.$(document).trigger('app:frame:closeModal');

        if(!this.$(this.options.checkoutShippingPlaceButton).length) {
            this.$(this.options.checkoutActionsLabelSubTotal).addClass('d-none');
            this.$(this.options.checkoutActionsLabelTotal).removeClass('d-none');

            if(this.isLogged && !this.isEditing) {
                this.setActionButtons(this.$(`${this.options.checkoutActionsInitial} ${this.options.checkoutActionsSaveDelivery}`));
                return;
            }

            this.setActionButtons(this.$(`${this.options.checkoutActionsInitial} ${this.options.checkoutActionsStageBilling}`));
        } else {
            this.setActionButtons(this.$(`${this.options.checkoutActionsInitial} ${this.options.checkoutActionsStageBilling}`), true);
        }
    }

    finishSaveSelectedShipping() {
        this.showMultishippingTexts();
        this.showShippingSummary();
        this.$(document).trigger('app:contextLoader:finish');

        if(this.isLogged) {
            this.setActionButtons(this.$(this.options.checkoutActionsStagePayment));
        } else {
            if(this.postalCode == '') this.postalCode = this.$(this.options.shippingTitlePostalCode).text();
            this.$(this.options.checkoutLastPostalCode).html(this.postalCode);
            this.setActionButtons(this.$(this.options.checkoutActionsStageBilling));
            this.$(`${this.options.checkoutActionsInitial} ${this.options.checkoutActionsStageBilling}`).addClass('is-active');
        }
    }

    saveInformations(button) {
        // change shipping value and shipping days
        this.$(this.options.checkoutLastShippingValue).html(this.shippingValue);
        this.$(this.options.checkoutLastDeliveryDays).html(this.shippingDays);

        const url = this.$(button).data('url');

        this.isEditingPayment = false;

        this.$(document).trigger('app:contextLoader:init', [{
            target: this.$(`${this.options.checkoutActionsSaveDelivery}:visible`, '.is-current')
        }]);

        if(this.$(button).hasClass('is-shipping') || this.$(button).hasClass('is-select-shipping')) {

            if(this.$(button).hasClass('is-select-shipping')) {
                if(this.isSpliting) {

                    this.$.ajax({
                        type: 'GET',
                        url
                    }).done((data) => {
                        if (data.success) {
                            this.saveSelecteShippingSpliting(data.renderedTemplate);
                        } else {
                            this.options.toast
                                        .setOptions({
                                            buttonOk: true,
                                            buttonMsg: "Ok",
                                            type: "error",
                                            msgText: data.errorMsg,
                                        }).openToast();
                        }
                    }).fail(() => {

                    }).always(() => {
                        this.$(document).trigger('app:contextLoader:finish');
                    });

                    return;
                } else {
                    this.$(this.options.checkoutActionsLabelSubTotal).addClass('d-none');
                    this.$(this.options.checkoutActionsLabelTotal).removeClass('d-none');
                }

                this.$(document).trigger('app:frame:closeModal');
            }

            this.finishSaveSelectedShipping();
        }

        if(this.$(button).hasClass('is-payment')) {
            // get the atual shipping form
            var shippingForm = this.$("[id=dwfrm_shipping]");
            var shippingRightForm = this.$(shippingForm[shippingForm.length - 1]);
            var formData = new FormData(shippingRightForm[0]);

            if(this.options.validator.validateForm(shippingRightForm, true)) {
                this.$.ajax({
                    type: 'POST',
                    url: shippingRightForm.attr('action'),
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                }).done((result) => {
                    if (!result.form.shippingAddress.valid) {
                        if (typeof(result.fieldErrors) != 'undefined' && result.fieldErrors.length > 0) {
                            this.options.validator.clearForm(shippingRightForm);
                            var firstInputError = Object.getOwnPropertyNames(result.fieldErrors[0]);
                            firstInputError = firstInputError.length > 1 ? firstInputError[0] : firstInputError;
                            var inputFocus = $("[name='"+firstInputError+"']");
                            inputFocus.focus();
                            this.options.validator.validateForm(shippingRightForm, true, result.fieldErrors);
                        }
                    } else{
                        // remove shipping form looged user when change the address
                        this.$(this.options.checkoutLastShippingForm).remove();

                        // get informations to update first page
                        const form = this.getAddressFieldsFromUI(shippingRightForm);
                        for(let i = 0; i < Object.entries(form).length; i++) {
                            const objectEntries = Object.entries(form);
                            this.$(`${this.options.checkoutLastInfo}${objectEntries[i][0]}`).html(objectEntries[i][1]);
                        }

                        this.$(this.options.checkoutSummaryText).html(result.summaryMessage);
                        this.$(this.options.checkoutLastText).addClass('d-none');
                        this.$(this.options.checkoutSummaryText).removeClass('d-none');

                        // show first page again
                        this.showMultishippingTexts();
                        this.showShippingSummary();

                        this.setActionButtons(this.$(this.options.checkoutActionsStagePayment));

                        // close modal and active checkout page
                        this.$(document).trigger('app:frame:closeModal', [{
                            fallback: () => { this.firstPage = true; }
                        }]);
                    }
                }).fail((data) => {
                    if(data.responseJSON.errorMessage) {
                        this.options.toast
                                    .setOptions({
                                        buttonOk: true,
                                        buttonMsg: "Ok",
                                        type: "error",
                                        msgText: data.responseJSON.errorMessage,
                                    }).openToast();
                    }
                }).always(() => {
                    this.$(document).trigger('app:contextLoader:finish');
                });
            } else {
                this.$(document).trigger('app:contextLoader:finish');
            }
        }
    }

    showMultishippingTexts() {
        const totalProducts = this.$(this.options.checkoutTile, '.checkout__tiles').length;
        this.$(this.options.checkoutMultishippingTotalMethods).text(totalProducts);

        if(this.isSpliting) {
            this.$(this.options.checkoutMultishippingTitle).removeClass('d-none');
            this.$(this.options.checkoutMultishippingMethods).removeClass('d-none');
            this.$(this.options.checkoutMultishippintLastText).removeClass('d-none');

            this.$(this.options.checkoutLastText).addClass('d-none');
            this.$(this.options.shippingTitle).addClass('d-none');
            this.$(this.options.checkoutAciontsShippingDate).addClass('d-none');

            if(this.isEditing) this.$(this.options.checkoutSummaryText).addClass('d-none');
        } else {
            this.$(this.options.checkoutMultishippingTitle).addClass('d-none');
            this.$(this.options.checkoutMultishippingMethods).addClass('d-none');
            this.$(this.options.checkoutMultishippintLastText).addClass('d-none');

            if(!this.hasPickup && !this.isEditing && this.isLogged) {
                this.$(this.options.checkoutLastText).removeClass('d-none');
            } else {
                this.$(this.options.checkoutLastText).addClass('d-none');
                this.$(this.options.checkoutSummaryText).removeClass('d-none');
            }

            this.$(this.options.shippingTitle).removeClass('d-none');
            this.$(this.options.checkoutAciontsShippingDate).removeClass('d-none');
        }

        this.isEditing = false;
    }

    showShippingSummary() {
        if(this.isLogged) {
            this.$(this.options.checkoutLastStepLogged).removeClass('d-none');
        } else {
            this.$(this.options.checkoutShippingSummary).removeClass('d-none');
        }
        this.$(this.options.checkoutShipping).addClass('d-none');
    }

    setActionButtons(actionButton, removeActiveClass = false) {
        if(!actionButton.length) return;

        this.$(this.options.checkoutActionsButton).addClass('d-none');

        if(actionButton) {
            actionButton.removeClass('d-none');

            if(removeActiveClass) actionButton.removeClass('is-active');
        }

        return this;
    }

    verifyPostalCode(showError = false, initialCheck = false) {
        const inputPostalCode = this.$(this.options.inputPostalCode);
        const patternCEP = inputPostalCode.attr('pattern');
        const cep = inputPostalCode.val();
        const regexCEP = cep.match(patternCEP);
        const minLenght = inputPostalCode.attr('minlength');

        if(!cep.length) return;

        if (showError) {
            if(!regexCEP) {
                this.setShippingError();

                this.$(this.options.shippingPostalCodeClear).addClass('d-none');

                if(this.$(this.options.shippingPostalCodeReturn).hasClass('is-available')) {
                    this.$(this.options.shippingPostalCodeReturn).removeClass('d-none');
                }
            }

            return;
        }

        this.$(this.options.multishippingOrderButton).addClass('d-none');
        this.$(this.options.shippingMethodBlock).addClass('d-none');
        this.$(this.options.inputPostalCode).parent().find('.invalid-feedback').addClass('d-none');

        // removes all characters that are not numbers or -
        const regexLetra = cep.substring(cep.length - 1).match(/^[0-9]?-?$/);
        if(!regexLetra) {
            inputPostalCode.val(cep.substring(0, cep.length - 1));
            return;
        }

        if((cep.length >= minLenght && regexCEP) && !showError) {
            this.postalCode = cep;

            this.$(this.options.shippingPostalCodeClear).addClass('d-none');
            this.$(this.options.shippingPostalCodeReturn).addClass('d-none');
            this.$(this.options.inputPostalCode).trigger('blur');

            let url = window.app.urls.autoCompleteAddress;
            //to valid cep before call submitUpdateShipmentList
            this.$.ajax({
                type: 'GET',
                url: url,
                data: {
                    postalCode:  this.postalCode
                }
            }).done((data) => {
                if (data.success) {
                    this.submitUpdateShipmentList(inputPostalCode);
                }
                else {
                    if (data.errorMsg) {
                        this.options.toast
                            .setOptions({
                                buttonOk: true,
                                buttonMsg: "Ok",
                                type: "error",
                                msgText: data.errorMsg,
                            }).openToast();
                    }
                }
            }).fail((data) => {
                if (data.responseJSON && data.responseJSON.message) {
                    this.options.toast
                        .setOptions({
                            buttonOk: true,
                            buttonMsg: "Ok",
                            type: "error",
                            msgText: data.responseJSON.message,
                        }).openToast();
                }
            });

            if(initialCheck) {
                this.$(this.options.shippingPostalCodeContainer).addClass('d-none');
                this.$(this.options.shippingSelectedContainer).removeClass('d-none');
            }
        }
    }

    multishippingOrder(multiShipping = 'button') {
        const btn = this.$(this.options.multishippingOrderButton);
        const url = btn.data('url');
        let multiShip = multiShipping == 'button' ? btn.data('multiship') : multiShipping;

        this.isSpliting = multiShip ? true : false;

        this.updateShippingDrawer(url, 'POST', {usingMultiShip: multiShip}, (data) => {
            btn.text(multiShip ? btn.data('mergetext') : btn.data('splittext'))
               .removeClass(`${this.options.mergeClass} ${this.options.splitClass}`)
               .addClass(`${multiShip ? this.options.mergeClass : this.options.splitClass}`)
               .data('multiship', !multiShip);

            if(data.order.items.totalQuantity == 1) btn.addClass('d-none');

            if(this.isSpliting) {
                this.$(this.options.shippingMethodBlock).addClass('is-spliting');
            } else {
                this.$(this.options.shippingMethodBlock).removeClass('is-spliting');
            }

            // scroll page to top
            if(!multiShip) this.$(this.options.containerPageCheckout).scrollTop(0);

            this.setActionButtons(this.$(this.options.checkoutActionsStageBilling));
        });
    }

    editMultishipItem(target) {
        const btn = this.$(target);
        const url = btn.data('url');
        // TODO: decide whether to update the shipping drawer partially or fully
        // This does a complete update
        this.updateShippingDrawer(url, 'POST');
        this.setActionButtons(this.$(this.options.checkoutActionsStageBilling));
    }

    updateShippingDrawer(url, method = 'GET', data = {}, callback) {
        const btn = this.$(this.options.multishippingOrderButton);
        const wrapper = this.$(this.options.shippingMethodBlock);

        this.$.ajax({
            type: method,
            url,
            data,
        }).done((data) => {
            if (data.success) {
                wrapper.html(data.renderedTemplate).removeClass('d-none');

                if(data.order.priceTotal) this.$(this.options.checkoutActionsTotalPrice).html(data.order.priceTotal);

                // verify if hava shipping methods
                if(data.showEditDrawer) {
                    this.$(this.options.shippingPostalCodeContainer).removeClass('d-none');
                    this.$(this.options.shippingSelectedContainer).addClass('d-none');
                } else if(data.showEditDrawer == false) {
                    this.$(this.options.shippingPostalCodeContainer).addClass('d-none');
                    this.$(this.options.shippingSelectedContainer).removeClass('d-none');
                }

                if (callback) callback(data);
            }
            else {
                this.options.toast
                    .setOptions({
                        buttonOk: true,
                        buttonMsg: "Ok",
                        type: "error",
                        msgText: data.errorMsg,
                    }).openToast();
            }
        });
    }

    showCouponForm() {
        this.$(this.options.checkoutCouponOpenForm).addClass('d-none');
        this.$(this.options.checkoutCouponForm).removeClass('d-none');
    }

    hideCouponForm() {
        this.$(this.options.checkoutCouponOpenForm).removeClass('d-none');
        this.$(this.options.checkoutCouponForm).addClass('d-none');
    }

    verifyCouponField() {
        const form = this.$(this.options.checkoutCouponForm);
        const couponInput = this.$(this.options.checkoutCouponField);
        const couponUrl = couponInput.data('previewurl') || couponInput.parents('form').attr('action');
        const couponCode = couponInput.val();

        this.$.ajax({
            method: "GET",
            url: couponUrl,
            data: { couponCode }
        }).done((data) => {

            if(!data.requireValidation) {
                this.submitCoupon(false);
                return;
            }

            this.$(this.options.checkoutCouponValidationFields).empty().removeClass('d-none').html(data.renderedTemplate);
            VMasker(this.$(this.options.cpfInput)).maskPattern("999.999.999-99");

            couponInput.addClass('is-validated');

        }).fail((data) => {
            if(data.responseJSON.fieldErrors.length) {
                this.options.validator.validateForm(form, true, data.responseJSON.fieldErrors);
            }

            this.$(this.options.checkoutCouponValidationFields).addClass('d-none')
            if(data.responseJSON.errorMessage) {
                this.options.toast
                            .setOptions({
                                buttonOk: true,
                                buttonMsg: "Ok",
                                type: "error",
                                msgText: data.responseJSON.errorMessage,
                            }).openToast();
            }
        }).always(() => {
            this.$(document).trigger('app:contextLoader:finish');
        });
    }

    checkValidationFieldsCoupon() {
        const submitButton = this.$(this.options.checkoutCouponValidationSubmit);
        const submitButtonRight = submitButton.eq(submitButton.length - 1);
        const email = this.$(this.options.checkoutCouponEmail);
        const cpf = this.$(this.options.checkoutCouponCpf);
        const regexEmail = /^[\w.%+-]+@[\w.-]+\.[\w]{2,6}$/i;
        const emailValidate = regexEmail.test(email.val());
        let valid = false;

        if(email.length && cpf.length) {
            if(emailValidate && cpf.val().length == 14) {
                valid = true;
            }
        } else {
            if((email.length && emailValidate) || (cpf.length && cpf.val().length == 14)) {
                valid = true;
            }
        }

        if(valid) {
            submitButtonRight.removeClass('d-none');
        } else {
            submitButtonRight.addClass('d-none');
        }
    }

    submitCoupon(requireValidation = true) {
        const form = this.$(this.options.checkoutCouponForm);
        const checkoutActionsTotalPrice = this.$(this.options.checkoutActionsTotalPrice);
        let totalPriceHTML = checkoutActionsTotalPrice.html();

        let data = requireValidation ? this.$('[name!="cpf"]', this.options.checkoutCouponForm).serialize() : form.serialize();

        if(requireValidation) {
            const cpf = this.$(this.options.checkoutCouponCpf).val().replace(/[^\w]+/g, "");
            data += `&cpf=${cpf}`
        };

        this.$.ajax({
            method: "GET",
            url: form.attr('action'),
            data,

        }).done((data) => {
            if(data.refreshTilesUrl) {
                this.$.ajax({
                    method: "GET",
                    url: data.refreshTilesUrl,
                }).done((data) => {
                    this.$(this.options.checkoutCouponValidationFields).addClass('d-none');
                    this.hideCouponForm();
                    this.$(this.options.checkoutCouponForm)[0].reset();

                    this.renderCouponHTML(this.options.checkoutCouponTiles, data);
                });
            }

            if(data.basketTotal) totalPriceHTML = data.basketTotal;

            if(data.error && data.errorMessage) {
                this.options.toast
                            .setOptions({
                                buttonOk: true,
                                buttonMsg: "Ok",
                                type: "error",
                                msgText: data.errorMessage,
                            }).openToast();
            }

        }).fail((data) => {
            if(data.responseJSON && data.responseJSON.fieldErrors) {
                this.options.validator.validateForm(form, true, data.responseJSON.fieldErrors);
                return;
            }

            if(data.responseJSON && data.responseJSON.errorMessage) {
                this.options.toast
                            .setOptions({
                                buttonOk: true,
                                buttonMsg: "Ok",
                                type: "error",
                                msgText: data.responseJSON.errorMessage,
                            }).openToast();
            }
        }).always(() => {
            this.$(document).trigger('app:contextLoader:finish');
            checkoutActionsTotalPrice.html(totalPriceHTML);
        });
    }

    removeCoupon(el) {
        const url = this.$(el).data('link');
        const checkoutActionsTotalPrice = this.$(this.options.checkoutActionsTotalPrice);
        let totalPriceHTML = checkoutActionsTotalPrice.html();

        this.$.ajax({
            method: "GET",
            url,

        }).done((data) => {
            if(data.refreshTilesUrl) {
                this.$.ajax({
                    method: "GET",
                    url: data.refreshTilesUrl,
                }).done((data) => {
                    this.renderCouponHTML(this.options.checkoutCouponTiles, data);
                });
            }

            // show payment methods again
            if(!data.error) {
                this.$(this.options.checkoutPaymentMethodsTitle).removeClass('d-none');
                this.$(this.options.paymentOptionsTabContent).removeClass('d-none');
                this.$(this.options.paymentOptionsTabs).removeClass('d-none');
            }

            if(data.basketTotal) totalPriceHTML = data.basketTotal;

        }).fail((data) => {
            if(data.responseJSON.errorMessage) {
                this.options.toast
                            .setOptions({
                                buttonOk: true,
                                buttonMsg: "Ok",
                                type: "error",
                                msgText: data.responseJSON.errorMessage,
                            }).openToast();
            }
        }).always(() => {
            checkoutActionsTotalPrice.html(totalPriceHTML);
        });
    };

    submitUseBalance(elem) {
        const url = this.$(this.options.checkoutBalanceUseForm).attr('action');
        const use = this.$(elem).is(':checked');
        const checkoutActionsTotalPrice = this.$(this.options.checkoutActionsTotalPrice);
        let totalPriceHTML = checkoutActionsTotalPrice.html();

        this.$.ajax({
            method: "GET",
            url,
            data: { use: use }

        }).done((data) => {
            if(data.error) {
                this.options.toast
                            .setOptions({
                                buttonOk: true,
                                buttonMsg: "Ok",
                                type: "error",
                                msgText: data.errorMessage,
                            }).openToast();
            }

            if(data.refreshTilesUrl) {
                this.$.ajax({
                    method: "GET",
                    url: data.refreshTilesUrl,
                }).done((data) => {
                    this.renderCouponHTML(this.options.checkoutCouponTiles, data);
                });
            }

            if(data.basketTotal) totalPriceHTML = data.basketTotal;

        }).fail((data) => {

            if(data.responseJSON.errorMessage) {
                this.options.toast
                            .setOptions({
                                buttonOk: true,
                                buttonMsg: "Ok",
                                type: "error",
                                msgText: data.responseJSON.errorMessage,
                            }).openToast();
            }

        }).always(() => {
            checkoutActionsTotalPrice.html(totalPriceHTML)
        });
    }

    submitBalance() {
        const form = this.$(this.options.checkoutBalanceForm);
        const url = form.attr('action');
        const inputUsage = this.$(this.options.checkoutBalanceUsage);
        const value = inputUsage.val().replace(/,/g, '.');
        const checkoutActionsTotalPrice = this.$(this.options.checkoutActionsTotalPrice);
        let totalPriceHTML = checkoutActionsTotalPrice.html();

        this.$.ajax({
            method: "GET",
            url,
            data: {balanceUsage: value}

        }).done((data) => {
            if(data.error) {
                this.options.toast
                            .setOptions({
                                buttonOk: true,
                                buttonMsg: "Ok",
                                type: "error",
                                msgText: data.errorMessage,
                            }).openToast();
            }

            if(data.refreshTilesUrl) {
                this.$.ajax({
                    method: "GET",
                    url: data.refreshTilesUrl,
                }).done((data) => {
                    this.renderCouponHTML(this.options.checkoutCouponTiles, data);
                });
            }

            if(data.basketTotal) totalPriceHTML = data.basketTotal;

            // replace old informations about installments and adjust colors
            if(data.installmentsTemplate) {
                this.$(this.options.creditCardInstallmentsContainer).html(data.installmentsTemplate);
            };

            // if the purchase comes out for free
            this.$(this.options.billingIsPaymentFree).val(data.isPaymentFree);
            if(data.isPaymentFree) {
                this.$(this.options.checkoutPaymentMethodsTitle).addClass('d-none');
                this.$(this.options.paymentOptionsTabContent).addClass('d-none');
                this.$(this.options.paymentOptionsTabs).addClass('d-none');
            } else {
                this.$(this.options.checkoutPaymentMethodsTitle).removeClass('d-none');
                this.$(this.options.paymentOptionsTabContent).removeClass('d-none');
                this.$(this.options.paymentOptionsTabs).removeClass('d-none');
            }

            this.$(document).trigger('app:checkout:verifyShippingForm');

        }).fail((data) => {
            if(data.responseJSON && data.responseJSON.errorMessage) {
                this.options.toast
                            .setOptions({
                                buttonOk: true,
                                buttonMsg: "Ok",
                                type: "error",
                                msgText: data.responseJSON.errorMessage,
                            }).openToast();
            }

        }).always(() => {
            checkoutActionsTotalPrice.html(totalPriceHTML);
            this.$(document).trigger('app:contextLoader:finish');
        });
    }

    renderCouponHTML(elem, html) {
        this.$(elem).empty().removeClass('d-none').html(html);
        VMasker(this.$(this.options.checkoutBalanceUsage)).maskMoney({
            precision: 2,
            separator: ',',
            delimiter: '.',
        });
    }

    editBalaceUse() {
        this.$(this.options.checkoutBalanceGroup).addClass('is-editable');
        this.$(this.options.checkoutBalanceEdit).addClass('d-none');
        this.$(this.options.checkoutCouponCardValue).addClass('is-edit');
        this.$(this.options.checkoutBalanceUsage).val('0,00').focus();
    }

    shippingEdit() {
        if(this.$('body').hasClass('modal-open')) this.$(document).trigger('app:frame:closeModal');

        this.$(this.options.checkoutLastStepLogged).addClass('d-none');
        this.$(this.options.checkoutShippingSummary).addClass('d-none');
        this.$(this.options.shippingSelectedContainer).addClass('d-none');
        this.$(this.options.multishippingOrderButton).addClass('d-none');
        this.$(this.options.shippingMethodBlock).addClass('d-none');
        this.$(this.options.shippingPostalCodeContainer).removeClass('d-none');
        this.$(this.options.shippingPostalCodeReturn).removeClass('d-none').addClass('is-available');
        this.$(this.options.checkoutShipping).removeClass('d-none');

        this.$(this.options.checkoutActionsLabelSubTotal).removeClass('d-none');
        this.$(this.options.checkoutActionsLabelTotal).addClass('d-none');

        this.setActionButtons(this.$(this.options.checkoutActionsStageBilling), true);

        this.$(this.options.inputPostalCode).val('').next().removeClass('active');

        this.isEditing = true;
    }

    verifyLastStepOrder() {
        const inputEmail = this.$(this.options.placeOrderEmailInput);
        const cpf = this.$(`${this.options.placeOrderCpfInput}:visible`);
        const patternEmail = inputEmail.length ? inputEmail.attr('pattern') : '';
        const email = inputEmail.length ? inputEmail.val() : '';
        const regexEmail = inputEmail.length ? email.match(patternEmail) : false;
        const terms = this.$(this.options.termsAndPrivacy).is(':checked');
        const birthDate = this.$(this.options.placeOrderBirthDate);
        const birthDatePattern = birthDate.val().match(/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/);

        let cpfValid = true;
        let emailValid = true;
        let termsValid = true;
        let birthDateValid = true;

        if(cpf.length) {
            if(cpf.val().length < 14) {
                cpfValid = false;
            } else {
                cpfValid = true;
            }
        }

        if (inputEmail.length) {
            if(regexEmail) {
                emailValid = true;
            } else {
                emailValid = false;
            }
        }

        if(terms) {
            termsValid = true;
        } else {
            termsValid = false;
        }

        if(birthDate.length) {
            if(birthDatePattern) {
                birthDateValid = true;
            } else {
                birthDateValid = false;
            }
        }

        if(emailValid && cpfValid && termsValid && birthDateValid) {
            this.$(this.options.checkoutActionsStagePlaceOrder).addClass('is-active');
        } else {
            this.$(this.options.checkoutActionsStagePlaceOrder).removeClass('is-active');
        }
    }

    verifyShippingForm(target = false) {
        if(this.$(`${this.options.billingForm}:visible`).length) return;

        let shippingRightForm;

        if(target) {
            shippingRightForm = this.$(target).parents('form');
        } else {
            const shippingForm = this.$("[id=dwfrm_shipping]");
            shippingRightForm = this.$(shippingForm[shippingForm.length - 1]);
        }

        const activeButton = shippingRightForm.parents(this.options.checkoutModal).find(`${this.options.checkoutActionsButton}:visible`);

        if(this.options.validator.validateForm(shippingRightForm)) {
            activeButton.addClass('is-active');
            shippingRightForm.addClass('is-right');
        } else {
            activeButton.removeClass('is-active')
        }
    }

    verifyPostalCodeChange() {
        if(this.isLogged && this.isEditing && !this.isSpliting) {
            this.setActionButtons(this.$(this.options.checkoutActionsStageBilling, '.modals-viewport .is-current'));
        } else {
            this.setActionButtons(this.$(this.options.checkoutActionsSaveDelivery, '.modals-viewport .is-current'));
        }
    }

    setEditLink(target) {
        const url = this.$(target).attr('href');
        this.$(this.options.shippingEditAddress).attr('data-link', url);

        return this;
    }

    showFirstPage() {
        this.$(this.options.checkoutLastStepLogged).addClass('d-none');
        this.$(this.options.shippingPostalCodeContainer).addClass('d-none');
        this.$(this.options.checkoutShippingSummary).addClass('d-none');

        this.$(this.options.shippingSelectedContainer).removeClass('d-none');
        this.$(this.options.checkoutShipping).removeClass('d-none');

        let removeActive = false;

        if(!this.isSpliting) {
            removeActive = true;
            this.$(this.options.checkoutActionsLabelSubTotal).removeClass('d-none');
            this.$(this.options.checkoutActionsLabelTotal).addClass('d-none');
        };

        this.setActionButtons(this.$(`${this.options.checkoutActionsInitial} ${this.options.checkoutActionsStageBilling}`), removeActive);

        this.firstPage = false;
    }

    checkoutUserLastCardEdit() {
        //this.$(this.options.storedPaymentInstrumentsList).show();
        this.$(this.options.paymentOptionsTabs).removeClass('d-none');
        this.$(this.options.checkoutCardInput).removeClass('d-none');
        this.$(this.options.checkoutLastUserCard).addClass('d-none');
        this.$(this.options.creditCardTabContent).removeClass('is-card-correct');
        this.$(this.options.paymentCreditCardToken).val('');
        this.$(document).trigger('app:checkout:verifyShippingForm');

        if(isUsingLastPaymentCard) isUsingLastPaymentCard = false;
    }

    paymentEdit(button) {
        if(this.isLogged) {
            this.checkoutUserLastCardEdit();
            this.firstPage = false;
            this.$(document).trigger('app:frame:closeModal');
        } else {
            this.isEditingPayment = true;
            const link = this.$(button).data('url');
            this.$(document).trigger('app:frame:loadPage', [{ link, isModal: true }]);
        }
    }

    listen() {
        VMasker(this.$(this.options.checkoutBalanceUsage)).maskMoney({
            precision: 2,
            separator: ',',
            delimiter: '.',
        });

        this.$(document).trigger('app:contextLoader:finish');

        let debouncePostalCode = Debounce((ev) => {
            if (ev.key == 'Control' || ev.key == 'Shift' || ev.ctrlKey || ev.shiftKey) return this;

            this.verifyPostalCode();
        }, 300);

        this.$(this.options.inputPostalCode).on("keyup paste", debouncePostalCode);

        this.$(this.options.inputPostalCode).on('blur', () => {
            this.verifyPostalCode(true);
        });

        this.$(this.options.shippingPostalCodeClear).on(this.tapEvent, (ev) => {
            ev.preventDefault;
            ev.stopPropagation();

            this.$(this.options.shippingPostalCodeClear).addClass('d-none');
            this.$(this.options.shippingPostalCodeReturn).removeClass('d-none');
            this.$(this.options.inputPostalCode).val('').trigger('keyup');
        });

        this.$(this.options.shippingPostalCodeReturn).on(this.tapEvent, (ev) => {
            ev.preventDefault;
            ev.stopPropagation();

            const shippingTitlePostalCode = this.$(this.options.shippingTitlePostalCode);

            if(shippingTitlePostalCode.text()) {
                this.$(this.options.inputPostalCode).val(shippingTitlePostalCode.text());
                this.submitUpdateShipmentList(this.$(this.options.inputPostalCode));
            }
            this.hideShippingPostalCode();
        });

        this.$(this.options.shippingMethodViewMore).on(this.tapEvent, (ev) => {
            ev.preventDefault;
            ev.stopPropagation();

            this.showAllShippingMethods();
        })

        this.$('body').off(this.tapEvent, this.options.inputRadioShippingMethod).on(this.tapEvent, this.options.inputRadioShippingMethod, (ev) => {
            this.submitSelectedShippingMethod(ev.target);
        });

        this.$(this.options.inputPostalCode).keydown((ev) => {
            if (ev.keyCode == 13) {
                ev.preventDefault();

                return false;
            }
        });

        this.$('body').on('keyup', this.options.placeOrderEmailInput, () => {
            this.verifyLastStepOrder();
        });

        this.$('body').on('change', this.options.termsAndPrivacy, () => {
            this.verifyLastStepOrder();
        });

        this.$('body').on(this.tapEvent, this.options.checkoutPlaceLink, (ev) => {
            this.setEditLink(ev.currentTarget);
        });

        this.$('body').on('keyup', this.options.placeOrderCpfInput, () => {
            //delay because if the user fills in more digits than the need
            setTimeout(() => this.verifyLastStepOrder(), 100);
        });

        this.$('body').on('keyup', this.options.placeOrderBirthDate, () => {
            //delay because if the user fills in more digits than the need
            setTimeout(() => this.verifyLastStepOrder(), 100);
        });

        this.$('body').on(this.tapEvent, this.options.inputShippingPostalCode, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.shippingEdit();
        });

        this.$('body').on(this.tapEvent, this.options.shippingOptionsEdit, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.shippingEdit();
        });

        this.$('body').on(this.tapEvent, this.options.shippingEditAddress, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            if(!this.isSpliting) {
                const link = this.$(ev.currentTarget).data('link');
                this.$(document).trigger('app:frame:loadPage', [{ link, isModal: true }]);
            } else {
                this.$(this.options.checkoutShipping).removeClass('d-none');
                this.$(this.options.checkoutShippingSummary).addClass('d-none');
            }
        });

        this.$('body').on(this.tapEvent, this.options.checkoutActionsStageBilling, (ev) => {
            this.$(document).trigger('app:contextLoader:init', [{
                target: this.$(`${this.options.checkoutActionsStageBilling}:visible`, '.is-current')
            }]);
        });

        this.$('body').on(this.tapEvent, this.options.editMultishipItemButton, (ev) => {
            this.editMultishipItem(ev.currentTarget);
        });

        this.$('body').on(this.tapEvent, this.options.multishippingOrderButton, () => {
            this.multishippingOrder();
        });

        this.$('body').on(this.tapEvent, this.options.checkoutActionsSaveDelivery, (ev) => {
            this.saveInformations(ev.currentTarget);
        });

        this.$('body').on('keyup', `${this.options.shippingForm} input:not(.shippingZipCode)`, (ev) => {
            this.verifyShippingForm(ev.target);
        });

        // Coupon
        this.$('body').on(this.tapEvent, this.options.checkoutCouponOpenForm, () => {
            this.showCouponForm();
        });

        this.$('body').on(this.tapEvent, this.options.checkoutCouponCancel, () => {
            this.hideCouponForm();
        });

        this.$('body').on(this.tapEvent, this.options.checkoutCouponAdd, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.$(document).trigger('app:contextLoader:init', [{
                target: this.$(`${this.options.checkoutCouponAdd}:visible`).parent()
            }]);

            this.verifyCouponField();
        });
        this.$('body').on('submit', this.options.checkoutCouponForm, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            if(this.$(this.options.checkoutCouponField).hasClass('is-validated')) {
                this.$(document).trigger('app:contextLoader:init', [{
                    target: this.$(`${this.options.checkoutCouponValidationSubmit}:visible`).parent()
                }]);

                this.submitCoupon();
            } else {
                this.$(document).trigger('app:contextLoader:init', [{
                    target: this.$(`${this.options.checkoutCouponAdd}:visible`).parent()
                }]);

                this.verifyCouponField();
            }
        });

        this.$('body').on('keyup', this.options.checkoutCouponCpf, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            //delay because if the user fills in more digits than the need
            setTimeout(() => this.checkValidationFieldsCoupon(), 100);
        });
        this.$('body').on('keyup', this.options.checkoutCouponEmail, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.checkValidationFieldsCoupon();
        });

        this.$('body').on(this.tapEvent, this.options.checkoutCouponValidationSubmit, () => {
            this.$(document).trigger('app:contextLoader:init', [{
                target: this.$(`${this.options.checkoutCouponValidationSubmit}:visible`).parent()
            }]);

            this.submitCoupon();
        });

        this.$('body').on(this.tapEvent, this.options.checkoutCouponRemove, (ev) => {
            this.removeCoupon(ev.currentTarget);
        });

        this.$('body').on('change', this.options.checkoutBalanceUse, (ev) => {
            this.submitUseBalance(ev.target);
        });

        this.$('body').on(this.tapEvent, this.options.checkoutBalanceSubmit, () => {
            this.$(document).trigger('app:contextLoader:init', [{
                target: this.$(`${this.options.checkoutBalanceSubmit}:visible`).parent()
            }]);

            this.submitBalance();
        });
        this.$('body').on('submit', this.options.checkoutBalanceForm, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.$(document).trigger('app:contextLoader:init', [{
                target: this.$(`${this.options.checkoutBalanceSubmit}:visible`).parent()
            }]);

            this.submitBalance();
        });

        this.$('body').on(this.tapEvent, this.options.checkoutBalanceEdit, () => {
            this.editBalaceUse();
        });
        // \Coupon

        //Installmente input OPEN
        this.$('body').on(this.tapEvent, this.options.installmentBox, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            if (isMobile()) {
                this.openDrawerCheckout();
            } else {
                this.$(this.options.installmentDrawer).removeClass("drawer");
                this.$(this.options.installmentDrawer).css("display", "block");
                this.$(this.options.installmentBox).addClass("dropdown-label");
            }
        });

        //Installmente input CLOSE
        this.$('body').on(this.tapEvent, this.options.installmentNumber, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            const installmentsText = this.$(ev.target).text();
            const installmentValue = parseInt(this.$(ev.target).data('installmentnumbers'));

            this.$(this.options.drawerlabelClick).text(installmentsText);
            this.$(this.options.installmentInput).val(installmentValue);

            this.closeDrawerCheckout();
            this.$(document).trigger('app:checkout:verifyShippingForm');
        });

        //State input OPEN
        this.$(this.options.accountStateLabel).on(this.tapEvent, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            if (isMobile()) {
                if (this.isDrawerOpen == false  && this.$(this.options.accountStateLabel).is(ev.target)) {
                    ev.preventDefault();
                    this.openDrawerState();
                }
            } else {
                this.$(this.options.stateDrawer).removeClass("drawer")
                this.$(this.options.stateDrawer).css("display", "block");
                this.$(this.options.chooseStateDrawer).addClass("dropdown-label");
            }
        });

        //State input CLOSE
        this.$('body').on(this.tapEvent, this.options.inputShippingStateCodeOption, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            const target = ev.target;
            const stateText = this.$(target).text();
            const value = this.$(target).attr('value');
            this.$(this.options.inputShippingStateCode).val(value);
            this.$(this.options.accountStateLabel).text(stateText);
            this.verifyShippingForm();

            this.closeDrawerState();
            this.$(document).trigger('app:checkout:verifyShippingForm');
        });

        //State billing input CLOSE
        this.$('body').on(this.tapEvent, this.options.inputBillingStateCodeOption, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            const target = ev.target;
            const stateText = this.$(target).text();
            const value = this.$(target).attr('value');
            this.$(this.options.inputBillingState).val(value);
            this.$(this.options.labelBillingState).text(stateText);

            this.closeDrawerState();
            this.$(document).trigger('app:checkout:verifyShippingForm');
        });

        this.$('body').on(this.tapEvent, this.options.checkoutLastUserCardEdit, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.checkoutUserLastCardEdit();
        });

        this.$('body').on(this.tapEvent, this.options.paymentOptionsEdit, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.paymentEdit(ev.currentTarget);
        });





        // from here thing that can or should be called only once
        if(this.isListening) return;
        this.isListening = true;
        this.isEditing = false;
        this.isLogged = this.$(this.options.checkoutLastStepLogged).length ? true : false;

        this.verifyPostalCode(false, true);
        this.checkoutProductTile.destroy().listen();

        this.$(document).on('app:user:login', (ev, data) => {
            this.$(document).trigger('app:checkout:reset');

            if(this.$('body').hasClass('is-checkout')) {
                const checkoutUrl = data.urls.checkout;

                this.$.ajax({
                    type: 'GET',
                    url: checkoutUrl,
                }).done((data) => {
                    const keepShoppingLink = this.$(this.options.keepShoppingLink).attr('href');
                    const rightCol = this.$(data).find(this.options.checkoutRightCol)[0].innerHTML;
                    const header = this.$(data).find(this.options.checkoutHeader)[0].innerHTML;

                    this.$(this.options.checkoutRightCol).html(rightCol);
                    this.$(this.options.checkoutHeader).html(header);
                    this.$(this.options.keepShoppingLink).attr('href', keepShoppingLink);

                    this.$(document).trigger('app:contextLoader:finish');
                    this.$(document).trigger('app:frame:closeModal');
                    this.$(document).trigger('app:checkout:reset');

                    this.destroy().listen();
                });
            }
        });

        this.$(document).on('app:user:logout', () => {
            this.$(document).trigger('app:checkout:reset');
        });

        this.$(document).on('app:frame:changed', (ev, data) => {
            if(data.pageName == 'page-checkout-select-shipping') {
                this.verifyPostalCodeChange();
                this.hideShippingMethods();
            }
        });

        this.$(document).on('app:frame:modalWillClose', () => {
            if(this.$('body').hasClass('is-checkout') && this.firstPage) {
                this.showFirstPage();
            }
        });

        // on modal closes active checkout page
        this.$(document).on('app:frame:modalIsClosed', () => {
            if(this.$('body').hasClass('is-checkout')) {
                this.$(document).trigger('app:frame:activeLastPage', [{pageName: 'page-checkout'}]);
            }
        });

        //verify if have previous link
        this.$(document).one('app:frame:ready', (ev, data) => {
            if((data.previousLink && !data.isModal)) {
                this.$(this.options.keepShoppingLink).attr('href', data.previousLink);
            }
        });

        // run this script only in address/payment page
        this.$(document).on('app:frame:changed', (ev, data) => {
            if(data.pageName == 'page-checkout-payment' && this.$('body').hasClass('is-checkout')) {
                if(this.isEditingPayment) return;

                if (this.$(this.options.inputShippingStreet).length) {
                    if(!this.isLogged) this.firstPage = true;
                    this.submitAutoCompleteAddress(this.$(this.options.inputPostalCode).val());
                }
            }
        });

        // run this script only in place-order page
        this.$(document).on('app:frame:changed', (ev, data) => {
            if(data.pageName == 'page-checkout-placeOrder' && this.$('body').hasClass('is-checkout')) {
                this.verifyLastStepOrder();
            }
        });

        // close drawers on click outside
        let debounceCloseDrawers = Debounce((event) => {
            if(!this.$('body').hasClass('is-checkout')) return;

            const drawerState = this.$(this.options.stateDrawer);
            const drawerInstallment = this.$(this.options.installmentBox);
            const drawerOverlay = this.$('.drawer-overlay');

            if((!drawerState.is(event.target) && !drawerState.has(event.target).length) || drawerOverlay.is(event.target)){
                this.closeDrawerState();
            }

            if((!drawerInstallment.is(event.target) && !drawerInstallment.has(event.target).length) || drawerOverlay.is(event.target)){
                this.closeDrawerCheckout();
            }
        }, 50);

        // I tried with window, body and document, it worked but when browsing between pages and came back to checkout it didn't work anymore
        this.$('*').on(this.tapEvent, (event) => debounceCloseDrawers(event));

        this.$(document).on('app:checkout:refresh', (ev, data) => {
            if(data.url) this.updateShippingDrawer(data.url);

            if(data.callMultiShipping) { this.multishippingOrder(data.multiShipping); }

            if(data.showFirstPage) this.showFirstPage();
        });

        this.$(document).on('app:checkout:reset', () => this.isListening = false);
    }

    destroy() {
        // body events
        this.$('body')
            .off(this.tapEvent, this.options.paymentOptionsEdit)
            .off(this.tapEvent, this.options.checkoutLastUserCardEdit)
            .off(this.tapEvent, this.options.installmentBox)
            .off(this.tapEvent, this.options.installmentNumber)
            .off(this.tapEvent, this.options.checkoutBalanceSubmit)
            .off(this.tapEvent, this.options.checkoutCouponRemove)
            .off(this.tapEvent, this.options.checkoutCouponValidationSubmit)
            .off(this.tapEvent, this.options.checkoutCouponAdd)
            .off(this.tapEvent, this.options.checkoutCouponCancel)
            .off(this.tapEvent, this.options.checkoutCouponOpenForm)
            .off(this.tapEvent, this.options.checkoutActionsSaveDelivery)
            .off(this.tapEvent, this.options.multishippingOrderButton)
            .off(this.tapEvent, this.options.editMultishipItemButton)
            .off(this.tapEvent, this.options.checkoutActionsStageBilling)
            .off(this.tapEvent, this.options.shippingEditAddress)
            .off(this.tapEvent, this.options.shippingOptionsEdit)
            .off(this.tapEvent, this.options.paymentOptionsEdit)
            .off(this.tapEvent, this.options.checkoutPlaceLink)
            .off(this.tapEvent, this.options.inputShippingPostalCode)
            .off('change', this.options.checkoutBalanceUse)
            .off('keyup', this.options.checkoutCouponEmail)
            .off('keyup', this.options.checkoutCouponCpf)
            .off('keyup', `${this.options.shippingForm} input:not(.shippingZipCode)`)
            .off('keyup', this.options.placeOrderCpfInput)
            .off('keyup', this.options.placeOrderBirthDate)
            .off('keyup', this.options.placeOrderEmailInput)
            .off('submit', this.options.checkoutCouponForm);

        // other events
        this.$(this.options.accountStateLabel).off(this.tapEvent);
        this.$(this.options.shippingMethodViewMore).off(this.tapEvent);
        this.$(this.options.shippingPostalCodeReturn).off(this.tapEvent);
        this.$(this.options.shippingPostalCodeClear).off(this.tapEvent);
        this.$(this.options.inputPostalCode).off("keyup paste");

        return this;
    }
}
