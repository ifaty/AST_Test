import isMobile from '../../utils/isMobile';

import ProductPayButton from '../ProductPayButton/ProductPayButton';

export default class CheckoutProductTile {

    constructor(options) {

        const defaultOptions = {

            myPage: 'checkout-shipping',
            shopModeCell: 'shopmode__cell',
            productHoverBackground: 'product__tile-background-hover',
            product: 'product',
            productTile: 'product__tile',
            productName: 'product-name',
            productPrice: 'price .value',
            colors: 'color__attribute',
            colorSwatch: 'swatch__circle',
            colorsOpened: 'colors__opened',
            colorsShowMoreButton: 'show-more-colors',
            colorsCloseButton: 'color__attribute .close__button',
            sizeSwatch: 'size__swatch',
            sizesOpened: 'sizes__opened',
            sizesShowMoreButton: 'show-more-sizes',
            sizesCloseButton: 'size__attribute .close__button',
            sizeButton: '.checkout_tile .size__item',
            removeLink: 'remove__link',
            removeCancel: 'remove__cancel',
            removeConfirm: 'remove__confirm',
            removeOpened: 'remove__opened',
            quantityMinus:'product__quantity-minus',
            quantity:'product__quantity',
            quantitySelector:'quantity-selector',
            quantityInput: 'quantity-selector',
            quantityPlus: 'product__quantity-plus',

            checkoutKeepShopping: '.checkout__keep-shopping',

            selectorEngine: {},
            toast: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.productPayButton = new ProductPayButton({selectorEngine: this.$});

        this.tapEvent = "click";
    }

    clearProductTile(){
        this.$(`.${this.options.shopModeCell}`)
        .removeClass(this.options.colorsOpened)
        .removeClass(this.options.sizesOpened)
        .removeClass(this.options.removeOpened)

        return this;
    }

    listenRemoveButton(){

        this.$('body')
        .on(this.tapEvent, `.${this.options.removeLink}`, (e) => {
            e.preventDefault();

            this.$(e.currentTarget)
            .closest(`.${this.options.shopModeCell}`)
            .addClass(this.options.removeOpened)
        })

        this.listenRemoveCancelButton();
        this.listenRemoveConfirmButton();

        return this;
    }

    listenRemoveCancelButton(){
        this.$('body')
        .on(this.tapEvent, `.${this.options.removeCancel}`, (e) => {

            e.preventDefault();

            this.$(e.currentTarget)
            .closest(`.${this.options.shopModeCell}`)
            .removeClass(this.options.removeOpened)
        })

        return this;
    }

    listenRemoveConfirmButton(){
        this.$('body')
        .on(this.tapEvent, `.${this.options.removeConfirm}`, (e) => {

            e.preventDefault();

            let url = this.$(e.currentTarget)
            .parent()
            .data('url');

            this.productRemove(url)
            .then((data) => {

                this.$(document).trigger("app:gtm:removeFromCart", {product: data.product,  quantity: 1});
                this.$(document).trigger("app:gtm:cartStatus", {products: data.cart ? data.cart.items : []});

                this.$(e.target)
                .closest(`.${this.options.shopModeCell}`)
                .remove();

                this.productPayButton.refreshCart(data.cart.items,
                                                  data.cart.totals.subTotal,
                                                  data.cart.actionUrls.updateQuantityUrl,
                                                  data.cart.actionUrls.removeProductLineItemUrl);

                if(data.payButtonTemplate) {
                    this.$(document).trigger('app:payButton:update', [{
                        template: data.payButtonTemplate
                    }]);
                }

                // if the cart is empty sends the user to home
                if(data.cart.numItems == 0) {
                    // hide pay button
                    this.$(document).trigger('app:paybutton:hide');

                    // const previousURL = this.$(this.options.checkoutKeepShopping).attr('href');
                    const previousURL = window.app.urls.shopmode;
                    this.$(document).trigger('app:frame:loadPage', [{ link: previousURL }]);

                    return;
                }

                this.$(document).trigger('app:checkout:refresh', [{
                    callMultiShipping: true,
                    multiShipping: data.cart.numItems == 1 ? false : data.usingMultiShipping,
                    showFirstPage: true,
                }]);
            })

        })

        return this;
    }

    listenProductHover(){
        this.$('body').on('mouseleave', `.${this.options.shopModeCell}`, () => {
            this.clearProductTile();
        });

        return this;
    }

    listenColorsMore(){
        this.$('body')
        .on(this.tapEvent, `.${this.options.colorsShowMoreButton}`, (e) => {
            this.$(e.target)
            .closest(`.${this.options.shopModeCell}`)
            .addClass(this.options.colorsOpened)
        })

        return this;
    }

    listenColorsClose(){
        this.$('body')
        .on(this.tapEvent, `.${this.options.colorsCloseButton}`, (e) => {
            this.$(e.target)
            .closest(`.${this.options.shopModeCell}`)
            .removeClass(this.options.colorsOpened)
        })

        return this;
    }

    listenColorSwatch() {
        this.$('body')
        .on(this.tapEvent, `.${this.options.colorSwatch}`, (e) => this.productUpdate(e, true))
    }

    listenSizeSwatch() {
        this.$('body').on(this.tapEvent, `.${this.options.sizeSwatch}`, (e) => this.productUpdate(e))
    }

    listenSizesMore(){
        this.$('body')
        .on(this.tapEvent, `.${this.options.sizesShowMoreButton}`, (e) => {
            e.preventDefault();
            e.stopPropagation();

            this.$(e.target)
            .closest(`.${this.options.shopModeCell}`)
            .addClass(this.options.sizesOpened)
        })

        return this;
    }

    listenSizesClose(){
        this.$('body')
        .on(this.tapEvent, `.${this.options.sizesCloseButton}`, (e) => {
            this.$(e.target)
            .closest(`.${this.options.shopModeCell}`)
            .removeClass(this.options.sizesOpened)
        })

        return this;
    }

    listenQuantityChange(){
        this.$('body')
        .on(this.tapEvent, `.${this.options.quantityMinus}`, (e) => {

            let input = this.$(e.currentTarget).closest(`.${this.options.quantity}`).find(`.${this.options.quantitySelector}`)
            let pid = this.$(e.currentTarget).closest(`.${this.options.productTile}`).data('pid');
            let uuid = this.$(e.currentTarget).closest(`.${this.options.productTile}`).data('uuid');
            input.val(parseInt(input.val()) - parseInt(1))
            let quantity = input.val();
            let url = `${input.data('action')}`;

            this.quantityChange(url, pid, uuid, quantity)
            .then((data) => {

                this.$(document).trigger("app:gtm:removeFromCart", {product: data.product,  quantity: 1});
                this.$(document).trigger("app:gtm:cartStatus", {products: data.cart.items});

                let url = this.$(".checkout__updateshipping-url").val();
                // Checkout.updateShippingDrawer()
                this.$(document).trigger('app:checkout:refresh', [{ url, showFirstPage: true }]);

                if(data.payButtonTemplate) {
                    this.$(document).trigger('app:payButton:update', [{
                        template: data.payButtonTemplate
                    }]);
                }

            })
            .catch((data) => {
                input.val(parseInt(input.val()) + parseInt(1))
            })
        })

        this.$('body')
        .on(this.tapEvent, `.${this.options.quantityPlus}`, (e) => {

            let input = this.$(e.currentTarget).closest(`.${this.options.quantity}`).find(`.${this.options.quantitySelector}`)
            let pid = this.$(e.currentTarget).closest(`.${this.options.productTile}`).data('pid');
            let uuid = this.$(e.currentTarget).closest(`.${this.options.productTile}`).data('uuid');
            input.val(parseInt(input.val()) + parseInt(1))
            let quantity = input.val();
            let url = `${input.data('action')}`;

            this.quantityChange(url, pid, uuid, quantity)
            .then((data) => {

                this.$(document).trigger("app:gtm:addToCart", {product: data.product, quantity: 1});
                this.$(document).trigger("app:gtm:cartStatus", {products: data.cart.items});

                let url = this.$(".checkout__updateshipping-url").val();
                // Checkout.updateShippingDrawer()
                this.$(document).trigger('app:checkout:refresh', [{ url, showFirstPage: true }]);

                if(data.payButtonTemplate) {
                    this.$(document).trigger('app:payButton:update', [{
                        template: data.payButtonTemplate
                    }]);
                }

            })
            .catch((data) => {
                input.val(parseInt(input.val()) - parseInt(1))
            })
        })

        return this;
    }

    quantityChange(url, pid, uuid, quantity){
        return this.$.get(url, {pid, uuid, quantity});
    }

    productRemove(url){
        return this.$.get(url)
    }

    productUpdate(e, changeColors = false) {
        let target = this.$(e.currentTarget);
        let productCell = target.closest(`.${this.options.shopModeCell}`);

        let oldProduct = {
            productName: productCell.find(`.${this.options.productName}`).text(),
            id: productCell.find(`.${this.options.productTile}`).data('pid'),
            price: {
                sales: {
                    decimalPrice: productCell.find(`.${this.options.productPrice}`).attr('content')
                }
            },
            category: productCell.find(`.${this.options.productTile}`).data('category'),
            quantity: quantity
        }

        const isFirst = productCell.hasClass('is-first');

        let url = target.data().url;
        let uuid = target.data().uuid;
        let pid = target.data().pid;
        let quantity = productCell.find(`.${this.options.quantitySelector}`).val();

        if (!url) return;

        if (target.data().selectable == false) {
            return;
        }

        this.$.ajax({
            type: 'post',
            dataType: 'json',
            url: url,
            data: {pid, uuid, quantity},

            success: (data) => {

                this.$(document).trigger("app:gtm:removeFromCart", {product: oldProduct,  quantity: quantity});
                this.$(document).trigger("app:gtm:addToCart", {product: data.product, quantity: quantity});
                this.$(document).trigger("app:gtm:cartStatus", {products: data.cartModel ? data.cartModel.items : []});

                if (data.success) {
                    let url = this.$(".checkout__updateshipping-url").val();

                    productCell.find(`.${this.options.product}`).first().remove();
                    productCell.append(this.$(data.renderedTemplate).find(".product")[0]);
                    this.clearProductTile().destroy().listen();

                    // Checkout.updateShippingDrawer()
                    this.$(document).trigger('app:checkout:refresh', [{ url, showFirstPage: true }]);

                    if(data.payButtonTemplate) {
                        this.$(document).trigger('app:payButton:update', [{
                            template: data.payButtonTemplate
                        }]);
                    }

                    if(changeColors) {
                        const colorMatrix = data.renderedColorMatrix || '';
                        const colorMatrixParse = this.$(colorMatrix).data('colormatrix');
                        const colorMatrixTile = this.$.parseJSON(data.tileColorMatrix.colors);
                        const textColor = colorMatrixTile.text;
                        const offWhite = colorMatrixTile.offwhite;
                        productCell.css({ 'color': textColor });

                        productCell.find(`.${this.options.productHoverBackground}`)
                                   .css({ 'background-color': offWhite });

                        if(isFirst) {
                            // removes the old colorMatrix so that adyen can pick up the new
                            const oldColorMatrix = this.$('.container[class*="page-checkout"] .color-matrix').eq(0);
                            oldColorMatrix.after(colorMatrix);
                            oldColorMatrix.remove();

                            // if adyen has already started updates the styles
                            if(AdyenCheckout && typeof(customCard) != 'undefined') {
                                customCard.updateStyles({
                                    base: {
                                        color: colorMatrixParse.text,
                                        fontSize: adyenFontSize,
                                    },
                                    error: {
                                        color: colorMatrixParse.text,
                                    },
                                    validated: {
                                        color: colorMatrixParse.text,
                                    }
                                });
                            }

                            this.$(document).trigger('app:colors:setcolors', [ colorMatrix ]);
                        }
                    }

                } else {
                    this.options.toast
                        .setOptions({
                            msgText: "Sorry! something went wrong."
                        })
                        .openToast();
                }
            },

            error: () => {
                this.options.toast
                    .setOptions({
                        msgText: "Sorry! something went wrong."
                    })
                    .openToast();
            }
        });

    }

    listen(){

        if (!isMobile()) {
            this.listenColorSwatch();
            this.listenSizeSwatch();
            this.listenRemoveButton();
        }

        this.listenProductHover();
        this.listenColorsMore();
        this.listenColorsClose();
        this.listenSizesMore();
        this.listenSizesClose();
        this.listenQuantityChange();

        return this;
    }

    destroy(){

        this.$("body")
        .off(this.tapEvent, `.${this.options.colorSwatch}`)
        .off(this.tapEvent,`.${this.options.removeLink}`)
        .off(this.tapEvent,`.${this.options.removeCancel}`)
        .off(this.tapEvent,`.${this.options.removeConfirm}`)
        .off(this.tapEvent,`.${this.options.colorsShowMoreButton}`)
        .off(this.tapEvent,`.${this.options.colorsCloseButton}`)
        .off(this.tapEvent,`.${this.options.sizeSwatch}`)
        .off(this.tapEvent,`.${this.options.sizesShowMoreButton}`)
        .off(this.tapEvent,`.${this.options.sizesCloseButton}`)
        .off(this.tapEvent,`.${this.options.quantityMinus}`)
        .off(this.tapEvent,`.${this.options.quantityPlus}`)
        .off('mouseleave', `.${this.options.shopModeCell}`);

        return this;
    }
}
