/**
 * Class responsible for the toast module
 *
 * @example
 *    this.options.toast
 *      .setOptions({
 *          buttonOk: true,
 *          buttonMsg: "Ok",
 *          msgText: data.error,
 *          positionX: "center",
 *          positionY:"center",
 *          type: "default",
 *          closeDefault: functionDefault,
 *          closeUser: functionUser
 *      }).openToast();
 *
 * @param   {boolean} [buttonOk] Default True
 * @param   {String} buttonMsg Button text to be displayed
 * @param   {String} msgText Message to be displayed
 * @param   {Text} [positionX] right, left, center
 * @param   {text} [positionY]  bottom, top, center
 * @param   {text} [type] warning, error, default
 * @param   {function} [closeDefault] Callback Default
 * @param   {function} [closeUser] Callback Click User
 */

import isMobile from '../../utils/isMobile';

export default class Toast {
    constructor(options) {
        const defaultOptions = {
            buttonOk: true,
            buttonMsg: "Ok",
            positionX: "right",
            positionY: "bottom",
            type: "default",
            closeDefault: () => {},
            closeUser: () => {},
            selectorEngine: {},
            toastBackground: '#0E4FCE',
            toastTextColor: '#FFFFFF',
            toastButtonLink: '',
            toastButtonLinkIsSearch: false,
            toastButtonLinkIsModal: false,
            buttonClass: '',
            dismissButton: false,
            dismissText: 'Dismiss',
            toastTimeOutMS: 7000,

            toastDefault: '.toast.default'
        }

        this.isDefaultReset = true;
        this.timeToast = 0;
        this.options = Object.assign({}, defaultOptions, options);
        this.defaults = defaultOptions;
        this.$ = this.options.selectorEngine;
        this.tapEvent = "click";
    }

    setOptions(options) {

        if ( this.isDefaultReset ) this.resetDefault();

        this.options = Object.assign({}, this.options, options);

        //User clicked on Close Button
        this.$('.toast__btn-timer').on('click', ()=> {
            this.closeToastUser();
        });

        return this;

    }

    resetDefault() {
        this.options = this.defaults;

        console.log('reseting');

        return this;
    }

    openToast() {
        //Setting height of toast if centralized
        if (this.options.positionY == "center") {
            setTimeout( () => {
                let altura = this.$('.toast').outerHeight()/2;
                this.$('.toast').css("margin-top", -altura)
            },100)
        }

        //Toast HTML Structure
        if(this.$('.toast').length === 0 ) {
            // 2000 / 2s is delay of animation
            let toastTimeOutS = ((this.options.toastTimeOutMS - 2000) / 1000).toFixed(1);

            $('body').prepend(`
                <div class="toast ${!this.options.buttonOk ? 'noButton' : ''} ${this.options.positionX == "center" && !isMobile() ? "centerX" : this.options.positionX} ${this.options.positionY == "center" && !isMobile() ? "centerY" : this.options.positionY} ${this.options.dismissButton ? 'has-dismissButton': ''} ${this.options.type} fadeInUp animated" >
                    <style>
                        .toast__nr { animation-duration: ${toastTimeOutS}s; }
                    </style>

                    <div class="toast__message">
                        <p>${this.options.msgText}</p>
                    </div>

                    ${this.options.dismissButton ? `
                        <div class="toast__dismiss">
                            <span class="toast__btn-dismiss">${this.options.dismissText}</span>
                        </div>
                    ` : ''}

                    <div class="toast__btn-timer ${this.options.buttonClass}" >
                        ${this.options.toastButtonLink ? `
                            <a
                                href="${this.options.toastButtonLink}"
                                ${this.options.toastButtonLinkIsSearch ? 'data-is-search-menu="true"' : ''}
                                ${this.options.toastButtonLinkIsModal ? 'data-is-modal="true"' : ''}
                            >
                        ` : ''}
                            <svg width="80" height="42">
                                <rect class="toast__nr" x="1" y="1" rx="20" ry="20" width="78" height="40" />
                                <rect class="toast__op" x="1" y="1" rx="20" ry="20" width="78" height="40" />
                                <text x="50%" y="50%" dominant-baseline="central" text-anchor="middle" font-size="16" fill="#FFFFFF">${this.options.buttonMsg}</text>
                            </svg>
                        ${this.options.toastButtonLink ? '</a>' : ''}
                    </div>

                </div>
            `);
            //Start Toast closing time
            this.timeToast = setTimeout( () => {
                if(this.$('.toast').length == 1 ) {
                    this.closeToastDefault();
                }
            }, this.options.toastTimeOutMS);
        }

        //User clicked on Close Button
        this.$('.toast__btn-timer svg, .toast__btn-dismiss').on('click', ()=> {
            this.closeToastUser();
        });
        this.$(this.options.toastDefault).css({"background-color": this.options.toastBackground, "color": this.options.toastTextColor});
    }

    willReset(willReset) {
        this.isDefaultReset = willReset;

        return this;
    }

    //Automatic Toast Closing
    closeToastDefault() {
        this.$('.toast').addClass('fadeOutDown');
        this.$('.toast').removeClass('fadeInUp');
        setTimeout(() => {
            this.$('.toast').remove();
            this.options.closeDefault();
            this.$(document).trigger('app:toast:closeDefault');
        },300)
    }

    //Toast closed by user
    closeToastUser() {
        clearTimeout(this.timeToast);
        this.$('.toast').addClass('fadeOutDown');
        this.$('.toast').removeClass('fadeInUp');
        setTimeout(() => {
            this.$('.toast').remove();
            this.options.closeUser();
            this.$(document).trigger('app:toast:closeUser')
        },300)
    }

    setBackgroundColor(backgroundColor) {
        this.options.toastBackground = backgroundColor;

        return this;
    }
}
