import isMobile from '../../utils/isMobile';
import debounce from '../../utils/debounce';
export default class Colors {
    constructor(options) {
        const defaultOptions = {
            selectorEngine: {},
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        //setting initial colorMatrix
        this.setColors($(`.page-initial > [data-pagename] .color-matrix:eq(0)`));
    }

    /*

    https: //awik.io/determine-color-bright-dark-using-javascript/
    islightOrDark('#333333') => dark
    islightOrDark('#000000') => dark
    islightOrDark('#808080') => light
    islightOrDark('#ffffff') => light

    */

    islightOrDark(color) {

        // Variables for red, green, blue values
        var r, g, b, hsp;

        // Check the format of the color, HEX or RGB?
        if (color.match(/^rgb/)) {

            // If RGB --> store the red, green, blue values in separate variables
            color = color.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+(?:\.\d+)?))?\)$/);

            r = color[1];
            g = color[2];
            b = color[3];
        } else {

            // If hex --> Convert it to RGB: http://gist.github.com/983661
            color = +("0x" + color.slice(1).replace(
                color.length < 5 && /./g, '$&$&'));

            r = color >> 16;
            g = color >> 8 & 255;
            b = color & 255;
        }

        // HSP (Highly Sensitive Poo) equation from http://alienryderflex.com/hsp.html
        hsp = Math.sqrt(
            0.299 * (r * r) +
            0.587 * (g * g) +
            0.114 * (b * b)
        );

        // Using the HSP value, determine whether the color is light or dark
        if (hsp > 127.5) {

            return 'light';
        } else {

            return 'dark';
        }
    }

    /*
        blendColors('#ffffff', '#000000', 0.8) => #333333
        blendColors('#ffffff', '#000000', 0.5) => #808080
        blendColors('#ffffff', '#000000', 0.3) => #b3b3b3

        ammount represents how much colorB will mixed into colorA.
    */

    blendColors(colorA = '#ffffff', colorB = '#000000', amount = 0.5) {
        const [rA, gA, bA] = colorA.match(/\w\w/g).map((c) => parseInt(c, 16));
        const [rB, gB, bB] = colorB.match(/\w\w/g).map((c) => parseInt(c, 16));
        const r = Math.round(rA + (rB - rA) * amount).toString(16).padStart(2, '0');
        const g = Math.round(gA + (gB - gA) * amount).toString(16).padStart(2, '0');
        const b = Math.round(bA + (bB - bA) * amount).toString(16).padStart(2, '0');

        return '#' + r + g + b;
    }

    /*

        https://css-tricks.com/snippets/javascript/lighten-darken-color/
        // Lighten
        var NewColor = lightenDarkenColor("#F06D06", 20);

        // Darken
        var NewColor = lightenDarkenColor("#F06D06", -20);

    */
    lightenDarkenColor(color, amount) {

        return '#' + color.replace(/^#/, '').replace(/../g, color => ('0'+Math.min(255, Math.max(0, parseInt(color, 16) + amount)).toString(16)).substr(-2));

    }

    setColors(target) {
        if (!target) {
            console.warn('Colors.js: cannot setColor of target undefined');

            return this;
        }

        let colors = this.$(target).data('colormatrix') || false;

        if (!colors) {
            console.warn("Color matrix are not provided, setting a fallback...");

            colors = {
                'text': '#533f1c',
                'background': '#f6d9a7',
                'ui': '#d0a967',
                'uiText': '#533f1c'
            }
        }

        window.colors = {
            'textColor': colors.text,
            'backgroundColor': colors.background,
            'ui': colors.ui,
            'uiText': colors.uiText,

            //darker10
            'textColorDark10': this.lightenDarkenColor(colors.text, -10),
            'backgroundColorDark10': this.lightenDarkenColor(colors.background, -10),
            'uiDark10': this.lightenDarkenColor(colors.ui, -10),
            'uiTextDark10': this.lightenDarkenColor(colors.uiText, -10),

            //lighter10
            'textColorLight10': this.lightenDarkenColor(colors.text, 10),
            'backgroundColorLight10': this.lightenDarkenColor(colors.background, 10),
            'uiLight10': this.lightenDarkenColor(colors.ui, 10),
            'uiTextLight10': this.lightenDarkenColor(colors.uiText, 10)
        };

        let colorStyle = `<style class="global__colors">
            html > body.is-ready {
                background: ${colors.background};
            }

            html > body .matrixBgColor {
                background: ${colors.background};
            }
            html > body .matrixOffwColor {
                background: ${colors.offwhite};
            }
            html > body .matrixOffwColor.opacity80 {
                background: ${colors.offwhite}CC;
            }
            html > body .matrixTxtColor {
                color: ${colors.text};
            }
            html > body .matrixTxtColor.opacity70 {
                color: ${colors.text}B3;
            }
            html > body .matrixTxtColor.opacity80 {
                color: ${colors.text}CC;
            }
            html > body .matrixTxtColorSvg svg g {
                fill: ${colors.text};
            }
            html > body .matrixUiElement {
                background: ${colors.ui};
            }
            html > body .matrixUiText {
                color: ${colors.uiText};
            }
            html > body .matrixTxtAsBgColor {
                background: ${colors.text};
            }
            html > body .matrixBgAsTxtColor {
                color: ${colors.background};
            }
            html > body .matrixUiTxtAsBgColor {
                background: ${colors.uiText};
            }
            html > body .matrixUiBgAsTxtColor {
                color: ${colors.ui};
            }
            html > body .matrixGradientBgUi {
                color: ${colors.uiText};
                background-image: linear-gradient(45deg, ${colors.background}, ${colors.ui});
            }
            /* adds '00' in the hexa to get opacity 0 */
            html > body .matrixGradientScrollBgUi {
                background-image: linear-gradient(${colors.background}00, ${colors.background} 30%);
            }
            html > body .matrixBgColorAsBorder {
                border-color: ${colors.background};
            }
            html > body .matrixTxtColorAsBorder {
                border-color: ${colors.text};
            }
            html > body .matrixTxtColorAsBorder.opacity70 {
                border-color: ${colors.text}B3;
            }
            html > body .matrixTxtColorAsBorder.opacity80 {
                border-color: ${colors.text}CC;
            }
            html > body .matrixUiColorAsBorder {
                border-color: ${colors.ui};
            }
            html > body .matrixUiTxtColorAsBorder {
                border-color: ${colors.uiText};
            }


            @media (min-width: 799px) {

                /* 10 darker */

                html > body .matrixBgColor.desk-darker10 {
                    background: ${this.lightenDarkenColor(colors.background, -10)};

                }
                html > body .matrixTxtColor.desk-darker10 {
                    color: ${this.lightenDarkenColor(colors.text, -10)};

                }
                html > body .matrixUiElement.desk-darker10 {
                    background: ${this.lightenDarkenColor(colors.ui, -10)};

                }
                html > body .matrixUiText.desk-darker10 {
                    color: ${this.lightenDarkenColor(colors.uiText, -10)};

                }
                html > body .matrixTxtAsBgColor.desk-darker10 {
                    background: ${this.lightenDarkenColor(colors.text, -10)};

                }
                html > body .matrixBgAsTxtColor.desk-darker10 {
                    color: ${this.lightenDarkenColor(colors.background, -10)};

                }
                html > body .matrixUiTxtAsBgColor.desk-darker10 {
                    background: ${this.lightenDarkenColor(colors.uiText, -10)};

                }
                html > body .matrixUiBgAsTxtColor.desk-darker10 {
                    color: ${this.lightenDarkenColor(colors.ui, -10)};

                }
                html > body .matrixGradientBgUi.desk-darker10 {
                    color: ${this.lightenDarkenColor(colors.uiText, -10)};
                    background-image: linear-gradient(45deg, ${this.lightenDarkenColor(colors.background, -10)}, ${this.lightenDarkenColor(colors.ui, -10)});
                }

                /* adds '00' in the hexa to get opacity 0 */
                html > body .matrixGradientScrollBgUi.desk-darker10 {
                    background-image: linear-gradient(${this.lightenDarkenColor(colors.background, -10)}00, ${this.lightenDarkenColor(colors.background, -10)} 30%);
                }

                html > body .matrixBgColorAsBorder.desk-darker10 {
                    border-color: ${this.lightenDarkenColor(colors.background, -10)};

                }
                html > body .matrixTxtColorAsBorder.desk-darker10 {
                    border-color: ${this.lightenDarkenColor(colors.text, -10)};

                }
                html > body .matrixUiColorAsBorder.desk-darker10 {
                    border-color: ${this.lightenDarkenColor(colors.ui, -10)};

                }
                html > body .matrixUiTxtColorAsBorder.desk-darker10 {
                    border-color: ${this.lightenDarkenColor(colors.uiText, -10)};

                }

            }

            @media (max-width: 799px) {

                /* 10 darker */

                html > body .matrixBgColor.mobile-darker10 {
                    background: ${this.lightenDarkenColor(colors.background, -10)};

                }
                html > body .matrixTxtColor.mobile-darker10 {
                    color: ${this.lightenDarkenColor(colors.text, -10)};

                }
                html > body .matrixUiElement.mobile-darker10 {
                    background: ${this.lightenDarkenColor(colors.ui, -10)};

                }
                html > body .matrixUiText.mobile-darker10 {
                    color: ${this.lightenDarkenColor(colors.uiText, -10)};

                }
                html > body .matrixTxtAsBgColor.mobile-darker10 {
                    background: ${this.lightenDarkenColor(colors.text, -10)};

                }
                html > body .matrixBgAsTxtColor.mobile-darker10 {
                    color: ${this.lightenDarkenColor(colors.background, -10)};

                }
                html > body .matrixUiTxtAsBgColor.mobile-darker10 {
                    background: ${this.lightenDarkenColor(colors.uiText, -10)};

                }
                html > body .matrixUiBgAsTxtColor.mobile-darker10 {
                    color: ${this.lightenDarkenColor(colors.ui, -10)};

                }
                html > body .matrixGradientBgUi.mobile-darker10 {
                    color: ${this.lightenDarkenColor(colors.uiText, -10)};
                    background-color: ${this.lightenDarkenColor(colors.background, -10)}, ${this.lightenDarkenColor(colors.ui, -10)});

                }

                html > body .matrixGradientScrollBgUi.mobile-darker10 {
                    background-color: ${this.lightenDarkenColor(colors.background, -13)};
                    background-image: none;

                }

                html > body .matrixBgColorAsBorder.mobile-darker10 {
                    border-color: ${this.lightenDarkenColor(colors.background, -10)};

                }
                html > body .matrixTxtColorAsBorder.mobile-darker10 {
                    border-color: ${this.lightenDarkenColor(colors.text, -10)};

                }
                html > body .matrixUiColorAsBorder.mobile-darker10 {
                    border-color: ${this.lightenDarkenColor(colors.ui, -10)};

                }
                html > body .matrixUiTxtColorAsBorder.mobile-darker10 {
                    border-color: ${this.lightenDarkenColor(colors.uiText, -10)};

                }
            }

        </style>`;

        this.$('.global__colors').remove();
        this.$('body').append(colorStyle);

        this.$(document).trigger('app:colors:changed', colors)

    }

    listen() {

        let debouncedSetColors = debounce((target) => {
          this.setColors(target);
        }, 300, false);

        this.$(document).on('app:colors:setcolors', (ev, target) => debouncedSetColors(target = target));

        this.$(document).on('app:frame:changed', (ev, data) => {
            //this is very dangerours
            if(!data.isModal && !data.isSearchMenuContext) this.setColors(this.$(`[data-pagename='${data.pageName}']:last .color-matrix`));
        });
    }
}
