import isMobile from '../../utils/isMobile';

export default class ProductSizeGuide {
    constructor(options) {

        const defaultOptions = {

            cmButton: 'input.cm',
            inButton: 'input.in',
            cmSpan: '.centimeter-unit',
            inSpan: '.inch-unit',
            openBrandContainerLink: '.select-brand',
            selectBrandLink: '.brand-item a',
            brandsContainer: '.brands',
            brandsOverlayContainer: '.overlay-brands',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.reloadCounter = 0;

        this.tapEvent = "click";
    }

    listenMeasureChange(){


        this.$('body').on(this.tapEvent, this.options.cmButton, () => {
            this.$(this.options.cmSpan).removeClass("hidden");
            this.$(this.options.inSpan).addClass("hidden");
        })

        this.$('body').on(this.tapEvent, this.options.inButton, () => {
            this.$(this.options.cmSpan).addClass("hidden");
            this.$(this.options.inSpan).removeClass("hidden");
        })

    }

    preventPropagation(){
        this.$('body').on(this.tapEvent, this.options.openBrandContainerLink, (e) => e.stopPropagation())
        this.$('body').on(this.tapEvent, this.options.brandsContainer, (e) => e.stopPropagation())
        this.$('body').on(this.tapEvent, this.options.brandsOverlayContainer, (e) => e.stopPropagation())
    }

    openBrandContainer(){
        this.$(this.options.brandsContainer).removeClass("hidden");
        this.$(this.options.brandsOverlayContainer).removeClass("hidden");
    }

    closeBrandContainer(){

        this.$(this.options.brandsContainer).addClass("hidden");
        this.$(this.options.brandsOverlayContainer).addClass("hidden");
    }

    listenBrandChange(){

        this.$('body').on("click", this.options.selectBrandLink, (e) => {
            let brandClass = `${this.$(e.target).data().brand}`;

            this.$('td[class*=brand-]').addClass('hidden');
            this.$(`td.brand-${brandClass.replace(/\s+/g, '-').toLowerCase()}`).removeClass('hidden');

            this.$(this.options.openBrandContainerLink).html(`${brandClass}`);

            this.closeBrandContainer();

        })
    }


    listen() {

        this.$('body').on(this.tapEvent, () => this.closeBrandContainer());
        this.$('body').on(this.tapEvent, this.options.openBrandContainerLink, () => this.openBrandContainer());

        this.listenMeasureChange();
        this.preventPropagation();
        this.listenBrandChange();

    }
}