export default class GeoLocation {
    constructor(options) {

        const defaultOptions = {
            geoLocationUrl : window.app.urls.geoLocation,

            selectorEngine: {}
        }

        this.watching = false;

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
    }

    getPosition() {

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {

                let geoLocationPosition = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude
                };

                this.$(document).trigger('app:geoLocation:positionChanged', [{
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude
                }]);

                return geoLocationPosition;
            });
        } else {
            return this;
        }
    }

    sendPosition(data) {

        this.$.ajax({
            type: 'GET',
            url: `${this.options.geoLocationUrl}?latitude=${data.latitude}&longitude=${data.longitude}`,

            success: (data) => {
                window.app.location = data;
                console.log('geolocation', data);
            }
        });

        return this;
    }

    init() {
        this.getPosition();

        this.listen();

        return this;
    }

    listen() {

        if (this.watching) return this.reload();

        this.$(document).on('app:geoLocation:positionChanged', (ev, data) => {
            this.sendPosition(data);
        });

        this.watching = true;

        return this;
    }

    reload() {

        this.watching = false;

        return this.destroy().listen();

    }

    destroy() {

        this.$(document).off('app:geoLocation:positionChanged');

        return this;
    }
}