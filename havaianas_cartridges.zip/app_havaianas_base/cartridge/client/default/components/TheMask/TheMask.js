import VMasker from "vanilla-masker";
export default class TheMask {

    constructor(options) {

        const defaultOptions = {
            maskApplied: 'mask-is-applied',

            selectorEngine: {},
            frame: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.watching = false;
        this.inputs = null;

        // apply mask on site initiate
        this.applyMasksWhenNeeded();
    }

    getAvailableInputsInCurrentFrame() {
        // when the site starts currentAgnostic does not exist
        return this.$('body').find('input');
    }

    setInputTargets(inputs = {}) {
        this.inputs = inputs;

        return this;
    }

    applyMasksWhenNeeded() {
        this.currentInputs = this.inputs || this.getAvailableInputsInCurrentFrame();

        this.$.each(this.currentInputs, (idx, elem) => {
            // verification for not to call the function for elements that do not require mask
            if(!this.$(elem).hasClass(this.options.maskApplied) && this.$(elem).data('mask')) {
                this.applyCorrectMask(elem);
            }
        });

        return this;
    }

    applyCorrectMask(input = {}) {
        let inputMaskType = this.$(input).data('mask') || null; // get data-mask from input attribut

        if (inputMaskType && !!window.i18n.masks[inputMaskType]) {
            VMasker(input).maskPattern(window.i18n.masks[inputMaskType]);
            this.$(input).addClass(this.options.maskApplied);
        } else {
            console.warn(`maskType ${inputMaskType} not provided in window.i18n.masks`);
        }

        return this;
    }

    listen() {
        if(this.watching) return this.reload();

        this.$(document).on('app:frame:changed', () => this.applyMasksWhenNeeded());

        //receive input targets from javascript event
        this.$(document).on('app:masks:setInptus', (ev, data) => {
            this.setInputTargets(data.targets)
                .applyMasksWhenNeeded();
        });

        this.watching = true;

        return this;
    }

    reload() {

        this.watching = false;

        return this.destroy().listen();

    }

    destroy() {

        this.$(document).off('app:masks:setInptus');

        return this;
    }
}