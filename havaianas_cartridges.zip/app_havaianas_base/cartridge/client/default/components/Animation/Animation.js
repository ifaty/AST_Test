import isMobile from '../../utils/isMobile';
import ASYNC from '../../utils/async';

export default class Animation extends ASYNC {
    constructor(options) {

        super(options);

        const defaultOptions = {
            btnShopModeClassName: 'superActions__btnShopMode',
            superActionsContainer: '.superActions',
            btnShopModeLabel: '.superActions__btnShopMode__label',

            selectorEngine: {},
            frame: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.frames = null;
    }

    setOptions(options) {

        this.options = Object.assign({}, this.options, options);

        return this;
    }

    setFrames(frames = null) {

        this.frames = frames;

        return this;
    }

    setTarget(target = null) {

        this.target = target;

        return this;
    }

    setData(data = {}) {
        this.data = data;

        return this;
    }

    setFocus(focus = {focusX: '50%', focusY: '50%'}) {

        this.focus = focus;

        return this;
    }

    setDuration(duration = 400) {

        this.duration = duration;

        return this;
    }

    runPageAnimation(target, data, duration = 800){

        return new Promise((resolve, reject) => {

            anime({
                targets: target,
                clipPath: [`circle(0% at ${data.fromTarget.mouseEvents.pageX}px ${data.fromTarget.mouseEvents.pageY}px)`, `circle(130% at ${data.fromTarget.mouseEvents.pageX}px ${data.fromTarget.mouseEvents.pageY}px)`],
                easing: 'linear',
                duration: duration,
                complete: (anim) => resolve()
            });

        });
    }

    circleAnimation(target, initialPercentage = '0%', finalPercentage = '130%', positionX = '50%', positionY = '50%',  duration = 800){

        return new Promise((resolve, reject) => {

            anime({
                targets: target,
                clipPath: [`circle(${initialPercentage} at ${positionX} ${positionY})`, `circle(${finalPercentage} at ${positionX} ${positionY})`],
                easing: 'linear',
                duration: duration,
                complete: () => resolve()
            });

        })
    }

    runTransitionAnimation(target, duration = 300){
        return new Promise((resolve, reject) => {

            anime({
                targets: target,
                height: "100vh",
                width: "100vw",
                top: 0,
                left: 0,
                easing: 'linear',
                duration: duration,
                complete: (anim) => resolve()
            })

        })
    }

    discoveryModeVsShopTransition() {
        let frames = this.options.frame.getFrames();
        this.options.frame.unfreeze(frames.current);

        frames.current.find('>.container').css({
            opacity: 1
        });

        if (this.$(`.${this.options.btnShopModeClassName}`).hasClass('is-expanded')) {

            this.$(`.${this.options.btnShopModeClassName}`).fadeOut(300).promise().done(() => {

                this.$(`.${this.options.btnShopModeClassName}`).css({
                    'transform' : ''
                });

                super.clearTimeout('resetSuperActions').clearableWait(300, 'resetSuperActions').then(() => {
                    this.$(`.${this.options.btnShopModeClassName}`).children().css('display', '');

                    this.$(`.${this.options.btnShopModeClassName}`)
                    .removeClass('is-expanded')
                    .css({
                        'display' : ''
                    });
                });
            });
        };

        return this;
    }

    shopModeVsDiscoveryTransition() {

        let frames = this.options.frame.getFrames();
        this.options.frame.unfreeze(frames.current);

        frames.in.css({
            'clip-path': 'circle(0%)',
            '-webkit-clip-path': 'circle(0%)'
        });

        super.clearTimeout('animatorPageTransition').clearableWait(300, 'animatorPageTransition')
             .then(() => {

                anime({
                    targets: frames.in.find('>.container')[0],
                    opacity: 1,
                    easing: 'linear',
                    duration: 300,
                    delay: 100
                });

                this.runPageAnimation(frames.in.get(0), this.data, 600).then(() => {
                    frames.in.css({
                        "clip-path": 'none',
                        "-webkit-clip-path": 'none'
                    });

                    frames.out.find('>.container').css({
                        opacity: 0
                    });

                    this.options.frame.unfreeze(frames.in);
                });
            });

        return this;

    }

    defaultPageTransitionOut() {

        let frames = this.options.frame.getFrames();
        this.options.frame.freeze(frames.all);

        if (this.data.isModal || this.data.isSearchMenuContext) {
            frames.allModal.find('>.container').css({
                opacity: 0
            });
        } else {
            frames.all.find('>.container').css({
                opacity: 0
            });
        }

        return this;
    }

    filterPageTransitionOut() {

        let frames = this.options.frame.getFrames();
        this.options.frame.freeze(frames.all);

        frames.all.find('.shopmode .content, .story__section .content').css({
            opacity: 0
        });

        return this;
    }

    defaultPageTransitionIn() {

        let frames = this.options.frame.getFrames();
        this.options.frame.unfreeze(frames.current);
        if (this.data.isModal) {
            frames.currentModal.find('>.container').css({
                opacity: 1
            });
        } else {
            frames.current.find('>.container').css({
                opacity: 1
            });
        }

        return this;
    }

    willLoadDefaultAction() {
        this.defaultPageTransitionOut();

        return this;
    }

    willLoadWithFilter() {
        this.filterPageTransitionOut();

        return this;
    }

    willLoadShopMode() {
        let viewPortWidth = this.$(window).width();

        let scaleRatio;

        if (viewPortWidth <= 415) {
            scaleRatio = 18;
        } else if (viewPortWidth > 415 && viewPortWidth <= 1024) {
            scaleRatio = 36;
        } else {
            scaleRatio = 55;
        }

        this.$(`.${this.options.btnShopModeClassName}`).children().fadeOut(300).promise().done( () => {
            anime({
                targets: `.${this.options.btnShopModeClassName}`,
                scale: scaleRatio,
                easing: 'cubicBezier(0.25,0.1,0.25,1)',
                duration: 300,
                complete: () => {
                    this.$(`.${this.options.btnShopModeClassName}`).addClass('is-expanded');
                }
            });
        });

        return this;
    }

    readyDefaultAction() {

        this.defaultPageTransitionIn();

        return this;
    }

    ajaxFailDefaultAction() {

        let frames = this.options.frame.getFrames();
        this.options.frame.unfreeze(frames.current);
        if (this.data.isModal) {
            frames.currentModal.find('>.container').css({
                opacity: 1
            });
        } else {
            frames.current.find('>.container').css({
                opacity: 1
            });
        }

    }


    listen() {

        this.$(document).on("app:frame:willLoad", (ev, data) => {

            if (data.fromTarget.currentTarget.className.indexOf(this.options.btnShopModeClassName) < 0) {
                if (data.isDesktopFilter) {
                    this.setData(data).willLoadWithFilter();
                }
                else {
                    this.setData(data).willLoadDefaultAction();
                }
            } else {
                if (data.pageName.indexOf('page-shop') < 0) {
                    this.willLoadShopMode();
                }
            }
        });

        this.$(document).on("app:frame:ready", (ev, data) => {
            if (data.fromTarget.currentTarget.className.indexOf(this.options.btnShopModeClassName) < 0) {
                this.setData(data).readyDefaultAction();
            } else {
                if (data.fromPageName.indexOf('page-shop') >= 0) {
                    this.setData(data).shopModeVsDiscoveryTransition();
                } else {
                    this.setData(data).discoveryModeVsShopTransition();
                }
            }
        });

        this.$(document).on("app:frame:ajaxFail", (ev, data) => {

            this.setData(data).ajaxFailDefaultAction();
        });

        return this;
    }
}
