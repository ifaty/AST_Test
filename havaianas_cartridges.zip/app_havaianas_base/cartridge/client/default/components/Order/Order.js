import isMobile from '../../utils/isMobile';

export default class Product {
    constructor(options) {

        const defaultOptions = {

            pageOrder: '.page-order',
            pageOrderOverview: '.page-orderOverview',
            btnModifyOrderActions: '.btn__order-action',
            btnConfirmAction: '.btn__order-action-confirm',

            cancelOrderButton: '.order__cancel-button',
            copytrackingNumber: '.order__status-tracking',
            trackingNumber: '.order__status-tracking-number',

            createAccountToast: '.createAccount__toast',

            selectorEngine: {}
        }

        this.colorMatrixData;

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";
        this.isListening = false;
    }

    modifyOrderListener() {
        this.$(this.options.btnModifyOrderActions).on(this.tapEvent, (ev) => {
            var url = this.$(ev.target).data('url');

            this.$(document).trigger('app:frame:loadPage', [{
                isModal: true,
                link: url
            }]);
        });
    }

    confirmActionListener() {
        this.$(this.options.btnConfirmAction).on(this.tapEvent, (ev) => {
            var url = this.$(ev.target).data('url');
            this.$.ajax({
                type: 'POST',
                url: url,
                dataType: 'json',
                success: (data) => {
                    if(data.success) {
                        this.$(document).trigger('app:frame:loadPage', [{
                            isModal: true,
                            link: data.redirectUrl
                        }]);
                    }
                    // TODO: deal with success false
                },
                error: () => {
                    this.options.toast
                    .setOptions({
                        buttonOk: true,
                        buttonMsg: "Ok",
                        msgText: "Sorry! Something went wrong",
                        type: "error",
                    }).openToast();
                }
            });
            this.$(document).trigger('app:frame:loadPage', [{
                isModal: true,
                link: url
            }]);
        });
    }

    cancelOrder() {
        this.$('body').on(this.tapEvent, this.options.cancelOrderButton, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            const url = this.$(this.options.cancelOrderButton).data('url');

            this.$.ajax({
                type: 'post',
                dataType: 'json',
                url: url,
                success: (data) => {
                    if (data.success) {

                        // this solution is temporary waiting a better solution
                        const visitedLinks = this.options.frame.getVisitedLink('context', 'menusca');
                        this.$(document).trigger('app:menu:openLinkMenusca', [{
                            link: visitedLinks.link,
                        }]);
                        this.$(document).trigger('app:frame:closeModal');

                    } else {
                        this.options.toast
                            .setOptions({
                                msgText: data.errorMessage,
                                type: 'error',
                                buttonOk: true,
                            })
                            .openToast();
                    }
                },
                error: () => {
                    this.options.toast
                        .setOptions({
                            msgText: 'Sorry! something went wrong.',
                            type: 'error',
                            buttonOk: true,
                        })
                        .openToast();
                }
            });
        });
    };

    copyTracking() {
        this.$('body').on(this.tapEvent, this.options.copytrackingNumber, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            const copyText = document.querySelector(this.options.trackingNumber);

            copyText.select();
            copyText.setSelectionRange(0, 99999); /*For mobile devices*/

            document.execCommand("copy");

            // clear selection
            if (window.getSelection) {window.getSelection().removeAllRanges();}
            else if (document.selection) {document.selection.empty();}

            this.options.toast
                .setOptions({ msgText: this.$(this.options.copytrackingNumber).data('copy') })
                .openToast();
        });
    };

    listenCreateAccount() {
        if(this.$(this.options.createAccountToast).length && !this.$(this.options.createAccountToast).hasClass('is-active')) {
            this.options.toast
                .setOptions({
                    msgText: window.app.resources.properties.createAccount['text.createaccount'],
                    positionX: 'right',
                    positionY: 'top',
                    dismissButton: true,
                    dismissText: window.app.resources.properties.createAccount['text.createaccount.dismiss'],
                    buttonMsg: window.app.resources.properties.createAccount['button.createaccount'],
                    toastButtonLink: this.$(this.options.createAccountToast).data('link'),
                    toastButtonLinkIsModal: true,
                    toastTimeOutMS: 20000
                })
                .openToast();

            this.$(this.options.createAccountToast).addClass('is-active');
        }
    }

    listen() {
        if(this.isListening) return;
        this.isListening = true;

        this.modifyOrderListener();
        this.confirmActionListener();
        this.cancelOrder();
        this.copyTracking();
    }
}
