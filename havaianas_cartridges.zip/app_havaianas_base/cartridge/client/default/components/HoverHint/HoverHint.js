export default class HoverHint {
    constructor(options) {

        const defaultOptions = {
            frames: 39,
            duration: 1.2, //seconds

            'container': "hoverHint__images",
            'image': "hoverHint__image",

            box: '#hoverHint',
            rainbowReadyClass: 'is-rainbowReady',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.fps = this.options.duration / this.options.frames;
    }


    fadeIn(ms) {

        let duration = ms || 300;

        return new Promise(resolve => {

            this.$(this.options.box).fadeIn(duration, resolve);

        });
    }


    fadeOut(ms, delay) {

        let duration = ms || 300;
        let delayms = delay || 800;

        return new Promise(resolve => {

            this.$(this.options.box).delay(delayms).fadeOut(duration, resolve);

        });
    }

    collapseToRainbowEndTransition() {

        return new Promise(resolve => {

            this.$("body").addClass(this.options.rainbowReadyClass);
            setTimeout(() => {
                resolve();
            }, 820); // 800ms is the css animation duration
        });

    }

    calculateDimensions() {

        this.naturalW = this.$(`.${this.options.image}`).get(0).naturalWidth;
        this.naturalH = this.$(`.${this.options.image}`).get(0).naturalHeight;

        this.realW = this.$(`.${this.options.container}`).outerWidth();
        this.realH = this.$(`.${this.options.container}`).outerHeight();

        //naturalW     --  320
        //finalImageW  --  x

        this.finalImage = this.naturalW * this.realW / (this.naturalW / this.options.frames);

        //naturalW  --  naturalH
        //finalW    --  x

        this.finalImageH = this.finalImage * this.naturalH / this.naturalW;

        return this;
    }

    animate() {

        this.calculateDimensions();

        this.$(`.${this.options.image}`).css({
            width: this.finalImage,
            height: this.finalImageH
        });

        return new Promise(resolve => {

            anime.timeline({
                easing: `steps(${this.options.frames-1})`,
                duration: 1200,
                direction: "normal"
            })
            .add({
                targets: `.${this.options.image}`,
                translateX: -(this.finalImage - (this.finalImage / this.options.frames)),
                complete: resolve
            });

        });

    }
}