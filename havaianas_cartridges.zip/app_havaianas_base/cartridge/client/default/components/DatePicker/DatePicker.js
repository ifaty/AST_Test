import isMobile from '../../utils/isMobile';

export default class Drawer {
    constructor(options) {

        const defaultOptions = {
            dateofBirth: "#dateofbirth",

           selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";

        this.isLogged = this.$(".is-logged").length ? true : false;
    }

    listenCalendarClick() {
        this.$(this.options.dateofBirth).on('focus', () => {
            this.$('#dateofbirth').attr('type', 'date');
            this.$('#dateofbirth').trigger("click");
        });


        this.$(this.options.dateofBirth).on('blur', () => {
            if ($('#dateofbirth').val() == '') {
                this.$('#dateofbirth').attr('type', 'text');
            }
        });
    }

    listen() {
        this.listenCalendarClick();
    }
}