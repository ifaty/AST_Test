import isMobile from '../../utils/isMobile';
import debounce from '../../utils/debounce';

export default class Address {
    constructor(options) {

        const defaultOptions = {
            addressSaveBtn: '.address__save',
            addressForm: '.address-form',

            inputPostalCode: '#zipCode',
            inputAddress: '#address1',
            inputNumber: '#number',
            inputCity: '#city',
            inputNeighborhood: '#postBox',
            inputShippingStateCode: '.shipping_stateCode',
            inputShippingStateCodeOption: '.shipping_stateCode-option',

            groupAddress: '.account__form-autofill',
            groupAddressVisible: 'account__form-autofill--visible',

            accountStateLabel: '.account__floating-label-state',
            stateDrawer: '.state-drawer',
            chooseStateDrawer: '.choose-state-drawer',

            accountFloatingLabel: '.account__floating-label',
            accountInvalidFeedback: '.invalid-feedback',

            deleteAddressBtn: '.address__edit-actions__delete',
            deleteContainer: '.address__delete__container',
            deleteConfirmation: '.address__delete-actions__delete',
            deleteDismiss: '.address__delete-actions__dismiss',

            formInputs: '.form-control',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.reloadCounter = 0;

        this.tapEvent = "click";

        this.validate();
    }

    validate() {
        this.options.validator
                    .setOptions({
                        submitButton: "body form button[type='submit']"
                    })
                    .listenSubmitButton();

        return this;
    }

    submitAddressSave() {
        this.$.ajax({
            type: 'post',
            url: this.$(this.options.addressForm).attr('action'),
            data: this.$(this.options.addressForm).serialize(),

            success: (data) => {
                if (data.success) {
                    this.$(document).trigger('app:frame:loadPage', [{
                        isModal:true,
                        link:'/on/demandware.store/Sites-Havaianas-BR-Site/pt_BR/Address-List'
                    }]);
                } else {
                    this.options.validator.validateForm(this.$(this.options.addressForm), true, data.fields);
                }
            }, error () {
                this.options.toast
                    .setOptions({
                        msgText: "Sorry! something went wrong."
                    })
                    .openToast();
            }
        });
    }

    submitDeleteAddres(target) {
        this.$.ajax({
            url: this.$(target).data('action'),
            dataType: 'json',

            success: (data) => {
                if (data.success) {
                    this.reloadCounter += 1;

                    this.$(document).trigger('app:frame:loadPage', [{
                        isModal: true,
                        link: `${this.$(target).data('redirect')}?reload=true&counter=${this.reloadCounter}`
                    }]);

                    this.options.toast
                    .setOptions({
                        msgText: data.successMsg
                    })
                    .openToast();
                }
            }
        });
    }

    verifyPostalCode() {
        let inputPostalCode = this.$(this.options.inputPostalCode);
        let patternCEP = inputPostalCode.attr('pattern');
        let cep = inputPostalCode.val();
        let regexCEP = cep.match(patternCEP);
        let minLenght = inputPostalCode.attr('minlength');

        // removes all characters that are not numbers or -
        let regexLetter = cep.substring(cep.length - 1).match(/^[0-9]?-?$/);

        if(!regexLetter) {
            inputPostalCode.val(cep.substring(0, cep.length - 1));
            return;
        }

        if(!cep.length) return;

        if(cep.length >= minLenght && regexCEP) {
            this.options.validator.clearForm(this.options.addressForm)
            this.submitAutoCompleteAddress(cep);
        }
    }

    submitAutoCompleteAddress(postalCode) {
        let url = window.app.urls.autoCompleteAddress;
        this.$.ajax({
            type: 'GET',
            url: url,
            data: {
                postalCode: postalCode
            }
        }).done((data) => {
            if (data.success) {
                this.fillAddress(data);
            } else {
                this.emptyAddress(data);
            }
        }).fail((data) => {
            this.fillAddress(data);
        });
    }

    fillAddress(data) {
        this.$(this.options.groupAddress).addClass(this.options.groupAddressVisible);
        this.$(this.options.inputPostalCode).siblings(this.options.accountInvalidFeedback).text('');

        if (data.address) {
            this.$(this.options.inputAddress).val(data.address.address);
            this.$(this.options.inputNeighborhood).val(data.address.bairro);
            this.$(this.options.inputCity).val(data.address.city);
            this.$(this.options.inputShippingStateCode).val(data.address.uf);
            this.$(this.options.inputAddress).siblings(this.options.accountFloatingLabel).removeClass('empty').addClass('active');
            this.$(this.options.inputNumber).focus();

            // get the last inputShippingStateCodeOption selected text
            const inputsState = this.$(`${this.options.inputShippingStateCodeOption}[value=${data.address.uf}]`);
            const stateText = this.$(inputsState[inputsState.length - 1]).text();
            this.$(this.options.accountStateLabel).text(stateText);
        } else {
            this.$(this.options.inputAddress).focus();
        }
    }

    emptyAddress(data) {
        this.$(this.options.groupAddress).removeClass(this.options.groupAddressVisible);
        this.$(this.options.inputAddress).val('');
        this.$(this.options.inputAddress).siblings(this.options.accountFloatingLabel).removeClass('active').addClass('empty');
        this.$(this.options.inputPostalCode).siblings(this.options.accountInvalidFeedback).text(data.errorMsg);
        this.$(this.options.inputPostalCode).focus();
    }

    openDrawerState() {
        this.$(this.options.stateDrawer).addClass("drawer--isOpen")

        this.showDrawerTimeOut = setTimeout(() => {
            this.$(this.options.stateDrawer).addClass("drawer--isVisible")
        }, 200);
    }

    closeDrawerState() {
        clearTimeout(this.showDrawerTimeOut);

        if(isMobile()) {
            this.$(this.options.stateDrawer)
                .removeClass("drawer--isOpen")
                .removeClass("drawer--isVisible")

            this.isDrawerOpen = false;
        } else {
            this.$(this.options.stateDrawer).css("display", "none");
            this.$(this.options.chooseStateDrawer).removeClass("dropdown-label");
        }
    }

    listen() {
        this.$(this.options.deleteAddressBtn).on(this.tapEvent, (ev) => {
            ev.preventDefault();

            this.$(ev.target).siblings(this.options.deleteContainer).addClass('active');

            setTimeout(() => this.$(ev.target).siblings(this.options.deleteContainer).removeClass('active'), 5000);
        });

        this.$(this.options.deleteDismiss).on(this.tapEvent, (ev) => {
            ev.preventDefault();

            this.$(ev.target).parents(this.options.deleteContainer).removeClass('active');
        });

        // close drawers on click outside
        this.$('body').on(this.tapEvent, (event) => {
            const drawerState = this.$(this.options.stateDrawer);

            if(drawerState !== event.target && !drawerState.has(event.target).length){
                this.closeDrawerState();
            }
        });

        //State input OPEN
        this.$(this.options.accountStateLabel).off(this.tapEvent).on(this.tapEvent, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            if (isMobile()) {
                if (this.isDrawerOpen == false  && this.$(this.options.accountStateLabel).is(ev.target)) {
                    ev.preventDefault();
                    this.openDrawerState();
                }
            } else {
                this.$(this.options.stateDrawer).removeClass("drawer")
                this.$(this.options.stateDrawer).css("display", "block");
                this.$(this.options.chooseStateDrawer).addClass("dropdown-label");
            }
        });

        //State input CLOSE
        this.$('body').off(this.tapEvent, this.options.inputShippingStateCodeOption)
                      .on(this.tapEvent, this.options.inputShippingStateCodeOption, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            const target = ev.target;
            const stateText = this.$(target).text();
            const value = this.$(target).attr('value');
            this.$(this.options.inputShippingStateCode).val(value);
            this.$(this.options.accountStateLabel).text(stateText);

            this.closeDrawerState();
        });

        let debouncePostalCode = debounce((ev) => {
            if (ev.key == 'Control' || ev.key == 'Shift' || ev.ctrlKey || ev.shiftKey) return this;
            this.verifyPostalCode();
        }, 300);
        this.$(this.options.inputPostalCode).on("keyup paste", debouncePostalCode);

        this.$(this.options.addressSaveBtn).on(this.tapEvent, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.submitAddressSave();
        });

        this.$(this.options.deleteConfirmation).on(this.tapEvent, (ev) => {
            ev.preventDefault();

            this.submitDeleteAddres(ev.target);
        });

        this.activeSubmitButton(this.options.addressForm, this.options.addressSaveBtn);
    }

    activeSubmitButton(form, button) {
        this.$(form).find(this.options.formInputs).on('keyup', () => {
            if(this.options.validator.validateForm(this.$(form))) {
                this.$(button).addClass('active');
            } else {
                this.$(button).removeClass('active');
            }
        });
    }

    destroy() {
        // body events
        this.$('body')
            .off(this.tapEvent, this.options.inputShippingStateCodeOption)
            .off(this.tapEvent, this.options.stateDrawer);

        // other events

        return this;
    }
}
