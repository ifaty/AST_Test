import ASYNC from '../../utils/async';
import debounce from '../../utils/debounce';

export default class App extends ASYNC {
    constructor(options) {

            super(options);

            const defaultOptions = {
                selectorEngine: {}
            }

            this.options = Object.assign({}, defaultOptions, options);
            this.$ = this.options.selectorEngine;

            this.rainbowAnimTime = 800 * 2;
            this.watching = false;
            this.sleepTime = 200;
            this.browserStates = {
                ready: false,
                load: false
            };
            this.rainbowStates = {
                ready: false
            }

        this.listen();

        this.export();
    }

    setOptions(options) {

        this.options = Object.assign({}, this.options, options);

        return this;
    }

    export() {
        window.havaianasCore = this;

        return this;
    }

    readyDefaultAction() {

        setTimeout(() => {
            this.$(document).trigger("app:ready");
            this.browserStates.ready = true;
        }, this.sleepTime);

        return this;
    }

    rainbowReadyDefaultAction() {
        this.rainbowStates.ready = true;

        return this;
    }

    loadDefaultAction() {
        setTimeout(() => {
            this.$(document).trigger("app:load");
            this.browserStates.load = true;
        }, this.sleepTime);

        return this;
    }

    load() {
        return new Promise(resolve => {
            let loadInterval = setInterval(() => {
                if (this.browserStates.ready && this.browserStates.load) {
                    clearInterval(loadInterval);
                    resolve();
                }
            }, 300);
        });
    }

    ready() {
        return new Promise(resolve => {
            let readyInterval = setInterval(() => {
                if (this.browserStates.ready) {
                    clearInterval(readyInterval);
                    resolve();
                }
            }, 400);
        });
    }

    async rainbowAttached() {
        return new Promise(resolve => {
            let rainbowAttacheInterval = setInterval(() => {
                if (this.browserStates.ready && this.browserStates.load) {
                    clearInterval(rainbowAttacheInterval);

                    setTimeout(() => {
                        resolve();
                    }, this.rainbowAnimTime);
                }
            }, 300);
        });
    }

    async rainbowIsReady() {
        return new Promise(resolve => {
            let rainbowReadyAttachedInterval = setInterval(() => {
                if (this.rainbowStates.ready && this.browserStates.load) {
                    clearInterval(rainbowReadyAttachedInterval);

                    resolve();
                }
            }, 50);
        });
    }

    listen() {

        if (this.watching) return this.reload();

        let readyDebounced = debounce(() => {
            this.readyDefaultAction();
        }, 400, false);

        let loadDebounced = debounce(() => {
            this.loadDefaultAction();
        }, 200, false);

        let rainbowReadyDebounced = debounce(() => {
            this.rainbowReadyDefaultAction();
        }, 100, false);

        this.$(() => {
            readyDebounced();
        })

        this.$(window).on("load", () => {
            loadDebounced();
        });

        this.$(window).on("app:rainbow:isReady", () => {
            rainbowReadyDebounced();
        });
    }

    reload() {

        this.watching = false;

        return this.destroy().listen();

    }

    destroy() {

        return this;
    }
}