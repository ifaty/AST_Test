import isMobile from '../../utils/isMobile';
import Debounce from '../../utils/debounce';
import scrollMagic from 'scrollmagic';

export default class ProductMatchThis {
    constructor(options) {

        const defaultOptions = {

            page: ".container.page-product",
            pdpMatchThisContainer: '.pdp-match-this',
            bullets: ".bullet",
            matchWithGroupImg: ".match-with-group-item .match-with-img > img",
            matchThisContainer: ".match-this",
            matchWithContainer: ".match-with",
            matchWithTitle: ".match-with-title",
            matchWithGroupItem: ".match-with-group-item",
            matchWithGroupItemLast: ".match-with-group-item.is-last",
            matchWithBullets: ".match-with-bullets",
            currentProductContainer: ".current-product",
            currentProductPlaceholder: ".current-product-placeholder",
            currentProductInfo: ".current-product-info",
            matchThisWrapper: "#pdp-match-this-container",

            colorMatrix: ".color-matrix",

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.allVariationColors = [];

        this.tapEvent = "click";

        this.scrollMagicController = null;

        this.numberOfPictures = $(this.options.matchWithGroupItem).length;
    }

    setScrollController(controller){
        this.scrollMagicController = controller;

        return this;
    }

    configBullet() {

        $(this.options.matchWithGroupImg).map((i, element) => {

            let image = this.$(element);

            image.parent().find(this.options.matchWithBullets).css({
                position: 'absolute',
                left: -image.offset().left,
                top: -image.offset().top,
                right: -image.offset().left,
                bottom: -image.offset().top,
                margin: 'auto',
                width: image.width(),
                height: image.height()
            })

            image.parent().find(this.options.bullets).map((i, el) => {

                let y = $(el).data().y;
                let x = $(el).data().x;


                $(el).css({
                    left: `calc(${x}% - 30px)`,
                    top: `calc(${y}% - 30px)`,
                    display: 'block'
                }).addClass("is-visible")

                if (!isMobile()) {
                    new scrollMagic.Scene({
                        triggerElement: `[data-matchWith='${image.attr('data-matchWith')}']`,
                        triggerHook: 0.5,
                        duration: '100%'
                    })
                    .addTo(this.scrollMagicController)
                    .on('enter', (e) => {
                        let loadInterval = setInterval(() => {
                            if (image.data('is-lazyloaded') == true) {
                                setTimeout(() => this.$(el).removeClass("is-visible"),1000)
                                clearInterval(loadInterval);
                            }
                        }, 100);
                        e.target.destroy();
                    })
                }

            });

        });
    }

    matchThisScene() {

        let currentProduct = this.$(this.options.currentProductContainer);
        let matchThis = this.$(this.options.matchThisContainer);
        let page = document.querySelector(this.options.page);

        let pictures = this.$(this.options.matchWithGroupItem).length;
        let duration = matchThis.height() / pictures - (this.$(".pages-viewport").outerHeight() - this.$(this.options.matchWithGroupImg).height());

        let matchThisScene = new scrollMagic.Scene({
            triggerElement: this.options.matchWithContainer,
            triggerHook: 0,
            duration
        })
        .addTo(this.scrollMagicController)
        .on('enter start end', (e) => {

            if (e.type == 'enter') {
                currentProduct.removeClass('position-fix');
                currentProduct.addClass('sticky');
                matchThis.addClass('sticky');

                currentProduct.on('wheel', (e) => {
                    let direction = Math.max(-1, Math.min(1, (-(e.originalEvent.wheelDelta) || e.originalEvent.deltaY)));
                    let scroll = direction * 100;
                    page.scrollTop += scroll;
                });
            }

            else if (e.type == 'end' && e.scrollDirection == "FORWARD") {
                currentProduct.removeClass('sticky');
                currentProduct.addClass('position-fix')
                currentProduct.off('wheel')
            }

            else if (e.type == 'start' && e.scrollDirection == "REVERSE") {
                currentProduct.removeClass('sticky');
                currentProduct.removeClass('position-fix');
                matchThis.removeClass('sticky');
                currentProduct.off('wheel');
            }

        })

    }

    listenMatchThisDesktopScroll() {

        this.$(this.options.matchWithGroupItem).length > 1 ? this.matchThisScene() : this.$(this.options.currentProductContainer).addClass('match-this-single');

        let texts = $(this.options.matchThisContainer).find(this.options.matchWithTitle);

            this.$('.match-with-group-item').map((i, el) => {


                let matchThisScene = new scrollMagic.Scene({
                    triggerElement: el,
                    triggerHook: 0.5,
                    duration: '100%'
                })
                .addTo(this.scrollMagicController)
                .on('enter', (e) => {

                    let target = this.$(e.target.triggerElement());
                    let text = target.find('.match-with-title');
                    let placeHolderText = this.$(this.options.currentProductPlaceholder);

                    if (text.text() != placeHolderText.text()) {

                        this.$(this.options.currentProductPlaceholder).html(text.html());

                        anime({
                            targets: placeHolderText.find('h2')[0],
                            translateY: ['200%', '0'],
                            easing: 'linear',
                            duration: 300
                        });

                    };


                })

            });


        this.$(this.options.currentProductPlaceholder).html(this.$(texts).first().html());


    }

    listenMatchThisMobileScroll() {
        $(this.options.matchWithBullets).first().addClass('in-viewport');
        $(this.options.matchWithContainer).on("scroll", (el) => {
            $(el.target).find(this.options.matchWithGroupItem).map((i2, el2) => {
               let elementInViewport = $(el.target).scrollLeft() >= ($(el2)[0].offsetLeft - 80) && $(el.target).scrollLeft() <= ($(el2)[0].offsetLeft + 80) || $(el.target).scrollLeft() >= ($(el2)[0].offsetLeft - 80);

                if (elementInViewport) {
                    $(el2).find(this.options.matchWithBullets).addClass('in-viewport');
                }
            });
        });

    }
    placeMatchThisContainer() {
        this.$(this.options.matchThisContainer).insertBefore(this.options.currentProductInfo);
    }

    listen() {

        if (this.$(this.options.matchThisContainer).length) {

            if (!isMobile()) {
                this.listenMatchThisDesktopScroll();
            }

            this.configBullet();

            if (isMobile()) {
                this.listenMatchThisMobileScroll();
                this.placeMatchThisContainer();
            }

        }

    }
}
