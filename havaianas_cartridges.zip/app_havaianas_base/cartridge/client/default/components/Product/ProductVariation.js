import isMobile from '../../utils/isMobile';

export default class ProductVariation {
    constructor(options) {

        const defaultOptions = {
            rainbow: '.rainbow',
            rainbowWrapper: '.rainbow-loading-wrapper',
            rainbowLoading: '.rainbowLoading',

            productVariation: '.product__variation',
            productVariationBuilded: '.product__variation.builded',
            productVariationPlaceholder: '.product__variation-placeholder',
            productVariationContainer: '.product__variation-container',
            productVariationList: '.product__variation-list',
            productVariationItem: '.product__variation-item',
            productVariationBack: '.product__variation-back',
            productVariationLink: '.product__variation-link',

            colorMatrix: '.color-matrix',

            productVariationTwoRowsClass: 'product__variation-item__two-rows',
            productVariationThreeRowsClass: 'product__variation-item__three-rows',
            productVariationFourRowsClass: 'product__variation-item__four-rows',
            productVariationFiveOrMoreRowsClass: 'product__variation-item__five-or-more-rows',

            productBodyClass: 'page-product-body',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.allVariationColors = [];

        this.tapEvent = "click";

        this.isFrame = false;
    }

    productVariationPlaceholderFadeIn() {
        return new Promise(resolve => {
            if (isMobile()) {
                if(this.$('body').hasClass(this.options.productBodyClass)) {
                    this.$(this.options.productVariationPlaceholder).addClass('d-block');
                }

                resolve();

            } else {

                this.quickShowProductVariationsDesktop().then(() => {
                    // checks to see if the user is still on the product page
                    if(this.$('body').hasClass(this.options.productBodyClass)) {
                        this.$(this.options.productVariationPlaceholder).addClass('d-block');
                    }

                    resolve();
                });
            }
        });
    }

    quickShowProductVariationsDesktop() {
        return new Promise(resolve => {
            if (isMobile()) {
                return resolve();

            } else {
                this.mouseEnterProductVariation().then(() => {
                    setTimeout(() => {
                        this.mouseLeaveProductVariation();

                        this.$(this.options.productVariationPlaceholder).addClass('animate');

                        resolve();
                    }, 3500);
                });
            }
        });
    }

    buildProductRainbow() {
        this.productVariationPlaceholderFadeIn();

        this.orderProductList();

        if (this.$(this.options.productVariationBuilded).length) {
            this.$(this.options.productVariationBuilded).remove();
        }

        this.$(this.options.productVariation).appendTo('body').addClass('builded');

        this.productRainbowColors();
    }

    productRainbowColors() {
        if (this.$(this.options.colorMatrix).length) {
            let colorMatrixData = this.$(this.options.colorMatrix).data('colormatrix');

            this.$(this.options.productVariationPlaceholder)
                .css('background-image', `linear-gradient(45deg, ${colorMatrixData.background}, ${colorMatrixData.ui}`);
        };
    }

    orderProductList() {
        let itensLength;

        this.$(this.options.productVariationItem).removeClass(
            `${this.options.productVariationFourRowsClass},
            ${this.options.productVariationThreeRowsClass},
            ${this.options.productVariationTwoRowsClass},
            ${this.options.productVariationFiveOrMoreRowsClass}`
        );

        if (!this.$(this.options.productVariationBuilded).length) {

            this.$(`${this.options.productVariationItem}.selected`).prependTo(this.options.productVariationList);
            itensLength = this.$(this.options.productVariationItem).length;

        } else {
            itensLength = this.$(`${this.options.productVariationBuilded} ${this.options.productVariationItem}`).length;
        }

        if (itensLength == 4) {
            this.$(this.options.productVariationItem).addClass(this.options.productVariationFourRowsClass);
        } else if (itensLength == 3) {
            this.$(this.options.productVariationItem).addClass(this.options.productVariationThreeRowsClass);
        } else if (itensLength <= 2) {
            this.$(this.options.productVariationItem).addClass(this.options.productVariationTwoRowsClass);
        } else {
            this.$(this.options.productVariationItem).addClass(this.options.productVariationFiveOrMoreRowsClass);
        }
    }

    reOrderSelectedItem() {
        this.productRainbowColors();

        this.$(`${this.options.productVariationBuilded} ${this.options.productVariationItem}.selected`).prependTo(this.options.productVariationList);
    }

    openProductVariations() {
        let container = this.$(this.options.productVariationContainer);

        container.css({
            "display" : "block",
            "clip-path": "circle(0%)",
            "-webkit-clip-path": "circle(0%)"
        });

        this.options.animation.circleAnimation(container[0], '0%', '130%', '86%', '52px', 300).then(() => {
            container.css({
                "clip-path": "none",
                "-webkit-clip-path": "none"
            });
        });
    }

    closeProductVariations() {
        let container = this.$(this.options.productVariationContainer);

        container.css({
            "clip-path": "circle(130%)",
            "-webkit-clip-path": "circle(130%)"
        });

        return this.options.animation.circleAnimation(container[0], '130%', '0%', '86%', '52px', 300).then(() => {
            container.css({
                "clip-path": 'none',
                "-webkit-clip-path": 'none',
                "display" : "none",
            });

        this.productRainbowColors();

        });
    }

    collapseProductVariationDesktop() {
        return new Promise((resolve) => {
            let productVariationPlaceholderWidth = this.$(this.options.productVariationPlaceholder).width();
            let productVariationContainerWidth = this.$(this.options.productVariationContainer).width();
            let rightPos = productVariationContainerWidth - productVariationPlaceholderWidth;

            this.$(this.options.productVariationContainer).stop()
                .animate({right: -rightPos}, {
                    duration: 200,
                    complete: resolve
                });
        });
    }

    mouseEnterProductVariation() {
        return new Promise(resolve => {
            this.$(this.options.productVariationContainer).stop().show();

            this.$(this.options.productVariationContainer)
                .animate({right: 0}, {
                    duration: 200,
                    complete: resolve
                });
        });
    }

    mouseLeaveProductVariation() {
        this.$(this.options.productVariationPlaceholder).removeClass('animate');

        this.collapseProductVariationDesktop().then(() => {
            this.productVariationContainerFadeOutAndOrder();
        });
    }

    productVariationContainerFadeOutAndOrder() {
        return new Promise((resolve) => {
            setTimeout(() => {
                this.$(this.options.productVariationContainer).fadeOut();
                this.productRainbowColors();
            }, 600);
        });
    }

    variationLoaded() {
        if (isMobile()) {
            this.closeProductVariations();
        } else {
            this.$(this.options.rainbow).fadeOut();
            this.fadeOutRainbowLoading();
        };
    }

    fadeOutRainbowLoading() {
        return new Promise((resolve) => {
            setTimeout(() => {
                this.$(this.options.rainbowLoading).fadeOut();
                this.$('body').addClass('is-ready is-rainbowReady');
            }, 800);
        });
    }

    reset() {
        this.$(this.options.rainbow).fadeIn();
        this.$(this.options.productVariationPlaceholder).removeClass('d-block');
    }

    init(isFrame) {
        isFrame ? this.isFrame = true : this.isFrame = false;

        this.buildProductRainbow();

        this.listen();
    }

    listen() {
        this.$('.rainbowAnimation').removeClass(`discoveryRainbowAnimation`);

        if (isMobile()) {

            this.$(this.options.productVariationPlaceholder).on(this.tapEvent, (ev)=> {
                this.$(this.options.productVariationItem).length ? this.openProductVariations() : ev.preventDefault();
            });

        } else {
            this.$(this.options.productVariationPlaceholder).on('mouseenter', ()=> {
                this.mouseEnterProductVariation();
            });

            this.$(this.options.productVariationContainer).on('mouseleave', ()=> {
                this.mouseLeaveProductVariation();
            });
        }

        this.$(this.options.productVariationBack).on(this.tapEvent, (ev)=> {
            ev.preventDefault();

            this.closeProductVariations();
        });

        this.$(this.options.productVariationLink).on(this.tapEvent, (ev) => {
            this.$(this.options.productVariationItem).removeClass('selected');
            this.$(ev.currentTarget).parents(this.options.productVariationItem).addClass('selected');

            if (!isMobile()) {
                this.$('body').removeClass('is-ready is-rainbowReady');

                this.$(this.options.rainbowLoading).fadeIn();
            };
        });
    }
}
