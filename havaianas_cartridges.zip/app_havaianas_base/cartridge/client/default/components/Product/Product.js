import isMobile from '../../utils/isMobile';
import UnavailableNotify from './UnavailableNotify';
import productMatchThis from "./ProductMatchThis";
import similarProducts from "./SimilarProducts";
import scrollMagic from 'scrollmagic';

export default class Product {
    constructor(options) {

        const defaultOptions = {
            myPage: '.page-product',

            header: '.header',
            headerActions: '.superActions__header',
            headerSearch: '.superActions__header__search',
            headerLogo: '.header__logo',

            pageProduct: '.page-product',
            pageSizeGuide: '.container.page-sizeGuide',
            infoItem: ".product__info-item",
            infoDescription: ".product__item-description",
            buyBtn: '#buy__button',
            closeBuyBtnClass: 'product__buy-close',
            closeNotifyBtnClass: 'product__notify-close',
            chooseSize: ".choose__size",
            chooseSizeBtn: '.product__buy-container .size__button:not(.size__unavailable)',
            chooseSizeOpen: "choose__size--isOpen",
            sizeGuideTriggerDesktop: '.product__buy__size-guide',
            notifyContainer: '.notify__unavailable--container',

            drawerSize: '.drawer__choose-size',
            drawerOverlay: '.drawer-overlay',
            drawerSizeTitle: '.drawer__choose-size__title',

            sizeList: '.product__size-list',
            sizeItem: '.size__item',
            confirmSizeBtn: '.size__confirm__button',

            payBtn: '#pay__button',
            productHiddenClass: 'product__hidden',

            productBuyClose: '#buy__button.product__buy-close',
            productSizeButton: '.product__size-list .size__button',
            productBuyContainer: '.product__buy-container',
            productPayButtonVisible: '.product__pay-button__visible',

            productLeftCol: '.product__left-col',
            productRightCol: '.product__right-col',
            productImageGridContainer: '.imageGridContainer',
            productFunFactContainer: '.pdp-fun-fact',
            productMatchThisContainer: '#pdp-match-this-container',
            productVariationPlaceholder: '.product__variation-placeholder',

            sizeUnavailableClass: 'size__unavailable',
            productUnavailableClass: 'product__unavailable',
            sizeGuideBtn: '.selectable__size',
            selectedSize: '.selected__size',
            productDescription: '.product__description',
            productHeroImage: ".product__hero",
            scrollElementTrigger: ".product__images",
            headerLinkBack: '.header__link-back',
            productMainInfoFlag: '.product__main-info > .product__tile-flag p',

            recommendationsContainer: '.recommendations',
            recommendationsProductCell: '.recommendations .shopmode__cell',

            isMenuOpen: false,
            productId: null,

            productWishlistBtn: '.product__wishlist-btn',

            collapseRainbow: 'collapseRainbow',

            colorMatrix: '.page-product > .color-matrix',

            selectorEngine: {}
        }


        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.productMatchThis = new productMatchThis({selectorEngine: this.$});

        this.similarProducts = new similarProducts({
            selectorEngine: this.$,
            frame: this.options.frame,
            shopButton: this.options.shopButton,
            toast: this.options.toast,
            productBuyButton: this.options.productBuyButton,
            productPayButton: this.options.productPayButton
        });

        this.colorMatrixData;

        this.tapEvent = "click";
        this.unavailableNotify = new UnavailableNotify({selectorEngine: this.$, toast: this.options.toast});
    }

    openDescription(ev) {
        this.$(this.options.infoItem).off(this.tapEvent).on(this.tapEvent, (ev) => {
            ev.preventDefault();

            // Close other descriptions
            if(!this.$(ev.target).hasClass('is-open')) {
                this.$(ev.target).parent().find('.is-open').toggleClass("is-open").find(this.options.infoDescription).slideToggle();
            }
            // \Close

            this.$(ev.target).find(this.options.infoDescription).slideToggle().parent().toggleClass("is-open");
        });
    }

    closeDescription() {
        this.$('.product__info-list').find('.is-open').toggleClass("is-open").find(this.options.infoDescription).slideToggle();
    }

    payButtonVisible() {
        if (!isMobile() && this.$(this.options.productPayButtonVisible).length > 0) {
            this.$(this.options.drawerSize).addClass("payButton--isVisible");
            this.$(this.options.notifyContainer).addClass("payButton--isVisible");
            this.$(`.${this.options.closeNotifyBtnClass}`).addClass('payButton--isVisible');
            this.$(`.${this.options.closeBuyBtnClass}`).addClass('payButton--isVisible');
            this.$(this.options.sizeGuideTriggerDesktop).addClass("payButton--isVisible");
        } else {
            this.$(this.options.drawerSize).removeClass("payButton--isVisible");
            this.$(this.options.notifyContainer).removeClass("payButton--isVisible");
            this.$(`.${this.options.closeNotifyBtnClass}`).removeClass('payButton--isVisible');
            this.$(`.${this.options.closeBuyBtnClass}`).removeClass('payButton--isVisible');
            this.$(this.options.sizeGuideTriggerDesktop).removeClass("payButton--isVisible");
        }
    }

    openNotifyNoSize() {
        if (!isMobile()) {
            this.$(this.options.drawerSizeTitle).hide();

            if (this.$(this.options.colorMatrix).length) {
                this.colorMatrixData = this.$(this.options.colorMatrix).data('colormatrix');
            }

            this.payButtonVisible();

            this.$(this.options.sizeGuideTriggerDesktop).addClass("drawer--isVisible");

            this.$(this.options.buyBtn).addClass('isHidden');

            this.$(`.${this.options.closeNotifyBtnClass}`).addClass('isVisible');

            setTimeout(() => {
                this.$(this.options.buyBtn).addClass('d-none');
                this.$(`.${this.options.closeNotifyBtnClass}`).addClass('d-inline-block');
            }, 300);

            this.$(this.options.drawerSize).addClass("drawer--isOpen");

            this.$(this.options.drawerSize).addClass("drawer--isVisible");

            this.$(`${this.options.headerLogo},
                    ${this.options.headerSearch},
                    ${this.options.productVariationPlaceholder},
                    ${this.options.headerLinkBack}`).css('pointer-events', 'none');

            if (!isMobile()) {
                anime({
                    targets: `${this.options.headerActions},
                                ${this.options.header},
                                ${this.options.productLeftCol}`,

                    opacity: 0.3,
                    duration: 300,
                    easing: 'linear'
                });

                anime({
                    targets: `${this.options.productRightCol},
                                ${this.options.productImageGridContainer},
                                ${this.options.productFunFactContainer},
                                ${this.options.productMatchThisContainer}`,

                    opacity: 0.6,
                    duration: 300,
                    easing: 'linear'
                });
            }
        }
    }

    openSizes(ev) {
        var variantsUrl = this.$(this.options.buyBtn).data("url");

        this.$.ajax({
            type: 'GET',
            url: variantsUrl,
            data: {
                context: 'pay'
            },

            success: (data) => {
                if (!isMobile()) {
                    this.$(this.options.sizeGuideTriggerDesktop).addClass("drawer--isVisible");
                    this.$(this.options.buyBtn).addClass('isHidden');
                    this.$(this.options.sizeGuideTriggerDesktop).addClass('isHidden');
                }

               this.payButtonVisible();

                if (!this.$(this.options.sizeList).first().hasClass('builded')) {

                    this.$(this.options.sizeList).addClass('builded');

                    this.$(this.options.sizeList).append(data);
                }

                setTimeout(() => {
                    if (!isMobile()) {
                        this.$(this.options.buyBtn).addClass('d-none');
                        this.$(`.${this.options.closeBuyBtnClass}`).addClass('d-inline-block');
                    }
                    this.$(this.options.drawerSize).addClass("drawer--isOpen");
                }, 300);

                 setTimeout(() => {
                    if (!isMobile()) {
                        this.$(`.${this.options.closeBuyBtnClass}`).addClass('isVisible');
                        this.$(this.options.sizeGuideTriggerDesktop).removeClass('isHidden');
                    }
                    this.$(this.options.drawerSize).addClass("drawer--isVisible");
                 },400);

                this.$(`${this.options.headerLogo},
                        ${this.options.headerSearch},
                        ${this.options.productVariationPlaceholder},
                        ${this.options.headerLinkBack}`).css('pointer-events', 'none');

                if (!isMobile()) {
                    anime({
                        targets: `${this.options.headerActions},
                                ${this.options.header},
                                ${this.options.productLeftCol}`,

                        opacity: 0.3,
                        duration: 300,
                        easing: 'linear'
                    });

                    anime({
                        targets: `${this.options.productRightCol},
                                ${this.options.productImageGridContainer},
                                ${this.options.productFunFactContainer},
                                ${this.options.productMatchThisContainer}`,

                        opacity: 0.6,
                        duration: 300,
                        easing: 'linear'
                    });
                }
            },
            error: () => {
                this.options.toast
                .setOptions({
                    buttonOk: true,
                    buttonMsg: "Ok",
                    msgText: "Sorry! Something went wrong",
                    type: "error",
                }).openToast();
            }
        });

        this.options.isMenuOpen = true;
    }

    closeSizes() {
        if (!isMobile()) {
            this.$(this.options.sizeGuideTriggerDesktop).removeClass("drawer--isVisible");
            this.$(`.${this.options.closeBuyBtnClass}`).removeClass('isVisible');
            this.$(`.${this.options.closeNotifyBtnClass}`).removeClass('isVisible');
            this.$(this.options.sizeGuideTriggerDesktop).addClass('isHidden');

            setTimeout(() => {
                this.$(this.options.buyBtn).removeClass('isHidden');
                this.$(this.options.sizeGuideTriggerDesktop).removeClass('isHidden');
            },400);
        }

        this.payButtonVisible();

        this.$(this.options.drawerSize).removeClass("drawer--isVisible");

        setTimeout(() => {
            if (!isMobile()) {
                this.$(`.${this.options.closeBuyBtnClass}`).removeClass('d-inline-block');
                this.$(`.${this.options.closeNotifyBtnClass}`).removeClass('d-inline-block');
                this.$(this.options.buyBtn).removeClass('d-none');
            }
            this.$(this.options.drawerSize).removeClass("drawer--isOpen");
        }, 300);


        this.$(`${this.options.headerLogo},
                ${this.options.headerSearch},
                ${this.options.productVariationPlaceholder},
                ${this.options.headerLinkBack}`).css('pointer-events', 'all');

        if (!isMobile()) {
            anime({
                targets: `${this.options.headerActions},
                          ${this.options.header},
                          ${this.options.productLeftCol}`,

                opacity: 1,
                duration: 300,
                easing: 'linear'
            });

            anime({
                targets: `${this.options.productRightCol},
                          ${this.options.productImageGridContainer},
                          ${this.options.productFunFactContainer},
                          ${this.options.productMatchThisContainer}`,

                opacity: 1,
                duration: 300,
                easing: 'linear'
            });
        }

        this.options.isMenuOpen = false;
    }

    closeModal() {
        this.$(document).trigger('app:frame:activeLastPage', [{pageName: 'page-product'}]);
        this.options.frame.closeModal();
        this.options.isMenuOpen = false;
    }

    buyButtonListener() {
        var isStandardProduct = this.$(this.options.buyBtn).data("standardproduct");

        this.$(this.options.buyBtn).off(this.tapEvent).on(this.tapEvent, (ev) => {
            let url = this.$(ev.target).data("url");
            let pid = this.$(ev.target).data("pid");

            let available = !(this.$(this.options.buyBtn).hasClass(this.options.sizeUnavailableClass) || this.$(this.options.buyBtn).hasClass(this.options.productUnavailableClass));
            let selectedSize = $(this.options.selectedSize).find("button").data('pid');

            if (available) {
                if (isStandardProduct) {

                    this.options.productPayButton.addItem(url, pid)
                    .then((data) => {
                        console.log(data);
                    })
                    .catch((error) => {
                        console.log(error);
                    })

                } else if(selectedSize != null) {
                    url = $(this.options.selectedSize).find("button").data('url');

                    this.addItemToCart(url, selectedSize);
                } else {
                    this.openSizes();
                }
            } else {
                this.openNotifyNoSize();
            }
        });
    }

    selectSize(pid, url, value) {
        if (isMobile()) {
            $(this.options.sizeItem).find(`[data-pid='${pid}']`).addClass('selected__size__item')
                .removeClass('matrixTxtColor').removeClass('matrixTxtColorAsBorder')
                .addClass('matrixUiElement').addClass('matrixUiText');

            $(this.options.confirmSizeBtn).parent().css('opacity', '1');
        } else {
            $(this.options.sizeGuideTriggerDesktop).css('display', 'none');
            $(this.options.selectedSize).css('display', 'inline-block');
            $(this.options.selectedSize).find("button").data('pid', pid);
            $(this.options.selectedSize).find("button").data('url', url);
            $(this.options.selectedSize).find("button").text(value);
        }
    }

    clearSelectedSizes() {
        if (isMobile()) {
            $(this.options.sizeItem).find(".size__button")
                .removeClass('selected__size__item')
                .removeClass('matrixUiElement').removeClass('matrixUiText')
                .addClass('matrixTxtColor').addClass('matrixTxtColorAsBorder');

            $(this.options.confirmSizeBtn).parent().css('opacity', '0');
        } else {
            $(this.options.sizeGuideTriggerDesktop).css('display', 'inline-block');
            $(this.options.selectedSize).css('display', 'none');
            $(this.options.selectedSize).find("button").data('pid', null);
            $(this.options.selectedSize).find("button").data('url', null);
            $(this.options.selectedSize).find("button").text('');
        }
    }

    addItemToCart(url, pid) {

        this.options.productPayButton.addItem(url, pid)
        .then((data) => {

            this.$(document).trigger("app:gtm:addToCart", {product: data.product, currencyCode: data.currencyCode, quantity: 1});
            this.$(document).trigger("app:gtm:cartStatus", {products: data.cart ? data.cart.items : []});

            this.clearSelectedSizes();

            if (isMobile()) {
                this.closeSizes();
            } else {
                this.closeModal();
            }

            this.options.productPayButton.refreshCart(data.cart.items, data.cart.totals.subTotal, data.cart.actionUrls.updateQuantityUrl, data.cart.actionUrls.removeProductLineItemUrl);
            this.options.productBuyButton.animateProductToCart(data.quantityTotal);
        })
        .catch(() => {
            this.options.toast
                .setOptions({
                    buttonOk: true,
                    buttonMsg: "Ok",
                    msgText: "Sorry! Something went wrong",
                    type: "error",
                }).openToast();
        });
    }

    chooseSizeListener() {

        this.$('body').off(this.tapEvent, this.options.confirmSizeBtn).on(this.tapEvent, this.options.confirmSizeBtn, (ev) => {
            let selectedSize = $(this.options.sizeItem).find(`[class*='selected__size__item']`);
            let url = selectedSize.data("url");
            let pid = selectedSize.data("pid");

            this.addItemToCart(url, pid);
        });

        this.$('body').off(this.tapEvent, this.options.chooseSizeBtn).on(this.tapEvent, this.options.chooseSizeBtn, (ev) => {
            let url = this.$(ev.target).data("url");
            let pid = this.$(ev.target).data("pid");

            this.addItemToCart(url, pid);
        });

        this.$('body').off(this.tapEvent, this.options.sizeGuideBtn).on(this.tapEvent, this.options.sizeGuideBtn, (ev) => {
            let url = this.$(ev.target).data("url");
            let pid = this.$(ev.target).data("pid");
            let value = this.$(ev.target).text();

            this.closeModal();
            this.clearSelectedSizes();
            this.selectSize(pid, url, value);
        });
    }

    addProductToWishlist(el) {
        let btnWishlist = this.$(el);
        let urlWishlist = btnWishlist.hasClass('active') ? btnWishlist.data('href-remove') : btnWishlist.data('href-add');
        let textWishlist = btnWishlist.hasClass('active') ?  btnWishlist.data('text-add') : btnWishlist.data('text-remove');

        this.$.get({
            ajax: true,
            url: urlWishlist,
            success: function () {
                btnWishlist.html(textWishlist).toggleClass('active');
            },
            fail: function (data) {
                console.log(data);
            }
        });
    }

    listenPageScroll() {

        if(this.$(this.options.recommendationsContainer).length) {

            let sceneRecommendations = new scrollMagic.Scene({
                triggerElement: this.options.recommendationsContainer,
                duration: this.$(this.options.recommendationsContainer).height()
            });

            sceneRecommendations.addTo(this.scrollMagicController)
                .on("enter", (el) => {
                    if (!isMobile()) {
                        this.$(this.options.sizeGuideTriggerDesktop).fadeOut(600);
                    }
                    this.$(this.options.buyBtn).addClass('isHidden');
                    setTimeout(() => {this.$(this.options.buyBtn).addClass('d-none');}, 600);
                })
                .on("leave", (el) => {
                    this.$(this.options.buyBtn).removeClass('d-none');
                    setTimeout(() => {
                        this.$(this.options.buyBtn).removeClass('isHidden');
                        if (!isMobile()) {
                            this.$(this.options.sizeGuideTriggerDesktop).fadeIn(600);
                        }
                    ;}, 300);
                })
        }

        if (!isMobile()) {

            let scene = new scrollMagic.Scene({
                triggerElement: this.options.scrollElementTrigger,
                duration: $(this.options.scrollElementTrigger).outerHeight(),
                triggerHook: 0.2,
            });

            let parallax = anime({
                targets: this.options.productDescription,
                translateY: `-${$(this.options.productDescription).outerHeight()}`,
                easing: 'easeInOutQuad',
                endDelay: 500,
                direction: 'reverse'
            })

            scene.addTo(this.scrollMagicController)
            .on("enter", (el) => {
                this.$(this.options.productDescription).fadeIn();
            })
            .on('progress', (e) => {
                parallax.seek(parallax.duration * e.progress);
            })
            .on("leave", (el) => {
                this.$(this.options.productDescription).fadeOut();
            })
        }
    }

    backButtonLink() {
        this.$(this.options.headerLinkBack).attr('href', '#');
        this.$(this.options.headerLinkBack).attr('onclick', 'history.back()');
    }

    productScrollMagicControllerDestroy() {

        if (this.scrollMagicController) {
            this.scrollMagicController.destroy(true);
        }

        return this;

    }

    productScrollMagicController() {
        this.scrollMagicController = new scrollMagic.Controller({
            container: this.options.myPage
        });

        return this;
    }

    recommendationsColors() {
        let firstProductCell = this.$(this.options.recommendationsProductCell).first().find('.color-matrix');

        this.$(this.options.recommendationsContainer).css({
            'color': this.$(firstProductCell).data('colormatrix').text,
            'background-color' : this.$(firstProductCell).data('gradientsecondcolors').background
        });

        return this;
    }

    listen() {
        this.productScrollMagicControllerDestroy()

        this.backButtonLink();

        this.buyButtonListener();
        this.chooseSizeListener();
        this.openDescription();

        this.unavailableNotify.listen();

        this.productScrollMagicController();

        if (this.$(this.options.recommendationsProductCell).length) {
            this.similarProducts.setScrollController(this.scrollMagicController).init();

            this.recommendationsColors();
        }

        this.$(this.options.productWishlistBtn).off(this.tapEvent).on(this.tapEvent, (ev) => {
            this.addProductToWishlist(ev.currentTarget);
        });

        this.options.productBuyButton.init();
        this.productMatchThis.setScrollController(this.scrollMagicController).listen();

        this.listenPageScroll();

        this.$(this.options.drawerOverlay).on(this.tapEvent, () => {
            this.closeSizes();
            if (!isMobile()) {
                this.unavailableNotify.destroyForm();
            }else {
                this.unavailableNotify.destroyDrawer();
            }
        });

        this.$(document).on("app:product:closeSizes", () => this.closeSizes());
        this.$(document).on("app:product:openSizes", () => this.openSizes());

        if (this.$(`body.${this.options.collapseRainbow}`).length) this.$('body').removeClass(this.options.collapseRainbow);

        return this;
    }
}
