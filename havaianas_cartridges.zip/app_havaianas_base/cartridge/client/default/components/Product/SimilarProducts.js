import isMobile from '../../utils/isMobile';
import isotopeLayout from 'isotope-layout';
import 'isotope-packery';
import scrollMagic from 'scrollmagic';

export default class SimilarProducts {
    constructor(options) {

        const defaultOptions = {
            myPage: '.page-product',

            grid: '.shopmode__grid',
            gridCell: '.shopmode__cell',
            gridCellGutter: '.shopmode__cell-gutter',
            sizesItem: '.size-item',
            sizesShowMore: '.size-item.size-more',
            sizesOpenedClassName: 'sizes__opened',
            sizesCloseButton: '.size__attribute .close__button',
            sizeShowMoreClassName: 'size-more',
            sizeAttribute: '.size__attribute',
            displayableSizes: '.displayable__swatches > .sizes',

            colorsShowMore: '.color__swatch.show-more-colors',
            colorsShowMoreClose: '.color__attribute .close__button',
            colorSwatch: '.swatch-circle',
            product: '.product',
            productHover: '.product__tile-background-hover',
            productNewFlag: ".product__tile-flag",
            productTileBuyButton: '.product__tile-buy-btn',
            productDisplayableSwatches: '.displayable__swatches',
            productTileWishlistBtn: '.product__tile-wishlist-btn',

            inWishListClass: '.in-wishlist',

            colorMatrix: '.color-matrix'
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.viewportWidth = this.$("body").outerWidth();
        this.colDesk = this.viewportWidth / 79;

        this.tapEvent = "click";

    }

    listenWishListChange() {

        this.$('body').on(this.tapEvent, this.options.productTileWishlistBtn, (e) => {

            let target = this.$(e.currentTarget);

            if (target.hasClass('active')) {
                this.removeWishList(target)
            } else {
                this.addWishList(target)
            }

        })

    }

    findColorMatrix(target) {
        let fallbackColorMatrix = {
                'text': '#533f1c',
                'background': '#f6d9a7',
                'ui': '#d0a967',
                'uiText': '#533f1c'
            }

        return (target.find(".color-matrix").data() || {}).colormatrix || fallbackColorMatrix;
    }

    findFallbackColorMatrix(target) {
        return (target.find(".color-matrix").data() || {}).fallbackcolormatrix;
    }

    configTileColors() {
        this.$(this.options.product).map((i, el) => this.setProductColors(this.$(el)));
    }

    resetSelectedSize() {

        this.$(this.options.gridCell)
        .find(this.options.sizesItem)
        .removeClass("active")
        .removeAttr("style");

        this.selectedSize = null;
    }

    setSelectedSize(pid) {
        this.selectedSize = pid;
    }

    buildIsotopeLayout() {

        this.$(this.options.grid).map((i, el) => {
            let iso = new isotopeLayout(el, {
                itemSelector: this.options.gridCell,
                layoutMode: 'packery',
                percentPosition: true,
                packery: {
                    gutter: this.options.gridCellGutter
                }
            })
        })

    }

    setProducttileScenes() {
        // loop on product tiles to create scene for each one to scroll magic
        this.$(this.options.gridCell).map((i, el) => {

            let scene = new scrollMagic.Scene({
                triggerElement: el,
                triggerHook: 0.5,
                duration: this.$(el).outerHeight()
            })
            .addTo(this.scrollMagicController)
            .on("enter", (e) => this.$(e.target.triggerElement()).addClass("in-viewport"))
            .on("leave", (e) => this.$(e.target.triggerElement()).removeClass("in-viewport"))

        })
    }

    setScrollController(controller) {
        this.scrollMagicController = controller;

        return this;
    }

    addWishList(target, openToast = true) {

        let url = target.data().hrefAdd;

        this.$.get(url, {
                ajax: true
            }).then(() => {
            target.addClass("active")

            if (openToast) {
                this.options.toast
                .setOptions({
                    buttonOk: true,
                    msgText: target.data().toastAdd,
                    type: "default"
                }).openToast();
            }
        })

    }

    removeWishList(target) {

        let url = target.data().hrefRemove;

        this.$.get(url, {
                ajax: true
            }).then(() => {
            target.removeClass("active")

            this.options.toast
            .setOptions({
                buttonOk: true,
                buttonMsg: "UNDO",
                msgText: target.data().toastRemove,
                type: "default",
                closeUser: () => this.addWishList(target, false)
            }).openToast();
        })

    }

    listenProductHover() {

        this.$(this.options.gridCell)
        .hover((e) => {

            let target = this.$(e.currentTarget);
            let colors = this.findColorMatrix(target);
            let fallbackColors = this.findFallbackColorMatrix(target);

            // The check below is very ad hoc.
            // We should implement a better solution.
            target
            .find(this.options.productHover)
            .css({
                backgroundColor: colors.background == window.colors.backgroundColor ? fallbackColors.background : colors.background
            })

            target
            .find(this.options.product)
            .css({
                color: colors.text,
                borderColor: colors.text,
            })
            .find(this.options.productTileBuyButton).css({
                color: colors.ui,
            })
            .find("span")
            .css({
                color: colors.uiText
            })


        }, (e) => {

            let target = this.$(e.currentTarget);
            target.find(this.options.productHover).removeAttr("style");
            target.find(this.options.product).removeAttr("style");

        })

    }

    listenColorSwatch() {
        this.$('body').on(this.tapEvent, this.options.colorSwatch, (e) => {
            let element = this.$(e.target);
            let url = element.data().url;
            let target = element.closest(this.options.gridCell);

            if (!url) return;

            this.$.get(url, {
                    ajax: true
                }).then(({
                renderedTemplate
            }) => {
                target.append(renderedTemplate).find(this.options.product).first().remove();
                this.listenProductHover();
                this.listenSizeHover();
                setTimeout(() => {
                    this.$(this.options.myPage).trigger("scroll");
                }, 500)
            })

        })
    }

    listenSizeHover() {

        this.$(this.options.sizesItem)
        .hover((e) => {

            let target = this.$(e.currentTarget);
            let colors = this.findColorMatrix(target.closest(this.options.gridCell));

            target.css({
                color: colors.uiText,
                borderColor: colors.ui,
                backgroundColor: colors.ui
            })

        }, (e) => {

            let target = this.$(e.currentTarget);
            if (!target.hasClass("active")) {
                target.removeAttr("style");
            }

        })
    }

    listenSizeClick() {

        this.$('body')
        .on(this.tapEvent, this.options.sizesItem, (e) => {


            let target = this.$(e.currentTarget);
            let url = target.data().url;
            let pid = target.data().pid;
            let colors = this.findColorMatrix(target.closest(this.options.gridCell));

            if (!target.hasClass("active")) {
                this.resetSelectedSize();
            }

            target.toggleClass("active");

            if (target.hasClass("active")) {

                this.setSelectedSize(pid);

                target.css({
                    color: colors.uiText,
                    borderColor: colors.ui,
                    backgroundColor: colors.ui
                })

            } else {
                target.removeAttr("style");
            }

            if (this.$(target).parents('.hidden__swatches').length) {
                this.updateSelectedSizeWithHiddenSwatch(target);
            }

            return this;

        })
    }

    updateSelectedSizeWithHiddenSwatch(target) {
        let targetCell = this.$(target)
                            .parents(this.options.gridCell);

        let sizesContainer = this.$(target)
                                .parents(this.options.sizeAttribute)
                                .find(this.options.displayableSizes);

        let sizes = this.$(sizesContainer)
                        .find(`${this.options.sizesItem}:not(.${this.options.sizeShowMoreClassName})`);


        this.$(sizes).remove();
        this.$(sizesContainer).prepend(this.$(target)[0].outerHTML);
        this.$(targetCell).removeClass(this.options.sizesOpenedClassName);

        return this;
    }

    listenBuyClick() {

        this.$('body').on(this.tapEvent, this.options.productTileBuyButton, (e) => {

            if (!this.selectedSize) return;

            let element = this.$(e.currentTarget);
            let url = element.data().href+'?context=pay';
            let pid = this.selectedSize;

            this.options.productPayButton.addItem(url, pid)
            .then((data) => {
                this.resetSelectedSize();

                this.options.productPayButton.refreshCart(data.cart.items, data.cart.totals.subTotal, data.cart.actionUrls.updateQuantityUrl, data.cart.actionUrls.removeProductLineItemUrl);

                this.options.productBuyButton.animateProductTileToCart(data.quantityTotal);

            })
            .catch((data) => {
                console.log(data);
                this.options.toast
                .setOptions({
                    buttonOk: true,
                    buttonMsg: "Ok",
                    msgText: "Sorry! Something went wrong",
                    type: "error",
                }).openToast();
            })

        })

    }

    listenShowMoreSizesButton() {
        this.$('body').on(this.tapEvent, this.options.sizesShowMore, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.$(ev.target)
                .closest(this.options.gridCell)
                .addClass(this.options.sizesOpenedClassName);
        });

        return this;
    }

    listenSizesClose(){
        this.$('body').on(this.tapEvent, this.options.sizesCloseButton, (ev) => {
            this.$(ev.target)
                .closest(this.options.gridCell)
                .removeClass(this.options.sizesOpenedClassName);
        });

        return this;
    }

    listenShowMoreColorsButton() {
        this.$('body')
        .on(this.tapEvent, this.options.colorsShowMore, (e) => {
            let target = this.$(e.target);
            let product = target.closest('.product');
            product.addClass("colors-open");
        })
    }

    listenCloseMoreColorsButton() {
        this.$('body')
        .on(this.tapEvent, this.options.colorsShowMoreClose, (e) => {
            let target = this.$(e.target);
            let product = target.closest(this.options.product);
            product.removeClass("colors-open");
        })
    }

    hiddenSizesBackground() {
        let colors;
        let hiddenSizes;

        this.$(this.options.gridCell).each((i, element) => {
            colors = this.findColorMatrix(this.$(element));

            hiddenSizes = this.$(element).find('.size__attribute .hidden__swatches');

            this.$(hiddenSizes).css('background', colors.background);
        });

        return this;
    }

    init() {
        this.destroy().listen();

        return this;
    }

    listen() {

        if (!isMobile()) {

            this.listenProductHover();

            this.listenShowMoreSizesButton();
            this.listenSizesClose();

            this.listenShowMoreColorsButton();
            this.listenCloseMoreColorsButton();

            this.listenColorSwatch();

            this.listenSizeClick();
            this.listenSizeHover();

            this.listenBuyClick();

            this.listenWishListChange();

            this.setProducttileScenes();

            this.hiddenSizesBackground();
        }

        this.buildIsotopeLayout();

        return this;

    }

    destroy() {

        this.$('body')
        .off(this.tapEvent, this.options.productTileWishlistBtn)
        .off(this.tapEvent, this.options.colorSwatch)
        .off(this.tapEvent, this.options.sizesItem)
        .off(this.tapEvent, this.options.productTileBuyButton)
        .off(this.tapEvent, this.options.sizesShowMore)
        .off(this.tapEvent, this.options.colorsShowMore)
        .off(this.tapEvent, this.options.colorsShowMoreClose)
        .off(this.tapEvent, this.options.sizesCloseButton);

        return this;

    }
}
