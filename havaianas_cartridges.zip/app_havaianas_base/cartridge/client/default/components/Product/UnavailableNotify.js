import isMobile from '../../utils/isMobile';
import Drawer from '../Drawer/Drawer';

export default class UnavailableNotify {
    constructor(options) {

        const defaultOptions = {

            selectorEngine: {},

            notifyUnavailableContainer: '.notify__unavailable--container',
            notifyFormContainer: '.notify__unavailable',
            notifyForm: '#notify-form',
            notifyShowLink: '.size__unavailable, .product__unavailable',
            notifyEmailLabel: '.notify__label',
            notifyEmailInput: '.notify__email',
            notifyDrawer: '.drawer__choose-size',
            notifyCancel: '.notify__cancel',
            notifyClose: '.notify__close',
            notifySentContainer: '.notify-sent',
            notifySubmit: '.notify__submit',
            productAvailable: '.product__unavailable',

            drawerSizeTitle: '.drawer__choose-size__title'
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";
        this.emailRegex = /^[a-z0-9._-]+@[a-z]+(\.[a-z]{1,4}){1,2}$/;
        this.drawer = new Drawer({selectorEngine: this.$});
        this.oldDrawerData;
        this.notifyUrl = ``;
    }

    setUrl(url = ""){
        this.notifyUrl = url;
    }

    loadForm(){
        return this.$.get(this.notifyUrl, {
            ajax: true
        });
    }

    showForm(){
        this.$(this.options.notifyUnavailableContainer)
        .addClass("is-open")
    }

    hideForm(){
        this.$(this.options.notifyUnavailableContainer)
        .removeClass("is-open")
    }


    destroyForm(){
        this.$(this.options.notifyFormContainer).remove();
        this.$(this.options.drawerSizeTitle).show();

        this.hideForm();
    }

    showDrawer() {
        this.$(this.options.notifyDrawer).addClass('drawer--isOpen drawer--isVisible');
    }

    hideDrawer() {
        this.$(this.options.notifyDrawer).removeClass('drawer--isOpen drawer--isVisible');
    }

    destroyDrawer(){
        this.$(this.options.notifyDrawer).html(this.oldDrawerData);
    }

    loadMobileForm(data){
        this.oldDrawerData = this.$(this.options.notifyDrawer).html();
        this.$(this.options.notifyDrawer).prepend(data);
        this.listenNotifyFormClose();
    }

    loadDesktopForm(data) {
        this.$(data).appendTo(this.options.notifyUnavailableContainer);
        this.showForm();
    }

    showSuccessMobileMessage(){
        this.$(this.options.notifySentContainer).removeClass("hidden");
        this.$(this.options.notifyForm).addClass("hidden");
    }

    listenNotifyFormShow(){

        this.$('body').off(this.tapEvent, this.options.notifyShowLink)
                      .on(this.tapEvent, this.options.notifyShowLink, (ev) => {

            let url = this.$(ev.currentTarget).data().url;

            this.setUrl(url);
            this.loadForm().then((data) => {

                if (isMobile()) {
                    this.loadMobileForm(data);
                    this.showDrawer();
                } else {
                    this.loadDesktopForm(data)
                    this.showForm();
                }

                this.listenInputFocus();
                this.listenEmailInput();
                this.listenFormSubmit();

                this.$(document).trigger('product:notify:ready');
            });
        });

    }

    listenNotifyFormClose(){
        this.$("body")
        .on(this.tapEvent, this.options.notifyCancel, () => {
            this.destroyDrawer();

            if (isMobile()) {
                this.hideDrawer();
            }
        })
        .on(this.tapEvent, this.options.notifyClose, () => {
            this.destroyDrawer();
            this.hideDrawer();
        })
    }

    validateNotifyEmail(email) {
        if (this.emailRegex.test(email)) {
            this.$(this.options.notifySubmit).show();
        } else {
            this.$(this.options.notifySubmit).hide();
        }
    }

    listenEmailInput(){
        this.$("body")
        .on("keyup", this.options.notifyEmailInput, (e) => {
            this.validateNotifyEmail(e.target.value);
        })
        .on("input", this.options.notifyEmailInput, (e) => {
            this.validateNotifyEmail(e.target.value);
        });

        if (this.emailRegex.test(this.$(this.options.notifyEmailInput).val())) {
            this.$(this.options.notifySubmit).show();
        }
    }

    listenInputFocus(){
        this.$("body")
        .on("focus", this.options.notifyEmailInput, () => {
            this.$(this.options.notifyEmailLabel).addClass("focus")
        })
        .on('blur', this.options.notifyEmailInput, (ev) => {
            if (!ev.target.value) {
                this.$(this.options.notifyEmailLabel).removeClass("focus")
            }
        })
        this.$(this.options.notifyEmailInput).focus()
    }

    listenFormSubmit(){
        // this.$("form[name=simpleSearch]").off();

        this.$("#notify-form").on('submit', (e) => {

            e.preventDefault();
            e.stopPropagation();

            this.$.ajax({
                method: 'post',
                url: e.target.action,
                data: this.$(e.target).serialize()
            })
            .done((data) => {

                if (!data.success) {

                    this.options.toast
                        .setOptions({
                            buttonOk: true,
                            buttonMsg: "Ok",
                            msgText: data.errorMsg,
                            type: "error",
                        }).openToast();


                    return;
                }

                if (isMobile()) {
                    this.showSuccessMobileMessage();
                } else {

                    this.options.toast
                        .setOptions({
                            buttonOk: true,
                            buttonMsg: "Ok",
                            msgText: `${this.$(".notify-sent p").html()}`,
                            type: "default",
                        }).openToast();
                        this.destroyForm();
                        this.$(".drawer-overlay").trigger("click");
                }


                this.$(this.options.productAvailable).addClass("notified");

            })
            .fail((data) => {
                this.options.toast
                    .setOptions({
                        buttonOk: true,
                        buttonMsg: "Ok",
                        msgText: "Server error",
                        type: "error",
                    }).openToast();
            });

        })
    }

    init(){}

    listen(){
        this.listenNotifyFormShow();
    }
}
