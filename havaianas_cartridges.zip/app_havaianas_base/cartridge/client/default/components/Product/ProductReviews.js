import isMobile from '../../utils/isMobile';

export default class ProductReviews {
    constructor(options) {

        const defaultOptions = {

            loadMoreReviews: '.rate-summary__load-more',
            reviewers: '.rate-summary__reviewers',
            reviewer: 'rate-summary__reviewer',
            moreReviewers: '.rate-summary__reviewers-more',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.allVariationColors = [];

        this.tapEvent = isMobile() ? "tap" : "click";
        this.isListening = false;
        this.reviewsCount = 5;
    }

    loadMoreReviews() {
        this.$('body').on(this.tapEvent, this.options.loadMoreReviews, () => {
            const childrens = this.$(this.options.moreReviewers).children().slice(0,this.reviewsCount);

            for(let i = 0; i < childrens.length; i++) {
                this.$(this.options.reviewers).append(childrens[i].outerHTML);
            }

            childrens.remove();

            if(!this.$(this.options.moreReviewers).children().length) {
                this.$(this.options.loadMoreReviews).remove();
            }
        });
    }

    listen() {
        if(this.isListening) return;
        this.isListening = true;

        this.loadMoreReviews();
    }
}
