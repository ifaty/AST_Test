export default class AccountUserCards {
    constructor(options) {

        const defaultOptions = {
            page: '.page-paymentMethods',
            paymentForm: '.payment-form',
            btnSavePayment:'.btnSavePayment',
            paymentList: '.payments__list',

            deletePaymentBtn: '.payment__edit-actions__delete',
            deleteContainer: '.payment__delete__container',
            deleteConfirmation: '.payment__delete-actions__delete',
            deleteDismiss: '.payment__delete-actions__dismiss',
            paymentForm: '#paymentForm',
            adyentInput: '.checkout__cc-input__adyen',
            adyentInputLabel: '.checkout__cc-label',
            cardOwnerInput: '.cardOwner_adyenForm',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";
    }

    submitAddPayment() {
        const formSerialized =  this.$(this.options.paymentForm).serialize();

        this.$.ajax({
            type: 'POST',
            dataType: 'json',
            url: this.$(this.options.paymentForm).attr('action'),
            data: formSerialized
        }).done((data) => {
            if(data.success) {
                this.$.ajax({
                    data: { ajax: true },
                    type: 'GET',
                    url: data.redirectUrl,
                }).done((data) => {
                    const paymentList = this.$(data).find(this.options.paymentList).html()
                    this.updateSavedPayments(paymentList);
                    this.$(document).trigger('app:contextLoader:finish');

                    // reset form
                    customCardMethods.unmount('.customCard-container');
                    this.$(this.options.paymentForm)
                        .find(this.options.cardOwnerInput)
                        .val('').attr('value', '')
                        .next().removeClass('active');
                    this.$(this.options.paymentForm).find(this.options.adyentInput).removeClass('is-focus validated');
                    this.$(this.options.paymentForm).find(this.options.adyentInputLabel).removeClass('active');

                    // mount form again
                    if(typeof(adyenAccount) == 'function') { adyenAccount(); }
                });
            } else { 
                this.$(document).trigger('app:contextLoader:finish');
                if(data.error.message) {
                    this.options.toast.setOptions({
                        msgText: data.error.message,
                        buttonOk: true,
                        buttonMsg: "Ok",
                        type: "error"
                    }).openToast();
                }
            }
        }).fail((error) => {
            console.log('error');
            this.$(document).trigger('app:contextLoader:finish');
        });
    }

    deletePaymenMethod(url) {
        this.$.ajax({
            type: 'GET',
            dataType: 'json',
            url,
            data: {}
        }).done((data) => {
            if(data.redirectUrl) {
                this.$.ajax({
                    data: { ajax: true },
                    type: 'GET',
                    url: data.redirectUrl,
                }).done((data) => {
                    const paymentList = this.$(data).find(this.options.paymentList).html()
                    this.updateSavedPayments(paymentList);
                    this.$(document).trigger('app:contextLoader:finish');
                });
            }
        }).fail((error) => {
            this.$(document).trigger('app:contextLoader:finish');
            if(error.message) {
                this.options.toast.setOptions({
                    msgText: error.message,
                    buttonOk: true,
                    buttonMsg: "Ok",
                    type: "error"
                }).openToast();
            }
        });
    };

    updateSavedPayments(paymentList) {
        this.$(this.options.paymentList).html(paymentList);
    }

    listen() {
        // update style if adyen set before page exists
        if(typeof(AdyenCheckout) != 'undefined' && typeof(customCardMethods) != 'undefined') {
            const pageTextColor = this.$(this.options.page).css('color');
            const pageFontSize = $(this.options.page).find('input').css('font-size');

            customCardMethods.updateStyles({
                base: {
                    color: pageTextColor,
                    fontSize: pageFontSize,
                },
                error: {
                    color: pageTextColor,
                },
                validated: {
                    color: pageTextColor,
                }
            });
        }

        this.$('body').off(this.tapEvent, this.options.deletePaymentBtn)
                      .on(this.tapEvent, this.options.deletePaymentBtn, (ev) => {
            ev.preventDefault();

            this.$(ev.target).siblings(this.options.deleteContainer).addClass('active');

            setTimeout(() => this.$(ev.target).siblings(this.options.deleteContainer).removeClass('active'), 5000);
        });

        this.$('body').off(this.tapEvent, this.options.deleteDismiss)
                      .on(this.tapEvent, this.options.deleteDismiss, (ev) => {
            ev.preventDefault();

            this.$(ev.target).parents(this.options.deleteContainer).removeClass('active');
        });

        this.$('body').off(this.tapEvent, this.options.deleteConfirmation)
                      .on(this.tapEvent, this.options.deleteConfirmation, (ev) => {
            ev.preventDefault();

            const url = this.$(ev.currentTarget).data('action');
            this.$(document).trigger('app:contextLoader:init', [{ target: this.$(ev.currentTarget) }]);

            this.deletePaymenMethod(url);
        });

        this.$(this.options.paymentForm).off('submit').on('submit', (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.$(document).trigger('app:contextLoader:init', [{ target: this.$(this.options.btnSavePayment) }]);
            this.submitAddPayment();
        });
    }
}
