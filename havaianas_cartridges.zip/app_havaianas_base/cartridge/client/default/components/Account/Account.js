import isMobile from '../../utils/isMobile';
import debounce from '../../utils/debounce';

export default class Account {
    constructor(options) {

        const defaultOptions = {
            passwordChangeContainer: '.change-password',
            passwordChangeLink: '.edit-link',
            passwordResetSubmitBtn: '#submitEmailButton',
            passwordResetForm: '.reset-password-form',
            passwordResetFormBody: '.request-password-body',
            passwordResetDoneButton: '.account__button__password-reset-done',
            passwordResetFeedbackMsg: '.account__forgot-password-feedback',
            passwordResetBottomMsg: '.account__bottom-msg',
            passwordResetTitle: '.account__left-col > h1',
            passwordCurrent: '#currentPassword',

            passwordCreateAccount:'#registration-form-password',
            passwordConfirmCreateAccount:'#registration-form-password-confirm',
            invalidFeedback: '.invalid-feedback',

            accountPictureContainer: '.account__photo-edit__container',
            accountPictureInput: '.account__photo-edit__input',
            accountPictureImage: '.account__photo-edit__image',
            accountPictureForm: '#uploadProfilePicture',

            accountDate: '#dateofbirth',

            loginSubmitBtn: '#account__login-button',
            loginForm: '.account__login-form',
            accountCreate: '.account__account-create-form',
            accountCreateSubmitBtn: '.account__register-submit',

            accountInput: '.account__input',
            accountFloatingLabel: '.account__floating-label',

            accountEditProfileForm: '.edit-profile-form',
            accountEditProfileBtn: '.edit-profile-submit',

            accountActions: '.account__actions',

            registrationFormEmail: 'registration-form-email',
            registrationFormEmailConfirmation: 'registration-form-email-confirm',

            resetPasswordBtn: '#submitPasswordButton',
            resetPasswordForm: '.password-reset__form',

            formInputs: '.form-control',

            itemAccount: '.menu__item-account',

            drawerMenu: '.drawer__menu',
            drawerUsername: '.drawer__innerUsername',
            drawerImage: '.drawer__innerImage',
            drawerLink: '.drawer__open-link',

            currentStorySection: '.story__section.is-current',
            colorMatrix: '.color-matrix',

            invalidFeedback: '.invalid-feedback',

            selectorEngine: {},
            toast: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.reloadCounter = 0;

        this.tapEvent = "click";

        this.colorMatrixData;

        this.validate();
    }

    submitPasswordReset() {
        this.$.ajax({
            type: 'post',
            dataType: 'json',
            url: this.$(this.options.passwordResetForm).attr('action'),
            data: this.$(this.options.passwordResetForm).serialize(),

            success: (data) => {

                if (data.success) {
                    this.$(this.options.passwordResetTitle).text(data.receivedMsgHeading);

                    this.$(this.options.passwordResetFormBody).fadeOut();
                    this.$(this.options.passwordResetFeedbackMsg).fadeIn();

                    this.$(this.options.passwordResetSubmitBtn).fadeOut();
                    this.$(this.options.passwordResetDoneButton).fadeIn();

                    this.$(this.options.passwordResetBottomMsg).fadeOut();
                } else {
                    this.options.validator.validateForm(this.$(this.options.resetPasswordForm), true, data.fields);

                    let errors = Object.values(data.fields);
                    if (errors.length) {
                        this.options.toast
                            .setOptions({
                                type: 'error',
                                msgText: errors[0]
                            })
                            .openToast();
                    }
                }
            },

            error: () => {
                this.options.toast
                    .setOptions({
                        msgText: "Sorry! something went wrong."
                    })
                    .openToast();
            }
        });
    }

    validate() {
        this.options.validator
                    .setOptions({
                        submitButton: "body form button[type='submit']"
                    })
                    .listenSubmitButton();

        return this;
    }

    submitPictureForm() {
        var pictureForm = this.$(this.options.accountPictureForm)[0];
        var formData = new FormData(pictureForm);
        this.$.ajax({
            type: 'POST',
            url: this.$(this.options.accountPictureForm).attr('action'),
            data: formData,
            cache:false,
            contentType: false,
            processData: false,

            success: (data) => {
                if (data.success) {
                    this.$(this.options.accountPictureImage).attr('src', data.uploadedPictureUrl);
                    this.$(this.options.drawerImage).attr('src', data.uploadedPictureUrl);

                    this.options.toast
                        .setOptions({
                            msgText: data.successMsg,
                            type: "default"
                        })
                        .openToast();
                } else {
                    // TODO: include toast
                    this.options.toast
                        .setOptions({
                            msgText: data.errorMsg
                        })
                        .openToast();
                }
            },

            error: () => {
                this.options.toast
                    .setOptions({
                        msgText: "Sorry! something went wrong."
                    })
                    .openToast();
            }
        });

        return this;
    }

    uploadAccountPicture() {
       this.$(this.options.accountPictureInput).click();

       return this;
    }

    updateDrawerOnLogin(data) {
        return new Promise((resolve, reject) => {

            this.$(this.options.itemAccount).addClass('is-logged');
            this.$(this.options.drawerLink).addClass('redirect');
            this.$(this.options.drawerUsername).text(data.authenticatedCustomer.lastName);
            if (data.authenticatedCustomer.profilePictureURL) {
                this.$(this.options.drawerImage).attr("src", data.authenticatedCustomer.profilePictureURL);
            }

            resolve();
        })
    }

    submitLoginForm() {
        this.$(document).trigger('app:contextLoader:init', [{
            target: this.$(this.options.loginSubmitBtn).find('span')
        }]);

        if (this.$(this.options.currentStorySection).length > 0) {
            var colorMatrix = this.$(this.options.currentStorySection).find(this.options.colorMatrix).data('colormatrix');
        } else {
            var colorMatrix = this.$(this.options.colorMatrix).data('colormatrix');
        }
        const backgroundColor = colorMatrix.ui;

        this.$.ajax({
            type: 'post',
            dataType: 'json',
            url: this.$(this.options.loginForm).attr('action'),
            data: this.$(this.options.loginForm).serialize(),

            success: (data) => {

                this.$(document).trigger("app:gtm:loginStatus", {user: data.authenticatedCustomer});

                if (data.success) {

                    this.$(document).trigger('app:user:login', [{
                        components: data.components,
                        urls: data.urls
                    }]);

                } else {

                    let functionDefault = () => { console.log('Example Function closeDefault')}
                    let functionUser = () => { console.log('Example Function closeUser')}

                    // TODO: Include toast
                    this.options.toast
                        .setOptions({
                            buttonOk: true,
                            msgText: data.error,
                            positionX: "right",
                            positionY:"bottom",
                            type: "default",
                            closeDefault: functionDefault,
                            closeUser: functionUser
                        })
                        .setBackgroundColor(backgroundColor)
                        .openToast();
                }
            },

            error: () => {
                // TODO: Include toast
                this.options.toast
                    .setOptions({
                        msgText: "Sorry! something went wrong."
                    })
                    .openToast();
            }
        });
    }

    submitAccountCreateForm() {
        this.$.ajax({
            type: 'post',
            dataType: 'json',
            url: this.$(this.options.accountCreate).attr('action'),
            data: this.$(this.options.accountCreate).serialize(),

            success: (data) => {

                this.$(document).trigger("app:gtm:loginStatus", {user: data.authenticatedCustomer});

                if (data.success) {

                    // update components
                    this.$(document).trigger('app:user:login', [{
                        components: data.components,
                        urls: data.urls
                    }]);

                    this.$(document).trigger('app:frame:loadPage', [{
                        link: data.redirectUrl
                    }]);

                } else {
                    this.options.validator.validateForm(this.$(this.options.accountCreate), true, data.fields);
                }
            },

            error: () => {
                // TODO: Include toast
                this.options.toast
                    .setOptions({
                        msgText: "Sorry! something went wrong."
                    })
                    .openToast();
            }
        });
    }

    submitEditProfileForm() {
        this.$(this.options.loginForm).find(this.options.invalidFeedback).html('');

        this.$.ajax({
            type: 'post',
            dataType: 'json',
            url: this.$(this.options.accountEditProfileForm).attr('action'),
            data: this.$(this.options.accountEditProfileForm).serialize(),

            success: (data) => {
                if (data.success) {

                    this.options.toast
                    .setOptions({
                        msgText: data.successMessage,
                        type: "default"
                    })
                    .openToast();

                    this.options.frame.closeModal()

                } else {
                    this.options.validator.validateForm(this.$(this.options.accountEditProfileForm), true, data.fields);
                    if (data.errorMsg) {
                        this.options.toast
                            .setOptions({
                                msgText: data.errorMsg
                            })
                            .openToast();
                    }
                }
            },

            error: (data) => {
                // TODO: Include toast
                this.options.toast
                    .setOptions({
                        msgText: "Sorry! something went wrong."
                    })
                    .openToast();
            }
        });
    }

    accountEditListen() {
        this.$(this.options.accountPictureContainer).on(this.tapEvent, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.uploadAccountPicture();
        });

        this.$(this.options.accountPictureInput).on('change', (ev) => {
            ev.preventDefault();

            this.submitPictureForm();
        });


        this.$(this.options.accountEditProfileBtn).on(this.tapEvent, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.submitEditProfileForm();
        });

        // If the form contains errors it takes the user to the error
        this.$(this.options.accountEditProfileForm).on('invalid-form', () => {
            this.$(this.options.accountEditProfileForm).closest('.container').animate({
                scrollTop: this.$(this.options.accountEditProfileForm).find('.is-invalid').first().offset().top
            }, 'slow');
        });
        this.initFormBtn(this.options.accountEditProfileForm, this.options.accountEditProfileBtn);
        // Every time an input change does form validation to activate the button
        this.activeSubmitButton(this.options.accountEditProfileForm, this.options.accountEditProfileBtn);
    }

    accountCreateListen() {
        // Client Side Validation - User starts to type something inside the password
        var errors = this.options.invalidFeedback;
        var passwordInput = this.options.passwordCreateAccount;

        this.$(this.options.passwordCreateAccount).on('blur', function(e) {

            var error = $(e.currentTarget).data("error");
            var lowerCaseLetters = /[a-z]/g;
            var upperCaseLetters = /[A-Z]/g;
            var numbers = /[0-9]/g;

            if (this.value.match(lowerCaseLetters) && this.value.match(upperCaseLetters) && this.value.match(numbers) && this.value.length >= 8) {
                $(this).siblings(errors).html("");
            } else {
                $(this).siblings(errors).html(`<i class="icon-alert"></i> <span>${error}</span>`);
            }
            return false;

        });

        this.$(this.options.passwordConfirmCreateAccount).on('blur', function(e) {
            var error = $(e.currentTarget).data("error");
            if (this.value == $(passwordInput).val()) {
                $(this).siblings(errors).html("");
            } else {
                $(this).siblings(errors).html(`<i class="icon-alert"></i> <span>${error}</span>`);
            }
            return false;

        });
        // END Client Side Validation


        this.$(this.options.registrationFormEmail).on('keyup', function() {
            $(this).siblings(errors).html("");
        });

        this.$(this.options.registrationFormEmailConfirmation).on('keyup', function() {
            $(this).siblings(errors).html("");
        });

        this.$(this.options.passwordCreateAccount).on('keyup', function() {
            $(this).siblings(errors).html("");
        });
        this.$(this.options.passwordConfirmCreateAccount).on('keyup', function() {
            $(this).siblings(errors).html("");
        });


        let accountCreateDebounced = debounce(() => {
            this.submitAccountCreateForm();
        }, 800, true);

        this.$(this.options.accountCreate).off('submit').on('submit', (ev) => {
            ev.preventDefault();

            accountCreateDebounced();
        });

        // If the form contains errors it takes the user to the error
        this.$(this.options.accountCreate).on('invalid-form', () => {
            this.$(this.options.accountCreate).closest('.container').animate({
                scrollTop: this.$(this.options.accountCreate).find('.is-invalid').first().offset().top
            }, 'slow');
        });
        this.initFormBtn(this.options.accountCreate, this.options.accountCreateSubmitBtn);
        // Every time an input change does form validation to activate the button
        this.activeSubmitButton(this.options.accountCreate, this.options.accountCreateSubmitBtn);
    }

    passwordResetListen() {
        let passwordResetDebounce = debounce(() => {
            this.submitPasswordReset();
        }, 300, true);

        this.$(this.options.passwordResetForm).on('submit', (ev) => {
            ev.preventDefault();

            passwordResetDebounce();
        });
        this.initFormBtn(this.options.passwordResetForm, this.options.passwordResetSubmitBtn);
        // Every time an input change does form validation to activate the button
        this.activeSubmitButton(this.options.passwordResetForm, this.options.passwordResetSubmitBtn);
    }

    loginListen() {

        let accountLoginDebounced = debounce(() => {
            this.submitLoginForm();
        }, 800, true);

        this.$(this.options.loginForm).on('submit', (ev) => {
            ev.preventDefault();

            accountLoginDebounced();
        });

        this.initFormBtn(this.options.loginForm, this.options.loginSubmitBtn);
        // Every time an input change does form validation to activate the button
        this.activeSubmitButton(this.options.loginForm, this.options.loginSubmitBtn);
    }

    activeSubmitButton(form, button) {
        this.$(form).find(this.options.formInputs).on('keyup change', () => {
            if(this.options.validator.validateForm(this.$(form))) {
                this.$(button).addClass('active').removeAttr("disabled");;
            } else {
                this.$(button).removeClass('active').attr( "disabled", "disabled" );
            }
        });
    }

    initFormBtn(form, button) {
        if(this.options.validator.validateForm(this.$(form))) {
            this.$(button).addClass('active').removeAttr("disabled");
        } else {
            this.$(button).removeClass('active').attr( "disabled", "disabled" );
        }
    }

    listenResetPassword() {
        this.$('body').addClass('page-setNewPassword');
    }

    resetPasswordListen() {
        this.$(this.options.resetPasswordBtn).on(this.tapEvent, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            var resetForm = this.$(this.options.resetPasswordForm)[0];
            var formData = new FormData(resetForm);
            this.$.ajax({
                type: 'POST',
                url: this.$(this.options.resetPasswordForm).attr('action'),
                data: formData,
                cache:false,
                contentType: false,
                processData: false,
                dataType: 'json',

                success: (data) => {
                    if (data.success) {

                        // update components
                        this.$(document).trigger('app:user:login', [{
                            components: data.components,
                            urls: data.urls
                        }]);

                        // send user to home then open searchMenu
                        this.$(document).trigger('app:frame:loadPage', [{ link: window.app.urls.home }]);
                        this.$(document).one("app:frame:ready", () => {
                            this.$(document).trigger("app:searchmenu:open");
                        });

                    } else {
                        // TODO: include toast
                        this.options.toast
                        .setOptions({
                            msgText: JSON.stringify(data.error)
                        })
                        .openToast();
                    }
                },

                error: () => {
                    this.options.toast
                        .setOptions({
                            msgText: "Sorry! something went wrong."
                        })
                        .openToast();
                }
            });
        });
    }

    checkFloatingLabel(input) {
        if (this.$(input).val() && this.$(input).val().length >= 1) {
            this.$(input).attr('value', this.$(input).val()).siblings(this.options.accountFloatingLabel).removeClass('empty').addClass('active');
        } else {
            if(this.$(input).hasClass('validated')) return;
            this.$(input).attr('value', this.$(input).val()).siblings(this.options.accountFloatingLabel).removeClass('active').addClass('empty');
        }
    }

    listenChangePasswordButton(){
        this.$(this.options.passwordChangeLink).on("click, tap", () => {
            this.$(this.options.passwordChangeContainer).toggleClass("visible");

            if (this.$(this.options.passwordChangeContainer).hasClass('visible')) {
                this.$(this.options.passwordChangeLink).html(this.$(this.options.passwordChangeLink).attr("data-canceltext"));
                this.$(this.options.passwordCurrent).focus();
            } else {
                this.$(this.options.passwordChangeLink).html(this.$(this.options.passwordChangeLink).attr("data-edittext"));
            }
        });
    }

    setColorsAccount() {

        if (this.$(this.options.currentStorySection).length > 0) {
            var colorMatrix = this.$(this.options.currentStorySection).find(this.options.colorMatrix).data('colormatrix');
        } else {
            var colorMatrix = this.$(this.options.colorMatrix).data('colormatrix');
        }
            const backgroundColor = colorMatrix.background;

    }

    listen() {
        this.listenChangePasswordButton();

        this.resetPasswordListen();

        this.$(this.options.accountInput).each((i, element) => {
            this.checkFloatingLabel(element);
        });

        this.$('body').on('keypress click blur input', this.options.accountInput, (ev) => {
            this.checkFloatingLabel(ev.target);
        });

        //this.setColorsAccount();
    }

}
