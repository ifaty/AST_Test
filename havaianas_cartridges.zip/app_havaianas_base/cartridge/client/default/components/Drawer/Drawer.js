import isMobile from '../../utils/isMobile';

export default class Drawer {
    constructor(options) {

        const defaultOptions = {
            drawer: ".drawer__menu",
            drawerAccount: ".drawer__account",
            drawerLink: ".drawer__open-link",
            openDrawer: ".open-drawer",
            drawerContent: '.drawer__content',
            drawerOverlay: '.drawer-overlay',

            isDrawerOpen: false,

            //Classes
            drawerOpen: 'drawer--isOpen',
            drawerVisible: 'drawer--isVisible',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";

        this.isLogged = this.$(".is-logged").length ? true : false;

        this.drawerTarget = '';
    }

    openDrawer() {
        if(!this.drawerTarget) return;

        this.$(this.options.drawer).find(`[data-content="${this.drawerTarget}"]`).show();
        this.$(this.options.drawer).addClass(this.options.drawerOpen)
        setTimeout(() => {
            this.$(this.options.drawer).addClass(this.options.drawerVisible)
        }, 200);
        this.$(document).trigger('app:drawer:ready');

        this.options.isDrawerOpen = true;
    }

    setTarget(target) {
        this.drawerTarget = target;

        return this;
    }

    closeDrawer() {
        this.$(this.options.drawer).removeClass(this.options.drawerVisible);

        // wait 200 miliseconds before removing the class that makes the element disappear
        setTimeout(() => {
            this.$(this.options.drawer).removeClass(this.options.drawerOpen);
        }, 200);

        this.$(this.options.drawer).find(this.options.drawerContent).hide();

        this.options.isDrawerOpen = false;
    }

    listen() {
        this.$(document).on('app:drawer:close', () => this.closeDrawer());

        if (isMobile()) {
            this.$('.menu').off(this.tapEvent).on(this.tapEvent, (ev) => {
                if (this.$(this.options.drawerLink).is(ev.target) && this.$(ev.target).hasClass('redirect')) {
                    ev.preventDefault();

                    const drawerTarget = this.$(ev.target).data('drawer');

                    if(drawerTarget) {
                        this.setTarget(drawerTarget);
                        this.openDrawer();
                    }
                }

                if (this.options.isDrawerOpen && this.$(this.options.drawerOverlay).is(ev.target)) {
                    this.closeDrawer();
                }

                // if click in link close drawer
                if (this.options.isDrawerOpen && this.$(ev.target).hasClass('menu__link') && !this.$(ev.target).hasClass('redirect') && !this.$(ev.target).hasClass('menu__link--toggleSubmenu')) {
                    this.closeDrawer();
                }

                if(this.options.isDrawerOpen && this.$(ev.target).hasClass('menu__link--toggleSubmenu')) {
                    this.$(document).trigger('app:submenu:toggle');
                }
            });
        }
    }

}
