import isMobile from '../../utils/isMobile';
import searchInArray from '../../utils/arraySearch';
import ASYNC from '../../utils/async';

export default class Frame extends ASYNC {
    constructor(options) {

        super(options);

        const defaultOptions = {
            selectorEngine: {},

            viewPort: '.pages-viewport',
            pageWrapper: '.container[class*="page-"]',
            fxContainer: 'fx-container',
            modalsViewport: 'modals-viewport',
            searchMenuViewPort: 'search-menu',
            modalContainer: 'modal-page-container',
            closeModal: '.js-close-modal',

            baseUrl: null,
            filterUrl: window.location.pathname,
            defaultLink: 'on/demandware.store/Sites-Havaianas-BR-Site/default/Home-Show',

            modalBackLink: '.modal__back-link',

            onIframe: false,

            maxAppendedPages: 3,
            maxAgePage: 1, // in minutes
            target: ''
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.documentTitle = null;
        this.url = null;

        this.target = null;
        this.lastPageName = null;
        this.twoNDlastPageName = null;
        this.hash = window.location.hash;
        this.pathname = window.location.pathname;
        this.href = window.location.href;
        this.search = window.location.search;
        this.tapEvent = "click";
        this.pageName = null;
        this.pageTitle = null;
        this.isRainbowFilter = false;
        this.isModal = false;
        this.isSearchMenuContext = false;
        this.isDesktopFilter = false;
        this.previousLink = null;
        this.visitedLinks = [];
        this.jqxhr;

        this.linkPatternExclude = /\.(png|jpg|gif|PNG|JPG|GIF|jpeg|JPEG|zip|rar|exe)/;

        this.setFallbackTargetClick();
    }

    getPopStateContext(referenceLink) {

        if (!referenceLink) return {};

        return searchInArray(referenceLink, this.visitedLinks, 'link') || {};

    }

    dealWithPopStateContext(referenceLink) {
        let contextObj = this.getPopStateContext(referenceLink);

        return this.setIsModal(contextObj.context == 'modal' || false);

    }

    dealWithViewports() {
        if (this.$('.search-menu .menu__context-pages div[class*="page-"]').length) {
            let viewportPage = this.$('.search-menu .menu__context-pages div[class*="page-"]')[0];
            this.showViewportInSearchMenu(viewportPage);
            this.setIsSearchMenu(true);
            this.setIsModal(false);
            this.$(document).trigger("app:discovery:init");
        } else if (this.$('.modals-viewport .modal-page-container').length) {
            let viewportPage = this.$('.modals-viewport .modal-page-container')[0];
            this.showViewportAsModal(viewportPage);
            this.setIsSearchMenu(false);
            this.setIsModal(true);
            this.$(document).trigger("app:discovery:init");
        }

        return this;
    }

    showViewportAsModal(page) {
        this.$('body').addClass('modal-open');

        this.$(page).addClass('in-frame');
        this.$(page).addClass('is-current');

        this.$(page).find('.container').css('opacity', 1);
        this.$(page).find('.modal__back-link')
            .removeClass('modal__back-link')
            .addClass('js-close-modal');

        let incomingData = {
            pageName: this.$(page).data('pagename'),
            pageTitle: this.$(page).find('.container').data('pagetitle'),
            isModal: true,
        };
        this.$(document).trigger("app:frame:changed", [incomingData]);
    }

    showViewportInSearchMenu(page) {
        if (!this.$('body').hasClass('menusca-open')) this.$(document).trigger('app:searchmenu:open');

        this.$('.menu__context-items').hide();
        this.$('.menu__context-pages').show();

        let incomingData = {
            pageName: this.$(page).data('pagename'),
            pageTitle: this.$(page).data('pagetitle'),
            isSearchMenuContext: true,
        };
        this.$(document).trigger("app:frame:changed", [incomingData]);
    }

    setFallbackTargetClick(fakeTarget = 'body') {

        this.targetClick = {
            mouseEvents: {
                pageX: this.$(fakeTarget).outerWidth() / 2,
                pageY: this.$(fakeTarget).outerHeight() / 2
            },
            currentTarget: this.$(fakeTarget).get(0),
            target: this.$(fakeTarget).get(0)
        };

        return this;
    }

    setTargetClick(targetClick) {
        if (targetClick) this.targetClick = targetClick;

        return this;
    }

    buildFiltersParams(listColors) {
        let colorMap = window.app.resources.rainbow;

        let urlCurrentParams = $("#clearall-url").data("url") || "";
        let prefNumber = this.$("#clearall-url").data("prefnumber") || "1";

        let queryStringColors = `&prefv${prefNumber}=${listColors.join('%7C')}`;
        let queryStringFilter = '';

        if (!listColors.length == 0) {
            if (urlCurrentParams.indexOf("?") >= 0) {
                queryStringFilter = `&prefn${prefNumber}=hav_colorset${queryStringColors}`;
            }
            else {
                queryStringFilter = `?prefn${prefNumber}=hav_colorset${queryStringColors}`;
            }
        }

        return queryStringFilter
    }

    getFrames() {

        let frames = {
            in: this.$(this.options.viewPort).find('.in-frame'),
            out: this.$(this.options.viewPort).find('.out-frame'),
            all: this.$(this.options.viewPort).find('.fx-container'),
            current: this.$(this.options.viewPort).find('.is-current'),

            inModal: this.$(`.${this.options.modalsViewport}`).find('.in-frame'),
            outModal: this.$(`.${this.options.modalsViewport}`).find('.out-frame'),
            allModal: this.$(`.${this.options.modalsViewport}`).find('.fx-container'),
            currentModal: this.$(`.${this.options.modalsViewport}`).find('.is-current'),

            inAgnostic: this.$(`${this.options.viewPort}, .${this.options.modalsViewport}`).find('.in-frame'),
            outAgnostic: this.$(`${this.options.viewPort}, .${this.options.modalsViewport}`).find('.out-frame'),
            allAgnostic: this.$(`${this.options.viewPort}, .${this.options.modalsViewport}`).find('.fx-container'),
            currentAgnostic: this.$(`${this.options.viewPort}, .${this.options.modalsViewport}`).find('.is-current')

        }

        return frames;
    }

    activeLastPage(pageName) {
        this.$(`${this.options.viewPort} [data-pagename*=${pageName}]`)
            .removeClass('out-frame')
            .addClass('is-current')
            .addClass('in-frame');
    }

    setVisitedLinks(link, context) {
        this.visitedLinks.push({link: link, context: context});
        return this;
    }

    getVisitedLink(param, value) {
        const visitedLinks = this.visitedLinks;
        const index = visitedLinks.slice().reverse().findIndex(x => x[param] === value);
        const count = visitedLinks.length - 1;
        const finalIndex = index >= 0 ? count - index : index;
        return visitedLinks[finalIndex] || {link: window.app.urls.home};
    }

    listen() {
        this.$(document).on("app:frame:changeHistory", (ev, data) => {
            if (!data || !data.url) throw new Error("The 'url' parameters are missing");

            this.setUrl(data.url);
            if (data.title) {
                this.setTitle(data.title);
            }

            this.newHistoryChange();
        });

        this.$(document).on('app:frame:setVisitedLinks', (ev, data) => {
            if(data && data.link && data.context) this.setVisitedLinks(data.link, data.context);
        });

        this.$(document).on('app:frame:loadPage', (ev, data) => {
            this.setPageContext(data.isModal ? "modal" : "main");
            this.setTargetClick(data.targetClick);
            this.setIsDesktopFilter(data.isDesktopFilter);
            if (data.link) {
                this.loadPage(data.link);
            }
        });

        this.$(document).on('app:frame:activeLastPage', (ev, data) => {
            if (data.pageName) this.activeLastPage(data.pageName)
        });

        this.$(document).on('app:frame:closeModal', (ev, data) => {
            let fallback;
            let onlyHistory = true;

            if(data && data.fallback) fallback = data.fallback;
            if(data && data.onlyHistory) onlyHistory = data.onlyHistory;

            this.closeModal(fallback, onlyHistory);
        });

        this.setInitialPageName()
            .addClassesToOrganicHTML();

        this.setInitialFilterUrl();

        this.requestListener();
        this.popStateListener();
        this.listenCloseModal();

        this.listenRainbowColors();

        this.$('body').off(this.tapEvent, this.options.closeModal)
            .on(this.tapEvent, this.options.closeModal, (ev) => {

                ev.preventDefault();
                ev.stopPropagation();

            this.closeModal();
        });

        this.$('body').off(this.tapEvent, this.options.modalBackLink)
                      .on(this.tapEvent, this.options.modalBackLink, (ev) => {

            ev.preventDefault();
            ev.stopPropagation();

            if(this.$('body').hasClass('menusca-open') || this.$('body').hasClass('is-checkout')) {
                this.closeModal();
            } else {
                history.back();
            }
        });

        this.setVisitedLinks(this.pathname, this.isModal ? 'modal' : (this.isSearchMenuContext ? 'searchMenu' : 'main'));
    }

    addClassesToOrganicHTML() {
        this.$(`.${this.options.fxContainer}`, this.options.viewPort)
            .attr('data-createdAt', Date.now() / 1000 | 0)
            .attr('data-pageName', this.pageName);

        return this;
    }

    setInitialPageName(pageName) {

        let name = pageName || this.$(`${this.options.pageWrapper}`, this.options.viewPort).eq(0).attr('data-pageName');

        this.pageName = name;
        this.lastPageName = name;

        return this;
    }

    setInitialFilterUrl() {
        this.options.filterUrl = this.$(`${this.options.pageWrapper}`).data('initialfilterurl');
    }

    checkIsOlder(time) {

        const now = Date.now() / 1000 | 0;
        const untilDate = parseInt(time, 10) + (this.options.maxAgePage * 100);

        return now >= untilDate;

    }

    removeOldAppendedPage(pageName) {

        let toRemove = this.$(`.fx-container[data-pagename='${pageName}']`);

        toRemove.remove();

        return this;
    }

    removeOldAppendedModals(pageName) {
        let toRemove = this.$(`.modals-viewport .fx-container[data-pagename='${pageName}']`);

        toRemove.remove();

        return this;
    }

    removeOlderAppendedPages() {
        if (this.$(`.${this.options.fxContainer}`, this.options.viewPort).length <= this.options.maxAppendedPages) return this;
        let frames = this.$(`.${this.options.fxContainer}`, this.options.viewPort);
        let toRemove = [];
        let toRemoveDOM = [];

        for (let index = 0; index < frames.length; index++) {
            const element = frames[index];

            toRemove.push({
                selector: `[data-pageName='${this.$(element).attr('data-pageName')}']`,
                timestamp: this.$(element).attr('data-createdAt')
            });
        }

        if (!toRemove.length) return this;

        toRemove.sort((x, y) => {
            return x.timestamp - y.timestamp;
        });

        toRemove.slice(0, this.options.maxAppendedPages - 1);

        for (let index = 0; index < toRemove.length; index++) {
            toRemoveDOM.push(toRemove[index].selector);
        }

        this.$(`.${this.options.fxContainer}`, this.options.viewPort)
            .filter(toRemoveDOM.join(','))
            .not('.is-current')
            .remove();

        return this;
    }

    listenRainbowColors() {

        this.$(document).on("app:rainbow:filter", (ev, data) => {

            this.$(document).on("app:frame:pageLoaded", (ev, data) => {
                this.$(document).trigger("app:orderBy:update", data);
                this.$(document).off("app:frame:pageLoaded");
            });

            let urlCurrentParams = $("#clearall-url").data("url") || this.options.filterUrl;

            let urlParans = this.buildFiltersParams(data.chosenColors);
            this.isRainbowFilter = true;

            this.setFallbackTargetClick('.rainbow__color');
            this.setIsModal().loadPage(urlCurrentParams + urlParans);
            this.historyChange(urlCurrentParams + urlParans);

        });
    }

    getPage(url) {
        return new Promise((resolve, reject) => {
            // if(this.verifyIsLoaded(this.pageName)) return resolve({});

            this.$(document).trigger("app:frame:willGet", [{
                url: url,
                isIframe: this.options.isOnIframe
            }]);

            if (this.jqxhr) {
                this.jqxhr.abort();
                this.$(document).trigger("app:frame:abortedRequest", [{
                    requestLink: this.lastLink
                }]);
            };

            this.jqxhr = this.$.get(url.replace(this.hash, ''), {
                ajax: true
            }, {
                type: "ajax"
            });

            this.jqxhr.done((data) => {
                this.pageName = this.$(data).filter('.container').attr('data-pageName') || this.pageName;
                this.pageTitle = this.$(data).filter('.container').attr('data-pageTitle') || this.pageTitle;
                this.setIsSearchMenu(this.$(data).filter('.container').attr('data-pageContext') == 'searchMenu' || false);

                this.$(document).trigger("app:frame:ajaxDone", [{
                    url: url,
                    pageName: this.pageName,
                    isIframe: this.options.isOnIframe
                }]);
                resolve(data);

            });

            this.jqxhr.fail((e) => {
                this.$(document).trigger("app:frame:ajaxFail", [{
                    url: url,
                    isModal: this.isModal,
                    error: e
                }]);
                reject(e);
            });

        });

    }

    verifyIsLoaded(pageName) {

        if (this.pageContext == 'modal') {
            return this.$(`.${this.options.modalsViewport}`).find('[class*="page-' + this.pageName + '"]').length;
        } else {
            return this.$(this.options.viewPort).find('[class*="page-' + this.pageName + '"]').length;
        }
    }

    goToPage(link) {
        let dataLink = link || this.lastLink;

        return new Promise(resolve => {
            let incomingData = {
                pageName: this.pageName,
                pageTitle: this.pageTitle,
                samePage: (this.pageName == this.lastPageName),
                fromTarget: this.targetClick,
                fromPageName: this.lastPageName,
                twoNDpageName: this.twoNDlastPageName,
                isModal: this.isModal,
                isSearchMenuContext: this.isSearchMenuContext,
                isDesktopFilter: this.isDesktopFilter,
                previousLink: this.previousLink
            };

            this.$('body').removeClass((index, css) => {
                return (css.match(/\bpage-\S+/g) || []).join(' ');
            });

            this.$('body')
                .addClass(`${this.pageName}-body`)
                .addClass(`${this.lastPageName}-body-from`)
                .attr('data-fromPage', this.pageName);

            if (this.pageContext == 'modal') {
                this.$('body').addClass('modal-open');
            } else {
                this.$('body').removeClass('modal-open');
            }

            this.$(this.options.pageWrapper)
                .parent()
                .removeClass('is-current')
                .removeClass('in-frame')
                .addClass('out-frame');

            if (this.pageContext == 'modal') {
                this.$(`.${this.options.modalsViewport}`).find('[data-link*="' + dataLink + '"]')
                    .removeClass('out-frame')
                    .addClass('in-frame')
                    .addClass('is-current');
            } else {
                this.$(this.options.viewPort).find('[data-link="' + dataLink + '"]')
                    .removeClass('out-frame')
                    .addClass('in-frame')
                    .addClass('is-current')
            }

            this.$(document).trigger("app:frame:changed", [incomingData]);

            setTimeout(() => {
                this.removeOlderAppendedPages();
                this.$(document).trigger("app:frame:ready", [incomingData]);

                resolve();
            }, 300);
        });
    }

    freeze(target) {
        let videos = this.$('video', target);

        this.$.each(videos, (idx, elem) => {
            elem.pause();
        });
    }

    unfreeze(target) {
        let videos = this.$('video', target);

        this.$.each(videos, (idx, elem) => {
            elem.play();
        });
    }

    appendPage(page) {
        return new Promise((resolve, reject) => {

            this.pageContext = $("<div/>").append(page).find('[data-pageContext]').attr('data-pageContext');
            this.setPageContext(this.pageContext);
            this.setVisitedLinks(this.lastLink, this.pageContext);

            if (this.pageContext == 'main') {
                this.removeOldAppendedPage(this.pageName);
            } else {
                this.removeOldAppendedModals(this.pageName);
            }

            // if(this.verifyIsLoaded(this.pageName)) return resolve();
            let container;
            if (this.pageContext == 'modal') {

                container = this.$(`<div data-pageName='${this.pageName}' data-link='${this.lastLink}' data-createdAt='${Date.now() / 1000 | 0}' class='${this.options.modalContainer} ${this.options.fxContainer} matrixBgColor matrixTxtColor'></div>`);
                container.html(page);

                const
                    divPage = this.$(`.${this.options.modalsViewport}`).find(`>[data-pageName='${this.pageName}']`),
                    pageLink = divPage ? divPage.data('link') : '';

                // verify if page already exists
                if (divPage.length && !divPage.find('form').length) {

                    divPage.html(page).addClass(`${this.options.modalContainer} ${this.options.fxContainer}`);

                } else {

                    if (divPage.length) divPage.remove();

                    this.$(`.${this.options.modalsViewport}`).prepend(container);

                }

            } else if (this.pageContext == 'searchMenu') {
                let searchMenuviewport = this.$('.search-menu .menu__context-pages');
                this.$(searchMenuviewport).html(page);

                let appendedPage = this.$(searchMenuviewport).find('.container').first();

                this.$(appendedPage).data('link', this.lastLink);
                this.$(appendedPage).data('createdAt', Date.now() / 1000 | 0);

                this.showViewportInSearchMenu(appendedPage);

            } else if (this.target) {

                this.$(this.target).append(page);

            } else {

                container = this.$(`<div data-pageName='${this.pageName}' data-link='${this.lastLink}' data-createdAt='${Date.now() / 1000 | 0}' class='${this.options.fxContainer}'></div>`)

                this.$(this.options.viewPort).prepend(container.append(page));
            }

            this.target = null;

            resolve(page);
        });

    }

    loadAsyncAsset(url) {

        return new Promise((resolve, reject) => {

            this.$.ajax({
                url: url,
                dataType: 'script',
                success: resolve(data),
                fail: reject(data),
                async: true
            });
        });
    }

    isIframe(isOnIframe) {
        this.options.onIframe = isOnIframe;

        return this;
    }

    listenCloseModal() {
        this.$('body').on(this.tapEvent, this.options.closeModal, () => this.closeModal());
    }

    closeModal(fallback = () => null, changeOnlyHistory = true) {
        return new Promise(resolve => {

            // this needs to be removed as soon as the frame is running with cache
            // verify if last page is searchMenu page to run history.back
            const lastLinkContext = this.visitedLinks[this.visitedLinks.length - 2].context;
            if(this.$('body').hasClass('menusca-open') && lastLinkContext === 'searchMenu') {
                history.back();
                resolve();
                return;
            }

            this.$(`.${this.options.fxContainer}`, `.${this.options.modalsViewport}`).fadeOut(300).removeClass('in-frame');

            this.$(document).trigger('app:frame:modalWillClose');

            //setTimeout for the animation to get cleaner
            super.clearTimeout('closeModal')
                .clearableWait(300, 'closeModal')
                .then(() => {
                    this.$(`.${this.options.fxContainer}`, `.${this.options.modalsViewport}`).removeClass('is-current').addClass('out-frame');
                    this.$('body').removeClass('modal-open');
                    this.$(document).trigger('app:frame:modalIsClosed');

                    // get lastLink
                    const link = this.getVisitedLink('context', 'main').link;
                    this.historyChange(link);

                    if(changeOnlyHistory) {
                        this.setVisitedLinks(link, 'main');
                    } else {
                        this.setPageContext()
                            .loadPage(link);
                    }

                    this.setActualPage();

                    resolve(fallback());
                });
        });
    }

    setActualPage() {
        const pages = this.$(`.${this.options.fxContainer}`, `${this.options.viewPort}`);

        let creats = [];

        pages.each((index, item) => {
            creats.push(this.$(item).data('createdat'));

            if (index == pages.length - 1) {
                const max = creats.reduce(function (a, b) {
                    return Math.max(a, b)
                });

                this.activeLastPage(pages.filter(`[data-createdat=${max}]`).data('pagename'));
            }
        });

        return this;
    }

    requestListener() {

        this.$('body').on(this.tapEvent, 'a:not(.redirect)', (ev) => {

            ev.preventDefault();

            this.setIsModal(this.$(ev.currentTarget).data('is-modal') || false);
            this.setIsSearchMenu(this.$(ev.currentTarget).data('is-search-menu') || false);
            this.setIsDesktopFilter(this.$(ev.currentTarget).data('is-desktop-filter') || false);

            this.targetClick = {
                mouseEvents: {
                    pageX: ev.clientX,
                    pageY: ev.clientY
                },
                currentTarget: ev.currentTarget,
                target: ev.target
            }

            this.isRainbowFilter = false;
            let link = this.$(ev.currentTarget).attr('href');

            if (!this.linkPatternExclude.test(link) && link != '#') {
                this.loadPage(link);
            }
        });
    }

    setTargetToAppend(target) {

        this.target = target;

        return this;
    }

    setIsModal(isModal = false) {
        this.isModal = isModal;

        return this;
    }

    setPageContext(pageContext = "main") {
        if (pageContext == 'modal') {
            this.setIsModal(true);
            this.setIsSearchMenu(false);
        } else if (pageContext == 'searchMenu') {
            this.setIsModal(false);
            this.setIsSearchMenu(true);
        } else {
            this.setIsModal(false);
            this.setIsSearchMenu(false);
        }

        return this;
    }

    setIsSearchMenu(searchMenuContext = false) {
        this.isSearchMenuContext = searchMenuContext;

        return this;
    }

    setIsDesktopFilter(isDesktopFilter = false) {
        this.isDesktopFilter = isDesktopFilter;
        return this;
    }

    setTitle(title = "") {
        this.documentTitle = title;
    }

    setUrl(url = "") {
        this.url = url;
    }

    loadPage(followLink) {

        this.previousLink = `${window.location.pathname}${window.location.search}`;
        this.lastLink = followLink;

        let link = followLink.substring(followLink.lastIndexOf('/') + 1);
        this.twoNDlastPageName = this.lastPageName;
        this.lastPageName = this.pageName;

        let incomingData = {
            pageName: this.pageName,
            pageTitle: this.pageTitle,
            samePage: (this.pageName == this.lastPageName),
            fromTarget: this.targetClick,
            fromPageName: this.lastPageName,
            twoNDpageName: this.twoNDlastPageName,
            isModal: this.isModal,
            isSearchMenuContext: this.isSearchMenuContext,
            isDesktopFilter: this.isDesktopFilter,
            previousLink: this.previousLink
        };

        if (this.target) {
            return this.getPage(followLink)
                       .then((data) => {
                            this.appendPage(data)
                                .then(() => {
                                    this.$(document).trigger("app:frame:pageLoaded", {page: data});
                                });
                        })
                       .catch((e) => {
                           console.warn(e);
                       });

        } else {
            this.$(document).trigger("app:frame:willLoad", [incomingData]);

            this.getPage(followLink)
                .then((data) => {
                    this.appendPage(data)
                        .then(() => {
                            this.goToPage()
                                .then(() => {
                                    this.historyChange(followLink);
                                    this.$(document).trigger("app:frame:pageLoaded", {page: data});

                                });
                        });
                })
                .catch((e) => {
                    console.warn(e);
                });
        }
    }

    /*

    Changes the url and push a index to browser
    history

    var state = { 'page_id': 1, 'user_id': 5 };
    var title = 'Hello World';
    var url = 'hello-world.html';

    history.pushState(state, title, url);

    */

    newHistoryChange() {

        if (!this.isModal) {
            history.replaceState(this.url, this.documentTitle, this.url);
            if (this.documentTitle) {
                document.title = this.documentTitle;
            }
        };

        return this;
    }

    historyChange(url) {

        if (this.isPopStateChange) {
            this.isPopStateChange = false;
            return this;
        }

        if (this.isRainbowFilter) {
            url = url.replace('?ajax=true&', '?');
        }

        // dont change url if is checkout page
        if (!(this.pageName.toLowerCase().indexOf('checkout') >= 0 && this.lastPageName.toLowerCase().indexOf('checkout') >= 0)) history.pushState(url, this.documentTitle, url);

        return this;
    }

    buildDefaultLink() {
        return this.options.baseUrl + this.options.defaultLink;
    }

    setIsPopStateChange(isPopSate = false) {
        this.isPopStateChange = isPopSate;

        return this;
    }

    /*

    Listen browser history navigation

    */
    popStateListener() {
        let followLink;

        this.$(window).on('popstate', (ev) => {
            ev.preventDefault();

            if(history.state) {

                if (history.state.length == 0 || history.state.length == undefined) {
                    followLink = window.app.urls.home;
                } else {
                    followLink = (history.state).replace(this.hash, '').replace(this.search, '');
                }

            } else {
                followLink = this.buildDefaultLink();
            }

            this.setIsPopStateChange(true).loadPage(followLink);
            history.replaceState(followLink, document.title, followLink);

        });
    }
}