import isMobile from '../../utils/isMobile';
import Drawer from '../Drawer/Drawer';
import throttle from '../../utils/throttle';
import debounce from '../../utils/debounce';

export default class Menu {
    constructor(options) {
        const defaultOptions = {
            selectorEngine: {},

            body: "body",
            searchIcon: ".superActions__header__search",
            logoutButton: ".menu__logout-button",
            menu: ".menu",
            menuContent: '.menu__content',
            menuContextItems: '.menu__context-items',
            menuOrders: '.menu__context-items .order__listing',
            menuBackground: '.menu__background',
            menuBackButton: ".search-menu .menu__link-back",
            menuCancelButton: '.menu__link-cancel',
            menuOptions: '.menu__block-options',

            menuContext: '.menu__context',
            categoryItems: '.categories__menu-category__items',
            categoryItem: '.categories__menu-category__item',
            categoryName: '.categories__menu-category-name',
            seeMoreCategories: 'is-seemore',

            searchForm: '#havaianasSearch',
            searchInput: '#havaianasSearch > .form-control.search-field',
            searchTypewritter: '.search-typewritter',
            searchClearAll: '#havaianasSearch .reset-button',

            suggestionsWrapper: '.suggestions-wrapper',
            suggestionNames: '.search__results-category__item-name',
            suggestionItem: '.search__results-category__item',
            suggestionItemLink: '.search__results-category__item > a',
            suggestionBackImage: '.search__results-category__item-background',

            submenu: '.menu__item--submenu',
            submenuLink: '.menu__link',
            submenuToggle: '.menu__link--toggleSubmenu',
            submenuParent: '.drawer__more-parent',
            submenuParentCollapsed: 'drawer__more-collapsed',

            isLogged: ".drawer__account.is-logged",
            drawerAccount: ".drawer__account",
            drawerAccountCollapsed: "drawer__account-collapsed",

            menuItemOrderTrack: '.menu__item-order',
            trackOrderFormInclude: '.track-order-include',
            trackOrderButton: '.btn__trackOrder',
            trackOrderInclude: '.scriptsButton',
            drawerMenu: '.drawer__menu',

            colorMatrix: '.color-matrix',

            // state classes
            menuOpen: "menu--isOpen",
            menuSuggestionMode: 'is-suggestion-search',
            discoverySuggestionItem: 'is-discovery-item',
            shopSuggestionItem: 'is-shop-item',
            helpSuggestionItem: 'is-help-item',
            linkReady: 'is-ready',

            orderColorMatrix: '#searchMenuColorMatrix',
            pageOrderOverview: '.page-orderOverview',
        }


        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.drawer = new Drawer({selectorEngine: this.$});

        this.tapEvent = "click";

        this.viewportWidth = this.$("body").outerWidth();
        this.colDesk = this.viewportWidth / 79;
        this.isTyping;
        this.textColor;
        this.isUpdated = 0;
        this.isSubmiting = false;
    }

    // NEED REFACTORING
    typeWritter() {
        this.$(this.options.searchTypewritter).show();

        const
            wait = parseInt(1000, 10),
            txtElement = this.$(this.options.searchTypewritter),
            words = this.$(this.options.searchInput).data('placeholder'),
            defaultTypeSpeed = 50;

        let
            text = '',
            subWords = '',
            subwordIndex = 0,
            wordIndex = 0,
            typeSpeed = defaultTypeSpeed,
            isDeleting = false,
            fullTxt = '',
            originalPhase = '';

        if(!words) return;

        const type = () => {
            if(subWords == '' && !isDeleting) {
                fullTxt = words[wordIndex];
            }

            if(fullTxt.indexOf('|') >= 0) {
                fullTxt = fullTxt.split('{');
                fullTxt[1] = fullTxt[1].replace('}', '');
                subWords = fullTxt[1].split('|');
                originalPhase = fullTxt[0];
                fullTxt = `${fullTxt[0]}${subWords[0]}`;
            }

            if(isDeleting) {
                text = fullTxt.substring(0, text.length - 1);
            } else {
                text = fullTxt.substring(0, text.length + 1);
            }

            txtElement.html(text);

            if(isDeleting) typeSpeed = defaultTypeSpeed / 2;

            // If word is complete
            if(!isDeleting && text === fullTxt) {
                if(wordIndex !== words.length - 1) {
                    isDeleting = true;
                } else if(subWords && subwordIndex !== subWords.length - 1) {
                    isDeleting = true;
                } else {
                    return;
                }
                typeSpeed = wait;

            } else if(isDeleting) {
                if(subWords && text === originalPhase) {
                    isDeleting = false;
                    // Move to next subword;
                    subwordIndex++;
                    if(subwordIndex === subWords.length) {
                        subWords = '';
                        isDeleting = true;
                        if(wordIndex === words.length - 1) {
                            isDeleting = false;
                            return;
                        }
                    } else {
                        fullTxt = `${originalPhase}${subWords[subwordIndex]}`;
                    }
                }

                if(text === '') {
                    isDeleting = false;
                    // Move to next word
                    wordIndex++;
                    // Pause before start typing
                    typeSpeed = defaultTypeSpeed;
                }
            }

            if(wordIndex + 1 <= words.length) {
                this.isTyping = setTimeout(() => type(), typeSpeed);
            }
        }

        type();
    }

    openSearchMenu() {
        if(!isMobile() && (this.$('body').hasClass('collapseRainbow') && !this.$('body').hasClass('is-rainbowReady'))) return;

        const body = this.$('body');

        body.addClass('menusca-open');
        this.$(document).trigger("app:menusca:willOpen");

        return new Promise(resolve => {

            const openAnim = anime({
                targets: this.options.menu,
                left: 0,
                autoplay: false,
                duration: 800,
                easing: 'easeOutQuint',
                complete: () => {
                    this.$(document).trigger("app:menusca:open");

                    resolve()
                }
            });

            if (!isMobile() && body.hasClass('page-product-body')) {
                // this.options.rainbow.listen();
                this.options.productVariation.reset();
            }

            this.setMenuColors();

            this.textColor = this.$(this.options.menu).css('color');

            this.$(this.options.menu).toggleClass(this.options.menuOpen);

            this.$(this.options.searchInput).focus();
            if (!isMobile()) {
                this.adjustMenuscaCategories()
                // this.options.rainbow.rainbowInMenusca();//will open
                setTimeout(this.typeWritter(), 300);
            } else {
                const mobilePlaceholder = this.$(this.options.searchInput).data('placeholder-mobile');
                this.$(this.options.searchTypewritter).show();
                this.$(this.options.searchTypewritter).html(mobilePlaceholder);
            };

            return openAnim.play();

        });
    }

    setMenuColors() {
        // if have color matrix from order overview
        const orderOverviewColorMatrix = this.$(this.options.pageOrderOverview).find(this.options.colorMatrix).eq(0);
        if (orderOverviewColorMatrix.length && orderOverviewColorMatrix.data('colormatrix').background) {
            this.$(document).trigger('app:colors:setcolors', [orderOverviewColorMatrix]);
            return;
        }

        // if have color matrix from orders
        const orderColorMatrix = this.$(this.options.orderColorMatrix);
        if (orderColorMatrix.length && orderColorMatrix.data('colormatrix').background) {
            this.$(document).trigger('app:colors:setcolors', [orderColorMatrix]);
            return;
        }

        return this;
    }

    closeSearchMenu(reason = {name:'menuscaCloseButton', data: {}}) {

        this.$(document).trigger("app:menusca:willClose", [{
            reason: reason
        }]);

        return new Promise(resolve => {

            const collapseAnim = anime({
                targets: this.options.menu,
                left: "100%",
                autoplay: false,
                duration: 800,
                easing: 'easeOutQuint',
                complete: () => {

                    let backLink = this.options.frame.getVisitedLink('context', 'main').link;
                    history.replaceState(backLink, document.title, backLink);

                    this.$(document).trigger('app:colors:setcolors', this.$(`[data-pagename].is-current .color-matrix:eq(0)`));

                    this.$(document).trigger("app:menusca:closed", [{
                        reason: reason
                    }]);

                    this.$('body').removeClass('menusca-open');
                    this.$(this.options.menu).removeClass(this.options.menuOpen);

                    // this solution should be removed as soon as the navigation through the menuca is completed
                    setTimeout(() => {
                        this.$('.site-search').fadeIn(0);
                        this.$('.menu__context').removeAttr('style');
                        this.$('.menu__context-items').fadeIn(0);
                        this.$('.rainbow').css('visibility', 'visible').fadeIn(200);
                        this.$('.menu').removeClass('is-teste');
                        this.$('.menu__context-pages').fadeOut(0).html('');
                    }, 300);

                    resolve()
                }
            });

            if(!isMobile()) {
                // this.options.rainbow.rainbowInMenusca(true);// will close
                clearTimeout(this.isTyping);
            };

            return collapseAnim.play();

        });

    }

    cancelSuggestions() {
        // this.$(this.options.menu).removeClass(this.options.menuSuggestionMode);
        this.$('body').removeClass('is-typing-menusca has-menusca-search').addClass('is-type-empty');

        this.$(this.options.searchClearAll).fadeOut(200);
        this.$(this.options.searchInput).val('').trigger('blur');

        if(!isMobile()) {
            if (this.$(this.options.menu).hasClass(this.options.menuOpen)) {
                // this.options.rainbow.rainbowInMenusca(); // will open
            }
            setTimeout(this.typeWritter(), 300);
        } else {

            const mobilePlaceholder = this.$(this.options.searchInput).data('placeholder-mobile');
            this.$(this.options.searchTypewritter).show();
            this.$(this.options.searchTypewritter).html(mobilePlaceholder);
        };
    }

    adjustMenuscaCategories() {
        const showItems = 5;

        this.$(this.options.categoryItems).each((e, item) => {
            const
                total = this.$(item).find(this.options.categoryItem).length,
                rest = (total + 1) - showItems,
                categoryName = this.$(item).attr('aria-label');

            if(total > showItems) {
                this.$(item).children().eq(showItems - 1)
                    .addClass(this.options.seeMoreCategories)
                    .attr('data-more', `+ ${rest} ${categoryName}`)
                    .nextAll().fadeOut();
            }
        });
    }

    clickSeeMoreCategories() {
        this.$(this.options.categoryItem).on(this.tapEvent, (ev) => {

            this.$(document).on("app:frame:pageLoaded", (ev, data) => {
                this.$(document).trigger("app:orderBy:update", data);
                this.$(document).off("app:frame:pageLoaded");
            });

            if(!this.$(ev.target).hasClass(this.options.seeMoreCategories)) return;

            this.$(ev.target)
                .removeClass(this.options.seeMoreCategories)
                .nextAll().fadeIn(200);
        });
    }

    logout() {
        this.$('body')
            .off(this.tapEvent, this.options.logoutButton)
            .on(this.tapEvent, this.options.logoutButton, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            const url = this.$(ev.currentTarget).data('url');

            this.$.ajax({
                type: 'get',
                dataType: 'json',
                url,
                success: (data) => {
                    if (data.success) {

                        this.$(document).trigger('app:user:logout', [{
                            components: data.components,
                            urls: data.urls
                        }]);

                    }
                },
                error: () => {
                    // TODO: Include toast
                    alert('Sorry! something went wrong.');
                }
            });
        });
    }
    mouseoverItemSuggestion(ev) {
        const
            item = this.$(ev.target).parents(this.options.suggestionItem),
            menuOriginalBackground = this.$(this.options.menu).css('background-color'),
            image = item.find(this.options.suggestionBackImage).data('src') || '',
            colorMatrix = item.find(this.options.colorMatrix) || '',
            backgroundColor = colorMatrix.data('colormatrix').background || '',
            firstRainbowColor = colorMatrix.data('colormatrix').primaryColor || '',
            secondRainbowColor = colorMatrix.data('colormatrix').secondRainbowColor ? colorMatrix.data('colormatrix').secondRainbowColor : '',
            thirdRainbowColor = colorMatrix.data('colormatrix').thirdRainbowColor ? colorMatrix.data('colormatrix').thirdRainbowColor : '';

        this.$(this.options.menu).attr('data-background', menuOriginalBackground);
        item.find(this.options.suggestionNames).css({'color': this.textColor});

        this.$(this.options.menuBackground).removeClass(`${this.options.shopSuggestionItem} ${this.options.discoverySuggestionItem} ${this.options.helpSuggestionItem}`);

        // if is discovery item
        if(item.hasClass(this.options.discoverySuggestionItem)) {
            this.$(this.options.menuBackground).css({
                'background-image': `url('${image}')`
            }).fadeIn(200);

            this.$(document).trigger("app:menusca:changeGradient", [{
                chosenColors: [firstRainbowColor, secondRainbowColor, thirdRainbowColor],
                from: 'menusca'
            }]);
            //this.options.rainbow.changeGradientColor(firstRainbowColor, secondRainbowColor, thirdRainbowColor);
        }

        // if is shop item
        if(item.hasClass(this.options.shopSuggestionItem)) {
            this.$(this.options.menuBackground).addClass(this.options.shopSuggestionItem).css({
                'background-image': `url('${image}')`
            }).fadeIn(200);

            anime({
                targets: this.options.menu,
                background: backgroundColor,
                easing: 'linear',
                duration: 200
            });

            this.$(document).trigger("app:menusca:changeGradient", [{
                chosenColors: [firstRainbowColor, secondRainbowColor, thirdRainbowColor],
                from: 'menusca'
            }]);

            //this.options.rainbow.changeGradientColor(firstRainbowColor, secondRainbowColor, thirdRainbowColor);
        }
    }

    mouseoutItemSuggestion(ev) {
        const
            item = this.$(ev.target).parents(this.options.suggestionItem),
            textColorDefault = item.find(this.options.suggestionNames).attr('data-color');

        this.$(this.options.menuBackground).fadeOut(200);
        item.find(this.options.suggestionNames).css({'color': textColorDefault});

        this.$(this.options.menu).css('background', '');

        this.$(document).trigger("app:menusca:resetRainbow");
        // this.options.rainbow.gradientRainbowDefault();
    }

    searchInput() {

        const suggestionsWrapper = this.$(this.options.suggestionsWrapper);

        this.$(this.options.searchInput).on('focus', (ev) => {

            // this.$(this.options.menu).addClass(this.options.menuSuggestionMode);
            this.$('body').addClass('is-typing-menusca').removeClass('has-menusca-search');

            this.$(this.options.searchInput).trigger('keyup');
        });

        this.$(this.options.searchInput).on('blur', (ev) => {
            // this.$(this.options.menu).removeClass(this.options.menuSuggestionMode);
            this.$('body').removeClass('is-typing-menusca');

            if (this.$(ev.target).val()) {
                this.$('body').addClass('has-menusca-search');

                if (!isMobile()) {

                    this.$(document).trigger("app:rainbow:expand");
                }
            } else {
                this.$('body').addClass('is-type-empty');
            }
        });

        let throttledTyping = throttle((ev) => {

            const
                suggestionsUrl = suggestionsWrapper.data('url'),
                search = this.$(this.options.searchInput).val(),
                colorWithOpacity = this.textColor.replace(')', ', 0.5)').replace('rgb', 'rgba');

            this.$.ajax({
                url: `${suggestionsUrl}${search}`,
                type: 'POST',
                success: (data) => {
                    let outerHTML = this.$(data).find('.search__suggestions');
                    suggestionsWrapper.html(outerHTML[0] ? outerHTML[0].outerHTML : '');

                    this.$(this.options.suggestionNames).each((ev, item) => {
                        let text = this.$(item).text();
                        const regex = new RegExp(search, 'gi');
                        text = text.replace(regex, match => `<span class="highlight" style="color: ${this.textColor}">${match}</span>`);
                        this.$(item)
                            .attr('data-color', colorWithOpacity)
                            .css({
                                'color': colorWithOpacity
                            })
                            .html(text);
                    });

                }
            });

        }, 75);

        this.$(this.options.searchInput).off('keyup').on('keyup', throttledTyping);

        this.$(this.options.searchInput).on('keyup', (ev) => {
            clearTimeout(this.isTyping);

            let search = this.$(ev.target).val();

            // transition to suggestion layout
            // this.$(this.options.searchClearAll).fadeOut(0);
            // this.$(this.options.menuContext).fadeOut(200);
            // this.$(this.options.menuOptions).fadeOut(200);

            // this.$(this.options.menuBackButton).addClass('is-invisible');
            // this.$(this.options.menuCancelButton).addClass('is-visible');

            // this.options.rainbow.rainbowInMenusca(true);//will close
            // \ transition to suggestion layout

            // this.$(this.options.searchTypewritter).hide();

            if(isMobile()) {
                // this.$(this.options.menu).addClass();
                // this.options.rainbow.hideRainbow();
            }

            if (!search) {
                this.$('body').addClass('is-type-empty').removeClass('has-menusca-search');

                if (!isMobile()) {

                    this.$(document).trigger("app:rainbow:expand");
                }
            } else {
                this.$('body').removeClass('is-type-empty').addClass('has-menusca-search');

                if (!isMobile()) {

                    this.$(document).trigger("app:rainbow:collapse");
                }
            }

            // this serves so I can pick up the size of the text and in case it has no results add a clear button all
            if(!isMobile()) {
                this.$('.fake-text-element').text(search);

                if (search.length) {
                    const fakeWidth = $('.fake-text-element').outerWidth() + 30;
                    this.$(this.options.searchClearAll)
                        .css({'margin-left': fakeWidth})
                        .fadeIn(200);
                } else {
                    this.$(this.options.searchClearAll).hide();
                    this.typeWritter();
                }
            }
        });
    }

    formMenuSubmit() {
        const debounceSubmit = debounce(() => {
            const
                form = this.$(this.options.searchForm),
                url = `${form.attr('action')}?${form.serialize()}`;

            this.$(document).on("app:frame:pageLoaded", (ev, data) => {
                this.$(document).trigger("app:orderBy:update", data);
                this.$(document).off("app:frame:pageLoaded");
            });

            this.$(document).trigger('app:frame:loadPage', [{
                link: url
            }]);
        }, 200, false);

        this.$(this.options.searchForm).off('submit').on('submit', (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            debounceSubmit();
        });
    };

    listenTrackForm() {
        let isSearching = false;

        if(!isMobile()) {
            this.$(this.options.menuItemOrderTrack).off('mouseleave').on('mouseleave', () => {
                if(!isSearching) this.$(this.options.menuItemOrderTrack).removeClass('active');
            });
        }

        this.$(this.options.trackOrderButton).off(this.tapEvent).on(this.tapEvent, (ev) => {
            if(isSearching) return;

            const button = this.$(ev.target);
            isSearching = true;
            if(!isMobile()) this.$(this.options.menuItemOrderTrack).addClass('active');

            // if the catpcha takes too long to respond may mean that it gave error
            let captchaTimeOut = setTimeout(() => {
                this.$(document).trigger('app:menu:orderTrackingCaptcha');
            }, 5000);

            this.$(document).trigger('app:contextLoader:init', [{ target: this.$(ev.currentTarget) }]);
            this.$(document).one('app:menu:orderTrackingCaptcha', () => {
                clearTimeout(captchaTimeOut);
                debounceSubmit(button);
            });
        });

        const debounceSubmit = debounce((button) => {
            const form = button.parents('form');
            form.find('.invalid-feedback').html('');
            let data = this.$('[name!="g-recaptcha-response"]', form).serialize();

            if(form.find('[name=customerIdNumber]').length) {
                data = this.$('[name!="customerIdNumber"][name!="g-recaptcha-response"]', form).serialize();
                const customerIdNumber = form.find('[name=customerIdNumber]').val().replace(/[^\w]+/g, "");
                data += `&customerIdNumber=${customerIdNumber}`;
            }

            const url = `${form.attr('action')}?${data}`;

            this.$.ajax({
                url: url,
                type: 'get',
                dataType: 'json',
            }).done((data) => {
                if(data.success) {
                    this.$(document).trigger('app:frame:loadPage', [{
                        isModal: 'searchMenu',
                        link: data.redirectUrl
                    }]);

                    if(isMobile()) this.$(document).trigger('app:drawer:close');

                } else {
                    let invalidFeedBack;
                    if(data.errorMsg) {
                        invalidFeedBack = data.errorMsg;
                    } else if(data.reCaptchaForm && data.reCaptchaForm.reCaptchaResponse && data.reCaptchaForm.reCaptchaResponse.error) {
                        invalidFeedBack = data.reCaptchaForm.reCaptchaResponse.error;
                    }

                    form.find('.invalid-feedback').html(`<i class="icon-alert"></i> <span>${invalidFeedBack}</span>`);
                }
            }).always(() => {
                this.$(document).trigger('app:contextLoader:finish');
                isSearching = false;
                if(!isMobile()) this.$(this.options.menuItemOrderTrack).removeClass('active');

                const trackOrderIncludeUrl = isMobile() ? `${window.app.urls.trackOrderform}?mobile=true` : window.app.urls.trackOrderform;

                this.$.ajax({
                    type: 'GET',
                    url: trackOrderIncludeUrl,
                }).done((data) => {
                    form.find(this.options.trackOrderInclude).html(this.$(data).find(this.options.trackOrderInclude)[0].innerHTML);
                    this.listenTrackForm();
                });
            });
        }, 200, false);
    }

    submenuToggle() {
        this.$(this.options.submenuToggle).off(this.tapEvent).on(this.tapEvent, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            let target = $(ev.currentTarget);

            this.$(".menu__item--submenu.is-expanded").removeClass("is-expanded");
            target.closest(".menu__item--submenu").toggleClass("is-expanded");

            this.$(this.options.submenuParent).toggleClass(this.options.submenuParentCollapsed);

            if (this.$(this.options.isLogged).length) {
                this.$(this.options.drawerAccount).toggleClass(this.options.drawerAccountCollapsed);
            }
        });
    }

    listenExternalEvents() {
        this.$(document)
            .on("app:searchmenu:open", () => {
                console.log('app:searchmenu:open');
                this.openSearchMenu();
            });

        this.$(document)
            .on("app:searchmenu:close", () => {
                console.log('app:searchmenu:close');
                this.closeSearchMenu({name: 'eventTrigger'});
            });

        return this;
    }

    removeOldMenuComponents() {
        this.$(this.options.menuBackground).remove();
        this.$(this.options.menuContent).remove();
        this.$(this.options.orderColorMatrix).remove();
        this.$(this.options.menuOrders).remove();
        this.$(this.options.drawerMenu).remove();

        return this;
    }

    changeMenuComponents(components, fallback = () => {}) {
        this.removeOldMenuComponents();
        this.$(this.options.menu).prepend(components.searchMenuHeader);
        this.$(this.options.menuContextItems).prepend(components.searchMenuOrderTracking);
        this.$(this.options.menu).append(components.drawer);

        fallback();
    }

    subMenuColors() {
        if (!isMobile()) {
            this.$(this.options.submenu)
                .on('mouseover', (e) => {
                    this.$(e.currentTarget).find(this.options.submenuLink).addClass('matrixUiText');
                }).on('mouseleave', (e) => {
                    this.$(e.currentTarget).find(this.options.submenuLink).removeClass('matrixUiText');
                });
        }
    }

    listen() {
        this.searchInput();
        this.clickSeeMoreCategories();
        this.formMenuSubmit();
        this.listenTrackForm();
        this.logout();
        this.listenExternalEvents();
        this.subMenuColors();

        if (isMobile()) this.submenuToggle();

        this.$(document).on('app:user:login', (ev, data) => {
            const components = data.components;
            this.changeMenuComponents(components, () => {
                if(!this.$('body').hasClass('is-checkout')) {
                    this.$(document).trigger('app:frame:closeModal');
                    this.$(document).trigger('app:contextLoader:finish');
                }
                if(this.$('body').hasClass('menusca-open')) {
                    this.setMenuColors();
                    this.subMenuColors();
                }
            });
        });

        // had to do this because of the request cache
        this.$(document).on('app:menu:canUpdateComponents', () => this.isUpdated = 1);

        this.$(document).on('app:menu:updateComponents', (ev) => {
            const urlOrderTracking = window.app.urls.searchMenuOrderTracking;
            const urlMenuHeader = window.app.urls.searchMenuHeader;

            this.$.ajax({
                data: { ajax: true },
                type: 'GET',
                url: urlMenuHeader,
            }).done((data) => {
                const menuHeader = data;

                this.$.ajax({
                    data: { ajax: true },
                    type: 'GET',
                    url: urlOrderTracking,
                }).done((data) => {
                    const searchMenuOrderTracking = data;
                    this.removeOldMenuComponents();

                    this.$(this.options.menu).prepend(menuHeader);
                    this.$(this.options.menuContextItems).prepend(searchMenuOrderTracking);
                });
            });
        });

        this.$(document).on('app:user:logout', (ev, data) => {
            const components = data.components;

            if (isMobile()) { this.drawer.closeDrawer();}
            this.removeOldMenuComponents();
            this.$(this.options.menu).prepend(components.searchMenuHeader);
            this.$(this.options.menu).append(components.drawer);
            this.$(this.options.trackOrderFormInclude).html(isMobile() ? components.trackOrderFormMobile : components.trackOrderForm);
            this.$(document).trigger('app:masks:setInptus', [{
                targets: this.$(this.options.trackOrderFormInclude).find('input')
            }]);
            this.listenTrackForm();

            if(this.$('body').hasClass('menusca-open')) {
                this.setMenuColors();
                this.subMenuColors();
            }
        });

        // Cancel Search
        this.$('body').off(this.tapEvent, this.options.menuCancelButton)
                      .on(this.tapEvent, this.options.menuCancelButton, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.cancelSuggestions();
        });

        // Clear all search
        this.$('body').off(this.tapEvent, this.options.searchClearAll)
                      .on(this.tapEvent, this.options.searchClearAll, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.cancelSuggestions();
        });

        // Open search menu
        this.$('body').off(this.tapEvent, this.options.searchIcon)
                      .on(this.tapEvent, this.options.searchIcon, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            this.openSearchMenu();

        });

        // Close search menu
        this.$('body').off(this.tapEvent, this.options.menuBackButton)
                      .on(this.tapEvent, this.options.menuBackButton, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            let link = this.options.frame.getVisitedLink('context', 'main').link;
            this.$(document).trigger('app:frame:loadPage', [{ link }]);
        });

        if(!isMobile()) {
            this.$(document).on('mouseenter', this.options.suggestionItemLink, (ev) => this.mouseoverItemSuggestion(ev));
            this.$(document).on('mouseleave', this.options.suggestionItemLink, (ev) => this.mouseoutItemSuggestion(ev));
        }

        // on rainbow is ready enable click in search
        this.$(document).on('app:rainbow:ready', () => this.$(this.options.searchIcon).addClass(this.options.linkReady));

        this.$(document).on('app:drawer:ready', () => this.$(this.options.searchInput).blur());

        this.$(document).on('app:frame:willGet', () => {
            if(this.isUpdated == 1) {
                this.$(document).trigger('app:menu:updateComponents');
                this.isUpdated = 0;
            }
        });

        // if user change page, close menu
        this.$(document).on('app:frame:ready', (ev, data) => {
            this.$(this.options.searchInput).blur();

            if(!data.isModal && !data.isSearchMenuContext && this.$(this.options.menu).hasClass(this.options.menuOpen)) {
                this.cancelSuggestions();
                this.closeSearchMenu({name:'app:frame:ready', data: data});
            }
        });

        this.$(document).on('app:submenu:collapse', () => this.$(this.options.submenuParent).removeClass(this.options.submenuParentCollapsed));

        this.$(document).on('app:submenu:toggle', () => this.submenuToggle());
    }
}
