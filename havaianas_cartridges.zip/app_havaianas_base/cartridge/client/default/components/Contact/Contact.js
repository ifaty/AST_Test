import debounce from '../../utils/debounce';
import isMobile from '../../utils/isMobile';

export default class Contact {
    constructor(options) {

        const defaultOptions = {
            contactForm: '.js-contact-form',
            formInputs: '.form-control',
            contactFloatingLabel: '.contact__floating-label',
            contactTextArea: 'textarea.contact__input',
            inputZipCode: '#zipcode',
            inputStreet: '#street',
            inputCity: '#city',
            inputState: '#state',
            inputDoB: '#dob',
            submitBtn: '.submit__contact',
            invalidFeedback: '.invalid-feedback',
            selectorEngine: {},
            toast: {},
        };

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
    }

    submitContact(e) {
        if (!this.options.validator.validateForm(this.$(this.options.contactForm), true)) {
            return;
        }

        let form = this.$(e.target);
        let url = form.attr('action');
        $.ajax({
            url: url,
            type: 'post',
            dataType: 'json',
            data: form.serialize(),
            success: (data) => {
                if (data.success) {
                    this.options.toast.setOptions({
                            msgText: data.msg,
                            positionX: "left"
                        }).openToast();

                    this.$(this.options.contactForm).trigger('reset');
                    this.$(this.options.contactFloatingLabel).removeClass('active').addClass('empty');
                } else if (data.fields) {
                    this.options.validator.validateForm(this.$(this.options.contactForm), true, data.fields);
                } else {
                    this.options.toast
                        .setOptions({
                            type: "error",
                            msgText: data.msg,
                            positionX: "left"
                        })
                        .openToast();
                }
            },

            error: () => {
                this.options.toast
                    .setOptions({
                        type: "error",
                        msgText: "Sorry! something went wrong.",
                        positionX: "left"
                    })
                    .openToast();
            }
        });
        return false;
    }

    submitAutoCompleteAddress(zipCode) {
        let url = window.app.urls.autoCompleteAddress;
        this.$.ajax({
            type: 'GET',
            url: url,
            data: {
                postalCode: zipCode
            },
            success: (data) => {
                if (data.success) {
                    this.$(this.options.inputZipCode).val(zipCode);
                    this.$(this.options.inputStreet).val(data.address.address);
                    this.$(this.options.inputCity).val(data.address.city);
                    this.$(this.options.inputState).val(data.address.uf);
                }
                else {
                    this.options.toast
                        .setOptions({
                            type: 'error',
                            buttonMsg: 'Close',
                            msgText: JSON.stringify(data.errorMsg)
                        })
                        .openToast();
                }
            },
            error: () => {
                this.options.toast
                    .setOptions({
                        buttonOk: true,
                        buttonMsg: "Ok",
                        msgText: "Sorry! Something went wrong",
                        type: "error",
                    }).openToast();
            }
        });
    }

    validateContactForm(form, button) {
        if(this.options.validator.validateForm(this.$(form))) {
            this.$(button).addClass('is-active matrixTxtAsBgColor').removeAttr("disabled");
        } else {
            this.$(button).removeClass('is-active matrixTxtAsBgColor').attr( "disabled", "disabled" );
        }
    }

    activeSubmitButton(form, button) {
        this.$(form).find(this.options.formInputs).on('keyup change', () => {
            this.validateContactForm(form, button);
        });

        // Custom Select
        this.$(form).find(this.options.customSelects).on('click', (ev) => {
            let customInput = this.$(ev.currentTarget).find(this.options.customSelectHiddenInput);
            let error = this.$(customInput).data("missing-error");
            setTimeout(() => {$(customInput).siblings(this.options.invalidFeedback).html(`<i class="icon-alert"></i> <span>${error}</span>`)}, 300);

            if (customInput.val() != '') {
                $(customInput).siblings(this.options.invalidFeedback).html("");
            }

            this.$(this.options.customSelectDrawerItem).on('click', (ev) => {
                this.validateContactForm(form, button);
                $(customInput).siblings(this.options.invalidFeedback).html("");
            });
        })
    }

    checkValues(input) {
        let errors = this.options.invalidFeedback;

        this.$(input).on('blur', function(e) {
            if ($(e.currentTarget).prop('required')) {
                if ($(e.currentTarget).attr("pattern")) {
                    let error = $(e.currentTarget).data("pattern-mismatch");
                    let pattern = $(e.currentTarget).attr("pattern");

                    if (this.value.match(pattern)) {
                        $(this).siblings(errors).html("");
                    } else {
                        $(this).siblings(errors).html(`<i class="icon-alert"></i> <span>${error}</span>`);
                    }
                } else {
                    let error = $(e.currentTarget).data("missing-error");
                    if (this.value != '') {
                        $(this).siblings(errors).html("");
                    } else {
                        $(this).siblings(errors).html(`<i class="icon-alert"></i> <span>${error}</span>`);
                    }
                }
            }
        });
    }


    listen(){
        let contactSubmitDebounced = debounce((data) => {
            this.submitContact(data);
        }, 800, true);

        this.$(this.options.contactForm).off('submit').on('submit', (ev) => {
            ev.preventDefault();

            contactSubmitDebounced(ev);
        });

        this.$(this.options.formInput).each((i, element) => {
            this.checkFloatingLabel(element);
        });


        this.$('body').on('keypress click blur input', (ev) => {
            this.checkFloatingLabel(ev.target);
            this.activeSubmitButton(this.options.contactForm, this.options.submitBtn);
        });

        this.messageAutoResize(this.options.contactTextArea);

        this.checkValues(this.options.formInputs);

        this.clearFields();

    }

    messageAutoResize(textarea) {

        this.$(textarea).each(function (index, element) {
            element.style.boxSizing = 'border-box';
            var offset = element.offsetHeight - element.clientHeight;
            document.addEventListener('input', function (event) {
                event.target.style.height = 'auto';
                event.target.style.height = event.target.scrollHeight + offset + 'px';
            });
            element.removeAttribute('data-autoresize');
        });
    }

    checkFloatingLabel(input) {
        if (this.$(input).val().length >= 1) {
            this.$(input).siblings(this.options.contactFloatingLabel).removeClass('empty').addClass('active');
        } else {
            this.$(input).siblings(this.options.contactFloatingLabel).removeClass('active').addClass('empty');
        }
    }

    clearFields() {
        let inputs = $('.contact__input');

        inputs.each(function(i, item) {
            if ($(item).val()) {
                $(item).siblings('.contact__floating-label').addClass('active');
            }
        })
    }
}
