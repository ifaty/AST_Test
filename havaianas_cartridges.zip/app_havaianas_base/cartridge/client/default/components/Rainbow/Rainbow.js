import isMobile from '../../utils/isMobile';
import ASYNC from '../../utils/async';
import throttle from '../../utils/throttle';

export default class Rainbow extends ASYNC {
    constructor(options) {

        super(options);

        const defaultOptions = {
            selectorEngine: {},

            rainbowCursor: null,

            box: ".rainbow",
            selected: ".rainbow__selected",
            selectedGradient: ".rainbow__selected__gradient",
            selectedRemove: ".rainbow__selected li",
            placeholder: ".rainbow__placeholder",
            tutorial: ".rainbow__tutorial",
            tutorialItem: ".rainbow__tutorial >span",
            actions: ".rainbow__actions",
            slider: ".rainbow__slider",
            list: ".rainbow__list",
            color: ".rainbow__color",
            closeButton: ".rainbow__close",
            filterButton: ".rainbow__filter",
            clearButton: ".rainbow__clear",
            removeButton: ".rainbow__remove",
            hint: ".rainbow__hint",
            rainbowLoading: ".rainbowLoading",
            mainWrapper: '.rainbow-loading-wrapper',
            currentStorySection: '.story__section.is-current'

        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = isMobile() ? "tap" : "click";
        this.rainbowH = this.$(this.options.slider).find("li").eq(0).height();
        this.chosenColors = [];
        this.chosenColorsGradient = [];

        this.viewportWidth = this.$("body").outerWidth();
        this.colDesk = this.viewportWidth / 79;
        this.colMobile = this.viewportWidth / 11;
        this.firstTime = true;
        this.isListening = false;
        this.isMenusca = false;
        this.rainbowSize = 8 * 4;
        this.hasStoryColors = false;
        this.primaryStoryColor = null;
        this.colorsFromUrl = false;
        this.isScrolling = false;
    }


    addColorFilterArray(color) {
        this.chosenColors.push(color);
    }

    addColorFilterArrayGradient(color) {
        this.chosenColorsGradient.push(color);
    }


    removeColorFilterArray(color) {
        // to ignore case sensite
        color = color.toLowerCase();
        const colors = this.chosenColors.map(v => v.toLowerCase());

        var index = colors.indexOf(color);
        if (index > -1) {
            this.chosenColors.splice(index, 1);
        }

    }

    removeColorFilterArrayGradient(color) {

        var index = this.chosenColorsGradient.indexOf(color);
        if (index > -1) {
            this.chosenColorsGradient.splice(index, 1);
        }

    }

    cleanRainbowGradient() {
        if (isMobile()) {
            this.$(this.options.placeholder).css({ background: 'inherit' })
        }
    }

    //DEPRECATED
    showTutorials() {

        //remove this method
        return new Promise(resolve => {

            resolve();

        });

    }

    hideTutorialItens() {

        return new Promise(resolve => {

            setTimeout(() => {
                this.$(this.options.tutorialItem).removeClass('is-messageVisible');
                resolve();
            }, 150); // 300 is the css animation time

        });

    }

    showTutorialMessage(idx) {

        return new Promise(resolve => {

            this.$(this.options.tutorialItem).removeClass('is-messageVisible');
            this.$(this.options.tutorialItem).eq(idx).addClass('is-messageVisible');

            super.clearTimeout('rainbowMessages')
                 .clearableWait(3000, 'rainbowMessages')
                 .then(() => {
                    this.hideTutorialItens();
                 });

            resolve();
        });

    }

    hideTutorialMessage(idx) {

        return new Promise(resolve => {
            this.$(this.options.tutorialItem).eq(idx).clearQueue().stop().fadeOut(100, resolve);
        });

    }

    showRemoveButton(){

        this.$(this.options.removeButton).addClass('show')
        // this.$(this.options.selectedGradient).css({'opacity': 0})

    }

    hideRemoveButton(){

        this.$(this.options.removeButton).removeClass('show')
        // this.$(this.options.selectedGradient).css({'opacity': 1})

    }

    showFilterActions() {

        return new Promise(resolve => {
            this.$(this.options.actions).clearQueue().stop().fadeIn(300, resolve);
        });

    }

    hideFilterActions() {

        return new Promise(resolve => {
            this.$(this.options.actions).clearQueue().stop().fadeOut(100, resolve);
        });

    }

    setIsMenusca(isMenusca) {

        this.isMenusca = isMenusca || false;

        return this;
    }

    rainbowInMenusca(reason) {

        let reasonTargetIsRainbow = reason.data ? this.$(reason.data.fromTarget.currentTarget).parents(this.options.box).length : false;

        if (!reasonTargetIsRainbow || reason.name == 'menuBackButton') {
            this.mouseLeaveRainbow();
        } else if (reason.name == 'app:frame:ready') {
            this.$(this.options.box).addClass('is-openedInMenusca');
            this.mouseEnterRainbow();
        }
    }

    addColorFilter(colorname, bgColor) {
        // debugger;

        if(this.chosenColors.length < 3) {
            if(!this.chosenColors.includes(colorname)) {
                this.addColorFilterArray(colorname);
                this.addColorFilterArrayGradient(bgColor);
                this.plusSelectedColorMarkup(colorname, bgColor);
                this.animateSelectedColorsHeight();
                this.doRainbowWithSelectedColors();
                this.showRemoveButton();

                // if(!isMobile()) setTimeout(() => this.hideRemoveButton(), 2000);

                this.showTutorialMessage(this.chosenColors.length)
                    .then(() => {
                        setTimeout(() => {
                            // this.hideTutorialItens();
                            this.hideRemoveButton();
                        }, 2000);
                    });

                if(this.chosenColors.length == 1) {
                    this.$(this.options.box).addClass('has-filters');
                    this.animateSelectedColorsWidth();
                }
            }

            this.$(document).trigger("app:rainbow:filter", [{ chosenColors: this.chosenColors }]);

        } else {
            this.showTutorialMessage(4);
        }

        setTimeout(() => {
            if(!isMobile())
                this.fadeInSelectedGradient()
                this.animateSelectedColorsMouseleaveDesktop();
        }, 800)

    }

    animateSelectedColorsWidthDesktop() {

        return new Promise(resolve => {

            this.$(this.options.selected)
                .animate({width: `${this.colDesk * 2}px`, opacity: 1}, {
                    duration: 300,
                    easing: "linear",
                    complete: resolve
                })
        });

    }

    animateSelectedColorsMouseenterDesktop() {

        return new Promise(resolve => {
            if(isMobile()) return resolve();

            this.$(`${this.options.selected}, ${this.options.selectedGradient}`)
                .clearQueue()
                .animate({ width: `${this.colDesk * 3}px` }, {
                    duration: 150,
                    easing: "linear",
                    complete: resolve
                });
        });

    }

    animateSelectedColorsMouseleaveDesktop() {

        return new Promise(resolve => {
            if(isMobile()) return resolve();

            this.$(this.options.selected)
            .clearQueue()
            .animate({
                        width: `${this.colDesk * 2}px`
                    }, {
                duration: 150,
                easing: "linear",
                complete: () => {
                    resolve();
                    // setTimeout(() => {
                    //     // this.$(this.options.box).removeClass("is-expanded");
                    // }, 500);
                }
            });
        });

    }

    collapseSelectedColorsWidthDesktop(ms) {

        return new Promise(resolve => {

            this.$(this.options.selected)
                .animate({width: "0px", opacity: 0}, {
                    duration: 300,
                    easing: "linear",
                    complete: resolve
                })
        });

    }

    animateSelectedColorsWidth() {
        if(!isMobile()) return this.animateSelectedColorsWidthDesktop();

        return new Promise(resolve => {

            let widthMobile = `${(100 / 9)}%`;
            let widthDesk = `${this.colDesk * 2}px`;

            let width = isMobile() ? widthMobile : widthDesk;

            this.$(this.options.selected)
                .animate({width: `${width}`, opacity: 1}, {
                    duration: 300,
                    easing: "linear",
                    complete: resolve
                })
        });

    }

    collapseSelectedColorsWidth(ms) {

        if(!isMobile()) return this.collapseSelectedColorsWidthDesktop(ms);

        let duration = ms || 300;

        return new Promise(resolve => {

            this.$(this.options.selected)
                .animate({width: 0, opacity: 0}, {
                    duration: 0,
                    easing: "linear",
                    complete: resolve
                })
        });

    }

    plusSelectedColorMarkup(colorName, bgColor) {

        let selectedItem = this.$(`<li data-colorName="${colorName}" data-colorbackground="${bgColor}" style="background-color: ${bgColor}"><button class="rainbow__remove">Remove</button></li>`);

        selectedItem.appendTo(this.$(this.options.selected));

    }

    animateSelectedColorsHeight() {

        return new Promise(resolve => {

            let percentHeight = (100 / this.chosenColors.length);
            let duration = this.chosenColors.length > 1 ? 300 : 0;

            this.$(this.options.selected).find("> li")
                .animate({height: `${percentHeight}%`}, {
                    duration: 0,
                    easing: "linear",
                    complete: resolve
                })
        });

    }

    removeColorFilter(ev = '', colorName = '', colorBackground = '') {
        if(ev) {
            colorName = (this.$(ev.currentTarget).data("colorname")).substr(0, 1).toUpperCase() + (this.$(ev.currentTarget).data("colorname")).substr(1);
            colorBackground = this.$(`${this.options.selectedRemove}[data-colorname="${colorName}"]`).data("colorbackground");
        }

        // to ignore case sensite
        const testColorName = new RegExp( this.chosenColors.join( "|" ), "i");
        if(testColorName.test(colorName)) {
            this.removeColorFilterArray(colorName);
            this.removeColorFilterArrayGradient(colorBackground);
        }

        if(this.chosenColors.length == 0) {
            this.clearAllColors();
            setTimeout(() => {
                if(ev) {
                    this.$(ev.currentTarget).remove();
                    this.animateSelectedColorsHeight();
                }
            }, 300);
        } else {
            this.$(`${this.options.selectedRemove}[data-colorname="${colorName}" i]`).remove();
            this.$(document).trigger("app:rainbow:filter", [{ chosenColors: this.chosenColors }]);

            if(ev) this.$(ev.target).remove();
            this.animateSelectedColorsHeight();
            this.doRainbowWithSelectedColors();
        }

    }

    doRainbowWithSelectedColors() {
        let gradient = this.chosenColorsGradient.join(",");

        if(this.chosenColorsGradient.length > 1) {
            this.$(this.options.selectedGradient).css({
                background: `linear-gradient(180deg,${gradient})`
            })
        } else {
            this.$(this.options.selectedGradient).css({
                background: gradient
            });
        }

        this.$(this.options.box).css({
            background: `linear-gradient(-233deg,${gradient})`,
            backgroundSize: "100%"
        })

        this.$(this.options.placeholder).css({
            background: `linear-gradient(-233deg,${gradient})`,
            backgroundSize: "100%"
        });

    }


    fadeInSelectedGradient() {

        return new Promise(resolve => {

            if(isMobile()) return resolve();
            if(this.chosenColorsGradient.length < 1) return resolve();

            this.$(this.options.selectedGradient).stop().animate({
                        // opacity: 1,
                        width: `${this.colDesk * 2}px`
                    }, {
                        duration: 300,
                        complete: () => {
                resolve()
            }});

        });

    }

    fadeInSelectedGradientCollapsed() {
        return new Promise(resolve => {
            if(isMobile()) return resolve();

            if(this.chosenColorsGradient.length < 1) return resolve();

            this.$(this.options.selectedGradient).css({width: `${this.colDesk * 2}px` })
            // this.$(this.options.selectedGradient).stop().animate({opacity: 1}, {duration: 300, complete: () => {
                resolve()
            // }});

        });

    }

    fadeOutSelectedAndGradient() {

        return new Promise(resolve => {
            this.$(`${this.options.selectedGradient}, ${this.options.selected}`)
                .stop()
                .animate({opacity: 0, width: 0}, {duration: 300, complete: () => {
                resolve()
            }});
        });

    }

    fadeInSelectedAndGradient() {

        return new Promise(resolve => {
            this.$(`${this.options.selectedGradient}, ${this.options.selected}`)
                .stop()
                .animate({opacity: 1, width: `${this.colDesk * 2}px`}, {duration: 300, complete: () => {
                resolve()
            }});
        });

    }

    clearAllColorsScreen() {

        this.chosenColorsGradient = [];
        this.chosenColors = [];
        this.doRainbowWithSelectedColors();

        // this.fadeOutSelectedGradient();
        this.collapseSelectedColorsWidth().then(() => {
            this.$(this.options.selectedRemove).remove();
        });

        return this;
    }

    clearAllColors() {
        // debugger;

        this.clearAllColorsScreen();

        this.$(this.options.box).removeClass('has-filters');

        this.showTutorialMessage(6);

        this.$(document).trigger("app:rainbow:filter", [{ chosenColors: this.chosenColors }]);

    }

    expandDesktop(ms) {

        // debugger;

        let duration = ms || 500;
        let sidebarWidth = (this.viewportWidth/79) * 18;

        if(this.isMenusca) sidebarWidth = (this.viewportWidth/79) * 9;

        let selectedColorsWidth = (this.viewportWidth/79) * 2;

        return new Promise(resolve => {

            this.$(this.options.box)
                .animate({top: 0, right: 0, width: `${sidebarWidth}px`}, {
                    duration: duration,
                    easing: "linear",
                })

            this.$(this.options.list)
                .animate({opacity: 1}, {
                    duration: duration,
                    easing: "linear",
                    complete: () => {

                        this.showFilterActions();

                        if (this.isMenusca) {
                            this.showTutorialMessage(5);
                        } else {
                            this.showTutorialMessage(0);
                        }

                        if(this.chosenColors.length > 0) {
                            //this.animateSelectedColorsWidth();
                        }

                        this.$(this.options.list).css({pointerEvents: "all", height: "100%", width: "100%"});
                        //this.$(this.options.selected).css({width: `${selectedColorsWidth}px`});

                        resolve()
                    }
                });

            this.$('body').addClass('is-rainbow-expanded');

        });

    }

    expand(ms) {

        this.$(this.options.box)
            .addClass('is-expanded');

        if(!isMobile()) return this.expandDesktop();

        let duration = ms || 500;

        return new Promise(resolve => {

            this.$(this.options.box)
                .animate({top: 0, right: 0}, {
                    duration: duration,
                    easing: "linear",
                    queue: false
                })

            this.$(this.options.placeholder)
                .animate({width: "300vh", height: "300vh", backgroundSize: "400%"}, {
                    duration: duration,
                    easing: "swing",
                    queue: false
                })

            this.$(this.options.list)
                .animate({opacity: 1}, {
                    duration: duration,
                    easing: "swing",
                    queue: true,
                    complete: () => {

                        if(this.chosenColors.length > 0) {
                            this.animateSelectedColorsWidth();
                        }

                        this.$(`${this.options.selected}`).css({opacity: 1});
                        this.$(this.options.list).css({pointerEvents: "all", height: "100%", width: "100%"});
                        this.$(this.options.box).css({pointerEvents: "all", height: "100%", width: "100%"});

                        this.showTutorialMessage(0);

                        resolve();
                    }
                })
        });
    }

    hideRainbowLoading() {

        return new Promise(resolve => {
            this.$(this.options.rainbowLoading).stop().fadeOut(() => {
                this.$(document).trigger('app:rainbow:isReady');
                this.$('body').addClass('rainbow-attached');
                resolve();
            })
        });

    }

    collapseDesktop(ms) {

        let duration = ms || 300;

        // this.fadeInSelectedGradientCollapsed();
        this.hideTutorialItens();
        this.hideFilterActions();

        return new Promise(resolve => {

            const collapseAnim = anime({
                targets: this.options.box,
                width: this.colDesk * 2,
                autoplay: false,
                duration: 800,
                easing: 'easeOutQuint',
                complete: () => {
                    resolve()
                }
            });

            return collapseAnim.play();

        });

        this.$('body').removeClass('is-rainbow-expanded');

    }

    collapse(ms) {

        this.$(this.options.box)
            .removeClass('is-expanded');

        if(!isMobile()) return this.collapseDesktop(ms);

        let duration = ms || 300;

        return new Promise(resolve => {

            this.$(this.options.list).stop();
            this.$(this.options.box).stop();
            this.$(this.options.placeholder).stop();

            this.$(`${this.options.selected}`).css({opacity: 0});
            return setTimeout(async () => { //weiting css close button animation

                this.$(this.options.list).css({pointerEvents: "none"});
                this.$(this.options.box).css({height: (this.rainbowSize), width: (this.rainbowSize)});

                return this.$(this.options.list)
                    .animate({opacity: "0"}, {
                        duration: duration,
                        easing: "linear",
                        complete: () => {

                            this.$(this.options.box)
                                .animate({top: (8 * 4.5), right: this.colMobile}, {
                                    duration: duration,
                                    easing: "linear",
                                    queue: false
                                })

                            this.$(this.options.placeholder)
                                .animate({width: (this.rainbowSize), height: (this.rainbowSize), opacity: 1, backgroundSize: "100%"}, {
                                    duration: duration,
                                    easing: "swing",
                                    queue: false,
                                    complete: () => {
                                        resolve()
                                    }
                                })
                        }
                    })

            }, 150);

        });

    }

    //need adjusts
    //throttle
    doLoopingClone() {

        let fold = 0;
        let firstScroll = 0;
        let hints = 0;
        let childs = {
            first: this.$(this.options.slider).find(">li").eq(0),
            second: this.$(this.options.slider).find(">li").eq(1),
            third: this.$(this.options.slider).find(">li").eq(2)
        }

        if (this.firstTime) {
            this.prependChilds(childs);
            if (!this.hasStoryColors) {
                this.$(this.options.slider).scrollTop(this.rainbowH * 3);
            }
            this.firstTime = false;
        }

        this.$(this.options.slider).on("scroll", (ev) => {
            // this.changeTutorialColor(ev);
            this.showRainbowHint(true);

            firstScroll = firstScroll || ev.target.scrollTop;

            if (Math.abs(ev.target.scrollTop - firstScroll) >= 500 && Math.abs(ev.target.scrollTop - firstScroll) <= 700 && !hints) {
                this.showTutorialMessage(7);
                hints = 1;
            }

            if (Math.abs(ev.target.scrollTop - firstScroll) >= 3000 && Math.abs(ev.target.scrollTop - firstScroll) <= 3200 && hints == 1){
                this.showTutorialMessage(8);
                hints = 2;
            }

            // get rainbow slider height, multiplies by <li> elements quantity and subtracts original slider height
            fold = (this.$(this.options.slider).first().find(">li").length * this.rainbowH) - this.$(this.options.slider).height();


            if(ev.target.scrollTop >= fold - 200 && ev.target.scrollTop <= fold) { // scroll bottom

                this.appendChilds(childs);
                this.removeChilds();
            }

            if(ev.target.scrollTop > 0 && ev.target.scrollTop < 200) { // scroll top

                this.prependChilds(childs);
                this.removeChilds()

            }

        });

    }

    appendChilds(childs) {
        childs.first.clone(true).appendTo(this.$(this.options.slider));
        childs.second.clone(true).appendTo(this.$(this.options.slider));
        childs.third.clone(true).appendTo(this.$(this.options.slider));
    }

    prependChilds(childs) {
        childs.first.clone(true).prependTo(this.$(this.options.slider));
        childs.second.clone(true).prependTo(this.$(this.options.slider));
        childs.third.clone(true).prependTo(this.$(this.options.slider));
    }

    removeChilds() {
        this.$(this.options.slider).find(">li").eq(0).remove();
        this.$(this.options.slider).find(">li").eq(1).remove();
        this.$(this.options.slider).find(">li").eq(2).remove();
    }

    changeGradientColor(firstColor, secondColor, thirdColor) {
        // Clear filters
        this.chosenColors = [];
        this.chosenColorsGradient = [];
        this.$(this.options.selected).fadeOut(300);

        let background;

        firstColor = this.$(`${this.options.color}[data-colorname="${firstColor}"]`).data('colorbackground');
        secondColor = this.$(`${this.options.color}[data-colorname="${secondColor}"]`).data('colorbackground');
        thirdColor = this.$(`${this.options.color}[data-colorname="${thirdColor}"]`).data('colorbackground');

        if(firstColor && secondColor && thirdColor) {
            background = `linear-gradient(180deg, ${thirdColor}, ${secondColor}, ${firstColor})`;
        } else if(firstColor && secondColor) {
            background = `linear-gradient(180deg, ${secondColor}, ${firstColor})`;
        } else {
            background = firstColor;
        }

        this.$(this.options.selectedGradient)
            .css({
                width: `${this.colDesk * 2}px`,
                background
            })
            // .animate({ opacity: 1 }, 200);
    }

    gradientRainbowDefault() {
        this.$(this.options.selectedGradient)
            .animate({ opacity: 0 }, 200);
    }

    hideRainbow() {
        this.$(this.options.box).fadeOut(200);
    }

    showRainbow() {
        this.$(this.options.box).fadeIn(200);
    }

    setIsClosedHistory() {

    }

    listenMouseMove() {

        if (!isMobile()) {

            let throttledMousemove = throttle(() => {
                this.showRainbowHint();
            }, 1);

            this.$(this.options.box).on('mousemove', throttledMousemove);

            this.$(document).on('mousemove', e => {
                this.e = e;
            }).trigger('mousemove');

        }
    }

    showRainbowHint(isScrolling) {

        this.isScrolling = isScrolling;

        if (this.e.clientY > $(window).height() * 0.6) {
            if(this.isScrolling) {
               this.hideCollapseRainbowHint();
            } else {
                this.mouseEnterRainbowFooter();
            }
        } else {
            this.mouseLeaveRainbowFooter();
        }
    }

    listenExternalEvents() {
        this.$(document).on('app:rainbow:removeColorFilter', (ev, data) => {
            const colorName = data.colorName;
            const colorBackground = data.colorBackground;
            if(colorName && colorBackground) {
                this.removeColorFilter(false, colorName, colorBackground)
            }
        });

        if (!isMobile()) {

            this.$(document)
                .on("app:menusca:willClose", (ev, data) => {

                    console.log("app:menusca:willClose", data);

                    this.hideTutorialItens();

                });

            this.$(document)
                .on("app:menusca:closed", (ev, data) => {

                    console.log("app:menusca:closed", data);

                    this.setIsMenusca(false).rainbowInMenusca(data.reason);

                });

            this.$(document)
                .on("app:menusca:willOpen", () => {
                    console.log("app:menusca:willOpen");
                    this.clearAllColorsScreen();
                    // this.fadeOutSelectedAndGradient();
                    this.setIsMenusca(true)
                        .hideTutorialItens()
                            .then(() => this.showTutorialMessage(5))
                            .then(() => this.hideFilterActions())
                            .then(() => this.mouseEnterRainbow())
                });
        }


        this.$(document)
            .on("app:menusca:changeGradient", (ev, data) => {

                let [firstRainbowColor, secondRainbowColor, thirdRainbowColor] = data.chosenColors;

                this.changeGradientColor(firstRainbowColor, secondRainbowColor, thirdRainbowColor);

                // if (isMobile()) this.hideRainbow();
            });

        this.$(document)
            .on("app:menusca:resetRainbow", () => {
                this.gradientRainbowDefault();
            });

        this.$(document)
            .on("app:menusca:close", () => {
                // if (isMobile()) this.showRainbow();
            });

        this.$(document)
            .on("app:menusca:open", () => {
                // if (isMobile()) this.hideRainbow();
            });

        this.$(document)
            .on('app:rainbow:storyColorsToRainbow', (ev, currentStory) => {
                this.storyColorsToRainbow(currentStory);
            });

        return this;

    }

    listenInternalEvents() {
        this.$(document)
            .on("app:rainbow:collapse", () => {
                console.log('app:rainbow:collapse event');
                this.hideTutorialItens();
                // this.collapseSelectedColorsWidth(0);
                this.hideFilterActions();
                this.hideCollapseRainbowHint();
                this.collapse(400);

                // this.fadeInSelectedGradient();
                this.animateSelectedColorsMouseleaveDesktop();
            })

        this.$(document)
            .on("app:rainbow:expand", () => {
                console.log('app:rainbow:expand event');

                this.expand()
                    .then(() => {
                        this.doLoopingClone();
                        this.showFilterActions();
                        this.relocateRainbowGradient();
                        this.showCollapseRainbowHint();

                        console.log("expand animation done")
                    });
            });
    }



    // DISCOVERY X RAINBOW

    storyColorsToRainbow(currentStory) {
        // debugger

        let colors = $(currentStory).find(".color-matrix").first();

        let firstRainbowColor = colors.data('colormatrix').primaryColor || '';
        let secondRainbowColor = colors.data('colormatrix').secondRainbowColor ? colors.data('colormatrix').secondRainbowColor : '';
        let thirdRainbowColor = colors.data('colormatrix').thirdRainbowColor ? colors.data('colormatrix').thirdRainbowColor : '';

        this.hasStoryColors = true;
        this.primaryStoryColor = firstRainbowColor;

        this.changeDiscoveryRainbowGradientColor(firstRainbowColor, secondRainbowColor, thirdRainbowColor);
        this.scrollToColor(currentStory);

        return this;

    }

    changeDiscoveryRainbowGradientColor(firstColor, secondColor, thirdColor) {
        // debugger
        // Clear filters
        this.chosenColors = [];
        this.chosenColorsGradient = [];
        // this.$(this.options.selected).fadeOut(300);

        let background;

        firstColor = this.$(`${this.options.color}[data-colorid="${firstColor}" i]`).data('colorbackground');
        secondColor = this.$(`${this.options.color}[data-colorid="${secondColor}" i]`).data('colorbackground');
        thirdColor = this.$(`${this.options.color}[data-colorid="${thirdColor}" i]`).data('colorbackground');

        if (firstColor && secondColor && thirdColor) {
            background = `linear-gradient(${isMobile() ? '-45deg' : '180deg'}, ${thirdColor}, ${secondColor}, ${firstColor})`;
        } else if (firstColor && secondColor) {
            background = `linear-gradient(${isMobile() ? '-45deg' : '180deg'}, ${secondColor}, ${firstColor})`;
        } else {
            background = `linear-gradient(${isMobile() ? '-45deg' : '180deg'}, ${firstColor}, #FFFFFF)`;
        }

        this.$(this.options.selectedGradient)
        .css({
            width: `${this.colDesk * 2}px`,
            background
        })

        if (isMobile()) {

            this.$(this.options.placeholder).css({background: background})
        }

        return this;

    }

    scrollToColor(currentStory) {
        // debugger
        let rainbow = $(".rainbow__slider");
        let currentColor = $(currentStory).find(".color-matrix").data('colormatrix').primaryColor;
        let rainbowColor = $(`.rainbow__color[data-colorid='${currentColor}' i]`).first()

        this.$(this.options.list).animate({ opacity: 1 });

        if (rainbowColor) {
            rainbow.scrollTop(rainbow.scrollTop() + (rainbowColor.offset().top - (rainbowColor.height() * 1.5)));
        }

        return this;
    }

    setUrlColors() {
        this.urlColors = this.$("#search-url").data("localizedselectedcolors") || [];
        this.colorsFromUrl = true;

        return this;
    }

    addUrlColorsToFilter() {
        // debugger
        if (this.urlColors.length >= 1 && this.urlColors != "") {

            for (let index = 0; index < this.urlColors.length; index++) {
                const currentColor = this.urlColors[index];

                 let colorname = currentColor;
                 let bgColor = this.$(`[data-colorid="${currentColor}" i]`).eq(0).data("colorbackground");

                this.addColorFilterArray(colorname);
                this.addColorFilterArrayGradient(bgColor);
                this.plusSelectedColorMarkup(colorname, bgColor);

                if (index == this.urlColors.length -1) {
                    setTimeout(() => {
                        this.animateSelectedColorsHeight();
                        this.doRainbowWithSelectedColors();
                        this.showRemoveButton();
                    }, 600);
                }

            }

            setTimeout(() => {
                if (!isMobile())
                    this.fadeInSelectedGradient()
                    this.animateSelectedColorsMouseleaveDesktop();
                }, 800);

            this.$(document)
                .trigger("app:rainbow:collapse")
                .trigger("app:rainbow:filter", [{ chosenColors: this.chosenColors }]);

        }

        return this;

    }

    listen() {
        // if this function has already been called won't call it again
        if(this.isListening) return;
        this.isListening = true;

        this.listenInternalEvents();
        this.listenExternalEvents();

        this.setUrlColors().addUrlColorsToFilter();
        this.listenMouseMove();

        this.$(this.options.clearButton).on('click', (ev) => {
            ev.stopPropagation();
            this.$(document).trigger("app:rainbow:clearButton");
        });

        this.$(this.options.color).bind(this.tapEvent, (ev) => {
            ev.stopPropagation();

            let colorname = $(ev.target).data("colorname");
            let bgColor = $(ev.target).data("colorbackground");

            this.cleanRainbowGradient();
            this.addColorFilter(colorname, bgColor);

            this.$(document).trigger("app:rainbow:choseColor");

        });

        this.$("body").on('click', this.options.selectedRemove, (ev) => {
            ev.stopPropagation();
            this.removeColorFilter(ev);
            this.$(document).trigger("app:rainbow:removeColor");
        });

        if (isMobile()) {
            this.$(this.options.box).bind('click', (ev) => {
                this.$(document).trigger("app:rainbow:expand");
                this.$(this.options.mainWrapper).addClass('is-expanded');
            });

            this.$(this.options.closeButton).on('click', (ev) => {

                ev.stopPropagation();

                this.$(document).trigger("app:rainbow:collapse");
                this.$(this.options.mainWrapper).removeClass('is-expanded');

            });

            this.$(this.options.filterButton).on('click', (ev) => {
                ev.stopPropagation();

                this.$(this.options.closeButton).trigger('click');
            });
        }

        //desktop events
        if(!isMobile()) {

            this.$(this.options.box).on('mouseenter', function(ev) {
                ev.stopPropagation();

                if (this.isMenusca) return;

                this.mouseEnterRainbow();

            }.bind(this));

            this.$(this.options.box).on('mouseleave', function(ev) {
                ev.stopPropagation();
                ev.preventDefault();

                if (this.isMenusca) return;

                this.mouseLeaveRainbow();

            }.bind(this));

            this.$(this.options.selected).on('mouseover', function (ev) {
                // this.fadeOutSelectedGradient();
                this.animateSelectedColorsMouseenterDesktop();
            }.bind(this));

            this.$(this.options.selected).on('mouseleave', function (ev) {

                this.animateSelectedColorsMouseleaveDesktop();
                this.fadeInSelectedGradient();
            }.bind(this));

            this.$(this.options.clearButton).on('click', function(ev) {
                this.clearAllColors();
            }.bind(this));
        }

    }

    relocateRainbowGradient () {
        let colorEl = this.$(this.options.color).eq(0);
        let relocation = this.$(colorEl).height() ? this.$(colorEl).height() / 2 : 0;
        this.$(this.options.slider).find('> li').css('background-position', '0 ' + relocation + 'px');
    }

    mouseEnterRainbow() {

        clearTimeout(this.$(this.options.box).data('timeoutLeave'));

        if (this.$(this.options.box).hasClass("is-expanded") && !this.$(this.options.box).hasClass('is-openedInMenusca')) return;

        this.$(this.options.box).data('timeoutEnter', setTimeout(() => {

            this.$(document).trigger("app:rainbow:expand");
            this.$(this.options.box).addClass("is-expanded");
            this.$(this.options.box).removeClass('is-openedInMenusca');

        }, 200 ));
    }

    mouseLeaveRainbow() {
        clearTimeout(this.$(this.options.box).data('timeoutEnter'));

        if (!this.$(this.options.box).hasClass("is-expanded")) return;

        this.$(this.options.box).data('timeoutLeave', setTimeout(() => {

            this.$(document).trigger("app:rainbow:collapse");

        }, 400));
    }

    mouseEnterRainbowFooter() {
        this.$(this.options.hint).addClass("is-visible");
    }

    mouseLeaveRainbowFooter() {
        this.$(this.options.hint).removeClass("is-visible");
    }

    hideCollapseRainbowHint() {
        this.$(this.options.hint).css('display','none');
    }

    showCollapseRainbowHint() {
        this.$(this.options.hint).css('display','block');
    }

    fadeIn(ms) {

        let duration = ms || 300;

        return new Promise(resolve => {
            this.$(this.options.box).stop().fadeIn(duration, resolve);
        });

    }
}
