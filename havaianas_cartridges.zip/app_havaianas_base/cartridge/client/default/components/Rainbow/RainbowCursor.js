import isMobile from '../../utils/isMobile';
import throttle from '../../utils/throttle';

export default class RainbowCursor {
    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},

            box: ".rainbow__list",
            color: ".rainbow__color",
            selected: ".rainbow__selected",
            actions: ".rainbow__actions",
            tutorial: ".rainbow__tutorial",

            customCursor: "#mouse",
            customCursorFlipflopLeft: ".rainbow__cursor__flipflop-left",
            customCursorFlipflopRight: ".rainbow__cursor__flipflop-right",
            customCursorPlus: ".rainbow__cursor__plus",
            customCursorPlusBackground: ".rainbow__cursor__plus-background",

            clearButton: ".rainbow__clear",

            // classes
            cursorActive: 'is-active',
            cursorClearActive: 'is-clear',
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.isAnimating = false;
        this.isClicked = false;

        this.rFeetMove;
        this.lFeetMove;
        this.lFeetClick;
        this.rFeetClick;
        this.addCircle;

        this.oldX = 0;
        this.oldY = 0;
        this.directionX = 0;
        this.directionY = 0;

        //auto start by defult in desktops
        if (!isMobile()) {
            this.init();
        }
    }

    init() {
        this.prepare()
            .setupMoveAnimation()
            .setupClickAnaimation()
            .setupCircleAnimation()
            .listenMouse();

        return this;
    }

    prepare() {
        this.rFoot = this.$(this.options.customCursorFlipflopRight)[0];
        this.lFoot = this.$(this.options.customCursorFlipflopLeft)[0];
        this.addCircle = this.$(this.options.customCursorPlus)[0];

        return this;
    }

    setupMoveAnimation() {

        // Settings move
        const settingsMove = {
            autoplay: false,
            easing: 'spring(1, 100, 5, 50)',
            complete: () => {
                this.isAnimating = false
            }
        }

        this.rFeetMove = anime({
            targets: this.rFoot,
            autoplay: false,
            rotate: [{
                value: 5
            }],
            ...settingsMove
        })

        this.lFeetMove = anime({
            targets: this.lFoot,
            autoplay: false,
            rotate: [{
                value: -5
            }],
            ...settingsMove
        });

        return this;

    }

    setupClickAnaimation() {

        // Settings click
        const settingsClick = {
            autoplay: false,
            easing: 'spring(1, 100, 15, 20)',
        }

        this.rFeetClick = anime.timeline({
            ...settingsClick
        });

        this.rFeetClick
            .add({
                targets: this.rFoot,
                translateX: 10,
                rotate: -3
            })
            .add({
                targets: this.rFoot,
                translateX: 0,
                rotate: 0
            });

        this.lFeetClick = anime.timeline({
            ...settingsClick
        });

        this.lFeetClick
            .add({
                targets: this.lFoot,
                translateX: -10,
                rotate: 3
            })
            .add({
                targets: this.lFoot,
                translateX: 0,
                rotate: 0
            });

        return this;

    }

    setupCircleAnimation() {

        // Circle animation
        this.addCircleAnimation = anime({
            targets: this.addCircle,
            scale: ['0', '1'],
            opacity: ['0', '1'],
            autoplay: false,
            easing: 'spring(1, 100, 15, 20)',
            complete: () => {
                this.addCircleAnimationRes.play();
                this.addCircleAnimationRes.restart();
            }
        });

        this.addCircleAnimationRes = anime({
            targets: this.addCircle,
            scale: ['1', '0'],
            opacity: ['1', '0'],
            easing: 'easeOutExpo',
            complete: () => {
                this.isClicked = false
            }
        });

        return this;

    }

    animateCursorMove() {
        this.$(this.options.customCursor).css({
            transform: `translate(${(this.e.clientX - 50)}px, ${(this.e.clientY - 50)}px )`,
            '-webkit-transform': `translate(${(this.e.clientX - 50)}px, ${(this.e.clientY - 50)}px )`
        });

        if (!this.isAnimating && !this.isClicked) {
            this.isAnimating = true;
            this.rFeetMove.play();
            this.rFeetMove.restart();
            this.lFeetMove.play();
            this.lFeetMove.restart();
        }
    }

    detectMouseDirection() {

        let diffX = 0;
        let diffY = 0;

        if (this.e.pageX < this.oldX) {
            this.directionX = "left"
            // diffX = this.oldX - this.e.pageX;
        } else if (this.e.pageX > this.oldX) {
            this.directionX = "right"
            // diffX = this.e.pageX - this.oldX;
        }

        if (this.e.pageY < this.oldY) {
            this.directionY = "top"
            // diffY = this.oldY - this.e.pageY;
        } else if (this.e.pageY > this.oldY) {
            this.directionY = "bottom";
            // diffY = this.e.pageY - this.oldY;
        }

        this.oldX = this.e.pageX;
        this.oldY = this.e.pageY;
    }

    listenMouse() {

        let throttledMousemove = throttle(() => {
            this.animateCursorMove();
        }, 1);

        this.$(this.options.box).on('mousemove', throttledMousemove);

        this.$(this.options.clearButton).on('mousemove', throttledMousemove);

        this.$(document).on('mousemove', e => {
            this.e = e;
        }).trigger('mousemove');

        this.$(`${this.options.box}`).on('mouseleave', () => {
            this.$(this.options.customCursor).removeClass(this.options.cursorActive);
        });

        this.$(`${this.options.color}`).on('mouseenter', () => {
            this.$(this.options.customCursor).addClass(this.options.cursorActive);
        });

        this.$(`${this.options.clearButton}`).on('mouseenter', () => {
            this.$(this.options.customCursor)
                .removeClass(this.options.cursorActive)
                .addClass(this.options.cursorClearActive);
        });

        // on click remove clear icon
        this.$(`${this.options.clearButton}`).on('click', () => {
            this.$(`${this.options.clearButton}`).trigger('mouseleave');
        });

        this.$(`${this.options.clearButton}`).on('mouseleave', () => {
            this.$(this.options.customCursor)
                .removeClass(this.options.cursorClearActive)
                .addClass(this.options.cursorActive);
        });

        this.$(document).on("app:rainbow:collapse", () => {
            this.$(this.options.customCursor).removeClass(this.options.cursorActive);
        })

        this.$(this.options.color).on('click', () => {
            this.isClicked = true;
            this.rFeetClick.play();
            this.rFeetClick.restart();
            this.lFeetClick.play();
            this.lFeetClick.restart();
            this.addCircleAnimation.play();
            this.addCircleAnimation.restart();
        });

        return this;
    }
}
