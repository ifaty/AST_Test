import isMobile from '../../utils/isMobile';

export default class ProductBuyButton {
    constructor(options) {

        const defaultOptions = {
            buyBtn: '#buy__button',
            buyBtnLabel: '#buy__button > .product__button-label',
            productBtnsContainer: '.product__button__container',

            payContainer: '.superActions__payButton__container',
            payBtn: '#pay__button',
            payBtnVisibleClass: 'product__pay-button__visible',
            payBtnLabel: '#pay__button > .product__button-label',

            drawerSize: '.drawer__choose-size',
            drawerSizeTitle: '.drawer__choose-size__title',

            sizeGuideDesktop: '.product__buy__size-guide',
            sizeLink: '.size__link',

            productHeroImage: '.js-product__hero-image',
            productBuyButtonHeroImageContainer: '.product__buy-button__hero-image',
            productBuyButtonHeroImage: '.product__buy-button__hero-image img',
            productBuyButtonHeroOverlay: '.product__buy-button__overlay',

            productCartCounter: '.product__pay-button__counter',

            colorMatrix: '.color-matrix',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.viewportWidth = this.$(".pages-viewport").outerWidth();
        this.viewportHeight = this.$(".pages-viewport").outerHeight();
        this.colDesk = this.viewportWidth / 79;
        this.colorMatrixData;

        this.tapEvent = "click";
    }

    animateProductToCart(quantityTotal) {
        this.showBuyHeroImage().then(() => {

            this.showPayButton();
            this.showCounter(quantityTotal);
            this.collapseBuyHeroAnimation();

        });

    }

    animateProductTileToCart(quantityTotal) {

        this.showCounter(quantityTotal);
        this.showPayButton();

    }

    showBuyHeroImage() {
        return new Promise((resolve, reject) => {
            this.$(this.options.productBuyButtonHeroImageContainer).stop().fadeIn(300, resolve);
        });
    }

    collapseBuyHeroAnimation() {
        return new Promise((resolve, reject) => {
            let heroImage = this.$(this.options.productBuyButtonHeroImage);
            let heroOverlay = this.$(this.options.productBuyButtonHeroOverlay);

            this.viewportWidth = this.$(".pages-viewport").outerWidth();
            this.viewportHeight = this.$(".pages-viewport").outerHeight();

            let counterPosition = this.$(this.options.productCartCounter).offset();
            let leftPosition = counterPosition.left / this.viewportWidth * 100;
            let topPosition = counterPosition.top / this.viewportHeight * 100;

            let imageHeight = (parseFloat(heroImage.height()) * 100) / this.viewportHeight;
            let imageWidth = (parseFloat(heroImage.width()) * 100) / this.viewportWidth;

            this.$(document).trigger("app:product:closeSizes");

            anime.timeline({
                duration: 200,
                easing: 'easeInOutQuad',
            })
            .add({
                targets: heroOverlay[0],
                width: ['100vw',`${imageWidth}vw`],
                height: ['100vh', `${imageHeight}vh`],
                duration: 250,
                easing: 'easeInCirc'
            })
            .add({
                targets: heroOverlay[0],
                opacity: 0,
                duration: 50,
            })
            .add({
                targets: heroImage[0],
                height: [
                    { value: [`${imageHeight}vh`, '3vh'], duration: 300, delay: 0, easing: 'linear' }
                ],
                borderRadius: [
                    { value:['0', '50%'], duration: 300, delay: 0 }
                ],
                top: [
                    { value: ['50%', '40%'], duration: 150, delay: 0, easing: 'linear'},
                    { value: ['40%', '60%'], duration: 150, delay: 0, easing: 'linear' },
                    { value: `${Math.ceil(topPosition) + 1 }%`, duration: 300, delay: 0, easing: 'easeOutCirc' }
                ],
                left: [
                    { value: ['50%', '85%'], duration: 300, delay: 0, easing: 'linear'},
                    { value: `${Math.ceil(leftPosition) + .2 }%`, duration: 300, delay: 0, easing: 'easeOutCirc' },
                ],
            })
            .add({
                targets: heroImage[0],
                opacity: 0,
                duration: 300,
                 complete: () => {
                    this.resetBuyHeroImage();
                    this.$(document).trigger('app:update:counter');
                }
            })

        });
    }

    showCounter(quantityTotal) {
        this.$(document).on('app:update:counter', () => {
            this.$(this.options.productCartCounter).html(quantityTotal);

            if (!this.$(this.options.productCartCounter).hasClass('is-visible')) {
                this.$(this.options.productCartCounter).addClass('is-visible')
            }
        })
    }

    resetBuyHeroImage() {
        return new Promise((resolve, reject) => {

            this.$(this.options.productBuyButtonHeroImage).removeAttr('style');
            this.$(this.options.productBuyButtonHeroImageContainer).removeAttr('style');
            this.$(this.options.productBuyButtonHeroOverlay).removeAttr('style');

        });
    }

    showPayButton() {
        return new Promise((resolve, reject) => {

            if (!this.$(this.options.payContainer).hasClass(this.options.payBtnVisibleClass)) {
                this.$(this.options.payContainer).addClass(this.options.payBtnVisibleClass);

                let margin = isMobile() ? '0 0 16px 0' : `0 0 0 ${this.colDesk * 2}px`;

                anime({
                    targets: this.$(this.options.payBtn)[0],
                    scale: (0, 1),
                    duration: 600,
                    easing: 'cubicBezier(.25, .1, .25, 1)',

                    complete: resolve
                });
            }

        });
    }

    buildProductImageAnimation() {
        this.$(this.options.productBuyButtonHeroImageContainer).remove();

        let imageSrc =  this.$(this.options.productHeroImage).first().data('src');

        let html = `<div class="product__buy-button__hero-image"><img src="${imageSrc}" class="matrixUiElement"/><div class="product__buy-button__overlay matrixUiElement"></div></div>`;

        this.$('body').append(html);

    }

   init() {
        this.buildProductImageAnimation();
   }
}
