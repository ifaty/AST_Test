import isMobile from '../../utils/isMobile';

export default class ProductPayButton {
    constructor(options) {

        const defaultOptions = {
            payButton: '#pay__button:last',
            payBtnVisibleClass: 'product__pay-button__visible',
            superActions: '.superActions',
            productPayContainer: '.superActions__payButton__container',
            productCartContainer: '.product__pay__cart',
            productCartItem: '.product__pay__cart-item',
            productCartImage: '.product__pay__cart-item__image',
            productCartItemRemove: '.product__pay__cart-item__remove',

            productCartItemsMore: '.product__pay__cart-more',
            productCartItemsMoreText: '.product__pay__cart-more__text',

            productPayButtonSubTotal: '.product__button-label__pay-cash',
            productPayButtonLabel: '.product__button-label__pay-label',

            productPayButtonCounter: '.product__pay-button__counter',

            headerLogo: '.header__logo',

            productBuyContainer: '.product__buy-container',

            colorMatrix: '.color-matrix',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.maxNumberOfItems = 5;
        this.defaultMaxNumberOfItems = 5;
        this.colorMatrixData;

        this.tapEvent = "click";
    }

    prepare() {
        this.checkMaxItemsAccordingToViewport();
        this.setContainerHeight();

        this.$(this.options.productCartContainer).css({
            height: this.containerHeight + (this.$(this.options.payButton).outerHeight() / 2) * 1.2,
            bottom: (this.$(this.options.payButton).outerHeight() / 2) * 1.2,
            paddingBottom: (this.$(this.options.payButton).outerHeight() / 2) * 1.2
        });

        this.$(`${this.options.productCartItem}, ${this.options.productCartItemsMore}`).css({
            opacity: 1,
            transform: `translateY(${this.containerHeight * 1.6 + (this.$(this.options.payButton).outerHeight() / 2) * 1.2}px) scale(0.6)`,
            '-webkit-transform': `translateY(${this.containerHeight * 1.6 + (this.$(this.options.payButton).outerHeight() / 2) * 1.2}px) scale(0.6)`
        });

        return this;
    }

    refresh() {

        this.prepare();

        return this;
    }

    setColorMatrix(colors){
        this.colorMatrixData = colors;
        return this;
    }

    configBackground(){

        if (!this.colorMatrixData) {
            throw new Error("Run setColorMatrix method before configBackground to set color matrix");
        }

        let colors = this.colorMatrixData;
        let payContainer = this.$('.superActions__payButton__container');

        return this;

    }

    hideMiniCart() {
        return new Promise((resolve, reject) => {

            anime({
                targets: [this.options.productCartItem, this.options.productCartItemsMore],
                scale: 0.6,
                opacity: 0.2,
                translateY: this.containerHeight + this.$(this.options.payButton).outerHeight() / 2,
                easing: 'cubicBezier(.25, .1, .25, 1)',
                duration: 600,
                complete: () => {

                    this.$(this.options.productCartContainer).css({height: 0});

                    resolve();
                }
            });
        });
    }

    setContainerHeight() {

        this.itemHeight = this.$(this.options.productCartItem).eq(0).height();
        this.itemMargin = parseInt(this.$(this.options.productCartItem).eq(0).css('margin-bottom'));
        this.itemTotalHeight = this.itemHeight + this.itemMargin;

        this.itemsLength = this.$(this.options.productPayContainer).first().find(this.options.productCartItem).length;

        if (this.itemsLength <= this.maxNumberOfItems) {
            this.containerHeight = this.itemsLength * this.itemTotalHeight;
        } else if (this.maxNumberOfItems >= this.defaultMaxNumberOfItems) {
            this.containerHeight = (this.defaultMaxNumberOfItems * this.itemTotalHeight) + this.itemTotalHeight;
        } else {
            this.containerHeight = (this.maxNumberOfItems * this.itemTotalHeight) + this.itemTotalHeight;
        }

        return this;
    }

    showMiniCart() {
        return new Promise((resolve, reject) => {

            this.$(this.options.productCartContainer).css({
                height: this.containerHeight + this.$(this.options.payButton).outerHeight() / 2
            });

            anime.remove([this.options.productCartItem, this.options.productCartItemsMore]);

            anime({
                targets: [this.options.productCartItem, this.options.productCartItemsMore],
                scale: 1,
                opacity: 1,
                translateY: 0,
                easing: 'cubicBezier(.25, .1, .25, 1)',
                duration: 600,
                complete: resolve
            });
        });
    }

    buildCartItemsMore(hiddenItems = 0) {

        if (hiddenItems) {

            this.showMore = true;

            this.$(this.options.productCartItemsMore)
                .stop().fadeIn();

            this.$(this.options.productCartItemsMoreText)
                .html(`+ ${hiddenItems}`)
                .stop()
        } else {
            this.showMore = false;
            this.$(this.options.productCartItemsMore).stop().fadeOut();
        }
    }

    hideItems(hideAfter = this.defaultMaxNumberOfItems) {

        let cartItems = this.$(this.options.productPayContainer).first().find(this.options.productCartItem);
        let remainingItems = 0;

        if (cartItems.length >= hideAfter) {

            this.$(cartItems.get().reverse()).each((index, item) => {

                if (index > hideAfter - 1) {
                    this.$(item).hide();
                }

            });

            remainingItems = cartItems.length - hideAfter;
            this.buildCartItemsMore(remainingItems);
        }

    }

    checkMaxItemsAccordingToViewport() {

        let viewportHeight = this.$(window).outerHeight();

        let itemHeight = this.$(this.options.productCartItem).eq(0).height();
        let itemMargin = parseInt(this.$(this.options.productCartItem).eq(0).css('margin-bottom'));
        let headerHeight = this.$(this.options.headerLogo).outerHeight();
        let payContainerHeight = this.$(this.options.productPayContainer).height();

        let itemTotalHeight = itemHeight + itemMargin;

        let cartItemsTotalSpace = viewportHeight - (itemTotalHeight + headerHeight + payContainerHeight);

        let maxNumberOfItems = parseInt(cartItemsTotalSpace / itemTotalHeight);

        // One item less to fit "more" item
        this.maxNumberOfItems = maxNumberOfItems - 1;

        this.hideItems(this.maxNumberOfItems);

    }

    updateCounter(quantity) {
        this.$(document).on('app:update:counter', () => {
            this.$(this.options.productPayButtonCounter).html(quantity);
        })
    }

    refreshCart(items, subtotal, updateQuantityUrl, removeProductUrl) {
        this.$(this.options.productCartItem).remove();

        this.$(this.options.productPayButtonSubTotal).html(subtotal);

        items.length ? this.updateCounter(items.length) : this.hidePayButton();

        this.$.each(items, (index, item) => {
            let html = `
                <div class="product__pay__cart-item" style="color: ${item.colorMatrix.ui}; opacity:0">
                    <img class="product__pay__cart-item__image" src="${item.images.large[0].url}" alt="${item.images.large[0].title}">

                    <span data-url="${item.quantity > 1 ? updateQuantityUrl : removeProductUrl}?pid=${item.id}&uuid=${item.UUID}&quantity=${item.quantity-1}&context=pay" class="product__pay__cart-item__remove"></span>
                </div>
            `;

            this.$(this.options.productCartContainer).append(html);

            if (index == items.length - 1) {
                this.refresh();
            }
        });
    }

    addItem(url, pid) {

        return this.$.ajax({
            type: 'POST',
            url: url,
            dataType: 'json',
            data: {
                pid: pid,
                quantity: 1,
                context: 'pay'
            }
        });

    }

    removeItem(url) {
        this.$.ajax({
            url: url,
            type: 'get',
            dataType: 'json',

            success: (data) => {

                this.$(document).trigger("app:gtm:removeFromCart", {product: data.product, quantity: 1});
                this.$(document).trigger("app:gtm:cartStatus", {products: data.cart ? data.cart.items : []});

                this.refreshCart(data.cart.items,
                                 data.cart.totals.subTotal,
                                 data.cart.actionUrls.updateQuantityUrl,
                                 data.cart.actionUrls.removeProductLineItemUrl);

                this.$(document).trigger('app:update:counter');
            }
        });
    }

    hidePayButton() {
        return new Promise((resolve, reject) => {
            anime({
                targets: this.$(this.options.productPayContainer)[0],
                scale: 0,
                width: 0,
                margin: 0,
                duration: 600,
                easing: 'cubicBezier(.25, .1, .25, 1)',

                complete: () => {
                    resolve();

                    this.$(this.options.productPayContainer).removeClass(this.options.payBtnVisibleClass).removeAttr('style');
                    this.$(this.options.productPayButtonCounter).removeClass('is-visible').removeAttr('style');
                }
            });
        });
    }

    buildProductInCart() {
        this.checkMaxItemsAccordingToViewport();
    }

    replaceOldPayButton(payButton) {
        this.$(this.options.productPayContainer).remove();
        this.$(this.options.superActions).append(payButton);
        this.prepare().listen();
    }

    listen() {
        if(isMobile()) return this;

        this.$('body').off('mouseenter', this.options.productPayContainer)
                      .on('mouseenter', this.options.productPayContainer, () => {
            this.showMiniCart();
        });

        this.$('body').off('mouseleave', this.options.productPayContainer)
                      .on('mouseleave', this.options.productPayContainer, () => {
            this.hideMiniCart();
        });

        this.$('body').off(this.tapEvent, this.options.productCartItemRemove)
                      .on(this.tapEvent, this.options.productCartItemRemove, (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            let url = this.$(ev.currentTarget).data('url');

            this.removeItem(url);
        });
    }

    init() {
        this.$(document).on('app:paybutton:hide', () => this.hidePayButton());

        this.$(document).on('app:user:login', (ev, data) => {
            const components = data.components;

            this.replaceOldPayButton(components.payButton);
        });

        this.$(document).on('app:user:logout', (ev, data) => {
            const components = data.components;

            this.replaceOldPayButton(components.payButton);
        });

        this.$(document).on('app:payButton:update', (ev, data) => {
            const template = data.template;
            this.replaceOldPayButton(template);
        });

        if (isMobile()) return this;

        this.prepare()
            .listen();

        return this;
    }
}
