import isMobile from '../../utils/isMobile';

export default class Size {
    constructor(options) {

        const defaultOptions = {
           sizeSelectionInput: ".account__dropdown-content",
           sizeSelectionButton: ".account__dropdown",
           sizeSelectionSelect: ".account__select",
           sizeFormInput: ".account__select-input",
           sizeFormInputSelected: "account__select-input--isSelected",
           chooseSize: ".choose__size",
           chooseSizeOpen: "choose__size--isOpen",
           chooseSizeContentShoes: ".size__shoe",
           chooseSizeContentClothes: ".size__clothes",
           chooseSizeSearchInput: ".size__search-input",

           sizeMenuButton: ".size__button",
           sizeMenuButtonSelected: "size__button--isSelected",

           globalDrawer: ".drawer-viewport .drawer",
           drawerOpen: ".drawer--isOpen",

           isMenuOpen: false,

           selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";
    }

    appendToDrawer(ev) {
        let content = this.$(ev.target).closest(this.$(this.options.sizeSelectionButton)).find(this.$(this.options.chooseSize));

        this.$(content)
            .clone()
            .appendTo(this.$(this.options.globalDrawer))

        this.$(this.options.globalDrawer)
            .find(this.options.chooseSize)
            .addClass(this.options.chooseSizeOpen);

        this.$(this.options.globalDrawer).addClass("drawer--isOpen")
        setTimeout(() => {
            this.$(this.options.globalDrawer).addClass("drawer--isVisible")
        }, 200);

        this.options.isMenuOpen = true;

    }

    openDrawer(ev) {
        this.closeDrawer();
        this.$(ev.target)
            .closest(this.$(this.options.sizeSelectionButton))
            .find(this.$(this.options.chooseSize))
            .addClass(this.options.chooseSizeOpen);

        this.options.isMenuOpen = true;
    }

    closeDrawer() {
        if(isMobile()) {
            this.$(this.options.globalDrawer)
                .find(this.options.chooseSize)
                .remove();

            this.$(this.options.globalDrawer)
                .removeClass("drawer--isOpen drawer--isVisible")
        }
        else {
            this.$(this.options.chooseSize).removeClass(this.options.chooseSizeOpen);
        }

        this.options.isMenuOpen = false;
    }

    chooseSize(ev) {
        let value = this.$(ev.target).data("value");
        let type = this.$(ev.target).data("product-type");

        this.$(`.${this.options.sizeMenuButtonSelected}`)
            .removeClass(this.options.sizeMenuButtonSelected);

        this.$(ev.target).addClass(this.options.sizeMenuButtonSelected);

        this.$(`.account__dropdown-${type}`)
            .find(this.options.sizeFormInput)
            .addClass(this.options.sizeFormInputSelected)
            .attr({"value": value, "placeholder": value});

        this.closeDrawer();
    }

    clearFilter() {
        this.$(this.options.chooseSizeSearchInput).each((i, item) => {
            item.value = "";
        });

        this.$(this.options.sizeMenuButton).each((item, i) => {
            this.$(i).show();
        });
    }

    filterSize(ev) {
        let value = ev.currentTarget.value;

        this.$(this.options.sizeMenuButton).each((item, i) => {
            if (this.$(i).data("value").toUpperCase().indexOf(value.toUpperCase()) === -1) {

                this.$(i).hide();
            }
            else this.$(i).show();
        })
    }

    listen() {

        this.$('body').on('input', this.options.chooseSizeSearchInput, (ev) => {
            this.filterSize(ev);
        });

        this.$('.modals-viewport, .drawer-viewport').off(this.tapEvent).on(this.tapEvent, (ev) => {
            let openMenu = this.$(`.${this.options.chooseSizeOpen}`);
            let sizeInput = this.$(this.options.sizeSelectionInput);

            if (!this.options.isMenuOpen) {
                if (sizeInput.is(ev.target) || sizeInput.has(ev.target).length !== 0) {
                    this.clearFilter();

                    if (isMobile()) {
                        this.appendToDrawer(ev);
                    } else this.openDrawer(ev);

                    this.options.isMenuOpen = true;
                }

            }

            else {
                if (this.$(this.options.sizeMenuButton).is(ev.target)) {
                    this.chooseSize(ev);
                }
                if (!this.$(this.options.chooseSizeSearchInput).is(ev.target)) {
                    openMenu.removeClass(this.options.chooseSizeOpen);
                    this.closeDrawer();
                    this.options.isMenuOpen = false;
                }
            }
        });
    }
}
