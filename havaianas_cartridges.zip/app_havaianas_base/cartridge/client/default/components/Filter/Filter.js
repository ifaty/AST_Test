import isMobile from '../../utils/isMobile';
import removeStringParameter from '../../utils/removeStringParameter';
import debounce from '../../utils/debounce';

export default class Filter {

    constructor(options){

        const defaultOptions = {
            selectorEngine: '',
            filterIcon: '.filter-icon',
            filterContainer: '.shopmode__filter-modal',
            filterClose: '.filter__modal-close',
            filterSection: '.refinements__list-section',
            filterSectionList: '.section__list',
            filterSectionTitle: '.section-title',
            filterSectionHeader: '.refinements__container-header',
            filterSectionContent: '.refinements__container-content',
            filterSectionSelectedFilters: '.shopmode__header-selectedFilters',
            filterSectionClearAll: '.shopmode__refinement__clearAll',
            filterSectionClearAllButton: '.shopmode__refinement__clearAll__button',
            filterSectionRefinementsList: '.refinement__attributes-list',
            filterSectionRefinementsMoreButton: 'shopmode__refinement__more',
            filterSectionRefinementsShowMoreButton: '.shopmode__refinement__more__button',
            orderByItem: '.shopmode__filter-modal .orderBy__item',
            categoryFilterOptions: '.shopmode__refinement',
            categoryFilterOptionsInsideModal: '.shopmode__filter-modal .shopmode__refinement',
            categoryFilterOptionsOutSideModal: '.shopmode__header-selectedFilters .shopmode__refinement',
            moreItemsButton: '.more__items',
            lessItemsButton: '.less__items',
            storysSection: '.story__section',
            currentStorySection: '.story__section.is-current',
            applyFilters: '.apply-filters',
            colorMatrix: '.color-matrix',
        };

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.tapEvent = 'click';
        this.lastUrl = '';
        this.filterFilthy = false;
        this.watching = false;
    }

    addRefinement(url, e) {
        this.lastFilterScrollPosition = this.$(e.target).closest('.shopmode__filter-modal').scrollTop();

        const debounceAddRefinement = debounce((fallback) => { fallback() }, 200, false);

        if (!isMobile()) {

            this.cloneFilter();

            this.$(document).on("app:frame:pageLoaded", (ev, data) => {
                this.$(document).trigger("app:orderBy:update", data);
                this.$(document).off("app:frame:pageLoaded");
            });

            this.$(document).one('app:frame:ready', () => {
                this.$(this.options.storysSection).removeClass('is-current');
            });

            debounceAddRefinement(() => {
                this.$(document).trigger('app:frame:loadPage', [{
                    link: url,
                    isDesktopFilter: true,
                    targetClick: {
                        mouseEvents: {
                            pageX: e.clientX,
                            pageY: e.clientY
                        },
                        currentTarget: e.currentTarget,
                        target: e.target
                    }
                }]);
            });

        } else {
            debounceAddRefinement(() => {
                this.$(document).trigger('app:frame:loadPage', [{
                    link: url
                }]);
            });

            this.hideFilter();
        }

        this.filterFilthy = false;

    }

    toggleVisibleRefinements(target) {

        target
        .parent(this.options.filterSectionRefinementsList)
        .toggleClass('expanded');

        return this;
    }

    toggleShowMoreButton(target) {

        target
        .find(this.options.filterSectionRefinementsShowMoreButton)
        .toggleClass('visible');

        return this;
    }

    markSelected(target) {

        if (target.closest(".refinements__categories-list").length) {

            target.toggleClass('selected');
            target.find('em').toggleClass("matrixUiTxtAsBgColor");
            target.find('b').toggleClass("matrixUiBgAsTxtColor");
            target.closest(this.options.categoryFilterOptions).siblings().removeClass('selected');
            target.closest(this.options.categoryFilterOptions).siblings().find('em').removeClass("matrixUiTxtAsBgColor");
            target.closest(this.options.categoryFilterOptions).siblings().find('b').removeClass("matrixUiBgAsTxtColor");
            target.closest(this.options.filterSection).siblings().find(this.options.categoryFilterOptions).removeClass("selected");
            target.closest(this.options.filterSection).siblings().find('em').removeClass("selected matrixUiTxtAsBgColor");
            target.closest(this.options.filterSection).siblings().find('b').removeClass("selected matrixUiBgAsTxtColor");

        } else if (target.closest(".refinement-size").length) {

            target.toggleClass('selected');
            target.find('em').toggleClass("matrixUiBgAsTxtColor matrixUiTxtAsBgColor");

        }
        else if (target.closest(".refinement-price").length) {

            target.toggleClass('selected matrixUiBgAsTxtColor matrixUiTxtAsBgColor');
            target.closest('li').siblings().removeClass("selected matrixUiBgAsTxtColor matrixUiTxtAsBgColor");

        }
        else if (target.closest(".clear.shopmode__refinement").length) {

            return;
        }
        else {
            target.toggleClass('selected matrixUiBgAsTxtColor matrixUiTxtAsBgColor');
        }
    }

    listenDesktopRefinement() {
        this.$('body').off(this.tapEvent, this.options.categoryFilterOptions)
                      .on(this.tapEvent, this.options.categoryFilterOptions, (e) => {
            let target = this.$(e.currentTarget);

            if (target.hasClass(this.options.filterSectionRefinementsMoreButton)) {

                this
                .toggleVisibleRefinements(target)
                .toggleShowMoreButton(target);

            } else {
                let url = target.find('button').data('href');

                if (!target.hasClass('clear-all')) {

                    this.markSelected(target);
                }

                const colorName = target.data("colorname");
                const colorBackground = target.data("colorbackground");
                if(colorName && colorBackground) {
                    this.$(document).trigger('app:rainbow:removeColorFilter', [{ colorName, colorBackground }]);
                }

                this.addRefinement(url, e);
                this.runOnce = true;
            }
        });

        return this;
    }

    listenMobilepRefinement() {

        this.$('body').off(this.tapEvent, this.options.categoryFilterOptionsOutSideModal)
                      .on(this.tapEvent, this.options.categoryFilterOptionsOutSideModal, (e) => {
            let url = this.$(e.currentTarget).find('button').data('href');
            if (this.$(e.currentTarget).attr("data-colorname")) {
                this.options.rainbow.removeColorFilter(e);
            }

            this.addRefinement(url, e);
            this.runOnce = true;
        });


        this.$('body').off(this.tapEvent, `${this.options.categoryFilterOptionsInsideModal}, ${this.options.orderByItem}`)
            .on(this.tapEvent, `${this.options.categoryFilterOptionsInsideModal}, ${this.options.orderByItem}`, (e) => {
            let target = this.$(e.currentTarget);
            let url = target.find('button').data('href') || target.data("url");

            if (target.hasClass(this.options.filterSectionRefinementsMoreButton)) {

                this
                .toggleVisibleRefinements(target)
                .toggleShowMoreButton(target);

            } else if (target.hasClass("clear-all")) {

                this.addRefinement(url, e);

            } else {

                this.markSelected(target);

                this.$.get(url, {
                    ajax: true
                })
                .done((data) => {
                    this.$(this.options.filterContainer).find(".refinements").html(this.$(data).find(".shopmode__filter-modal").find(".refinements").html())
                    this.filterFilthy = true;
                    this.$(document).trigger("app:orderBy:update", data);
                })

                this.runOnce = true;
                this.lastUrl = url;

            }

        });

        return this;
    }

    listenMobileFilterApply() {
        this.$('body').on(this.tapEvent, this.options.applyFilters, (e) => {
            this.addRefinement(this.lastUrl, e);
        })

        return this;
    }

    listenMoreItemsButton(){
        this.$('body').on(this.tapEvent, this.options.moreItemsButton, (e) => {
            const sectionList = this.$(e.target).parents(this.options.filterSectionList);
            sectionList.removeClass('hide__categories');
            sectionList.find(this.options.moreItemsButton).addClass('d-none');
            sectionList.find(this.options.lessItemsButton).removeClass('d-none');
        })

        return this;
    }

    listenHideItemsButton(){
        this.$('body').on(this.tapEvent, this.options.lessItemsButton, (e) => {
            const sectionList = this.$(e.target).parents(this.options.filterSectionList);
            sectionList.addClass('hide__categories');
            sectionList.find(this.options.moreItemsButton).removeClass('d-none');
            sectionList.find(this.options.lessItemsButton).addClass('d-none');
        })

        return this;
    }

    listenCollapseCategories(){
        this.$('body')
        .off(this.tapEvent, this.options.filterSectionHeader)
        .on(this.tapEvent, this.options.filterSectionHeader, (e) => {
            this.$(e.currentTarget)
            .toggleClass('visible')
            .parent()
            .find(this.options.filterSectionContent)
            .slideToggle()
        });

        return this;
    }

    listenShowFilter() {
        this.$('body').on(this.tapEvent, this.options.filterIcon, () => this.$(document).trigger("app:filter:show"))

        this.$('body').on(this.tapEvent, this.options.filterContainer, (e) => {
            e.stopPropagation();
            e.preventDefault();
        })

        return this;
    }


    listenHideFilter() {

        this.$(this.options.filterClose).on(this.tapEvent, (e) => {
            e.stopPropagation();
            e.preventDefault();
            this.$(document).trigger("app:filter:hide")
        });

        /* close filter when clicking outside - won't close when interacting with links in general, the product tile, and view more. */
        this.$('.page-shop[data-pagename], .page-search[data-pagename], .page-wishlist[data-pagename]').on(this.tapEvent, (e) => {
            if (this.$('body.is-filter-open').length) {
                if (!this.$(e.target).is(`
                    .shopmode__filter-modal, .shopmode__filter-modal *,
                    a,
                    .shopmode__cell *,
                    .refinement-buttons *,
                    .btn__view-more-products
                `)) {
                    e.stopPropagation();
                    e.preventDefault();
                    this.$(document).trigger("app:filter:hide")
                }
            }
        })

        return this;

    }

    listenClearAllButtonHover() {

        this.$(this.options.filterSectionClearAll)

            .on('mouseenter', (e) => {

                let backgroundColor = this.$(this.options.filterContainer).css('background-color');

                let textColor = this.$(this.options.filterContainer).css('color');

                this.$(this.options.filterSectionClearAllButton).css({

                    'background': textColor,
                    'color': backgroundColor,
                    'border-color': textColor,

                });

            })

            .on('mouseleave', (e) => {

                this.$(this.options.filterSectionClearAllButton).removeAttr("style");

            });

        return this;

    }

    listenRefinementsOptionsHover() {

        let visibleRefinements = $('.is-current').find('.shopmode__header-selectedFilters .shopmode__refinement:not(".shopmode__refinement__clearAll")');

        if (this.$(visibleRefinements).length >= 2) {

            if (isMobile()) {
                this.$(this.options.filterSectionClearAll).addClass('visible');
            }

            else {

                this.$(this.options.filterSectionSelectedFilters)
                    .on('mouseenter', (e) => {
                        this.$(this.options.filterSectionClearAll).addClass('visible');
                        this.listenClearAllButtonHover();
                    })
                    .on('mouseleave', (e) => {
                        this.$(this.options.filterSectionClearAll).removeClass('visible');

                });
            }
        }

        return this;
    }

    showFilter(){
        this.$('body').addClass('is-filter-open');
        this.$(document).trigger("app:filter:opening")

        if (this.filterFilthy) {
            setTimeout(() => {
                this.$('body').addClass('is-filter-open');
                this.$(document).trigger("app:filter:opened")
            },300);
        }else {
            this.$(document).trigger("app:filter:opened")
        }


        return this;
    }

    hideFilter(){
        this.$(document).trigger("app:filter:closing")
        this.$('body').removeClass('is-filter-open');
        this.$(document).trigger("app:filter:closed")


        return this;
    }


    cloneFilter() {
        let filterClone = $('.fx-container.is-current .shopmode__filter-modal').addClass('is-cloned').clone();
        this.$('.pages-viewport').prepend(filterClone);
        this.scrollFilter();
    }

    hideClonedFilter() {
        if (this.$('.pages-viewport > .shopmode__filter-modal.is-cloned').length) {
            this.$('.pages-viewport > .shopmode__filter-modal.is-cloned').fadeOut(700).delay(100).remove();
        }
    }

    scrollFilter() {
        this.$(this.options.filterContainer).scrollTop(this.lastFilterScrollPosition);
    }

    listen() {
        if (this.watching) return this.reload();

        this.$(document).on("app:frame:ready", (ev, data) => {
            if (data.isDesktopFilter && (data.fromPageName == "page-shop" || data.fromPageName == "page-search" || data.fromPageName == "page-wishlist")) {
                this.scrollFilter();
            }
        });

        this.listenRefinementsOptionsHover();
        this.listenHideFilter();
        this.listenCollapseCategories();

        if (!isMobile()) {
            this.hideClonedFilter();
        }

        if (!this.runOnce) {
            if (isMobile()) {
                this.listenMobilepRefinement();
                this.listenMobileFilterApply();
            } else {
                this.listenDesktopRefinement();

                this.$(document)
                .on("app:filter:open", () => {
                    this.showFilter();
                })
                .on("app:filter:close", () => {
                    this.hideFilter();
                })
            }

            this.listenMoreItemsButton();
            this.listenHideItemsButton();
            this.listenShowFilter();
        }

        this.$(document)
        .on("app:filter:hide", () => {
            this.hideFilter();
        })
        .on("app:filter:show", () => {
            this.showFilter();
        });

        this.watching = true;
        return this;

    }

    reload() {

        this.watching = false;

        return this.destroy().listen();

    }

    destroy() {

        this.$(document)
        .off("app:filter:hide")
        .off("app:filter:show")
        .off("app:filter:close")
        .off("app:filter:open");

        this.$(this.options.filterClose).off(this.tapEvent);
        this.$(this.options.filterSectionSelectedFilters).off('mouseenter');
        this.$(this.options.filterSectionSelectedFilters).off('mouseleave');
        this.$(this.options.filterSectionClearAll).off('mouseenter');
        this.$(this.options.filterSectionClearAll).off('mouseleave');
        this.$(this.options.filterSectionHeader).off(this.tapEvent);

        return this;
    }
}
