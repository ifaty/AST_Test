import debounce from '../../utils/debounce';
import ASYNC from '../../utils/async';
export default class ContextLoader extends ASYNC {
    constructor(options) {

        super(options);

        const defaultOptions = {
            thebody: 'body',
            selectorEngine: {},

            waitingTime: 1500,
            defaultTargetSelector: 'body',
            loadingEventClass: 'is-contextual-loading',
            box: 'havaianasContextualLoader',
            availableTargets: ['superActions__btnShopMode__previewStory',
                               'superActions__btnShopMode',
                               'superActions__btnShopMode__text',
                               'superActions__btnShopMode__video',
                               'canbe-contextual-loading']
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.target = this.$(this.options.defaultTargetSelector);
        this.ignoreAvailableTargets = false;
    }


    setOptions(options) {

        this.options = Object.assign({}, this.options, options);

        return this;
    }

    setBaseColor(baseColor = "#000000") {

        this.$(this.options.box).css({backgroundColor: baseColor});

        return this;
    }

    setTarget(targetSelector = 'body') {

        this.target = this.$(targetSelector);

        return this;
    }

    //classic mode show the contextual loader at
    //the center of the viewport
    classic() {
        return this.setPosition();
    }

    setPosition(position = {posX:'50%', posY: '50%'}) {

        this.position = position;

        return this;
    }

    positionate() {

        this.$(`.${this.options.box}`).css({top: this.position.posY, left: this.position.posX});

        return this;
    }

    dealWithTargetPosition(targetClick = null) {

        if (!targetClick) return this.classic();

        //checking if the target is inside the default targets that can
        //receive the contextual loader
        if (!this.$(targetClick).is(`.${this.options.availableTargets.join(', .')}`) && !this.ignoreAvailableTargets) {

            //if not, the classic mode will be enabled
            this.classic();

            return this;
        }

        this.prepare(targetClick);

        let targetDom = targetClick.getBoundingClientRect();

        let targetPos = {
            posX: targetDom.left + targetDom.width / 2,
            posY: targetDom.top + targetDom.height / 2
        }

        this.setPosition(targetPos);

        return this;
    }

    prepare(targetClick) {

        this.lastTarget = targetClick;

        this.$(targetClick).addClass(`${this.options.loadingEventClass}-child`);

        return this;
    }

    show() {

        this.$(this.options.thebody).addClass(this.options.loadingEventClass);
        this.ignoreAvailableTargets = false;

        this.prepare();

        return this;
    }

    hide() {

        this.$(this.options.thebody).removeClass(this.options.loadingEventClass);
        this.$(`${this.options.loadingEventClass}-child`).removeClass(`${this.options.loadingEventClass}-child`);

        return this;
    }

    showRainbowLoading() {

        return this;
    }

    ignoreDefautTargets() {
        this.ignoreAvailableTargets = true;

        return this;
    }

    listen() {

        let debouncedInit = debounce((data) => {
            super.clearTimeout('havaianasContextualLoader');
            this.ignoreDefautTargets()

                if (data.target) this.dealWithTargetPosition(data.target.get(0));
                if (data.position) this.setPosition({posX: data.position.posX, posY: data.position.posY});

                this.positionate().show();
         }, 200, false);

        let debouncedInitWillLoad = debounce((data) => {
            super.clearableWait(this.options.waitingTime, 'havaianasContextualLoader')
                 .then(() => {
                    this.dealWithTargetPosition(data.fromTarget.currentTarget)
                        .positionate()
                        .show();
                 });
        }, 200, false);

        let debouncedFinish = debounce(() => {
            super.clearTimeout('havaianasContextualLoader');
            this.hide();
        }, 50, false);

        this.$(document).on('app:contextLoader:init', (ev, data) => debouncedInit(data = data));
        this.$(document).on('app:contextLoader:finish', (ev) => debouncedFinish());
        this.$(document).on('app:frame:willLoad', (ev, data) => debouncedInitWillLoad(data));

        this.$(document).on('app:frame:changed app:frame:ajaxFail app:frame:ready app:frame:modalIsClosed', (ev, data) => {
            debouncedFinish();
        });
    }
}