import isMobile from '../../utils/isMobile';
import throttle from '../../utils/throttle';

export default class FunFact {
    constructor(options) {

        const defaultOptions = {
            funFactMaskedImage: '.fun__fact--maskedImage',
            funFactWrapper: '.fun__fact',
            funFactContainer: '.fun__fact-container',

            funFactImageContainer: '.fun__fact-image__container',
            funFactImageMask: '.fun__fact-image__mask',
            funFactImage: '.fun__fact-image__container-image',
            funFactImageNormalizer: '.fun__fact-image__normalizer',

            funFactQuestion: '.fun__fact-question',
            funFactAnswer: '.fun__fact-answer',

            pageProduct: '.page-product',
            storySection: '.story__section',

            colorMatrix: '.color-matrix',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.viewportWidth = this.$("body").outerWidth();

        this.colDesk = this.viewportWidth / 79;
        this.colMobile = this.viewportWidth / 11;

        this.colorMatrixData;

        this.myPage = this.$(this.options.funFactMaskedImage).length ? '.story__section.is-current' : '.page-product';

        this.tapEvent = "click";
    }

    collapseFunFactImage(duration = 2000) {
        this.$(this.options.funFactWrapper).addClass('animated');
        this.ellipseImageContainer(duration);
        this.normalizeImage(duration);
    }

    ellipseImageContainer(duration) {
        return new Promise((resolve, reject) => {
            let containerHeight = isMobile() ? (this.colMobile * 9) * 1.2 : (this.colDesk * 25.5) * 1.2,
                containerWidth = isMobile() ? (this.colMobile * 9) : (this.colDesk * 24.5),
                borderRadius = isMobile() ? '48% 46% 42% 38%' : '50%';

            anime({
                targets: this.$(this.options.funFactImageContainer)[0],
                borderRadius: ['0', borderRadius],
                width: containerWidth,
                height: containerHeight,
                rotate: '15deg',
                margin: '0 auto',
                easing: 'cubicBezier(0.215, 0.61, 0.355, 1)',
                duration: duration,
                complete: resolve
            });
        });
    }

    normalizeImage(duration) {
        return new Promise((resolve, reject) => {
            anime({
                targets: this.$(this.options.funFactImageNormalizer)[0],
                rotate: '-15deg',
                easing: 'cubicBezier(0.215, 0.61, 0.355, 1)',
                duration: duration,
                complete: resolve
            });
        });
    }

    listenFunfact(){

        if (this.$(this.options.funFactWrapper).length) {
            let clientHeight = this.$(this.myPage).outerHeight(true);

            let throttledScroll = throttle((e) => {

                if(!this.$(this.options.funFactWrapper).hasClass('animated')) {
                    let percent = 100 - ($(this.options.funFactContainer).offset() || {}).top * 100 / clientHeight;
                    if (percent >= 50) this.collapseFunFactImage(300);
                }

            },100)

            this.$(this.myPage).on('scroll',throttledScroll);
        }

    }

   listen() {
        this.listenFunfact();
   }
}
