import isMobile from '../../utils/isMobile';

export default class Product {
    constructor(options) {

        const defaultOptions = {

            pageOrder: '.page-orderHistory',
            orderTrackingCard: '.orderTracking__card',

            selectorEngine: {}
        }


        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";
    }

    openOrderDetailsListener() {
        this.$(this.options.orderTrackingCard).on(this.tapEvent, (ev) => {
            var url = this.$(ev.target).closest(this.options.orderTrackingCard).data('url');
            this.options.frame.removeOldAppendedPage('page-order');
            this.$(document).trigger('app:frame:loadPage', [{
                isModal: true,
                link: url
            }]);
        });
    }

    listen() {
        this.openOrderDetailsListener();
    }
}
