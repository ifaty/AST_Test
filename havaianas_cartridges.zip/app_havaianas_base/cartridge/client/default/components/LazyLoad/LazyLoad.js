// import throttle from '../../utils/throttle';
import isMobile from '../../utils/isMobile';
import isRetina from '../../utils/isRetina';
import debounce from '../../utils/debounce';

export default class LazyLoad {
    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},
            lazySelector: 'lazyload',
            sourceSelector: 'picture > source',

            wrapper: '.container[class*="page-"], .story__section'
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.observableWrapper = this.options.wrapper;
        this.watcherInterval;
        this.isApple = !!navigator.platform && /iPad|iPhone|iPod|MacIntel/.test(navigator.platform);
        this.isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
        this.offset = this.isSafari ? 200 : 800;
    }

    //deprecated
    prepare() {

        this.$('body').addClass(`is-apple-${this.isApple}`);

        return this;
    }

    dealWithSource() {

        this.$('body').find(`${this.options.sourceSelector}`).each((i, el) => {
            this.loadImage(el);
        });

        return this;
    }

    getRect(el) {

        return {
            top: $(el).offset().top - $(window).scrollTop(),
            left: $(el).offset().left,
            right: $(el).outerWidth(),
            bottom: $(el).outerHeight() - $(window).scrollTop()
        }
    }

    isElementInViewport(el) {
        // return true;

        let rect = el.getBoundingClientRect();

        return (
            rect.top >= -2300 &&
            rect.bottom <= ((window.innerHeight || document.documentElement.clientHeight) * 2) &&
            rect.left >= this.offset * -1 &&
            rect.right <= ((window.innerWidth || document.documentElement.clientWidth) + this.offset)
        );
    }

    watchEnterInview() {
        let elems = this.$('body').find(`.${this.options.lazySelector}`).filter((idx, elem) => {

            return this.$(elem).data('is-lazyloading') != true && this.$(elem).data('is-lazyloaded') != true
        });

        this.$.each(elems, (idx, el) => {
            if (this.isElementInViewport(this.$(el).closest('div, a, p, section')[0])) this.loadImage(el);
        });
    }

    watch() {

        if (!'IntersectionObserver' in window &&
            !'IntersectionObserverEntry' in window &&
            !'intersectionRatio' in window.IntersectionObserverEntry.prototype
            || (this.isApple && this.isSafari && (window.devicePixelRatio === 2 || window.devicePixelRatio === 3) && screen.height === 896)) {

                console.log("is iphonei xr or xs")

                this.watcherInterval = setInterval(() => {
                    this.watchEnterInview();
                }, 350);

            }  else {

                this.watcherInterval = setInterval(() => {
                    this.watchEnterInview();
                }, 350);

                //return this.watchUsingIntersectionObserver();
            }

        return this;
    }

    clearWatcher() {
        clearTimeout(this.watcherInterval);

        return this;
    }

    watchUsingIntersectionObserver() {

        const io = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {

                let rect = entry.boundingClientRect;

                let willEnter =
                    rect.top >= -2300 &&
                    rect.bottom <= ((window.innerHeight || document.documentElement.clientHeight) * 4) &&
                    rect.left >= 400 * -1 &&
                    rect.right <= ((window.innerWidth || document.documentElement.clientWidth) + 400);

                // set image source only when it is in the viewport
                if (entry.isIntersecting || willEnter) {
                    const image = entry.target;
                    // setting image source from the dataset
                    // image.src = image.dataset.src;
                    this.loadImage(image);

                    // when image is loaded, we do not need to observe it any more
                    io.unobserve(image);
                }
            })
            }, {
                rootMargin: "100%"
            }
        );

        // this.$('.lazyload').closest('div, a, p, section')
        // document.querySelectorAll(".lazyload").forEach((element) => io.observe(element));
        document.querySelectorAll(`.${this.options.lazySelector}`).forEach((element) => io.observe(element));

        return this;
    }

    start() {

        this.prepare()
            .listen()
            .clearWatcher()
            .watch()
    }

    listen() {

        let debouncedListen = debounce(() => {
            this.clearWatcher()
                .watch();
        }, 400, false);

        this.$(document).on('app:frame:ready app:discovery:newStory app:lazyload:refresh DOMSubtreeModified propertychange', (ev) => debouncedListen());

        return this;
    }

    checkisLoaded() {
        this.$('body').find('.is-lazyloading').each((idx, el) => {
            if (el.complete) {
                this.$(el).trigger('load');

                this.$(el).data('is-lazyloaded', true);
                this.$(el).data('is-lazyloading', false);
            }
        })
    }

    loadImage(el) {

        if ((this.$(el).data('is-lazyloaded') || this.$(el).data('is-lazyloading')) && this.$(el).css('opacity') != 0) return;

        /*

        DATA IMAGE STRUCTURE
        ------------------------------------------------
        data-mobile="${productImage.src.mobile}"
        data-mobileRetina="${productImage.src.mobileRetina}"
        data-desktop="${productImage.src.desktop}"
        data-desktopRetina="${productImage.src.desktopRetina}"
        */

        let fallback = this.$(el).data('src');
        let mobileImage = this.$(el).data('mobile') || false;
        let mobileImageRetina = this.$(el).data('mobileretina') || false;
        let desktopImage = this.$(el).data('desktop') || false;
        let desktopImageRetina = this.$(el).data('desktopretina') || false;

        let finalSource = fallback;

        if (isMobile() && isRetina()) { // is retina mobile
            finalSource = mobileImageRetina || desktopImage || mobileImage || fallback;
        } else if (isMobile() && !isRetina()) { // is mobile
            finalSource = mobileImage || fallback;
        } else if (!isMobile() && isRetina()) { // is retina desktop
            finalSource = desktopImageRetina || desktopImage || mobileImageRetina || fallback;
        } else if (!isMobile() && !isRetina()) { // is desktop
            finalSource = desktopImage || fallback;
        }

        if (finalSource) {

            this.$(el).attr('src', finalSource.replace(/ /g, "%20"));

            this.$(el).data('is-lazyloading', true);
        }

        if (el.complete) {
            $(el).trigger('load'); // For jQuery >= 3.0
        }

        this.$(el).on('load', () => {

            let imgH = this.$(el).outerHeight();
            let imgW = this.$(el).outerWidth();

            if (imgW > imgH ) {
                this.$(el)
                    .parent()
                    .addClass('imgLandscape');
            } else if (imgW < imgH) {
                this.$(el)
                    .parent()
                    .addClass('imgPortrait');
            }


            // this.$(el).css({opacity: 1});
            anime.remove([el]);
            anime({
                targets: el,
                opacity: 1,
                duration: 250,
                easing: 'linear',
                complete: () => {
                    this.$(el).data('is-lazyloaded', true)
                              .data('is-lazyloading', false)
                }
            });

        });
    }
}
