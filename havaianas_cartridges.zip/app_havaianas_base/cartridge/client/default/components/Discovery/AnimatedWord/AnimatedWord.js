import AnimatedBase from '../AnimatedBase';

/**
 * AnimatedWord component
 * @export
 * @class AnimatedWord
 * @extends {AnimatedBase}
 */
export default class AnimatedWord extends AnimatedBase {
    constructor(options) {
        super(options);
        const defaultOptions = {
            root: '.animated_word',
            title: '.animated_word__title--animation',
            image: '.animated_word__image-wrapper',
            delay: 1000,
            easing: 'easeOutQuad',
            duration: 400
        };
        this.options = Object.assign({}, defaultOptions, options.selectors);
        this.delay = this.options.delay;
        this.easing = this.options.easing;
        this.duration = this.options.duration;
        this.animatedElements = [];
    }

    /**
     * Animate the title component
     * @param {HTMLElement} title element
     * @param {boolean} [right=false] If its the left or right one
     * @returns {this} instance
     */
    animateTitle(title, right = false) {
        if (!this.shouldAnimate(title)) return this;

        /** @type {import('animejs/lib/anime.es')} anime */
        const { anime } = window;
        const { $, delay, easing, duration } = this;
        const $title = $(title);
        const translate = ['0%', '-50%'];
        if (right) translate.reverse();

        anime({
            targets: title,
            translateY: translate,
            delay,
            endDelay: delay,
            easing,
            duration,
            loop: true,
            direction: 'alternate'
        });

        $title.children().each((i, el) => {
            let revert = (Boolean(i));
            if (right) revert = !revert;

            anime({
                targets: el,
                opacity: revert ? [0, 1] : [1, 0],
                delay: delay,
                endDelay: delay,
                easing: 'easeOutQuint',
                duration,
                loop: true,
                direction: 'alternate'
            });
        });
        return this;
    }

    /**
     * Animate the image component
     * @param {HTMLElement} image element
     * @param {boolean} [right=false] If its the left or right one
     * @returns {this} instance
     */
    animateImage(image, right = false) {
        if (!this.shouldAnimate(image)) return this;
        /** @type {import('animejs/lib/anime.es')} anime */
        const { $, delay, easing, duration } = this;
        const { anime } = window;
        const translate = ['-100%', '0%'];
        // if (!right && $(window).outerWidth() <= 799) translate[0] = '100%'; // variant animation on mobile
        if (right) translate.reverse();

        anime({
            targets: image,
            translateY: translate,
            delay,
            endDelay: delay,
            easing,
            duration,
            loop: true,
            direction: 'alternate'
        });

        if (right) {
            anime({
                targets: $(image).children()[0],
                translateY: ['0%', '100%'],
                delay,
                endDelay: delay,
                easing,
                duration,
                loop: true,
                direction: 'alternate'
            });
        }

        return this;
    }


    /**
     * Register animations
     * @returns {this} instance
     */
    registerScenes() {
        const { $, options: selectors } = this;
        const $components = $(selectors.root);
        $components.each((i, root) => {
            const $root = $(root);
            const $title = $root.find(selectors.title);
            const $image = $root.find(selectors.image);

            this.animateTitle($title[0]);
            this.animateTitle($title[1], true);
            this.animateImage($image[0]);
            this.animateImage($image[1], true);
        });
        return this;
    }

    listen() {
        this.registerScenes();
        return this;
    }
}
