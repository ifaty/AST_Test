import isMobile from '../../../utils/isMobile';
import scrollMagic from 'scrollmagic';
import 'scrollmagic/scrollmagic/minified/plugins/debug.addIndicators.min';

export default class VideoComponent {

    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},

            currentStorySection: '.story__section.is-current .match-with',
            videoFullComponent: ".story__section.is-current .fullWidthComponent--video",
            videoHalfComponent: ".story__section.is-current .halfWidthComponent--video",

        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.tapEvent = "click";
        this.scrollMagicController = null;
    }

    setScrollController(controller){
        this.scrollMagicController = controller;

        return this;
    }

    cropVideo(el){

        let target = this.$(el);
        let video = this.$(target).find('video');
        let canvas = this.$(target).find('canvas');
        let videoSpec = {
            x: -(video[0].videoWidth  / 4),
            y: -(video[0].videoHeight  / 4),
            w: video[0].videoWidth * 0.8,
            h: video[0].videoHeight * 0.8
        }

        let ctx = canvas[0].getContext('2d');
        ctx.drawImage(video[0], videoSpec.x , videoSpec.y , videoSpec.w, videoSpec.h);
        setTimeout(() => this.cropVideo(target), 1000/30);

    }

    videoScenes(){

        this.$(this.options.videoFullComponent).map((i, el) => {

            this.cropVideo(el);
            let video = this.$(el).find('video');

            let scene = new scrollMagic.Scene({
                triggerElement: el,
                triggerHook: 1,
                duration: this.$(el).height()
            })
            .addTo(this.scrollMagicController)
            // .addIndicators()
            .on("enter", (e) => video.trigger("play"))

        })

        this.$(this.options.videoHalfComponent).map((i, el) => {

            console.log(el);

            this.cropVideo(el);
            let video = this.$(el).find('video');

            let scene = new scrollMagic.Scene({
                triggerElement: el,
                triggerHook: 1,
                duration: this.$(el).height()
            })
            .addTo(this.scrollMagicController)
            // .addIndicators()
            .on("enter", (e) => video.trigger("play"))

        })

        return this;

    }

    listen(){

        this.videoScenes();

    }

}
