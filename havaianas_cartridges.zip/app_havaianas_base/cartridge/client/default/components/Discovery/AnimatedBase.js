

export default class AnimatedBase {
    constructor(options) {
        const defaultOptions = {
            selectorEngine: {}
        };

        this.options = Object.assign({}, defaultOptions, options);

        /** @type {JQueryStatic} this.$ */
        this.$ = this.options.selectorEngine;

        /** @type {ScrollMagic.Controller} this.controller */
        this.controller = null;

        /** @type {[ScrollMagic.Scene]} this.scenes */
        this.scenes = [];

        /** @type {[HTMLElement]} this.scenes */
        this.animated = [];
    }

    /**
     * Update ScrollMagic Controller
     * @param {ScrollMagic.Controller} controller instance
     * @returns {AnimatedBase} this
     */
    setScrollController(controller) {
        this.controller = controller;
        return this;
    }

    /**
     * Start event listeners
     * @returns {AnimatedBase} this
     */
    listen() { return this; }

    /**
     * Remove event listeners
     * @returns {AnimatedBase} this
     */
    destroy() { return this; }

    /**
     * Check if an element was already animated. Automatically sets if not animated
     * @param {HTMLElement} element to be checked
     * @returns {boolean} Should animate
     */
    shouldAnimate(element) {
        if (this.animated.find(el => el === element)) return false;
        this.animated.push(element);
        return true;
    }

    /**
     * Remove an element of the animated list
     * @param {HTMLElement} element to be removed
     */
    removeAnimated(element) {
        const i = this.animated.findIndex(el => el === element);
        if (i >= 0) { this.animated.splice(i, 1); }
    }
}
