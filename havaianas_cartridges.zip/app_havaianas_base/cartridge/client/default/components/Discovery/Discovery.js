import isMobile from '../../utils/isMobile';
import scrollMagic from 'scrollmagic';
// import 'scrollmagic/scrollmagic/minified/plugins/debug.addIndicators.min';
import ASYNC from '../../utils/async';
import debounce from '../../utils/debounce';


// class imports
import TransitionalComponent from './transitionalComponent/transitionalComponent';
import Titles from './Titles/Titles';
import MatchThis from './matchThis/matchThis';
// import CoverTitle from './transitionalComponent/coverTitle/coverTitle';
import CompoundTitle from './compoundTitle/CompoundTitle';
import SentenceWithImage from './sentenceWithImage/SentenceWithImage';
import SingleWordMask from './singleWordMask/SingleWordMask';
import AnimatedWord from './AnimatedWord/AnimatedWord';

export default class Discovery extends ASYNC {
    constructor(options) {

        super(options);

        const defaultOptions = {
            selectorEngine: {},

            waitingTime: 1100,

            discoveryModeWrapper: '.discovery-mode',
            discoveryActions: '.superActions',

            btnShopMode: '.superActions__btnShopMode',
            btnStoriesNext: '.superActions__storiesNext',
            previewLabel: '.superActions__btnShopMode__label',
            previewWrapper: '.superActions__btnShopMode__previewStory',

            myPage: '.page-discovery',

            storySection: '.story__section',
            currentStorySection: '.discovery-mode .story__section.is-current',
            storyContainer: '.story__container',
            previousStorySection: '.story__section.is-previous',
            colorMatrix: '.color-matrix-variables',

            paginationOffset: 0,
            storiesPerPage: 6,

            storiesViewAll: '.superActions__storiesViewAll',
            storiesNext: '.superActions__storiesNext',
            headerSearch: '.superActions__header__search',
            headerSearchNoTextClass: 'superActions__header__search__no-text',

            nextPlaceholder: '.story__next',
            previousPlaceholder: '.story__previous',
            nextStoryLink: '.superActions__storiesNext',
            moreButton: '.btn__view-more-stories',

            footer: '#footercontent',

            animateWord: '.animated-word'
        };

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.listenCounter = 0;

        this.scrollGutter = 6;
        this.index = 200;
        this.isBusy = false;
        this.blockLoad = false;
        this.scrollMagicController = null;

        this.tapEvent = isMobile() ? 'touchend' : 'click';
        this.isTouchMoving = false;
        this.isReplacingDiscovery = false;
        this.isLoadingNextStory = false;
        this.isLoadingPreviousStory = false;
        this.nextStoryFooterCounter = 1;

        // sub components
        this.transitionalComponent = new TransitionalComponent({ selectorEngine: this.$ });
        this.titles = new Titles({ selectorEngine: this.$ });
        this.matchThis = new MatchThis({ selectorEngine: this.$ });
        this.compoundTitle = new CompoundTitle({ selectorEngine: this.$ });
        this.sentenceWithImage = new SentenceWithImage({ selectorEngine: this.$ });
        this.singleWordMask = new SingleWordMask({ selectorEngine: this.$ });
        this.animateWord = new AnimatedWord({ selectorEngine: this.$ });
        // sub components
    }

    destroyPageScrollAcontroller() {
        if (this.scrollMagicController) {
            this.scrollMagicController.destroy(true);
        }

        return this;
    }

    createPageScrollAcontroller() {
        this.scrollMagicController = new scrollMagic.Controller({
            container: this.options.currentStorySection
        });
    }

    loadPreviousStory() {

        return new Promise((resolve, reject) => {

            if (this.isLoadingPreviousStory == true) resolve();
            this.isLoadingPreviousStory = true;

            let currentStory = this.$(this.options.currentStorySection);

            if (currentStory.data('previousurl')) {

                this.isBusy = true;
                let url = currentStory.data('previousurl');
                let index = parseInt(currentStory.css('z-index')) + parseInt(1);

                // currentStory.prev(this.options.previousPlaceholder).remove();
                this.$.get(url, {
                    ajax: true
                })
                    .then((data) => {

                        this.$(`[data-storyurl*='${url}']`, this.options.discoveryModeWrapper).remove();
                        this.$(this.options.currentStorySection).nextAll().eq(0).nextAll().remove();
                        this.$(this.options.discoveryModeWrapper).prepend(this.$(this.$(data).css({'z-index': index,'transform': 'translateY(-100%) translateZ(0)'})));

                        this.isBusy = false;

                        if (!currentStory.scrollTop()) {
                            currentStory.scrollTop(1);
                        }

                        this.$(document).trigger("app:discovery:newStory");
                        this.isLoadingPreviousStory = false;
                        resolve(this);

                    }).catch((e) => {
                        console.warn(e);
                        this.isBusy = false;
                        this.isLoadingPreviousStory = false;
                        reject(this);
                    });
            } else {
                this.isLoadingPreviousStory = false;
                resolve(this);
            }
        });
    }

    loadNextStory(block = this.blockLoad) {
        return new Promise((resolve, reject) => {

            if (block) return;
            if(this.isLoadingNextStory == true) resolve();
            this.isLoadingNextStory = true;

            let currentStory = this.$(this.options.currentStorySection);
            if (currentStory.data('nexturl')) {

                this.isBusy = true;
                let url = currentStory.data('nexturl');
                let index = parseInt(currentStory.css('z-index')) - parseInt(1);

                if (url) {
                    this.$.get(url, {
                        ajax: true
                    })
                        .then((data) => {

                            this.$(`[data-storyurl*='${url}']`, this.options.discoveryModeWrapper).remove();
                            this.$(this.options.currentStorySection).prevAll().eq(0).prevAll().remove();

                            // currentStory.next(this.options.nextPlaceholder).remove();

                            this.$(this.options.discoveryModeWrapper).append(this.$(data).css({
                                'z-index': index
                            }));

                            // currentStory.next(this.options.previousPlaceholder).remove();
                            this.$(this.options.currentStorySection).prevAll().eq(0).prevAll().remove();

                            this.isBusy = false;
                            this.blockLoad = false;

                            if (currentStory.scrollTop() == (currentStory[0].scrollHeight - currentStory[0].clientHeight)) {
                                currentStory.find('> div').css({
                                    height: '+=4'
                                });
                            }

                            this.$(document).trigger("app:discovery:newStory");
                            this.isLoadingNextStory = false;
                            resolve(this);
                        }).catch(() => {
                            this.isBusy = false;
                            this.isLoadingNextStory = false;
                            reject(this);
                        });
                }
            } else {

                if (!currentStory.nextAll(this.storySection).length && !currentStory.nextAll(this.options.nextPlaceholder).length) {
                    this.$(this.options.nextStoryLink).hide();
                    this.placeFooter(currentStory);
                }

                this.isLoadingNextStory = false;
                reject(this);
            }
        });
    }

    goToNextStory() {

        let currentStory = this.$(this.options.currentStorySection);
        let nextStory = currentStory.nextAll(this.options.storySection).eq(0);

        if(this.isAnimatingNext || !nextStory.length) return this;
        this.isAnimatingNext = true;
        // anime.remove([currentStory.prev(this.options.storySection)[0], currentStory[0]]);

        this.nextStoryFooterCounter += 1;

        anime({
            targets: currentStory[0],
            translateY: ['-100%'],
            translateZ: [0],
            duration: 600,
            easing: 'cubicBezier(0.25,0.1,0.25,1)',

            begin: () => {


                // start read next story from top
                let sixth = this.nextStoryFooterCounter == 2;

                if (sixth && nextStory.data('nexturl')) {
                    this.placeFooter(nextStory)
                    this.blockLoad = true;
                    this.$(this.options.moreButton).show();
                    this.nextStoryFooterCounter = 0;
                } else {
                    this.$(this.options.moreButton).hide();
                }
                this.$(document).trigger('app:rainbow:storyColorsToRainbow', nextStory);
                nextStory.scrollTop(1).css({overflowY: 'hidden'});

            },
            complete: () => {

                // now currentStory is the former nextStory
                currentStory = currentStory
                    .removeClass('is-current')
                    .addClass('is-previous')
                    .nextAll(this.options.storySection).eq(0)
                    .addClass("is-current");


                setTimeout(() => {
                    this.destroyHistory().listen().loadNextStory();

                    this.$(document).trigger('app:contextLoader:init', [{
                        position: {
                            posX: '50%',
                            posY: 'calc(100% - 82px)'
                        }
                    }]);

                }, 100);

                setTimeout(() => {
                    currentStory.prevAll().eq(0).prevAll().remove();
                    this.$(document).trigger('app:contextLoader:finish');
                    currentStory.css({
                        overflowY: 'auto'
                    });
                    this.isAnimatingNext = false;
                }, 1200);

            }
        });
    }

    goToPreviousStory() {
        let currentStory = this.$(this.options.currentStorySection);
        let previousStory = currentStory.prevAll(this.options.storySection).eq(0);

        if (!previousStory.length || this.isAnimatingPrev) return this;
        this.isAnimatingPrev = true;
        this.nextStoryFooterCounter = Math.max(0, this.nextStoryFooterCounter - 1);

        // anime.remove([currentStory.prev(this.options.storySection)[0], previousStory[0]]);

        anime({
            targets: previousStory[0],
            translateY: [0],
            translateZ: [0],
            duration: 600,
            easing: 'cubicBezier(0.25,0.1,0.25,1)',
            begin: () => {
                // start read previous story from bottom
                this.$(document).trigger('app:rainbow:storyColorsToRainbow', previousStory);
                // create a gap of 5px to allow scroll back to next story (it was made to works on every operational system scale - DO NOT CHANGE)
                previousStory.scrollTop((previousStory[0].scrollHeight - previousStory[0].clientHeight) - 5);

            },
            complete: () => {
                this.$(this.options.myPage).trigger("scroll");
                currentStory = currentStory
                    .removeClass('is-current')
                    .prevAll(this.options.storySection).eq(0)
                    .addClass("is-current")
                    .removeClass("is-previous");

                setTimeout(() => {
                    this.destroyHistory().listen().loadPreviousStory();
                    this.$(document).trigger('app:contextLoader:init', [{
                        position: {
                            posX: '50%',
                            posY: 'calc(100% - 82px)'
                        }
                    }]);
                }, 100);

                setTimeout(() => {
                    currentStory.nextAll().eq(0).nextAll().remove();
                    this.$(document).trigger('app:contextLoader:finish');
                    currentStory.css({ 'transform': 'none' });
                    this.isAnimatingPrev = false;
                }, 1200);

            }
        });
    }

    listenStoryScroll() {

        if (this.currentScene) {
            this.currentScene.remove();
        }

        let target = this.$(this.options.currentStorySection);
        let scrollHeight = target[0].scrollHeight - target[0].clientHeight;
        let sceneContainer = target.find(this.options.storyContainer);

        this.currentScene = new scrollMagic.Scene({
            triggerElement: sceneContainer[0],
            triggerHook: 0,
            duration: scrollHeight - 4 // (maintain 4px of gap to prevent system operational scale crash on scroll - DO NOT CHANGE)
        })
        // .addIndicators()
        .addTo(this.scrollMagicController)
        .on('enter', (e) => {

            let target = this.$(e.target.triggerElement()).parent();

            let colors = target.find(".color-matrix").first();
            this.$(document)
            .trigger("app:colors:setcolors", colors)
            .trigger('app:frame:changeHistory', [{url: target.data('storyurl')}]);

            this.currentScene.off('enter');

        })
        .on('progress', (e) => {

            if (e.progress == 1 && e.scrollDirection == "FORWARD") {

                if (!isMobile()) {
                    this.goToNextStory();
                } else {

                    if (!this.isTouchMoving) this.goToNextStory()
                }

            };

            if (e.progress == 0 && e.scrollDirection == "REVERSE") {

                if (!isMobile()) {
                    this.goToPreviousStory();
                } else {
                    if (!this.isTouchMoving) this.goToPreviousStory()
                }

            };
        });

        target
        .on("touchstart touchmove", () => {
            this.isTouchMoving = true;

        })
        .on("touchend", () => {
            this.isTouchMoving = false;

            if (this.currentScene.progress() == 0) {
                setTimeout(() => {
                    this.goToPreviousStory();
                }, 300)
            }

            if (this.currentScene.progress() == 1) {
                setTimeout(() => {
                    this.goToNextStory();
                }, 300)
            }
        })

    }

    configCurrentStory() {
        let currentStory = this.$(this.options.currentStorySection);
        var shopModeId = currentStory.data('shopmodeid');
        this.$(this.options.btnShopMode).attr('href', currentStory.data('shopmodeurl'));
        this.$(this.options.btnShopMode).attr('data-storyid', currentStory.data('storyid'));
        this.$(this.options.btnShopMode).attr('data-shopmodeid', shopModeId);
        const previewImages = currentStory.data('previewimages');
        if (previewImages && previewImages.items) this.options.shopButton.changePreviewImages(previewImages.items);


        if (!shopModeId) {
            this.options.shopButton.hide();
        } else {
            this.options.shopButton.show();
        }
    }

    // deprecated? not currently in use
    listenNextButton() {
        this.$(this.options.btnStoriesNext).on(this.tapEvent, () => {
            this.$(this.options.myPage).scrollTop(100);
        });
    }

    goToShopButton() {
        let shopmodeImage = this.$(`${this.options.previewWrapper} img`).data('image-shopmode');
        let shopmodeLink = this.$(this.options.btnShopMode).data('link-shopmode');

        this.$(this.options.btnShopMode)
            .removeClass('is-shopmode')
            .attr('href', this.$(this.options.currentStorySection)
                .data('shopmodeurl'));

        this.$(this.options.previewWrapper).removeClass('keep-background');

        this.$(`${this.options.previewWrapper} img`).attr('src', shopmodeImage);

        let shopmodeLabel = this.$(this.options.previewLabel).data('label-shopmode');

        this.$(this.options.previewLabel).text(shopmodeLabel);
    }

    showActionButtons() {
        if (!isMobile()) {
            this.$(this.options.storiesViewAll).show();
            this.$(this.options.storiesNext).show();
        }
    }

    hideActionButtons() {
        this.$(this.options.storiesViewAll).hide();
        this.$(this.options.storiesNext).hide();
    }

    showActionContainer() {
        this.$(this.options.discoveryActions).show();
    }

    hideActionContainer() {
        this.$(this.options.discoveryActions).hide();
    }

    changeToShopMode() {
        let shopmodeLabel = this.$(this.options.previewLabel).data('label-discovery');
        this.$(this.options.previewLabel).text(shopmodeLabel);
    }

    setupShopModeActions() {
        this.changeToShopMode();
    }

    resetScroll() {
        this.$(this.options.myPage).animate({
            scrollTop: Math.floor(this.scrollGutter / 2)
        });
    }

    resetOffset() {
        this.options.paginationOffset = 0;
    }

    listenSubComponents() {
        this.matchThis
            .setScrollController(this.scrollMagicController)
            .listen();

        this.transitionalComponent
            .setScrollController(this.scrollMagicController)
            .listen();

        this.compoundTitle
            .setScrollController(this.scrollMagicController)
            .listen();

        this.sentenceWithImage
            .setScrollController(this.scrollMagicController)
            .listen();

        this.singleWordMask
            .setScrollController(this.scrollMagicController)
            .listen();

        this.titles
            .setScrollController(this.scrollMagicController)
            .listen();

        this.animateWord
            .setScrollController(this.scrollMagicController)
            .listen();


        clearInterval(this.animateInterval);
    }

    setShopObject(shop) {
        this.options.shop = shop;
    }

    placeFooter(story) {
        if (story.find('.story__container footer').length) return this;

        let footerClone = story.find('.story__container').append(this.$(this.options.footer).clone());
        if (story.data('nexturl')) {
            // this.$(this.options.currentStorySection)
            this.$(this.options.moreButton).eq(0).clone().insertBefore(footerClone.find('footer'));
        }
        return this;

    }

    listenExternalEvents() {
        this.$(document)
            .on('app:discovery:init', () => {
                console.log('app:discovery:init');
                this.init();
            })

        return this;
    }

    replaceOldDiscovery(url) {
        this.isReplacingDiscovery = true;
        this.$.ajax({
            data: { ajax: true },
            type: 'GET',
            url,
        }).done((data) => {
            const discovery = this.$(data)[0].innerHTML;
            this.$(`.container${this.options.myPage}`).html(discovery);
            this.$(document).trigger('app:discovery:newStory');
            this.isReplacingDiscovery = false;
            this.destroyHistory().listen();
        });
    }

    init() {
        this.blockLoad = false;
        this.nextStoryFooterCounter = 1;

        this.$(this.options.storySection).first().addClass("is-current").css({
            'z-index': this.index
        });

        this.loadPreviousStory();
        this.loadNextStory();
        this.resetScroll();

        this.$(document).trigger('app:contextLoader:finish');

        this.destroy().listen();

        this.$(document).one('app:user:login', (ev, data) => {
            if(this.isReplacingDiscovery) return;
            const discoveryUrl = data.urls.discovery;
            this.replaceOldDiscovery(discoveryUrl);
        });

        this.$(document).one('app:user:logout', (ev, data) => {
            if(this.isReplacingDiscovery) return;
            const discoveryUrl = data.urls.discovery;
            this.replaceOldDiscovery(discoveryUrl);
        });

        let debouncedMoreButton = debounce((data) => {
            this.blockLoad = false;
            this.$(document).trigger('app:contextLoader:init', [{
                position: {
                    posX: '50%',
                    posY: 'calc(100% - 82px)'
                }
            }]);
            this.loadNextStory().then(() => {
                this.$(document).trigger('app:contextLoader:finish');
                super.clearableWait(this.options.waitingTime, 'discoveryAppendNewStory').then(() => {
                    this.goToNextStory()
                });

            });
        }, 200, false);

        this.$('body').on(this.tapEvent, this.options.moreButton, debouncedMoreButton);

        this.$(this.options.nextStoryLink).on(this.tapEvent, () => {
            if (this.isBusy) return this;
            if (this.blockLoad) {
                this.$(this.options.moreButton).trigger(this.tapEvent);
            } else {
                this.goToNextStory();
            }
        });

        this.$(document).trigger("app:filter:hide");
        this.$(document).on("app:rainbow:ready", () => {
            this.$(document).trigger('app:rainbow:storyColorsToRainbow', this.options.currentStorySection);
            this.rainbowIsReady = true;
        });

        this.$('.rainbowAnimation').addClass(`discoveryRainbowAnimation`);

        return this;
    }

    listen() {

        this.$(document).trigger("app:logo:sticky");

        this.createPageScrollAcontroller();
        this.configCurrentStory();
        this.listenStoryScroll();
        this.listenSubComponents();
        this.goToShopButton();

        if (this.$(this.options.currentStorySection).data('nexturl') && !isMobile()) this.$(this.options.nextStoryLink).show();

        if (this.rainbowIsReady) {
            this.$(document).trigger('app:rainbow:storyColorsToRainbow', this.options.currentStorySection);
        }
        return this;

    }

    destroy() {

        this.destroyHistory();

        this.$(this.options.nextStoryLink).off(this.tapEvent);
        this.$(this.options.btnStoriesNext).off(this.tapEvent);
        this.$(this.options.moreButton).off(this.tapEvent);
        this.$('body').off(this.tapEvent, this.options.moreButton);

        return this;
    }

    destroyHistory() {

        this.destroyPageScrollAcontroller();

        this.$(this.options.currentStorySection)
        .off("scroll")
        .off("touchstart")
        .off("touchmove")
        .off("touchend");

        return this;
    }
}
