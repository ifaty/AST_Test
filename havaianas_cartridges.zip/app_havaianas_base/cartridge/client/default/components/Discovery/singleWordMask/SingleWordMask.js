import AnimatedBase from '../AnimatedBase';
import { Scene } from 'scrollmagic';

export default class SingleWordMask extends AnimatedBase {
    constructor(options) {
        super(options);
        const defaultOptions = {
            root: '.singleWordMask',
            title: '.singleWordMask__title',
            image: '.singleWordMask__image'
        };
        this.options = Object.assign({}, defaultOptions, options.selectors);
    }

    registerScenes() {
        const { $, controller, options: selectors } = this;
        const $components = $(selectors.root);

        this.scenes = $components.map((i, root) => {
            /** @type {anime} anime */
            const { anime } = window;
            const $root = $(root);
            const $title = $root.find(selectors.title);
            const $image = $root.find(selectors.image);
            const translate = Number($root.data('translate') || 0) / 10;

            let animation = anime({
                targets: $title[0],
                scale: {
                    value: [1, 41],
                    easing: 'easeOutQuad'
                },
                translateX: ['0%', `${translate}%`],
                opacity: [
                    {
                        value: [1, 0],
                        delay: 850
                    }
                ],
                duration: 1000,
                autoplay: false
            });

            let imageAnimation = anime({
                targets: $image[0],
                scale: [1.2, 1],
                duration: 1000,
                easing: 'easeInQuad',
                autoplay: false
            });

            return new Scene({ triggerElement: root, duration: '200%', triggerHook: 'onLeave' })
                // .setPin($title[0], { pushFollowers: false })
                .addIndicators()
                .on('progress', e => {
                    console.log(animation.duration);
                    animation.seek(animation.duration * e.progress);
                    imageAnimation.seek(imageAnimation.duration * e.progress);
                })
                .addTo(controller);
        });
        return this;
    }

    listen() {
        this.registerScenes();
        return this;
    }
}
