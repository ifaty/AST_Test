import isMobile from '../../../utils/isMobile';
import scrollMagic from 'scrollmagic';

export default class Titles {

    constructor(options) {

        /** @type {number} Timeout register */
        this.animatedWordEvent = null

        const defaultOptions = {
            selectorEngine: {},
            storySection: '.story__section',
            animatedTextFirst: '.animated_word__text.first',
            animatedTextSecond: '.animated_word__text.second',
            animatedImgFirst: '.animated_word__image--first',
            animatedImgSecond: '.animated_word__image--second',
            animatedWordsImg: '.animated_word__images',
            animatedWords: '.animated_word',
            currentStorySection: '.discovery-mode .story__section.is-current'
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.tapEvent = "click";
        this.scrollMagicController = null;
    }

    setScrollController(controller){
        this.scrollMagicController = controller;

        return this;
    }

    animateCompoundTitle(){

        this.$('.compound_title').map((i, el) => {

            let target = this.$(el);

            if(!target.hasClass("animated")){


                let animation = anime({
                    targets: target.find('.text')[0],
                    top: '150vh',
                    color: '#fff',
                    easing: 'linear',
                    duration: 600,
                    autoplay: false
                })


                this.$(el)
                .addClass("animated")
                .closest(this.options.storySection)
                .on("scroll",  (e) => {

                        let scrollTarget = this.$(e.target);
                        let percentage = scrollTarget.scrollTop() / (scrollTarget[0].scrollHeight - scrollTarget[0].clientHeight) * 100;

                        animation.seek(animation.duration * (percentage / 100))


                })

            }

        })

    }

    animateSingleWord(){

        this.$('.single_word').map((i, el) => {

            let target = this.$(el);

            if(!target.hasClass("animated")){


                let animation = anime({
                    targets: target.find('.text')[0],
                    top: '150vh',
                    color: '#fff',
                    easing: 'linear',
                    duration: 600,
                    autoplay: false
                })


                this.$(el)
                .addClass("animated")
                .closest(this.options.storySection)
                .on("scroll",  (e) => {

                        let scrollTarget = this.$(e.target);
                        let percentage = scrollTarget.scrollTop() / (scrollTarget[0].scrollHeight - scrollTarget[0].clientHeight) * 100;

                        animation.seek(animation.duration * (percentage / 100))


                })

            }

        })

    }

    animateBackgroundtitle(){

        this.$('.background_title').map((i, el) => {

            let target = this.$(el);

            if(!target.hasClass("animated")){


                let animation = anime({
                    targets: target.find('.text')[0],
                    top: '150vh',
                    color: '#fff',
                    easing: 'linear',
                    duration: 600,
                    autoplay: false
                })


                this.$(el)
                .addClass("animated")
                .closest(this.options.storySection)
                .on("scroll",  (e) => {

                        let scrollTarget = this.$(e.target);
                        let percentage = scrollTarget.scrollTop() / (scrollTarget[0].scrollHeight - scrollTarget[0].clientHeight) * 100;

                        animation.seek(animation.duration * (percentage / 100))


                })

            }

        })
    }

    animatedWord() {

        if (!this.$(this.options.animatedImgSecond).attr('style')) {
            this.$(this.options.animatedImgSecond).css({'opacity' : '0'});
        }

        let leftSide = anime({
            targets: this.options.animatedImgFirst,
            opacity: this.$(this.options.animatedImgFirst).css('opacity') == 0 ? 1 : 0,
            autoplay: false,
            easing: 'linear'
        });

        let rightSide = anime({
            targets: this.options.animatedImgSecond,
            opacity: this.$(this.options.animatedImgSecond).css('opacity') == 0 ? 1 : 0,
            autoplay: false,
            easing: 'linear'
        })

        new scrollMagic.Scene({
            triggerElement: this.options.animatedWords,
            triggerHook: 0,
            offset: -100,
            duration: '100%'
        })
        .addTo(this.scrollMagicController)
        .on('enter', (e) => {

            if (!isMobile()) {
                this.$(this.options.animatedWords).on('wheel', (e) => {
                    let direction = Math.max(-1, Math.min(1, (-(e.originalEvent.wheelDelta) || e.originalEvent.deltaY)));
                    leftSide.seek(leftSide.duration * direction);
                    rightSide.seek(rightSide.duration * direction);
                });

            }

        })
        .on('progress', (e) => {

            if (isMobile()) {
                leftSide.seek(leftSide.duration * (e.progress * 5));
                rightSide.seek(rightSide.duration * (e.progress * 5));
            }

        })
    }

    listen(){

        this.animateCompoundTitle();
        this.animateBackgroundtitle();
        this.animateSingleWord();

    }

    destroy(){

        return this;

    }
}
