import isMobile from '../../../utils/isMobile';
import scrollMagic from 'scrollmagic';
// import 'scrollmagic/scrollmagic/minified/plugins/debug.addIndicators.min';

export default class MatchThis {

    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},

            currentStorySection: '.story__section.is-current .match-with',
            matchWithContainer: ".story__section.is-current .match-with",
            matchWithImage: ".match-with-img img",
            matchWithBulletsContainer: ".match-with-bullets",
            matchWithBullets: ".bullet"

        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.tapEvent = "click";
        this.scrollMagicController = null;
    }

    setScrollController(controller){
        this.scrollMagicController = controller;

        return this;
    }

    configBullet() {

        this.$(this.options.matchWithContainer).map((i, el) => {

            let scene = new scrollMagic.Scene({
                triggerElement: el,
                triggerHook: 0.3,
                duration: this.$(el).height()
            })
            .addTo(this.scrollMagicController)
            // .addIndicators()
            .on('enter', (e) => {

                let target = this.$(e.target.triggerElement());

                if (e.state != "DURING" || target.hasClass("animated")) return;

                let image = target.find(this.options.matchWithImage);


                this.$(this.options.matchWithBulletsContainer).css({
                    position: 'absolute',
                    left: -Math.abs(image.offset().left),
                    top: -Math.abs(image.offset().top),
                    right: -Math.abs(image.offset().left),
                    bottom: -Math.abs(image.offset().top),
                    margin: 'auto',
                    width: image.width(),
                    height: image.height()
                })

                target.find(this.options.matchWithBullets).map((i, el) => {

                    let y = $(el).data().y;
                    let x = $(el).data().x;

                    this.$(el).css({
                        left: `${x}%`,
                        top: `calc(${y}%)`,
                    }).addClass("is-visible")

                    if (!isMobile()) {
                        setTimeout(() => this.$(el).removeClass("is-visible"),3000)
                    }

                });

                target.addClass("animated");

            })

        })

        return this;
    }

    listen(){

        this.destroy().configBullet();

    }

    destroy(){

        return this;

    }

}
