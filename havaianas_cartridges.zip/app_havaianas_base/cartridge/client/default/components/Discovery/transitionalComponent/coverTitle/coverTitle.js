import isMobile from '../../../../utils/isMobile';
import scrollMagic from 'scrollmagic';

export default class CoverTitle {

    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},

            fullWidthComponent: '.fulWidthComponent',
            coverTitle: '.is-current .chapeu',
            coverTitleComponent: '.coverTitleComponent',
            coverTitleComponentContent: '.coverTitleComponent__content',
            currentStorySection: '.story__section',
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.tapEvent = "click";
        this.cols = 100 / 79;
        this.mobileCols = 100 / 11;
    }

    setScrollController(controller){
        this.scrollMagicController = controller;

        return this;
    }

    setPageScrollActions() {

        this.$(this.options.coverTitle).map((i, el) => {

            let target = this.$(el);
            let fullWidthComponent = target.closest('.experience-component').prev().find(this.options.fullWidthComponent);
            let fullWidthAnimation = null;
            let translateTop = '';

            if (window.innerWidth < 1800) {
                translateTop = '-248px';
            } else {
                translateTop = '-342px';
            }

            let coverTitle = anime({
                targets: [target.find(this.options.coverTitleComponentContent)[0]],
                translateY: [translateTop , '0'],
                autoplay: false,
                easing: 'linear'
            })

            if (fullWidthComponent.length) {
                fullWidthAnimation = anime({
                    targets: [fullWidthComponent[0]],
                    width: `${this.cols * 73}%`,
                    marginLeft: `${this.cols * 2}%`,
                    autoplay: false,
                    easing: 'linear'
                })
            }

            let scene = new scrollMagic.Scene({
                triggerElement: el,
                triggerHook: 0.9,
                duration: target.height()
            })
            .addTo(this.scrollMagicController)
            .on('progress', (e) => {
                coverTitle.seek(coverTitle.duration * e.progress)
                if (fullWidthAnimation && !isMobile()) {
                    fullWidthAnimation.seek(fullWidthAnimation.duration * (e.progress * 2))
                }
            })

        })

    }


    listen(){

        this.setPageScrollActions();
    }

    destroy() {

    }

}
