import BigTextComponent from "./bigTextComponent/bigTextComponent";
import MarqueTextComponent from "./marqueTextComponent/marqueTextComponent";
import CoverTile from "./coverTitle/coverTitle";
import FunFact from "../../FunFact/FunFact";
import SingleWordsAsBackground from "./singleWordsAsBackground/singleWordsAsBackground";
import TagWord from "./tagWordComponent/tagWordComponent";

export default class TransitionalComponent {

    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.bigTextComponent = new BigTextComponent({selectorEngine: this.options.selectorEngine});
        this.marqueTextComponent = new MarqueTextComponent({selectorEngine: this.options.selectorEngine});
        this.coverTile = new CoverTile({selectorEngine: this.options.selectorEngine});
        this.funFact = new FunFact({selectorEngine: this.options.selectorEngine});
        this.singleWordsAsBackground = new SingleWordsAsBackground({selectorEngine: this.options.selectorEngine});
        this.tagWord = new TagWord({selectorEngine: this.options.selectorEngine});
    }

    setScrollController(controller){
        this.scrollMagicController = controller;
        return this;
    }

    listen(){

        this.bigTextComponent
            .setScrollController(this.scrollMagicController)
            .listen();

        this.coverTile
            .setScrollController(this.scrollMagicController)
            .listen();

        this.marqueTextComponent
            .setScrollController(this.scrollMagicController)
            .listen();

        this.funFact.listen();

        this.singleWordsAsBackground
            .setScrollController(this.scrollMagicController)
            .listen();

        this.tagWord
            .setScrollController(this.scrollMagicController)
            .listen();
    }

}
