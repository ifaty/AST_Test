import isMobile from '../../../../utils/isMobile';
import '../../../../utils/fitText';
import scrollMagic from 'scrollmagic';
// import 'scrollmagic/scrollmagic/minified/plugins/debug.addIndicators.min';

export default class TagWord {

    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},

            bigTextParagraphWrapper: '.tagWord',
            bigTextParagraphText: '.tagWord__textContainer',
            bigTextParagraphImage: '.tagWord__imagesContainer',
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.tapEvent = "click";
        this.scrollMagicController = null;
    }

    setScrollController(controller){
        this.scrollMagicController = controller;

        return this;
    }

    setPageScrollActions() {

        this.$(this.options.bigTextParagraphWrapper).map((i, el) => {

            let target = this.$(el);

            if (!target.find(this.options.bigTextParagraphImage).length) return;

            let animation = anime({
                targets: target.find('.tagWord__textContainer__text')[0],
                translateY: target.outerHeight(),
                easing: 'linear',
                autoplay: false
            });

            let scene = new scrollMagic.Scene({
                triggerElement: el,
                triggerHook: 0,
                duration: target.outerHeight()
            })
            // .addIndicators()
            .addTo(this.scrollMagicController)
            .on('progress', (e) => {

                animation.seek(animation.duration * e.progress);

            })
        })

    }

    listen(){
        this.setPageScrollActions();
    }

}
