import isMobile from '../../../../utils/isMobile';
import throttle from '../../../../utils/throttle';
import '../../../../utils/fitText';
import scrollMagic from 'scrollmagic';

// import 'scrollmagic/scrollmagic/minified/plugins/debug.addIndicators.min';

export default class BigTextComponent {

    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},

            bigTextParagraphWrapper: '.big-text-background',
            bigTextParagraphText: '.big-text-background-text',
            bigTextParagraphImage: '.big-text-background-image',
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.tapEvent = "click";
        this.scrollMagicController = null;
        this.animations = [];
    }

    setScrollController(controller){
        this.scrollMagicController = controller;

        return this;
    }

    /**
     * Gets or generate the element anime instance
     * @param {HTMLElement} el element to be animated
     * @param {Object} configs anime configs
     * @returns {Anime} Instance
     */
    getAnimation(el, configs) {
        let animation = this.animations.find(([element]) => element === el);
        if (!animation) {
            animation = [el, anime({
                targets: el,
                ...configs
            })];
            this.animations.push(animation);
        }
        return animation[1];
    }

    setPageScrollActions() {

        this.$(this.options.bigTextParagraphWrapper).map((i, el) => {

            let target = this.$(el);

            if (!target.find(this.options.bigTextParagraphImage).length) return;

            target.find(this.options.bigTextParagraphImage).height(target.find(this.options.bigTextParagraphText).outerHeight());

            let animation = this.getAnimation(target.find('h1')[0], {
                translateY: (target.outerHeight() / 2),
                easing: 'linear',
                autoplay: false
            });

            let scene = new scrollMagic.Scene({
                triggerElement: el,
                offset: target.find('h1').outerHeight() / 2,
                duration: target.outerHeight() / 2
            })
            // .addIndicators()
            .addTo(this.scrollMagicController)
            .on('progress', (e) => {
                animation.seek(animation.duration * e.progress);

            })
        })

    }

    checkTextSize(){

        this.$(this.options.bigTextParagraphWrapper).map((i, el) => {

            let textWrapper = this.$(el).find(this.options.bigTextParagraphText);
            let text = textWrapper.find("h1");
            let initialSize = 15;
            let step = 0.5;

            do {

                initialSize += step;
                text.css({'font-size': `${initialSize}vh`})

            } while (text.height() < textWrapper.height());

        });
    }

    setResizeRules() {

        let throttledResize = throttle((e) => {

            this.$(this.options.bigTextParagraphWrapper).map((i, el) => {

                let target = this.$(el);

                if (!target.find(this.options.bigTextParagraphImage).length) return;

                target.find(this.options.bigTextParagraphImage).height(target.find(this.options.bigTextParagraphText).outerHeight());

            });

        },200);

        this.$(window).on('resize',throttledResize);
    }

    listen(){

        this.setPageScrollActions();
        this.setResizeRules();
        // this.checkTextSize();
    }

}
