import isMobile from '../../../../utils/isMobile';
import '../../../../utils/fitText';
import scrollMagic from 'scrollmagic';
// import 'scrollmagic/scrollmagic/minified/plugins/debug.addIndicators.min';

export default class SingleWordsAsBackground {

    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},

            bigTextParagraphWrapper: '.singleWordsBackground',
            bigTextParagraphText: '.singleWordsBackground__text',
            bigTextParagraphImage: '.singleWordsBackground__image',
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.tapEvent = "click";
        this.scrollMagicController = null;
    }

    setScrollController(controller){
        this.scrollMagicController = controller;

        return this;
    }

    setPageScrollActions() {

        this.$(this.options.bigTextParagraphWrapper).map((i, el) => {

            let target = this.$(el);

            if (!target.find(this.options.bigTextParagraphImage).length) return;

            let animation = anime({
                targets: target.find('.singleWordsBackground__textContainer')[0],
                translateY: (target.outerHeight() / 2),
                easing: 'linear',
                autoplay: false
            });

            let scene = new scrollMagic.Scene({
                triggerElement: el,
                triggerHook: 0,
                duration: target.outerHeight() / 2
            })
            // .addIndicators()
            .addTo(this.scrollMagicController)
            .on('progress', (e) => {

                animation.seek(animation.duration * e.progress);

            })
        })

    }

    listen(){
        this.setPageScrollActions();
    }

}
