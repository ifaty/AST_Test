import isMobile from '../../../../utils/isMobile';
import scrollMagic from 'scrollmagic';

export default class MarqueTextComponent {
    constructor(options) {
        const defaultOptions = {
            selectorEngine: {},

            marqueTextWrapper: '.marque-text-background-wrapper',
            marqueTextContainer: '.is-current .marque-text-background',
            marqueTextElementText: '.marque-text-background-text',
            marqueTextElementImage: '.marque-text-background-image ',
            currentStorySection: '.story__section.is-current',
            bigTextParagraph: '.marque-text-background h1'
        };

        this.options = Object.assign({}, defaultOptions, options);
        /** @type {JQueryStatic} this.$ */
        this.$ = this.options.selectorEngine;
        this.tapEvent = 'click';
    }

    setScrollController(controller) {
        this.scrollMagicController = controller;

        return this;
    }

    listenMarqueTextScroll() {
        const { anime } = window;
        const { $, options } = this;

        $(options.marqueTextContainer).each((i, target) => {
            const $target = $(target);
            const $wrapper = $target.closest(options.marqueTextWrapper);
            const $title = $target.find('h1');
            const $image = $target.find(options.marqueTextElementImage);

            // TODO: handle window resize
            let textScroll = anime({
                targets: $title[0],
                left: [$(window).width(), `-${$title.width()}px`],
                autoplay: false,
                easing: 'linear'
            });

            const imageScroll = anime({
                targets: $image[0],
                translateY: [-150, 0],
                autoplay: false,
                easing: 'linear'
            });

            // BEGIN image animation
            new scrollMagic.Scene({
                triggerElement: $wrapper[0],
                duration: $target.outerHeight() / 4
            })
                .on('progress', e => imageScroll.seek(imageScroll.duration * e.progress))
                .addTo(this.scrollMagicController);

            // END image animation
            new scrollMagic.Scene({
                triggerElement: target,
                offset: ($target.outerHeight() / 4) * 3,
                duration: $target.outerHeight() / 4,
                triggerHook: 'onEnter'
            })
                .on('progress', e => imageScroll.seek(imageScroll.duration * (1 - e.progress)))
                .addTo(this.scrollMagicController);

            // TEXT animation
            new scrollMagic.Scene({
                triggerElement: target,
                offset: $target.outerHeight() / 4,
                duration: $target.outerHeight() / 2
            })
                .addTo(this.scrollMagicController)
                .setPin($image[0])
                .on('enter', () => {
                    $target.find(options.marqueTextElementText).css({ position: 'fixed', transform: 'none' });
                })
                .on('progress', (e) => {
                    textScroll.seek(textScroll.duration * e.progress);
                })
                .on('leave', (e) => {
                    if (e.state === 'BEFORE') {
                        $target.find(options.marqueTextElementText).css({ position: 'absolute', transform: 'none' });
                    } else {
                        $target
                            .find(options.marqueTextElementText)
                            .css({ position: 'absolute', transform: `translateY(${$target.outerHeight() / 2}px)` });
                    }
                });
        });
    }

    listen() {
        this.listenMarqueTextScroll();
    }
}
