import AnimatedBase from '../AnimatedBase';
import { Scene } from 'scrollmagic';

export default class CompoundTitle extends AnimatedBase {
    constructor(options) {
        super(options);

        const defaultOptions = {
            root: '.compoundTitle',
            content: '.compoundTitle__content'
        };

        this.options = Object.assign({}, defaultOptions, options.selectors);
    }

    registerScenes() {
        const { $, controller, options: selectors } = this;
        const $components = $(selectors.root);
        this.scenes = $components.find(selectors.content).map((i, content) => {
            const $content = $(content);
            const $root = $content.closest(selectors.root);
            return new Scene({ triggerElement: $root[0], duration: $root.height() / 2, offset: $root.height() / 4 })
                .addTo(controller)
                .on('progress', e => $content.css({ top: 50 + (e.progress * 100) + '%' }));
        });
        return this;
    }

    listen() {
        this.registerScenes();
        return this;
    }
}
