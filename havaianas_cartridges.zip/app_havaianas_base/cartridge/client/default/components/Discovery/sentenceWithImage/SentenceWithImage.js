import AnimatedBase from '../AnimatedBase';
import { Scene } from 'scrollmagic';

export default class SentenceWithImage extends AnimatedBase {
    constructor(options) {
        super(options);
        const defaultOptions = {
            root: '.sentenceWithImage',
            title: '.sentenceWithImage__title'
        };
        this.options = Object.assign({}, defaultOptions, options.selectors);
    }

    registerScenes() {
        const { $, controller, options: selectors } = this;
        const $components = $(selectors.root);
        this.scenes = $components.map((i, root) => {
            const $root = $(root);
            const $title = $root.find(selectors.title);
            return new Scene({ triggerElement: root, duration: $root.height() / 2, offset: $title.height() / 2 })
                .setPin($title[0], { pushFollowers: false })
                .addTo(controller);
        });
        return this;
    }

    listen() {
        this.registerScenes();
        return this;
    }
}
