import isMobile from '../../utils/isMobile';
import Drawer from '../Drawer/Drawer';

export default class Wishlist {
    constructor(options) {
        const defaultOptions = {
            productTile: '.product',
            productTileWishlistRemoveBtn: '.page-wishlist .product__tile-wishlist-btn.active',

            shopmodeGrid: '.shopmode__grid',
            shopmodeCell: '.shopmode__cell',
            wishlistProducts: '.wishlist-products',
            wishlistMoreBtn: '.wishlist-btn-show-more',
            shopmodeCellGutter: '.page-wishlist .shopmode__cell-gutter',

            stash: '#stash',

            selectorEngine: {}
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;
        this.drawer = new Drawer({ selectorEngine: this.$ });

        this.tapEvent = "click";
    }

    removeProduct(el) {
        let btn = this.$(el);
        this.$.get({
            ajax: true,
            url: btn.data('url'),
            success: () => {
                btn.parents(this.options.productTile).hide(500, () => {

                    if (!this.$(this.options.stash).length) this.$('body').append('<div id="stash" style="display: none"></div>');

                    this.$(btn.parents(this.options.shopmodeCell)).appendTo(this.options.stash);
                    this.options.shop.buildIsotopeLayout(this.$(this.options.shopmodeGrid)[0]);

                });

                this.$(document).on('app:toast:closeDefault', (e) => {
                    this.$(this.options.stash).remove();
                });

                // If user clicks on Toast button, recovery the product and display it again on Wishlist
                this.$(document).on('app:toast:closeUser', (e) => {

                    let recoveryProduct = this.$(this.options.stash).children().last();
                    this.$(this.options.shopmodeCellGutter).after(recoveryProduct);

                    btn.parents(this.options.productTile).show();
                    this.options.shop.buildIsotopeLayout(this.$(this.options.shopmodeGrid)[0]);
                    this.$(this.options.stash).remove();
                });

             },
            fail: data => {
                console.log(data.msg);
            }
        });
    }

    listenRemoveProduct() {
        this.$('body')
            .on(this.tapEvent, this.options.productTileWishlistRemoveBtn, (ev) => {
                this.removeProduct(ev.currentTarget);
            });
    }

    init () {
        if (isMobile()) {
            this.drawer.closeDrawer();
        }

        return this;
    }

    listen() {

        if (this.watching) return this.reload();

        this.init();

        this.listenRemoveProduct();

        this.watching = true;
        return this;
    }

    reload() {

        this.watching = false;

        return this.destroy().listen();

    }

    destroy() {

        this.$('body')
        .off(this.tapEvent, this.options.productTileWishlistRemoveBtn);

        return this;
    }
}
