import isMobile from '../../utils/isMobile';

export default class customSelect {

    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},

            customSelect: ".custom__select",
            customSelectItem: ".custom__select-item",
            customSelectChoosenItem: ".custom__select-choosen-item",
            customSelectFloatingLabel: ".custom__select-floating-label",
            customSelectContent: ".custom__select-content",
            customSelectOptionContent: ".custom__select-options",
            customSelectExtended: ".js-custom__select-expanded",

            customSelectDrawerLink: ".js-custom__select--drawerLink",
            customSelectDrawerContent: ".js-custom__select--drawerContent",
            customSelectDrawerItem: ".custom__select-drawer-items",
            customSelectDrawerOverlay: ".js-custom__select-drawerOverlay",
            customSelectDrawerLabel: ".custom__select-drawer-label",
            customSelectHiddenInput: ".custom__select-hidden-input"
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.$ = this.options.selectorEngine;

        this.tapEvent = "click";
        this.isDrawerOpen = false;

        this.watching = false;
    }

    openDrawer(target) {

        this.isDrawerOpen = true;
        this.$(target).closest(this.options.customSelect).addClass('js-custom__select-drawer--isVisible');

        return this;
    }

    closeDrawer() {
        this.isDrawerOpen = false;
        this.$(this.options.customSelect).removeClass('js-custom__select-drawer--isVisible');

        return this;
    }

    expandSelectOptions(target) {
        this.$(target).closest(this.options.customSelect).toggleClass('js-custom__select-expanded');

        this.$(target).toggleClass('matrixUiElement');
        this.$(target).find(this.options.customSelectOptionContent).toggleClass('matrixUiElement');

        return this;
    }

    floatingLabel(target) {

        let htmlValue = this.$(target).attr('data-value');
        let valueSelectedItem = this.$(target).text();

        this.$(target).closest(this.options.customSelect).removeClass('js-custom__select-expanded');
        this.$(target).closest(this.options.customSelectContent).removeClass('matrixUiElement');

        this.$(target).parents(this.options.customSelectContent).find(this.options.customSelectFloatingLabel).addClass('js-custom__select--active');

        this.$(target).parents(this.options.customSelectContent).find(this.options.customSelectChoosenItem).html(valueSelectedItem);

        //adding option value to hidden input
        this.$(target).closest(this.options.customSelect).find(this.options.customSelectHiddenInput).val(htmlValue);

        //close drawer
        this.closeDrawer();

        return this;
    }


    listen() {
        if(this.watching) return this.reload();


        this.$(this.options.customSelectDrawerLink).on(this.tapEvent, (ev) => {
            ev.stopPropagation();
            this.closeDrawer();
            this.openDrawer(ev.currentTarget);
        });

        this.$(this.options.customSelectDrawerItem).on(this.tapEvent, (ev) => {
            ev.stopPropagation();
            this.floatingLabel(ev.currentTarget);
        });

        this.$(this.options.customSelectDrawerOverlay).on(this.tapEvent, (ev) => {
            this.closeDrawer();
            ev.stopPropagation();
        });

        if (!isMobile()) {
            this.$('body').on(this.tapEvent, (e) => {
                if (this.$('.js-custom__select-drawer--isVisible').length) {
                    e.stopPropagation();
                    e.preventDefault();
                    this.closeDrawer();
                }
            })
        }


        this.watching = true;

        return this;
    }

    reload() {

        this.watching = false;

        return this.destroy().listen();

    }

    destroy() {

        this.$(this.options.customSelectItem).off('click');
        this.$(this.options.customSelectDrawerLink).off(this.tapEvent);
        this.$(this.options.customSelectDrawerItem).off(this.tapEvent);
        this.$(this.options.customSelectDrawerContent).off(this.tapEvent);

        return this;
    }
}
