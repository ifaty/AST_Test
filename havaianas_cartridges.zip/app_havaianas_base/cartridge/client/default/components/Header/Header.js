import isMobile from '../../utils/isMobile';
import Throttle from '../../utils/throttle';

export default class Header {
    constructor(options) {

        const defaultOptions = {
            selectorEngine: {},

            body: "body",
            header: "header.header",
            headerActions: ".superActions__header",
            headerSearch: '.superActions__header__search',
            headerSection: '.story__section',
            headerLogo: ".header__logo",
            backButton: ".header__back-button",
            myPage: ".pages-viewport .container",
            elementAnimate: '.elementAnimate',
            searchNoTextClass: 'superActions__header__search__no-text',
            backButton: '.header .menu__link.menu__link-back'
        }

        this.options = Object.assign({}, defaultOptions, options);
        this.defaults = defaultOptions;
        this.$ = this.options.selectorEngine;

        this.tapEvent = isMobile() ? "touchend" : "click";
        this.stickyPages = '.story__section, .page-viewAll, .page-product, .page-shop, .page-search, .page-wishlist';

        this.observeGoBackButton();

    }

    setOptions(options) {

        this.options = Object.assign({}, this.options, options);

        return this;
    }

    observeGoBackButton() {
        this.$(document).on("app:frame:ready", (ev, data) => {
            this.$(this.options.backButton).attr('href', data.previousLink);
        });
    }

    hideHeaderSearchText(){
        this.$(this.options.headerSearch).addClass(this.options.searchNoTextClass);
    }

    showHeaderSearchText(){
        this.$(this.options.headerSearch).removeClass(this.options.searchNoTextClass);
    }

    hideHeader(){
        this.$(this.options.header).hide();
    }

    showHeader(){
        this.$(this.options.header).show();
    }

    hideHeaderActions(){
        this.$(this.options.headerActions).hide();
    }

    showHeaderActions(){
        this.$(this.options.headerActions).show();
    }

    resetDefaultOptions() {
        this.options = this.defaults;

        return this;
    }

    listenScroll() {

        let lastPercentage = 0;

        let throttleFunc = Throttle((e) => {

            let target = this.$(e.currentTarget);
            let percentage = Math.round(target.scrollTop()) / Math.round(target[0].scrollHeight - target[0].clientHeight) * 100;

            if (lastPercentage) {
                if (lastPercentage > percentage) {
                    this.stickLogo();
                } else {
                    this.unstickLogo();
                }
            }

            if (percentage == 0) {
                this.stickLogo();
            }

            lastPercentage = percentage;

        }, isMobile() ? 600 : 20);

        this.$(this.stickyPages).on("scroll", throttleFunc)

    }

    stickLogo() {

        let header = this.$(this.options.header);
        if (!header.hasClass("unstick") || this.isAnimatingHeaderStick) return;

        this.isAnimatingHeaderStick = true;

        anime.remove(header[0]);

        anime({
            targets: header[0],
            translateY: 0,
            duration: 200,
            easing: 'easeInOutQuad',
            complete: () => {
                header.removeClass("unstick");
                this.isAnimatingHeaderStick = false;
            }
        });

        return this;
    }

    unstickLogo() {

        let header = this.$(this.options.header);
        if (header.hasClass("unstick") || this.isAnimatingHeaderUnStick) return;

        this.isAnimatingHeaderUnStick = true;

        anime.remove(header[0]);

        anime({
            targets: header[0],
            translateY: -this.$(this.options.headerLogo).outerHeight(),
            easing: 'easeInOutQuad',
            duration: 200,
            complete: () => {
                header.addClass("unstick");
                this.isAnimatingHeaderUnStick = false;
            }
        });

        return this;
    }

    listen() {

        this.listenScroll();

        this.$(document)
        .on("app:logo:sticky", () => {
            this.stickLogo();
            this.listenScroll();
        })
        .on('app:frame:changed', () => this.stickLogo())

    }

    destroy() {



    }

}
