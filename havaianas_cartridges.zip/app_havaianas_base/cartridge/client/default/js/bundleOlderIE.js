// Main javascript entry point
// Should handle bootstrapping/starting application
// App.js should be the last imported script
'use strict'

import "@babel/polyfill";
import "./bundle.js";