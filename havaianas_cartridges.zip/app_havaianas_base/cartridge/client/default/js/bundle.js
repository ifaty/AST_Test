// Main javascript entry point
// Should handle bootstrapping/starting application
'use strict'

// -----------------------------------------------
// External Importings
// -----------------------------------------------
import e from 'jquery';
import anime from 'animejs/lib/anime.min.js';
window.$ = e;
window.anime = anime;

import loadTouchEvents from 'jquery-touch-events';
import '../utils/easings';
loadTouchEvents(e);

// -----------------------------------------------
// App importings
// -----------------------------------------------
import Debug from '../utils/debug';
import App from '../components/App/App';
import GoogleTagManager from '../components/GoogleTagManager/GoogleTagManager';

import LazyLoad from '../components/LazyLoad/LazyLoad';
import LightBox from '../components/LightBox/LightBox';
import Colors from '../components/Colors/Colors';
import Header from '../components/Header/Header';
import HoverHint from '../components/HoverHint/HoverHint';
import Rainbow from '../components/Rainbow/Rainbow';
import Frame from '../components/Frame/Frame';
import ViewAll from '../components/ViewAll/ViewAll';
import Discovery from '../components/Discovery/Discovery';
import ShopMode from '../components/ShopMode/ShopMode';
import ShopButton from '../components/ShopButton/ShopButton';
import RainbowCursor from '../components/Rainbow/RainbowCursor';
import Menu from '../components/Menu/Menu';
import Account from '../components/Account/Account';
import PaymentMethods from '../components/Account/PaymentMethods';
import Address from '../components/Address/Address';
import Size from '../components/Size/Size';
import Animation from '../components/Animation/Animation';
import Drawer from '../components/Drawer/Drawer';
import Wishlist from '../components/Wishlist/Wishlist';
import ProductVariation from '../components/Product/ProductVariation';
import ProductBuyButton from '../components/ProductBuyButton/ProductBuyButton';
import Product from '../components/Product/Product';
import ProductSizeGuide from '../components/ProductSizeGuide/ProductSizeGuide';
import ProductReviews from '../components/Product/ProductReviews';
import Toast from '../components/Toast/Toast';
import FormValidator from '../utils/clientSideValidation';
import RequiredFieldsValidator from '../utils/requiredFieldsValidator';
import FunFact from '../components/FunFact/FunFact';
import DatePicker from '../components/DatePicker/DatePicker';
import ContextLoader from '../components/ContextLoader/ContextLoader';
import Checkout from '../components/Checkout/Checkout';
import CheckoutEditProduct from '../components/Checkout/EditProduct';
import ProductPayButton from '../components/ProductPayButton/ProductPayButton';
import Order from '../components/Order/Order';
import PaymentOptions from '../components/Checkout/PaymentOptions';
import Filter from '../components/Filter/Filter';
import OrderBy from '../components/OrderBy/OrderBy';
import Contact from '../components/Contact/Contact';
import Institutional from '../components/Institutional/Institutional';
import Faq from '../components/Institutional/Faq/Faq';
import TheMask from '../components/TheMask/TheMask';
import GeoLocation from '../components/GeoLocation/GeoLocation';
import BecomeFranchisee from '../components/Institutional/BecomeFranchisee/BecomeFranchisee';
import BecomeDealer from '../components/Institutional/BecomeDealer/BecomeDealer';
import FindStore from '../components/FindStore/FindStore';
import CustomSelect from '../components/CustomSelect/CustomSelect';


// -----------------------------------------------
// Instances
// -----------------------------------------------
const app = new App({
    selectorEngine: e
});

const colors = new Colors({
    selectorEngine: e
});

const frame = new Frame({
    selectorEngine: e,
    baseUrl: window.location.protocol + "//" + window.location.host + "/",
});
const contextLoader = new ContextLoader({
    selectorEngine: e
});
const debug = new Debug({
    selectorEngine: e
});
const lightbox = new LightBox({
    selectorEngine: e,
    colors: colors
});
const toast = new Toast({
    selectorEngine: e
});
const lazyload = new LazyLoad({
    selectorEngine: e
});
const animation = new Animation({
    selectorEngine: e,
    frame: frame
});
const productBuyButton = new ProductBuyButton({
    selectorEngine: e,
    animation: animation
});
const productPayButton = new ProductPayButton({
    selectorEngine: e,
    productBuyButton: productBuyButton
});
const header = new Header({
    selectorEngine: e,
    frame: frame
});
const formValidator = new FormValidator({
    selectorEngine: e,
    toast: toast
});
const requiredFieldsValidator = new RequiredFieldsValidator({
    selectorEngine: e
});
const hintPNGSequence = new HoverHint({
    selectorEngine: e,
    images: e('.hoverHint__images').find('img')
});
const rainbowCursor = new RainbowCursor({
    selectorEngine: e
});
const rainbow = new Rainbow({
    selectorEngine: e,
    rainbowCursor: rainbowCursor
});
const view = new ViewAll({
    selectorEngine: e,
    frame: frame,
    contextLoader: contextLoader,
    toast: toast,
    header: header
});
const shopButton = new ShopButton({
    selectorEngine: e
});
const shop = new ShopMode({
    selectorEngine: e,
    frame: frame,
    shopButton: shopButton,
    toast: toast,
    productBuyButton: productBuyButton,
    productPayButton: productPayButton
});
const discovery = new Discovery({
    selectorEngine: e,
    frame: frame,
    shopButton: shopButton,
    colors: colors,
    productPayButton: productPayButton,
    header: header
});
shop.setDiscoveryObject(discovery);
discovery.setShopObject(shop);
const account = new Account({
    selectorEngine: e,
    frame: frame,
    toast: toast,
    validator: formValidator
});
const paymentMethods = new PaymentMethods({
    selectorEngine: e,
    frame: frame,
    toast: toast,
    validator: formValidator
});
const address = new Address({
    selectorEngine: e,
    frame: frame,
    toast: toast,
    validator: formValidator
});
const size = new Size({
    selectorEngine: e,
    colors: colors
});
const drawer = new Drawer({
    selectorEngine: e
});
const wishlist = new Wishlist({
    selectorEngine: e,
    shop: shop,
    drawer: drawer,
    frame: frame
});
const productVariation = new ProductVariation({
    selectorEngine: e,
    animation: animation,
    frame: frame
});
const productSizeGuide = new ProductSizeGuide({
    selectorEngine: e
});
const datePicker = new DatePicker({
    selectorEngine: e
});
const institutional = new Institutional({
    selectorEngine: e
});
const funFact = new FunFact({
    selectorEngine: e
});
const checkout = new Checkout({
    selectorEngine: e,
    frame: frame,
    toast: toast,
    contextLoader: contextLoader,
    validator: formValidator,
    frame: frame,
    colors: colors
});
const order = new Order({
    selectorEngine: e,
    frame: frame,
    toast: toast
});
const checkoutEditProduct = new CheckoutEditProduct({
    selectorEngine: e,
    frame: frame
});
const paymentOptions = new PaymentOptions({
    selectorEngine: e,
    toast: toast,
    frame: frame,
    contextLoader: contextLoader,
    validator: formValidator,
    productPayButton: productPayButton,
    requiredFieldsValidator: requiredFieldsValidator
});
const filter = new Filter({
    selectorEngine: e,
    frame: frame,
    rainbow: rainbow
});
const orderBy = new OrderBy({
    selectorEngine: e,
    frame: frame
});
const productReviews = new ProductReviews({
    selectorEngine: e
});
const product = new Product({
    selectorEngine: e,
    productBuyButton: productBuyButton,
    productPayButton: productPayButton,
    productVariation: productVariation,
    toast: toast,
    shop: shop,
    productVariation: productVariation,
    rainbow: rainbow,
    colors: colors,
    frame: frame
});
const menu = new Menu({
    selectorEngine: e,
    frame: frame,
    rainbow: rainbow,
    frame: frame,
    colors: colors,
    productVariation: productVariation,
    drawer: drawer,
    toast: toast
});
const contact = new Contact({
    selectorEngine: e,
    toast: toast,
    validator: formValidator
});
const faq = new Faq({
    selectorEngine: e,
    toast: toast
});
const theMask = new TheMask({
    selectorEngine: e,
    frame: frame
});
const geoLocation = new GeoLocation({
    selectorEngine: e
});

const becomeFranchisee = new BecomeFranchisee({
    selectorEngine: e,
    toast: toast,
    validator: formValidator
});

const becomeDealer = new BecomeDealer({
    selectorEngine: e,
    toast: toast,
    validator: formValidator
});

const findStore = new FindStore({
    selectorEngine: e,
    frame: frame
});

const gtm = new GoogleTagManager({
    selectorEngine: e,
});

const customSelect = new CustomSelect({
    selectorEngine: e,
});

// -----------------------------------------------
// Little useful things
// -----------------------------------------------

import isMobile from '../utils/isMobile';
import log from '../utils/log';
import URI from '../utils/uri';
let uri = new URI();

// -----------------------------------------------
// DOM is ready!
// -----------------------------------------------


app.ready().then(() => {

    header.listen();
    productPayButton.init();

    if (isMobile()) {
        e("body").addClass('is-mobile')
    }

    if (e('.page-discovery').length) {
        discovery.init();
        shopButton.resetDefaultSettings();

    } else if (e('.discovery-mode').length) {
        discovery.init();
        e('body').addClass('page-discovery-body');

    } else if (e('.page-viewAll').length) {

        view.init().destroy().listen();

        header.hideHeaderSearchText();

        discovery.goToShopButton();

    } else if (e('.page-product').length) {

        e('body').addClass('page-product-body');

        productSizeGuide.listen();
        funFact.listen();

    }

    if (e('.page-search').length) {

        header.hideHeaderSearchText();
        filter.listen();
        orderBy.listen();
        shop.setPageName('page-search').init();

    } else if (e('.page-wishlist').length) {

        header.hideHeaderSearchText();
        filter.listen();
        orderBy.listen();
        shop.setPageName('page-wishlist').init();
        productPayButton.init();

    } else if (e('.page-shop').length) {
        header.hideHeaderSearchText();
        filter.listen();
        orderBy.listen();
        shop.setPageName('page-shop').init();
    } else {
        filter.hideFilter();
    }

    if (e('.page-internationalOffices').length) {
        institutional.destroy().listen();
    }

    if (e('.page-institutional-body').length) {
        institutional.destroy().listen();
    }

    if (e('[class*="page-checkout"]').length) {
        checkout.destroy().listen();
        paymentOptions.destroy().init();
    } else if (e('.page-Checkout-EditDrawer').length) {
        checkoutEditProduct.init();
    } else if (e('.page-contact').length || e('.page-becomeDealer').length) {
        contact.listen();
        customSelect.destroy().listen();
    } else if (e('.page-faq').length) {
        institutional.destroy().listen();
        faq.listen();
    }


    shopButton.listen();
    discovery.listenExternalEvents();
});

// -----------------------------------------------
// Document loaded!
// -----------------------------------------------

app.load().then(() => {
    lazyload.start();
    lightbox.listen();
    gtm.listen();

    e("body").addClass("is-ready");

    if (!(e('[class*="page-checkout"]').length || e('.page-product').length)) {
        e("body").addClass("collapseRainbow");
    }
});

// -----------------------------------------------
// Document + rainbow animation is done/loaded!
// -----------------------------------------------

app.rainbowAttached().then(() => {
    colors.listen();
    contextLoader.listen();
    theMask.listen();
    requiredFieldsValidator.listen();
    geoLocation.init();
    lightbox.listen();

    if (isMobile()) {
        rainbow.fadeIn()
            .then(() => rainbow.hideRainbowLoading())
            .then(() => rainbow.listen())
            .then(() => e(document).trigger("app:rainbow:ready"))

    } else {
        hintPNGSequence.fadeIn(800);
        hintPNGSequence
            .animate()
            .then(() => hintPNGSequence.fadeOut(300))
            .then(() => {
                if (!e('.page-product').length) {
                    return hintPNGSequence.collapseToRainbowEndTransition();
                }

                return this;
            })
            .then(() => {
                rainbow.hideRainbowLoading();
                rainbow.listen();
                rainbow.fadeIn();
                e(document).trigger("app:rainbow:ready");
            })

    }

    if (e('.page-paymentMethods').length) {
        paymentMethods.listen();
    }

    if (e('.discovery-mode').length) {
        productPayButton.init();
    }

    if (e('.page-viewAll').length) {
        shopButton.listen();
    }

    if (e('.page-institutional').length) {
        institutional.listen();
    }

    if (e('.page-findStore-body').length) {
        findStore.init();
    }

    if (e('.page-faq').length) {
        institutional.listen();
    }

    if (e('.page-search').length) {
        wishlist.listen();
    }

    if (e('.page-wishlist').length) {
        wishlist.listen();
    }

    if (e('.page-product').length) {
        product.listen();
        productVariation.init();
        funFact.listen();

    } else {
        productVariation.reset();
    }

    if (e('[class*="page-checkout"]').length) {
        e('body').addClass('is-checkout');
    }

    if (e('div[data-pagename="page-setNewPassword"]').length) {
        account.listenResetPassword();
    }

    if (e('div[data-pagename="page-wishlist"]').length) {
        wishlist.listen();
    }

    order.listen();
    menu.listen();
    account.listen();
    drawer.listen();
    datePicker.listen();
});

app.rainbowIsReady().then(() => {
    frame.dealWithViewports().listen();
});

// -----------------------------------------------
// Ajax page events || working like routes
// -----------------------------------------------
e(document).on("app:frame:changed", (ev, data) => {
    console.log(data);

    document.title = data.pageTitle;

    ////// DESTROYING EVENTS

    discovery.destroy();
    shop.destroy();
    view.destroy();

    ////// DESTROYING EVENTS


    ////// GLOBAL LISTENINGS

    header.hideHeaderSearchText();
    account.listen();
    header.listen();
    productPayButton.init();

    ////// GLOBAL LISTENINGS

    if (data.pageName.indexOf('page-reviews') >= 0) {
        productReviews.listen();
    }

    if (data.pageName.indexOf('page-product') >= 0) {
        product.listen();
        productSizeGuide.listen();
        funFact.listen();

        if (e(data.fromTarget.currentTarget).attr('class') == 'product__variation-link') {
            productVariation.orderProductList();
            productVariation.listen();
            productVariation.variationLoaded();
            productVariation.buildProductRainbow();
            productVariation.productRainbowColors();
        } else {
            productVariation.init(true);
        }

    } else {
        productVariation.reset();
    }

    if (data.pageName.indexOf('page-paymentMethods') >= 0) {
        paymentMethods.listen();
    }

    if (data.pageName.indexOf('page-discovery') >= 0) {

        discovery.init();
        shopButton.resetDefaultSettings();
        header.showHeaderSearchText();

    }

    if (data.pageName.indexOf('page-order') >= 0) {
        order.listen();
        order.listenCreateAccount();
    }

    if (data.pageName.indexOf('page-viewAll') >= 0) {
        view.init().destroy().listen();

        discovery.goToShopButton();
    }

    if (data.pageName.indexOf('page-search') >= 0) {
        setTimeout(() => {
            filter.listen();
            orderBy.listen();
            shop.setPageName("page-search").init();
            wishlist.listen();
        }, 500);

    } else if (data.pageName.indexOf('page-wishlist') >= 0) {
        setTimeout(() => {
            filter.listen();
            orderBy.listen();
            shop.setPageName("page-wishlist").init();
            productPayButton.init();
            wishlist.listen();
        }, 500);

    } else if (data.pageName.indexOf('page-shop') >= 0) {
        discovery.changeToShopMode();
        setTimeout(() => {
            header.hideHeaderSearchText();
            filter.listen();
            orderBy.listen();
            shop.setPageName('page-shop').init();

        }, 500);

    } else {
        filter.hideFilter();
    }

    if (data.pageName.indexOf('page-passwordReset') >= 0) {
        account.passwordResetListen();
    }

    if (data.pageName.indexOf('page-profile') >= 0) {
        account.accountEditListen();
        size.listen();
    }

    if (data.pageName.indexOf('page-login') >= 0) {
        account.loginListen();
    }

    if (data.pageName.indexOf('page-createAccount') >= 0) {
        account.accountCreateListen();
        size.listen();
    }

    if (data.pageName.indexOf('page-addresses') >= 0 || data.pageName.indexOf('page-editAddress') >= 0) {
        address.listen();
    }

    if (data.pageName.indexOf('page-wishlist') >= 0) {
        wishlist.listen();
    }

    if (data.pageName.indexOf('page-checkout') >= 0) {

        e('body').addClass('is-checkout');

        checkout.destroy().listen();
        paymentOptions.destroy().init();

    } else {
        if(!data.isModal) e('body').removeClass('is-checkout');
    }

    if (data.pageName.indexOf('page-checkout-editDrawer') >= 0) {
        checkoutEditProduct.init();
    } else if (data.pageName.indexOf('page-contact') >= 0 || data.pageName.indexOf('page-becomeDealer') >= 0) {
        contact.listen();
        customSelect.destroy().listen();
    } else if (e('.page-faq').length) {
        institutional.destroy().listen();
        faq.listen();
    }
    if (e('.page-internationalOffices').length) {
        institutional.destroy().listen();
    }
    if (e('.page-becomeFranchisee').length) {
        becomeFranchisee.destroy().listen();
        customSelect.destroy().listen();
    }
    if (e('.page-becomeDealer').length) {
        becomeDealer.destroy().listen();
        customSelect.destroy().listen();
    }
    if (data.pageName.indexOf('page-findStore') >= 0) {
        findStore.init();
    }
    if (e('.page-institutional-body').length) {
        institutional.destroy().listen();
    }
    if (e('.page-contact-body').length) {
        institutional.destroy().listen();
        contact.listen();
        customSelect.destroy().listen();
    }
})

// -----------------------------------------------
// Page Transitions:
// -----------------------------------------------
app.load().then(() => {

    //all basic/default transition are inside anim
    //class
    animation.listen();

});

// -----------------------------------------------
// Emergency Area:
// -----------------------------------------------
// */
